package com.layarkita

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.launch
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.sqrt

/**
 * HUD melayang (bar gelap membulat) untuk mulai merekam dari app mana pun.
 * Tampil hanya saat rekaman IDLE. Begitu Record ditekan HUD dilepas total dari layar,
 * jadi tidak pernah ikut terekam; muncul lagi setelah rekaman selesai disimpan.
 */
class HudService : Service() {

    companion object {
        const val A_SHOW = "com.layarkita.HUD_SHOW"
        const val A_CLOSE = "com.layarkita.HUD_CLOSE"

        /** true dari Record ditekan sampai rekaman benar-benar jalan (atau dibatalkan): HUD disembunyikan. */
        val launching = MutableStateFlow(false)

        /** dinaikkan CaptureActivity setelah izin mic beres, supaya HUD membaca ulang pengaturan. */
        val refresh = MutableStateFlow(0)

        private const val CH = "hud"
        private const val NID = 2

        private const val BG = 0xF2181A20.toInt()
        private const val STROKE = 0x33FFFFFF
        private const val TXT = 0xFFE6E8EE.toInt()
        private const val GRAY = 0xFF8A8F9C.toInt()
        private const val ACCENT = 0xFF4D7CFF.toInt()
        private const val DOT_OFF = 0xFF3A3D48.toInt()

        /** Dipanggil setelah rekaman diizinkan: kalau 8 dtk kemudian masih IDLE (gagal mulai), HUD dimunculkan lagi. */
        fun releaseLaunchLater() {
            Handler(Looper.getMainLooper()).postDelayed({
                if (RecorderService.ui.value.phase == Phase.IDLE) launching.value = false
            }, 8000)
        }

        // TYPE_BLE_HEADSET = 26 (API 31)
        private val MIC_TYPES = setOf(
            AudioDeviceInfo.TYPE_BUILTIN_MIC, AudioDeviceInfo.TYPE_WIRED_HEADSET,
            AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET,
            AudioDeviceInfo.TYPE_BLUETOOTH_SCO, 26,
        )
    }

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var root: FrameLayout? = null
    private var attached = false
    private var wanted = false
    private var collapsed = false
    private var micOpen = false
    private var s = RecSettings()
    private var devs: List<AudioDeviceInfo> = emptyList()

    private lateinit var full: LinearLayout
    private lateinit var bubble: FrameLayout
    private lateinit var micPanel: LinearLayout
    private lateinit var micLabel: TextView
    private lateinit var devList: LinearLayout
    private lateinit var dots: List<View>
    private lateinit var icoSpk: Ico
    private lateinit var icoMic: Ico
    private lateinit var chipRes: TextView

    // pengukur level mic
    @Volatile private var gen = 0
    private var meterOn = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WindowManager::class.java)
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CH, "HUD perekam", NotificationManager.IMPORTANCE_MIN))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == A_CLOSE) { shutdown(); return START_NOT_STICKY }
        startFg()
        if (!Settings.canDrawOverlays(this)) { shutdown(); return START_NOT_STICKY }
        if (!wanted) {
            wanted = true
            s = RecPrefs.load(this)
            buildUi()
            scope.launch {
                combine(RecorderService.ui, launching) { u, l -> u.phase == Phase.IDLE && !l }
                    .collect { if (it) showHud() else hideHud() }
            }
            scope.launch {
                RecorderService.ui.collect { if (it.phase != Phase.IDLE && launching.value) launching.value = false }
            }
            scope.launch {
                refresh.drop(1).collect { s = RecPrefs.load(this@HudService); syncUi() }
            }
        } else {
            showHud()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        wanted = false
        hideHud()
        scope.cancel()
        super.onDestroy()
    }

    private fun startFg() {
        val n = notif()
        if (Build.VERSION.SDK_INT >= 34) {
            ServiceCompat.startForeground(this, NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NID, n)
        }
    }

    private fun notif(): Notification {
        val close = PendingIntent.getService(
            this, 10, Intent(this, HudService::class.java).setAction(A_CLOSE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("HUD Layar Kita aktif")
            .setContentText("Ketuk Tutup untuk menyembunyikan HUD")
            .setOngoing(true).setPriority(NotificationCompat.PRIORITY_MIN)
            .addAction(0, "Tutup", close)
            .build()
    }

    private fun shutdown() {
        wanted = false
        hideHud()
        scope.cancel()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ---------- tampil / sembunyi ----------

    private fun showHud() {
        val r = root ?: return
        if (!wanted) return
        if (attached) { syncUi(); return }
        clampPos()
        try { wm.addView(r, lp); attached = true } catch (e: Exception) { shutdown(); return }
        syncUi()
    }

    private fun hideHud() {
        stopMeter()
        val r = root
        if (r != null && attached) { try { wm.removeView(r) } catch (_: Exception) { /* sudah lepas */ } }
        attached = false
    }

    private fun clampPos() {
        val dm = resources.displayMetrics
        lp.x = lp.x.coerceIn(0, maxOf(0, dm.widthPixels - dp(72)))
        lp.y = lp.y.coerceIn(0, maxOf(0, dm.heightPixels - dp(72)))
    }

    // ---------- aksi ----------

    private fun onRecord() {
        stopMeter()
        try {
            // HUD masih terpasang saat startActivity: izin overlay mengizinkan buka Activity dari latar belakang
            startActivity(Intent(this, CaptureActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            launching.value = true
            main.postDelayed({
                if (launching.value && !CaptureActivity.alive && RecorderService.ui.value.phase == Phase.IDLE) launching.value = false
            }, 4000)
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal membuka izin rekam", Toast.LENGTH_SHORT).show()
            syncUi()
        }
    }

    private fun onToggleMic() {
        if (!s.mic && !hasMicPerm()) {
            startActivity(
                Intent(this, CaptureActivity::class.java).putExtra(CaptureActivity.X_PERM_ONLY, true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
            return
        }
        s = s.copy(mic = !s.mic); RecPrefs.save(this, s)
        micOpen = false
        syncUi()
    }

    private fun onToggleInternal() {
        s = s.copy(internal = !s.internal); RecPrefs.save(this, s)
        syncUi()
    }

    private fun onCycleRes() {
        val order = listOf(720, 1080, 0)
        s = s.copy(res = order[(order.indexOf(s.res) + 1) % order.size]); RecPrefs.save(this, s)
        syncUi()
    }

    private fun openApp(cmd: String) {
        startActivity(
            Intent(this, MainActivity::class.java).putExtra("cmd", cmd)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        )
    }

    // ---------- UI ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun rounded(fill: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(r).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun View.tap(f: () -> Unit) { setOnClickListener { f() } }

    private fun ico(kind: IK, w: Int = 32, tint: Int = TXT): Ico {
        val c: Context = this
        return Ico(c, kind).apply { this.tint = tint; layoutParams = LinearLayout.LayoutParams(dp(w), dp(36)) }
    }

    private fun divider(): View {
        val c: Context = this
        return View(c).apply {
            setBackgroundColor(0x33FFFFFF)
            layoutParams = LinearLayout.LayoutParams(dp(1), dp(22)).apply { setMargins(dp(4), 0, dp(4), 0) }
        }
    }

    private fun buildUi() {
        val c: Context = this
        val r = FrameLayout(c)

        // ---- bar utama ----
        val handle = ico(IK.DOTS, 20, GRAY)
        drag(handle)
        chipRes = TextView(c).apply {
            setTextColor(TXT); textSize = 12f; gravity = Gravity.CENTER
            setPadding(dp(8), 0, dp(8), 0)
            background = rounded(0x22FFFFFF, 12)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(28)).apply { setMargins(dp(2), 0, dp(2), 0) }
            tap { onCycleRes() }
        }
        icoSpk = ico(IK.SPEAKER).also { it.tap { onToggleInternal() } }
        icoMic = ico(IK.MIC).also { it.tap { onToggleMic() } }
        val recBtn = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, dp(8), 0)
            addView(Ico(c, IK.REC).apply { tint = TXT; layoutParams = LinearLayout.LayoutParams(dp(24), dp(24)) })
            addView(TextView(c).apply { text = "Rekam"; setTextColor(TXT); textSize = 13f; setPadding(dp(4), 0, 0, 0) })
            tap { onRecord() }
        }
        val icoFile = ico(IK.FILE).also { it.tap { openApp("edit_last") } }
        val icoFolder = ico(IK.FOLDER).also { it.tap { openApp("home") } }
        val icoMin = ico(IK.MIN).also { it.tap { collapsed = true; micOpen = false; syncUi() } }
        val icoClose = ico(IK.CLOSE).also { it.tap { shutdown() } }
        val bar = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = rounded(BG, 22, STROKE)
            setPadding(dp(8), dp(4), dp(8), dp(4)); elevation = dp(6).toFloat()
            addView(handle); addView(chipRes); addView(divider()); addView(icoSpk); addView(icoMic); addView(divider())
            addView(recBtn); addView(icoFile); addView(icoFolder); addView(icoMin); addView(icoClose)
        }

        // ---- panel mic (dropdown + level) ----
        micLabel = TextView(c).apply {
            setTextColor(TXT); textSize = 13f; maxLines = 1; ellipsize = TextUtils.TruncateAt.END; maxWidth = dp(190)
        }
        val pill = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = rounded(0x22FFFFFF, 16, STROKE)
            setPadding(dp(12), dp(7), dp(8), dp(7))
            addView(micLabel)
            addView(Ico(c, IK.CHEV).apply { tint = TXT; layoutParams = LinearLayout.LayoutParams(dp(20), dp(20)) })
            tap { micOpen = !micOpen; syncUi() }
        }
        val dotsRow = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), 0, dp(6), 0) }
        dots = List(5) {
            View(c).apply {
                layoutParams = LinearLayout.LayoutParams(dp(14), dp(5)).apply { setMargins(dp(2), 0, dp(2), 0) }
                background = rounded(DOT_OFF, 3)
            }
        }
        dots.forEach { dotsRow.addView(it) }
        val top = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; addView(pill); addView(dotsRow) }
        devList = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        micPanel = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            background = rounded(BG, 22, STROKE); elevation = dp(6).toFloat()
            setPadding(dp(8), dp(8), dp(8), dp(8))
            addView(top); addView(devList)
        }

        full = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            addView(micPanel, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) })
            addView(bar)
        }

        // ---- bubble (diminimalkan) ----
        bubble = FrameLayout(c).apply {
            visibility = View.GONE
            background = rounded(BG, 24, STROKE); elevation = dp(6).toFloat()
            addView(Ico(c, IK.REC).apply { tint = TXT }, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER))
        }
        drag(bubble) { collapsed = false; syncUi() }

        r.addView(full, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT))
        r.addView(bubble, FrameLayout.LayoutParams(dp(48), dp(48)))
        root = r

        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            val (px, py) = RecPrefs.hudPos(this@HudService)
            x = if (px >= 0) px else dp(12)
            y = if (py >= 0) py else resources.displayMetrics.heightPixels / 4
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun drag(v: View, onTap: (() -> Unit)? = null) {
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val mx = e.rawX - dx; val my = e.rawY - dy
                    if (!moved && (abs(mx) > slop || abs(my) > slop)) moved = true
                    if (moved) {
                        lp.x = (sx + mx).toInt(); lp.y = (sy + my).toInt(); clampPos()
                        val r = root
                        if (attached && r != null) wm.updateViewLayout(r, lp)
                    }
                }
                MotionEvent.ACTION_UP -> if (moved) RecPrefs.saveHudPos(this, lp.x, lp.y) else onTap?.invoke()
            }
            true
        }
    }

    /** Menyelaraskan tampilan dengan state (pengaturan, mic, minimize). */
    private fun syncUi() {
        icoSpk.tint = if (s.internal) ACCENT else GRAY; icoSpk.off = !s.internal
        icoMic.tint = if (s.mic) ACCENT else GRAY; icoMic.off = !s.mic
        chipRes.text = if (s.res <= 0) "Asli" else "${s.res}p"
        val dpW = resources.displayMetrics.widthPixels / resources.displayMetrics.density
        chipRes.visibility = if (dpW >= 390f) View.VISIBLE else View.GONE   // layar sempit: bar tidak muat

        devs = inputDevices()
        micLabel.text = devLabel(s.micDev)
        buildDevList()
        micPanel.visibility = if (s.mic && !collapsed) View.VISIBLE else View.GONE
        devList.visibility = if (micOpen && s.mic && !collapsed) View.VISIBLE else View.GONE
        full.visibility = if (collapsed) View.GONE else View.VISIBLE
        bubble.visibility = if (collapsed) View.VISIBLE else View.GONE

        if (attached && s.mic && !collapsed) startMeter() else stopMeter()
    }

    private fun buildDevList() {
        val c: Context = this
        devList.removeAllViews()
        val rows = listOf(-1 to devLabel(-1)) + devs.map { it.id to devLabel(it.id) }
        rows.forEach { (id, label) ->
            devList.addView(TextView(c).apply {
                text = label; textSize = 13f; maxLines = 1; ellipsize = TextUtils.TruncateAt.END
                setTextColor(if (id == s.micDev) ACCENT else TXT)
                setPadding(dp(12), dp(9), dp(12), dp(9))
                tap {
                    s = s.copy(micDev = id); RecPrefs.save(c, s)
                    micOpen = false; stopMeter(); syncUi()
                }
            })
        }
    }

    private fun inputDevices(): List<AudioDeviceInfo> =
        getSystemService(AudioManager::class.java).getDevices(AudioManager.GET_DEVICES_INPUTS).filter { it.type in MIC_TYPES }

    private fun devLabel(id: Int): String {
        val d = devs.firstOrNull { it.id == id }
        if (d == null) {
            val b = devs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_MIC }
            return if (b != null) "Default - ${b.productName}" else "Default"
        }
        val kind = when (d.type) {
            AudioDeviceInfo.TYPE_BUILTIN_MIC -> "Bawaan"
            AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Kabel"
            AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET -> "USB"
            else -> "Bluetooth"
        }
        return "${d.productName} ($kind)"
    }

    // ---------- level mic ----------

    private fun hasMicPerm() = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun setLevel(l: Double) {
        val lit = (l * dots.size + 0.5).toInt()
        dots.forEachIndexed { i, v -> (v.background as? GradientDrawable)?.setColor(if (i < lit) ACCENT else DOT_OFF) }
    }

    @SuppressLint("MissingPermission")
    private fun startMeter() {
        if (meterOn || !hasMicPerm()) return
        meterOn = true
        val my = ++gen
        val dev = devs.firstOrNull { it.id == s.micDev }
        thread(name = "hud-meter") {
            var ar: AudioRecord? = null
            try {
                val sr = 16000
                val buf = maxOf(AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT), 4096)
                ar = AudioRecord.Builder().setAudioSource(MediaRecorder.AudioSource.MIC)
                    .setAudioFormat(
                        AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build(),
                    )
                    .setBufferSizeInBytes(buf).build()
                if (ar.state != AudioRecord.STATE_INITIALIZED) return@thread
                if (dev != null) ar.setPreferredDevice(dev)
                ar.startRecording()
                val sh = ShortArray(1024)
                while (gen == my) {
                    val n = ar.read(sh, 0, sh.size)
                    if (n <= 0) break
                    var sum = 0.0
                    for (k in 0 until n) { val v = sh[k].toDouble(); sum += v * v }
                    val rms = sqrt(sum / n)
                    val db = if (rms < 1.0) -90.0 else 20 * log10(rms / 32768.0)
                    val lvl = ((db + 60) / 60).coerceIn(0.0, 1.0)
                    main.post { if (gen == my) setLevel(lvl) }
                }
            } catch (_: Exception) {
                // mic dipakai app lain / gagal dibuka: level diam saja
            } finally {
                try { ar?.stop() } catch (_: Exception) {}
                try { ar?.release() } catch (_: Exception) {}
                main.post { if (gen == my) meterOn = false }
            }
        }
    }

    private fun stopMeter() {
        gen++
        meterOn = false
        if (::dots.isInitialized) setLevel(0.0)
    }
}

// ---------- ikon (digambar manual, tanpa dependensi ikon tambahan) ----------

private enum class IK { DOTS, SPEAKER, MIC, REC, FILE, FOLDER, MIN, CLOSE, CHEV }

private class Ico(c: Context, private val kind: IK) : View(c) {
    var tint: Int = 0xFFE6E8EE.toInt()
        set(v) { field = v; invalidate() }
    var off: Boolean = false
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    override fun onDraw(cv: Canvas) {
        val sc = minOf(width, height) / 24f
        cv.save()
        cv.translate((width - 24 * sc) / 2f, (height - 24 * sc) / 2f)
        cv.scale(sc, sc)
        p.color = tint
        p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND; p.strokeWidth = 2f
        when (kind) {
            IK.DOTS -> {
                p.style = Paint.Style.FILL
                for (x in floatArrayOf(9f, 15f)) for (y in floatArrayOf(6f, 12f, 18f)) cv.drawCircle(x, y, 1.5f, p)
            }
            IK.SPEAKER -> {
                p.style = Paint.Style.FILL
                path.reset(); path.moveTo(4f, 9f); path.lineTo(8f, 9f); path.lineTo(13f, 5f)
                path.lineTo(13f, 19f); path.lineTo(8f, 15f); path.lineTo(4f, 15f); path.close()
                cv.drawPath(path, p)
                p.style = Paint.Style.STROKE
                cv.drawArc(RectF(9f, 8f, 18f, 16f), -50f, 100f, false, p)
                cv.drawArc(RectF(7f, 5f, 21f, 19f), -50f, 100f, false, p)
            }
            IK.MIC -> {
                p.style = Paint.Style.FILL
                cv.drawRoundRect(RectF(9f, 3f, 15f, 14f), 3f, 3f, p)
                p.style = Paint.Style.STROKE
                cv.drawArc(RectF(6f, 6f, 18f, 18f), 0f, 180f, false, p)
                cv.drawLine(12f, 18f, 12f, 21f, p)
                cv.drawLine(9f, 21f, 15f, 21f, p)
            }
            IK.REC -> {
                p.style = Paint.Style.STROKE
                cv.drawCircle(12f, 12f, 8.5f, p)
                p.style = Paint.Style.FILL; p.color = 0xFFFF4D55.toInt()
                cv.drawCircle(12f, 12f, 4.2f, p)
            }
            IK.FILE -> {
                p.style = Paint.Style.STROKE
                path.reset(); path.moveTo(7f, 3f); path.lineTo(14f, 3f); path.lineTo(19f, 8f)
                path.lineTo(19f, 21f); path.lineTo(7f, 21f); path.close()
                cv.drawPath(path, p)
                cv.drawLine(14f, 3f, 14f, 8f, p); cv.drawLine(14f, 8f, 19f, 8f, p)
                p.style = Paint.Style.FILL
                path.reset(); path.moveTo(10.5f, 12f); path.lineTo(10.5f, 17.5f); path.lineTo(15.5f, 14.75f); path.close()
                cv.drawPath(path, p)
            }
            IK.FOLDER -> {
                p.style = Paint.Style.FILL
                path.reset(); path.moveTo(3f, 6f); path.lineTo(9f, 6f); path.lineTo(11f, 8.5f)
                path.lineTo(20f, 8.5f); path.lineTo(20f, 19f); path.lineTo(3f, 19f); path.close()
                cv.drawPath(path, p)
            }
            IK.MIN -> { p.style = Paint.Style.STROKE; p.strokeWidth = 2.4f; cv.drawLine(6f, 12f, 18f, 12f, p) }
            IK.CLOSE -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = 2.4f
                cv.drawLine(6f, 6f, 18f, 18f, p); cv.drawLine(18f, 6f, 6f, 18f, p)
            }
            IK.CHEV -> {
                p.style = Paint.Style.STROKE
                path.reset(); path.moveTo(8f, 10f); path.lineTo(12f, 14f); path.lineTo(16f, 10f)
                cv.drawPath(path, p)
            }
        }
        if (off) {
            p.color = tint; p.style = Paint.Style.STROKE; p.strokeWidth = 2.2f
            cv.drawLine(5f, 19f, 19f, 5f, p)
        }
        cv.restore()
    }
}
