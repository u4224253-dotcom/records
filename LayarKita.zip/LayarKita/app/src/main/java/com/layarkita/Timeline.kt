package com.layarkita

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt

private val H_RULER = 20.dp
private val H_VIDEO = 52.dp
private val H_WAVE = 30.dp
private val H_TOUCH = 12.dp
private val H_ZOOM = 38.dp
private val GAP = 5.dp
private val HANDLE_W = 14.dp

private val STEPS_MS = longArrayOf(1000, 2000, 5000, 10_000, 15_000, 30_000, 60_000, 120_000, 300_000, 600_000)
private val LEVELS = floatArrayOf(1f, 2f, 4f, 8f)

private const val THUMBS = 16

private val PLAYHEAD = Color.White

/** Puncak amplitudo audio (0..1) per potongan waktu; [data] null = rekaman tanpa audio / tidak bisa dihitung. */
private class Peaks(val data: FloatArray?)

/** Mengurai audio video (AAC) lewat MediaCodec, hanya untuk menggambar gelombang di timeline. */
private object AudioPeaks {
    fun compute(ctx: Context, uri: Uri, durMs: Long): Peaks {
        // video sangat panjang: lewati supaya editor tidak terasa berat
        if (durMs > 20 * 60_000L) return Peaks(null)
        val buckets = (durMs / 60L).coerceIn(60L, 900L).toInt()
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, uri, null)
            var track = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { track = i; fmt = f; break }
            }
            if (track < 0 || fmt == null) return Peaks(null)
            ex.selectTrack(track)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: return Peaks(null)
            val totalUs = (durMs * 1000L).coerceAtLeast(1L)
            val c = MediaCodec.createDecoderByType(mime)
            codec = c
            c.configure(fmt, null, null, 0)
            c.start()
            val peaks = FloatArray(buckets)
            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false
            val deadline = System.nanoTime() + 25_000_000_000L
            while (!outDone && System.nanoTime() < deadline) {
                if (!inDone) {
                    val ii = c.dequeueInputBuffer(5000)
                    if (ii >= 0) {
                        val buf = c.getInputBuffer(ii)
                        val n = if (buf == null) -1 else ex.readSampleData(buf, 0)
                        if (n < 0) {
                            c.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            c.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = c.dequeueOutputBuffer(info, 5000)
                if (oi >= 0) {
                    if (info.size > 0) {
                        val ob = c.getOutputBuffer(oi)
                        if (ob != null) {
                            ob.position(info.offset)
                            ob.limit(info.offset + info.size)
                            val sb = ob.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                            var m = 0
                            while (sb.hasRemaining()) {
                                val v = abs(sb.get().toInt())
                                if (v > m) m = v
                            }
                            val b = (info.presentationTimeUs * buckets / totalUs).toInt().coerceIn(0, buckets - 1)
                            val a = m / 32768f
                            if (a > peaks[b]) peaks[b] = a
                        }
                    }
                    c.releaseOutputBuffer(oi, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true
                }
            }
            val mx = peaks.maxOrNull() ?: 0f
            if (mx <= 0f) return Peaks(null)
            val norm = maxOf(mx, 0.05f)
            for (i in peaks.indices) peaks[i] = (peaks[i] / norm).coerceIn(0f, 1f)
            return Peaks(peaks)
        } catch (_: Exception) {
            return Peaks(null)
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            try { ex.release() } catch (_: Exception) {}
        }
    }
}

/**
 * Timeline editor: ruler (ketuk/geser untuk memindah playhead), klip video berthumbnail dengan handle potong,
 * gelombang suara asli, penanda sentuhan, dan baris blok zoom (geser badan = pindah, geser tepi = ubah panjang).
 *
 * Semua gestur geser dipasang di kontainer baris (koordinat stabil), bukan di tiap blok,
 * karena blok ikut bergeser saat di-drag dan itu merusak pembacaan delta jari.
 */
@Composable
fun TimelineEditor(
    uri: Uri,
    durMs: Long,
    positionMs: Long,
    playing: Boolean,
    startMs: Float,
    endMs: Float,
    zooms: List<ZoomRegion>,
    touches: List<TouchEvent>,
    selectedId: Int?,
    enabled: Boolean,
    onSeek: (Long) -> Unit,
    onTrimStart: (Float) -> Unit,
    onTrimEnd: (Float) -> Unit,
    onSelect: (Int?) -> Unit,
    onZooms: (List<ZoomRegion>) -> Unit,
    leading: @Composable () -> Unit = {},
) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val density = LocalDensity.current
    var level by remember { mutableIntStateOf(0) }
    val scroll = rememberScrollState()
    val showTouch = touches.isNotEmpty()
    val rows = if (showTouch) 5 else 4
    val totalH = H_RULER + H_VIDEO + H_WAVE + H_ZOOM + (if (showTouch) H_TOUCH else 0.dp) + GAP * (rows - 1)

    val thumbs by produceState<List<Bitmap?>>(List(THUMBS) { null }, uri, durMs) {
        val out = arrayOfNulls<Bitmap>(THUMBS)
        withContext(Dispatchers.IO) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, uri)
                for (i in 0 until THUMBS) {
                    val t = ((i + 0.5) / THUMBS * durMs * 1000.0).toLong()
                    val b = r.getFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    if (b != null) {
                        val h = 160
                        val w = (b.width * h / b.height.toFloat()).toInt().coerceAtLeast(1)
                        val s = Bitmap.createScaledBitmap(b, w, h, true)
                        if (s !== b) b.recycle()
                        out[i] = s
                        value = out.toList()
                    }
                }
            } catch (_: Exception) {
            } finally {
                try { r.release() } catch (_: Exception) {}
            }
        }
    }
    val peaks by produceState<Peaks?>(null, uri, durMs) {
        value = withContext(Dispatchers.Default) { AudioPeaks.compute(ctx, uri, durMs) }
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.weight(1f)) { leading() }
            RoundBtn("−", level > 0) { level = (level - 1).coerceAtLeast(0) }
            Text("${LEVELS[level].toInt()}×", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
            RoundBtn("+", level < LEVELS.size - 1) { level = (level + 1).coerceAtMost(LEVELS.size - 1) }
        }

        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val viewW = maxWidth
            val contentW = viewW * LEVELS[level]
            val pxPerMs = with(density) { contentW.toPx() } / durMs.toFloat()
            val viewPx = with(density) { viewW.toPx() }

            // saat diputar dan timeline diperbesar: ikuti playhead
            LaunchedEffect(playing, positionMs / 150, level) {
                if (playing && level > 0) {
                    val x = (positionMs * pxPerMs).toInt()
                    if (x < scroll.value || x > scroll.value + viewPx.toInt() - 40) {
                        scroll.scrollTo((x - viewPx * 0.25f).toInt().coerceAtLeast(0))
                    }
                }
            }

            Row {
                Box(Modifier.width(viewW).horizontalScroll(scroll)) {
                    Box(Modifier.width(contentW).height(totalH)) {
                        Column(verticalArrangement = Arrangement.spacedBy(GAP)) {
                            RulerRow(durMs, pxPerMs, onSeek)
                            VideoRow(thumbs, durMs, pxPerMs, startMs, endMs, enabled, onSeek, onTrimStart, onTrimEnd)
                            WaveRow(peaks, pxPerMs, startMs, endMs)
                            if (showTouch) TouchRow(touches, pxPerMs)
                            ZoomRow(zooms, durMs, pxPerMs, selectedId, enabled, onSelect, onZooms)
                        }
                        Playhead(positionMs, pxPerMs, totalH)
                    }
                }
            }
        }
    }
}

@Composable
private fun RoundBtn(label: String, enabled: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier.size(32.dp).clip(CircleShape).background(cs.surfaceVariant).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, fontSize = 16.sp, color = if (enabled) cs.onBackground else cs.onSurfaceVariant.copy(alpha = 0.4f)) }
}

// ------------------------------------------------------------------------------------------------

@Composable
private fun RulerRow(durMs: Long, pxPerMs: Float, onSeek: (Long) -> Unit) {
    val density = LocalDensity.current
    val seek by rememberUpdatedState(onSeek)
    val minStepPx = with(density) { 56.dp.toPx() }
    val step = STEPS_MS.firstOrNull { it * pxPerMs >= minStepPx } ?: STEPS_MS.last()
    val line = MaterialTheme.colorScheme.outline
    val tickPx = with(density) { 6.dp.roundToPx() }
    val rulerPx = with(density) { H_RULER.roundToPx() }

    Box(
        Modifier.fillMaxWidth().height(H_RULER)
            .pointerInput(pxPerMs, durMs) {
                detectTapGestures { off -> seek((off.x / pxPerMs).toLong().coerceIn(0L, durMs)) }
            }
            .pointerInput(pxPerMs, durMs) {
                detectDragGestures(
                    onDragStart = { off -> seek((off.x / pxPerMs).toLong().coerceIn(0L, durMs)) },
                ) { change, _ ->
                    change.consume()
                    seek((change.position.x / pxPerMs).toLong().coerceIn(0L, durMs))
                }
            },
    ) {
        var t = 0L
        while (t <= durMs) {
            val x = (t * pxPerMs).roundToInt()
            Box(Modifier.offset { IntOffset(x, rulerPx - tickPx) }.width(1.dp).height(6.dp).background(line))
            Text(
                Library.fmtTime(t), fontSize = 10.sp, maxLines = 1,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.offset { IntOffset(x + 4, 0) },
            )
            t += step
        }
    }
}

@Composable
private fun VideoRow(
    thumbs: List<Bitmap?>,
    durMs: Long, pxPerMs: Float, startMs: Float, endMs: Float, enabled: Boolean,
    onSeek: (Long) -> Unit, onTrimStart: (Float) -> Unit, onTrimEnd: (Float) -> Unit,
) {
    val density = LocalDensity.current
    val cs = MaterialTheme.colorScheme
    val curStart by rememberUpdatedState(startMs)
    val curEnd by rememberUpdatedState(endMs)
    val ts by rememberUpdatedState(onTrimStart)
    val te by rememberUpdatedState(onTrimEnd)
    val seek by rememberUpdatedState(onSeek)
    val handlePx = with(density) { HANDLE_W.roundToPx() }
    val touchPx = with(density) { (HANDLE_W + 8.dp).toPx() }
    val shape = RoundedCornerShape(8.dp)
    val edge = Color.White
    val scrim = Color.Black.copy(alpha = 0.62f)

    Box(
        Modifier.fillMaxWidth().height(H_VIDEO)
            .clip(shape)
            .background(cs.surfaceContainerHighest)
            .pointerInput(pxPerMs, durMs, enabled) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val x = down.position.x
                    val sx = curStart * pxPerMs
                    val ex = curEnd * pxPerMs
                    val nearL = enabled && x >= sx - touchPx / 2 && x <= sx + touchPx
                    val nearR = enabled && x >= ex - touchPx && x <= ex + touchPx / 2
                    val left = when {
                        nearL && nearR -> abs(x - sx) <= abs(x - ex)
                        nearL -> true
                        nearR -> false
                        else -> null
                    }
                    if (left == null) {
                        // bukan handle: ketukan = pindahkan playhead; geseran dibiarkan untuk scroll timeline
                        val up = waitForUpOrCancellation()
                        if (up != null) seek((up.position.x / pxPerMs).toLong().coerceIn(0L, durMs))
                        return@awaitEachGesture
                    }
                    down.consume()
                    val baseS = curStart
                    val baseE = curEnd
                    drag(down.id) { ch ->
                        ch.consume()
                        val dMs = (ch.position.x - x) / pxPerMs
                        if (left) ts(baseS + dMs) else te(baseE + dMs)
                    }
                }
            },
    ) {
        // thumbnail: tiap potongan membentang rata di seluruh durasi
        Row(Modifier.fillMaxSize()) {
            thumbs.forEach { b ->
                Box(Modifier.weight(1f).fillMaxHeight()) {
                    if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                }
            }
        }
        // bagian yang dibuang digelapkan
        Box(
            Modifier.fillMaxHeight()
                .width(with(density) { (startMs * pxPerMs).coerceAtLeast(0f).toDp() })
                .background(scrim),
        )
        Box(
            Modifier.offset { IntOffset((endMs * pxPerMs).roundToInt(), 0) }
                .fillMaxHeight()
                .width(with(density) { ((durMs - endMs) * pxPerMs).coerceAtLeast(0f).toDp() })
                .background(scrim),
        )
        // bingkai rentang yang dipertahankan
        Box(
            Modifier.offset { IntOffset((startMs * pxPerMs).roundToInt(), 0) }
                .width(with(density) { ((endMs - startMs) * pxPerMs).coerceAtLeast(0f).toDp() })
                .fillMaxHeight()
                .border(2.dp, edge, shape),
        )
        // handle kiri / kanan: pegangan putih dengan garis grip gelap
        Box(
            Modifier.offset { IntOffset((startMs * pxPerMs).roundToInt(), 0) }
                .width(HANDLE_W).fillMaxHeight()
                .background(edge, RoundedCornerShape(topStart = 8.dp, bottomStart = 8.dp)),
            contentAlignment = Alignment.Center,
        ) { Box(Modifier.width(2.dp).height(18.dp).background(Color(0xFF0B0B0B), RoundedCornerShape(1.dp))) }
        Box(
            Modifier.offset { IntOffset((endMs * pxPerMs).roundToInt() - handlePx, 0) }
                .width(HANDLE_W).fillMaxHeight()
                .background(edge, RoundedCornerShape(topEnd = 8.dp, bottomEnd = 8.dp)),
            contentAlignment = Alignment.Center,
        ) { Box(Modifier.width(2.dp).height(18.dp).background(Color(0xFF0B0B0B), RoundedCornerShape(1.dp))) }
    }
}

/** Gelombang suara asli; bagian di dalam rentang potong berwarna aksen, di luarnya redup. */
@Composable
private fun WaveRow(peaks: Peaks?, pxPerMs: Float, startMs: Float, endMs: Float) {
    val cs = MaterialTheme.colorScheme
    val on = cs.primary
    val off = cs.onSurfaceVariant.copy(alpha = 0.35f)
    val data = peaks?.data
    Box(Modifier.fillMaxWidth().height(H_WAVE).clip(RoundedCornerShape(8.dp)).background(cs.surfaceVariant)) {
        Canvas(Modifier.fillMaxSize()) {
            val bw = 2.dp.toPx()
            val step = bw + 1.5.dp.toPx()
            val n = (size.width / step).toInt().coerceAtLeast(1)
            val mid = size.height / 2f
            val minH = 2.dp.toPx()
            for (i in 0 until n) {
                val x = i * step
                val tMs = x / pxPerMs
                val amp = if (data == null) 0.08f else {
                    val idx = (x / size.width * data.size).toInt().coerceIn(0, data.size - 1)
                    maxOf(data[idx], 0.06f)
                }
                val h = (size.height * 0.8f * amp).coerceAtLeast(minH)
                drawRoundRect(
                    color = if (tMs >= startMs && tMs <= endMs) on else off,
                    topLeft = Offset(x, mid - h / 2f),
                    size = Size(bw, h),
                    cornerRadius = CornerRadius(bw / 2f),
                )
            }
        }
        Text(
            when {
                peaks == null -> "Membaca suara..."
                data == null -> "Tanpa suara"
                else -> "Suara asli"
            },
            fontSize = 9.sp, maxLines = 1, color = cs.onSurfaceVariant,
            modifier = Modifier.align(Alignment.TopStart).padding(start = 8.dp, top = 2.dp),
        )
    }
}

@Composable
private fun TouchRow(touches: List<TouchEvent>, pxPerMs: Float) {
    val dot = MaterialTheme.colorScheme.tertiary
    val bg = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
    Box(Modifier.fillMaxWidth().height(H_TOUCH).background(bg, RoundedCornerShape(6.dp))) {
        Canvas(Modifier.fillMaxWidth().fillMaxHeight()) {
            val r = 2.5.dp.toPx()
            for (e in touches) {
                drawCircle(
                    color = if (e.kind == TouchLog.TEXT) dot.copy(alpha = 0.55f) else dot,
                    radius = r,
                    center = Offset(e.tMs * pxPerMs, size.height / 2f),
                )
            }
        }
    }
}

private enum class Grab { MOVE, LEFT, RIGHT }
private class Hit(val region: ZoomRegion, val grab: Grab)

private fun hitTest(list: List<ZoomRegion>, ms: Float, edgeMs: Float): Hit? {
    for (r in list) {
        if (ms < r.startMs || ms > r.endMs) continue
        val e = min(edgeMs, (r.endMs - r.startMs) / 3f)
        return when {
            ms <= r.startMs + e -> Hit(r, Grab.LEFT)
            ms >= r.endMs - e -> Hit(r, Grab.RIGHT)
            else -> Hit(r, Grab.MOVE)
        }
    }
    return null
}

@Composable
private fun ZoomRow(
    zooms: List<ZoomRegion>, durMs: Long, pxPerMs: Float, selectedId: Int?, enabled: Boolean,
    onSelect: (Int?) -> Unit, onZooms: (List<ZoomRegion>) -> Unit,
) {
    val density = LocalDensity.current
    val zl by rememberUpdatedState(zooms)
    val select by rememberUpdatedState(onSelect)
    val change by rememberUpdatedState(onZooms)
    val edgePx = with(density) { HANDLE_W.toPx() }

    Box(
        Modifier.fillMaxWidth().height(H_ZOOM)
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            .pointerInput(pxPerMs, durMs, enabled) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val hit = hitTest(zl, down.position.x / pxPerMs, edgePx / pxPerMs)
                    if (hit == null) {
                        val up = waitForUpOrCancellation()
                        if (up != null) select(null)
                        return@awaitEachGesture
                    }
                    select(hit.region.id)
                    if (!enabled) return@awaitEachGesture
                    down.consume()
                    val x0 = down.position.x
                    val base = hit.region
                    drag(down.id) { ch ->
                        ch.consume()
                        val dMs = ((ch.position.x - x0) / pxPerMs).toLong()
                        val cur = zl
                        change(
                            when (hit.grab) {
                                Grab.MOVE -> ZoomOps.move(cur, base.id, base.startMs + dMs, durMs)
                                Grab.LEFT -> ZoomOps.resizeStart(cur, base.id, base.startMs + dMs)
                                Grab.RIGHT -> ZoomOps.resizeEnd(cur, base.id, base.endMs + dMs, durMs)
                            },
                        )
                    }
                }
            },
    ) {
        zooms.forEach { r ->
            key(r.id) { ZoomBlock(r, pxPerMs, selected = r.id == selectedId) }
        }
        if (zooms.isEmpty()) {
            Text(
                "Belum ada zoom. Ketuk + untuk menambah.", fontSize = 10.sp, maxLines = 1,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.align(Alignment.CenterStart).padding(start = 10.dp),
            )
        }
    }
}

/** Tampilan saja; semua gestur ditangani [ZoomRow]. */
@Composable
private fun ZoomBlock(r: ZoomRegion, pxPerMs: Float, selected: Boolean) {
    val density = LocalDensity.current
    val primary = MaterialTheme.colorScheme.primary
    val shape = RoundedCornerShape(8.dp)
    Box(
        Modifier.offset { IntOffset((r.startMs * pxPerMs).roundToInt(), 0) }
            .width(with(density) { ((r.endMs - r.startMs) * pxPerMs).coerceAtLeast(0f).toDp() })
            .fillMaxHeight()
            .padding(vertical = 3.dp)
            .background(if (selected) primary else primary.copy(alpha = 0.55f), shape)
            .then(if (selected) Modifier.border(2.dp, Color.White, shape) else Modifier),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier.align(Alignment.CenterStart).width(5.dp).fillMaxHeight(0.5f)
                .padding(start = 2.dp).background(Color(0xFF0B0B0B).copy(alpha = 0.55f), RoundedCornerShape(2.dp)),
        )
        Box(
            Modifier.align(Alignment.CenterEnd).width(5.dp).fillMaxHeight(0.5f)
                .padding(end = 2.dp).background(Color(0xFF0B0B0B).copy(alpha = 0.55f), RoundedCornerShape(2.dp)),
        )
        Text(
            "%.1f×".format(r.scale) + if (r.auto) " A" else "",
            fontSize = 11.sp, maxLines = 1, color = MaterialTheme.colorScheme.onPrimary,
        )
    }
}

@Composable
private fun Playhead(positionMs: Long, pxPerMs: Float, totalH: Dp) {
    val density = LocalDensity.current
    val half = with(density) { 1.dp.roundToPx() }
    val knob = with(density) { 5.dp.roundToPx() }
    val x = (positionMs * pxPerMs).roundToInt()
    Box(Modifier.offset { IntOffset(x - half, 0) }.width(2.dp).height(totalH).background(PLAYHEAD))
    Box(Modifier.offset { IntOffset(x - knob, 0) }.size(10.dp).background(PLAYHEAD, CircleShape))
}
