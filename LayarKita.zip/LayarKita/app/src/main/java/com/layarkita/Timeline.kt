package com.layarkita

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt

private val H_RULER = 26.dp
private val H_VIDEO = 38.dp
private val H_TOUCH = 16.dp
private val H_ZOOM = 46.dp
private val GAP = 4.dp
private val LABEL_W = 46.dp
private val HANDLE_W = 16.dp

private val STEPS_MS = longArrayOf(1000, 2000, 5000, 10_000, 15_000, 30_000, 60_000, 120_000, 300_000, 600_000)
private val LEVELS = floatArrayOf(1f, 2f, 4f, 8f)

private val PLAYHEAD = Color(0xFFFF5252)

/**
 * Timeline editor: ruler (ketuk/geser untuk memindah playhead), baris video dengan handle potong,
 * penanda sentuhan, dan baris blok zoom (geser badan = pindah, geser tepi = ubah panjang).
 *
 * Semua gestur geser dipasang di kontainer baris (koordinat stabil), bukan di tiap blok,
 * karena blok ikut bergeser saat di-drag dan itu merusak pembacaan delta jari.
 */
@Composable
fun TimelineEditor(
    durMs: Long,
    positionMs: Long,
    playing: Boolean,
    startMs: Float,
    endMs: Float,
    zooms: List<ZoomRegion>,
    touches: List<TouchEvent>,
    selectedId: Int?,
    enabled: Boolean,
    onSeek: (Long) -> Unit,
    onTrimStart: (Float) -> Unit,
    onTrimEnd: (Float) -> Unit,
    onSelect: (Int?) -> Unit,
    onZooms: (List<ZoomRegion>) -> Unit,
) {
    val density = LocalDensity.current
    var level by remember { mutableIntStateOf(0) }
    val scroll = rememberScrollState()
    val totalH = H_RULER + H_VIDEO + H_TOUCH + H_ZOOM + GAP * 3

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Timeline", style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f))
            OutlinedButton(
                onClick = { level = (level - 1).coerceAtLeast(0) },
                enabled = level > 0,
                modifier = Modifier.size(width = 44.dp, height = 34.dp),
                contentPadding = PaddingValues(0.dp),
            ) { Text("−") }
            Text("${LEVELS[level].toInt()}×", style = MaterialTheme.typography.labelLarge)
            OutlinedButton(
                onClick = { level = (level + 1).coerceAtMost(LEVELS.size - 1) },
                enabled = level < LEVELS.size - 1,
                modifier = Modifier.size(width = 44.dp, height = 34.dp),
                contentPadding = PaddingValues(0.dp),
            ) { Text("+") }
        }

        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val viewW = maxWidth - LABEL_W
            val contentW = viewW * LEVELS[level]
            val pxPerMs = with(density) { contentW.toPx() } / durMs.toFloat()
            val viewPx = with(density) { viewW.toPx() }

            // saat diputar dan timeline diperbesar: ikuti playhead
            LaunchedEffect(playing, positionMs / 150, level) {
                if (playing && level > 0) {
                    val x = (positionMs * pxPerMs).toInt()
                    if (x < scroll.value || x > scroll.value + viewPx.toInt() - 40) {
                        scroll.scrollTo((x - viewPx * 0.25f).toInt().coerceAtLeast(0))
                    }
                }
            }

            Row {
                Column(Modifier.width(LABEL_W), verticalArrangement = Arrangement.spacedBy(GAP)) {
                    RowLabel("Waktu", H_RULER)
                    RowLabel("Video", H_VIDEO)
                    RowLabel("Sentuh", H_TOUCH)
                    RowLabel("Zoom", H_ZOOM)
                }
                Box(Modifier.weight(1f).horizontalScroll(scroll)) {
                    Box(Modifier.width(contentW).height(totalH)) {
                        Column(verticalArrangement = Arrangement.spacedBy(GAP)) {
                            RulerRow(durMs, pxPerMs, onSeek)
                            VideoRow(durMs, pxPerMs, startMs, endMs, enabled, onSeek, onTrimStart, onTrimEnd)
                            TouchRow(touches, pxPerMs)
                            ZoomRow(zooms, durMs, pxPerMs, selectedId, enabled, onSelect, onZooms)
                        }
                        Playhead(positionMs, pxPerMs, totalH)
                    }
                }
            }
        }
    }
}

@Composable
private fun RowLabel(text: String, h: androidx.compose.ui.unit.Dp) {
    Box(Modifier.height(h), contentAlignment = Alignment.CenterStart) {
        Text(text, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
    }
}

// ------------------------------------------------------------------------------------------------

@Composable
private fun RulerRow(durMs: Long, pxPerMs: Float, onSeek: (Long) -> Unit) {
    val density = LocalDensity.current
    val seek by rememberUpdatedState(onSeek)
    val minStepPx = with(density) { 56.dp.toPx() }
    val step = STEPS_MS.firstOrNull { it * pxPerMs >= minStepPx } ?: STEPS_MS.last()
    val line = MaterialTheme.colorScheme.outline

    Box(
        Modifier.fillMaxWidth().height(H_RULER)
            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(4.dp))
            .pointerInput(pxPerMs, durMs) {
                detectTapGestures { off -> seek((off.x / pxPerMs).toLong().coerceIn(0L, durMs)) }
            }
            .pointerInput(pxPerMs, durMs) {
                detectDragGestures(
                    onDragStart = { off -> seek((off.x / pxPerMs).toLong().coerceIn(0L, durMs)) },
                ) { change, _ ->
                    change.consume()
                    seek((change.position.x / pxPerMs).toLong().coerceIn(0L, durMs))
                }
            },
    ) {
        var t = 0L
        while (t <= durMs) {
            val x = (t * pxPerMs).roundToInt()
            val label = Library.fmtTime(t)
            Box(Modifier.offset { IntOffset(x, 0) }.width(1.dp).fillMaxHeight().background(line.copy(alpha = 0.6f)))
            Text(
                label, fontSize = 10.sp, maxLines = 1,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.offset { IntOffset(x + 4, 4) },
            )
            t += step
        }
    }
}

@Composable
private fun VideoRow(
    durMs: Long, pxPerMs: Float, startMs: Float, endMs: Float, enabled: Boolean,
    onSeek: (Long) -> Unit, onTrimStart: (Float) -> Unit, onTrimEnd: (Float) -> Unit,
) {
    val density = LocalDensity.current
    val curStart by rememberUpdatedState(startMs)
    val curEnd by rememberUpdatedState(endMs)
    val ts by rememberUpdatedState(onTrimStart)
    val te by rememberUpdatedState(onTrimEnd)
    val seek by rememberUpdatedState(onSeek)
    val primary = MaterialTheme.colorScheme.primary
    val handlePx = with(density) { HANDLE_W.roundToPx() }
    val touchPx = with(density) { (HANDLE_W + 6.dp).toPx() }

    Box(
        Modifier.fillMaxWidth().height(H_VIDEO)
            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(4.dp))
            .pointerInput(pxPerMs, durMs, enabled) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val x = down.position.x
                    val sx = curStart * pxPerMs
                    val ex = curEnd * pxPerMs
                    val nearL = enabled && x >= sx - touchPx / 2 && x <= sx + touchPx
                    val nearR = enabled && x >= ex - touchPx && x <= ex + touchPx / 2
                    val left = when {
                        nearL && nearR -> abs(x - sx) <= abs(x - ex)
                        nearL -> true
                        nearR -> false
                        else -> null
                    }
                    if (left == null) {
                        // bukan handle: ketukan = pindahkan playhead; geseran dibiarkan untuk scroll timeline
                        val up = waitForUpOrCancellation()
                        if (up != null) seek((up.position.x / pxPerMs).toLong().coerceIn(0L, durMs))
                        return@awaitEachGesture
                    }
                    down.consume()
                    val baseS = curStart
                    val baseE = curEnd
                    drag(down.id) { ch ->
                        ch.consume()
                        val dMs = (ch.position.x - x) / pxPerMs
                        if (left) ts(baseS + dMs) else te(baseE + dMs)
                    }
                }
            },
    ) {
        // rentang yang dipertahankan
        Box(
            Modifier.offset { IntOffset((startMs * pxPerMs).roundToInt(), 0) }
                .width(with(density) { ((endMs - startMs) * pxPerMs).coerceAtLeast(0f).toDp() })
                .fillMaxHeight()
                .background(primary.copy(alpha = 0.28f))
                .border(2.dp, primary, RoundedCornerShape(4.dp)),
        )
        // handle kiri / kanan
        Box(
            Modifier.offset { IntOffset((startMs * pxPerMs).roundToInt(), 0) }
                .width(HANDLE_W).fillMaxHeight()
                .background(primary, RoundedCornerShape(topStart = 4.dp, bottomStart = 4.dp)),
        )
        Box(
            Modifier.offset { IntOffset((endMs * pxPerMs).roundToInt() - handlePx, 0) }
                .width(HANDLE_W).fillMaxHeight()
                .background(primary, RoundedCornerShape(topEnd = 4.dp, bottomEnd = 4.dp)),
        )
    }
}

@Composable
private fun TouchRow(touches: List<TouchEvent>, pxPerMs: Float) {
    val dot = MaterialTheme.colorScheme.tertiary
    val bg = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
    Box(Modifier.fillMaxWidth().height(H_TOUCH).background(bg, RoundedCornerShape(4.dp))) {
        Canvas(Modifier.fillMaxWidth().fillMaxHeight()) {
            val r = 3.dp.toPx()
            for (e in touches) {
                drawCircle(
                    color = if (e.kind == TouchLog.TEXT) dot.copy(alpha = 0.55f) else dot,
                    radius = r,
                    center = Offset(e.tMs * pxPerMs, size.height / 2f),
                )
            }
        }
        if (touches.isEmpty()) {
            Text(
                "Tidak ada data sentuhan untuk rekaman ini", fontSize = 9.sp, maxLines = 1,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.align(Alignment.CenterStart).padding(start = 6.dp),
            )
        }
    }
}

private enum class Grab { MOVE, LEFT, RIGHT }
private class Hit(val region: ZoomRegion, val grab: Grab)

private fun hitTest(list: List<ZoomRegion>, ms: Float, edgeMs: Float): Hit? {
    for (r in list) {
        if (ms < r.startMs || ms > r.endMs) continue
        val e = min(edgeMs, (r.endMs - r.startMs) / 3f)
        return when {
            ms <= r.startMs + e -> Hit(r, Grab.LEFT)
            ms >= r.endMs - e -> Hit(r, Grab.RIGHT)
            else -> Hit(r, Grab.MOVE)
        }
    }
    return null
}

@Composable
private fun ZoomRow(
    zooms: List<ZoomRegion>, durMs: Long, pxPerMs: Float, selectedId: Int?, enabled: Boolean,
    onSelect: (Int?) -> Unit, onZooms: (List<ZoomRegion>) -> Unit,
) {
    val density = LocalDensity.current
    val zl by rememberUpdatedState(zooms)
    val select by rememberUpdatedState(onSelect)
    val change by rememberUpdatedState(onZooms)
    val edgePx = with(density) { HANDLE_W.toPx() }

    Box(
        Modifier.fillMaxWidth().height(H_ZOOM)
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
            .pointerInput(pxPerMs, durMs, enabled) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val hit = hitTest(zl, down.position.x / pxPerMs, edgePx / pxPerMs)
                    if (hit == null) {
                        val up = waitForUpOrCancellation()
                        if (up != null) select(null)
                        return@awaitEachGesture
                    }
                    select(hit.region.id)
                    if (!enabled) return@awaitEachGesture
                    down.consume()
                    val x0 = down.position.x
                    val base = hit.region
                    drag(down.id) { ch ->
                        ch.consume()
                        val dMs = ((ch.position.x - x0) / pxPerMs).toLong()
                        val cur = zl
                        change(
                            when (hit.grab) {
                                Grab.MOVE -> ZoomOps.move(cur, base.id, base.startMs + dMs, durMs)
                                Grab.LEFT -> ZoomOps.resizeStart(cur, base.id, base.startMs + dMs)
                                Grab.RIGHT -> ZoomOps.resizeEnd(cur, base.id, base.endMs + dMs, durMs)
                            },
                        )
                    }
                }
            },
    ) {
        zooms.forEach { r ->
            key(r.id) { ZoomBlock(r, pxPerMs, selected = r.id == selectedId) }
        }
    }
}

/** Tampilan saja; semua gestur ditangani [ZoomRow]. */
@Composable
private fun ZoomBlock(r: ZoomRegion, pxPerMs: Float, selected: Boolean) {
    val density = LocalDensity.current
    val primary = MaterialTheme.colorScheme.primary
    val shape = RoundedCornerShape(6.dp)
    Box(
        Modifier.offset { IntOffset((r.startMs * pxPerMs).roundToInt(), 0) }
            .width(with(density) { ((r.endMs - r.startMs) * pxPerMs).coerceAtLeast(0f).toDp() })
            .fillMaxHeight()
            .padding(vertical = 3.dp)
            .background(if (selected) primary else primary.copy(alpha = 0.55f), shape)
            .then(if (selected) Modifier.border(2.dp, Color.White, shape) else Modifier),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier.align(Alignment.CenterStart).width(5.dp).fillMaxHeight(0.5f)
                .padding(start = 2.dp).background(Color.White.copy(alpha = 0.7f), RoundedCornerShape(2.dp)),
        )
        Box(
            Modifier.align(Alignment.CenterEnd).width(5.dp).fillMaxHeight(0.5f)
                .padding(end = 2.dp).background(Color.White.copy(alpha = 0.7f), RoundedCornerShape(2.dp)),
        )
        Text(
            "%.1f×".format(r.scale) + if (r.auto) " A" else "",
            fontSize = 11.sp, maxLines = 1, color = MaterialTheme.colorScheme.onPrimary,
        )
    }
}

@Composable
private fun Playhead(positionMs: Long, pxPerMs: Float, totalH: androidx.compose.ui.unit.Dp) {
    val density = LocalDensity.current
    val half = with(density) { 1.dp.roundToPx() }
    val knob = with(density) { 6.dp.roundToPx() }
    val x = (positionMs * pxPerMs).roundToInt()
    Box(Modifier.offset { IntOffset(x - half, 0) }.width(2.dp).height(totalH).background(PLAYHEAD))
    Box(Modifier.offset { IntOffset(x - knob, 0) }.size(12.dp).background(PLAYHEAD, CircleShape))
}
