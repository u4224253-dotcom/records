package com.layarkita

import android.content.ContentValues
import android.content.Context
import android.graphics.SurfaceTexture
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.Matrix
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Gaya "frame" di sekitar video. Warna ARGB. */
data class FrameStyle(
    val top: Int = 0xFF1E3A8A.toInt(),
    val bottom: Int = 0xFF7C3AED.toInt(),
    val padding: Float = 0.08f,   // 0..0.25 dari sisi terpendek kanvas
    val corner: Float = 0.03f,    // 0..0.10 dari sisi terpendek kanvas
    val shadow: Boolean = true,
    val aspect: Float? = null,    // lebar/tinggi kanvas; null = sama dengan video
)

data class VideoInfo(val width: Int, val height: Int, val durationMs: Long)

object Exporter {

    /** Ukuran video setelah rotasi (yang dilihat penonton) + durasi. */
    fun probe(ctx: Context, uri: Uri): VideoInfo? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: return null
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: return null
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
            val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            VideoInfo(w, h, d)
        } catch (e: Exception) {
            null
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    class Cancel { @Volatile var requested = false }

    /**
     * Ekspor [src] dari [startUs] sampai [endUs] dengan [style].
     * Dipanggil di thread background. Mengembalikan Uri hasil, atau null jika gagal/dibatalkan.
     */
    fun export(
        ctx: Context,
        src: Uri,
        startUs: Long,
        endUs: Long,
        style: FrameStyle,
        cancel: Cancel,
        onProgress: (Float) -> Unit,
        onError: (String) -> Unit,
    ): Uri? {
        val resolver = ctx.contentResolver
        val name = "LayarKita_edit_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        val cv = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/LayarKita")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val out = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)
        if (out == null) { onError("Gagal membuat file hasil"); return null }

        var ok = false
        try {
            val pfd = resolver.openFileDescriptor(out, "rw") ?: error("File hasil gagal dibuka")
            pfd.use { ok = doExport(ctx, src, pfd, startUs, endUs, style, cancel, onProgress) }
        } catch (e: Throwable) {
            onError("Ekspor gagal: ${e.message ?: e.javaClass.simpleName}")
            ok = false
        }

        return if (ok && !cancel.requested) {
            resolver.update(out, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
            out
        } else {
            try { resolver.delete(out, null, null) } catch (_: Exception) {}
            null
        }
    }

    // ---------------------------------------------------------------------------------------------

    private const val VERT = """
        attribute vec2 aPos;
        varying vec2 vUV;
        void main() {
            gl_Position = vec4(aPos, 0.0, 1.0);
            vUV = aPos * 0.5 + 0.5;
        }
    """

    // Semua digambar di satu shader: background gradient, bayangan, dan video dengan sudut membulat.
    private const val FRAG = """
        #extension GL_OES_EGL_image_external : require
        precision highp float;
        uniform samplerExternalOES uTex;
        uniform mat4 uTexMat;
        uniform vec2 uRes;      // ukuran kanvas (px)
        uniform vec4 uRect;     // pusat x, pusat y, setengah lebar, setengah tinggi (px, asal kiri-atas)
        uniform float uRadius;  // px
        uniform vec3 uTop;
        uniform vec3 uBottom;
        uniform float uShadow;  // 0 / 1
        varying vec2 vUV;

        float sdBox(vec2 p, vec2 b, float r) {
            vec2 q = abs(p) - b + r;
            return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;
        }

        void main() {
            vec2 p = vec2(vUV.x * uRes.x, (1.0 - vUV.y) * uRes.y);
            vec2 c = uRect.xy;
            vec2 hb = uRect.zw;

            vec3 col = mix(uTop, uBottom, p.y / uRes.y);

            float blur = 0.035 * min(uRes.x, uRes.y);
            float ds = sdBox(p - c - vec2(0.0, blur * 0.6), hb, uRadius);
            float sh = (1.0 - smoothstep(-blur, blur * 1.5, ds)) * 0.45 * uShadow;
            col = mix(col, vec3(0.0), sh);

            float d = sdBox(p - c, hb, uRadius);
            float a = 1.0 - smoothstep(-1.0, 1.0, d);
            if (a > 0.0) {
                vec2 local = clamp((p - c) / (2.0 * hb) + 0.5, 0.0, 1.0);
                vec2 uv = vec2(local.x, 1.0 - local.y);
                vec4 t = uTexMat * vec4(uv, 0.0, 1.0);
                vec3 v = texture2D(uTex, t.xy).rgb;
                col = mix(col, v, a);
            }
            gl_FragColor = vec4(col, 1.0);
        }
    """

    private fun even(v: Int) = max(2, v and 1.inv())

    private fun doExport(
        ctx: Context,
        src: Uri,
        pfd: ParcelFileDescriptor,
        startUs: Long,
        endUs: Long,
        style: FrameStyle,
        cancel: Cancel,
        onProgress: (Float) -> Unit,
    ): Boolean {
        val vex = MediaExtractor()
        val aex = MediaExtractor()
        var dec: MediaCodec? = null
        var enc: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var muxerStarted = false
        var gl: Gl? = null
        var st: SurfaceTexture? = null
        var decSurface: Surface? = null
        var encSurface: Surface? = null

        try {
            vex.setDataSource(ctx, src, null)
            aex.setDataSource(ctx, src, null)

            var vIdx = -1
            var aIdx = -1
            for (i in 0 until vex.trackCount) {
                val m = vex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
                if (vIdx < 0 && m.startsWith("video/")) vIdx = i
                if (aIdx < 0 && m.startsWith("audio/")) aIdx = i
            }
            if (vIdx < 0) error("Video tidak ditemukan")
            val vFmt = vex.getTrackFormat(vIdx)
            val srcW = vFmt.getInteger(MediaFormat.KEY_WIDTH)
            val srcH = vFmt.getInteger(MediaFormat.KEY_HEIGHT)
            val rot = if (vFmt.containsKey(MediaFormat.KEY_ROTATION)) vFmt.getInteger(MediaFormat.KEY_ROTATION) else 0
            val dw = if (rot == 90 || rot == 270) srcH else srcW
            val dh = if (rot == 90 || rot == 270) srcW else srcH
            val fps = try {
                if (vFmt.containsKey(MediaFormat.KEY_FRAME_RATE)) vFmt.getInteger(MediaFormat.KEY_FRAME_RATE).coerceIn(15, 60) else 30
            } catch (_: Exception) { 30 }

            // --- ukuran kanvas ---
            val canvasW: Int
            val canvasH: Int
            val asp = style.aspect
            if (asp == null) {
                canvasW = even(dw); canvasH = even(dh)
            } else {
                val longSide = min(max(dw, dh), 1920).toFloat()
                if (asp >= 1f) { canvasW = even(longSide.roundToInt()); canvasH = even((longSide / asp).roundToInt()) }
                else { canvasH = even(longSide.roundToInt()); canvasW = even((longSide * asp).roundToInt()) }
            }
            val shortSide = min(canvasW, canvasH).toFloat()
            val pad = style.padding.coerceIn(0f, 0.25f) * shortSide
            val availW = canvasW - 2 * pad
            val availH = canvasH - 2 * pad
            val scale = min(availW / dw, availH / dh)
            val rw = dw * scale
            val rh = dh * scale
            val radius = min(style.corner.coerceIn(0f, 0.10f) * shortSide, min(rw, rh) / 2f)

            // --- encoder ---
            val bitrate = (canvasW.toLong() * canvasH * fps * 0.15).toLong().coerceIn(2_000_000L, 24_000_000L).toInt()
            val ef = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, canvasW, canvasH).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
                setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }
            val e = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            enc = e
            e.configure(ef, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            encSurface = e.createInputSurface()
            e.start()

            // --- EGL + shader ---
            val g = Gl(encSurface!!, canvasW, canvasH)
            gl = g
            g.makeCurrent()
            g.setup(VERT, FRAG)
            val tex = g.createExternalTexture()
            val frames = Semaphore(0)
            val s = SurfaceTexture(tex)
            st = s
            s.setOnFrameAvailableListener({ frames.release() }, Handler(Looper.getMainLooper()))
            val ds = Surface(s)
            decSurface = ds

            // --- decoder ---
            val mime = vFmt.getString(MediaFormat.KEY_MIME)!!
            val d = MediaCodec.createDecoderByType(mime)
            dec = d
            d.configure(vFmt, ds, null, 0)
            d.start()

            // --- muxer ---
            val mx = MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = mx
            var audioTrack = -1
            if (aIdx >= 0) {
                try {
                    audioTrack = mx.addTrack(vex.getTrackFormat(aIdx))
                    aex.selectTrack(aIdx)
                    aex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
                } catch (_: Exception) {
                    audioTrack = -1   // format audio tidak didukung muxer: lanjut tanpa suara
                }
            }
            var videoTrack = -1

            // --- audio pump: salin sampel AAC apa adanya (tanpa decode) ---
            val aBuf = ByteBuffer.allocate(256 * 1024)
            val aInfo = MediaCodec.BufferInfo()
            var audioDone = audioTrack < 0
            fun pumpAudio(untilUs: Long) {
                while (!audioDone && muxerStarted) {
                    val t = aex.sampleTime
                    if (t < 0 || t > endUs) { audioDone = true; break }
                    if (t < startUs) { aex.advance(); continue }
                    if (t - startUs > untilUs) break
                    aBuf.clear()
                    val n = aex.readSampleData(aBuf, 0)
                    if (n < 0) { audioDone = true; break }
                    aInfo.set(0, n, t - startUs,
                        if (aex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                    mx.writeSampleData(audioTrack, aBuf, aInfo)
                    aex.advance()
                }
            }

            // --- kuras output encoder ---
            val eInfo = MediaCodec.BufferInfo()
            var lastVideoUs = 0L
            fun drainEncoder(untilEos: Boolean) {
                var idle = 0
                while (true) {
                    val i = e.dequeueOutputBuffer(eInfo, if (untilEos) 10_000L else 0L)
                    when {
                        i == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                            if (!untilEos) return
                            if (++idle > 500) error("Encoder tidak merespons")
                        }
                        i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            videoTrack = mx.addTrack(e.outputFormat)
                            mx.start()
                            muxerStarted = true
                        }
                        i >= 0 -> {
                            idle = 0
                            val buf = e.getOutputBuffer(i)!!
                            if (eInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) eInfo.size = 0
                            if (eInfo.size > 0 && muxerStarted) {
                                buf.position(eInfo.offset)
                                buf.limit(eInfo.offset + eInfo.size)
                                mx.writeSampleData(videoTrack, buf, eInfo)
                                lastVideoUs = eInfo.presentationTimeUs
                                pumpAudio(lastVideoUs)
                            }
                            val eos = eInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                            e.releaseOutputBuffer(i, false)
                            if (eos) return
                        }
                    }
                }
            }

            // --- loop utama: decode -> gambar -> encode ---
            vex.selectTrack(vIdx)
            vex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)

            val texMat = FloatArray(16)
            val stMat = FloatArray(16)
            val rotMat = FloatArray(16)
            val dInfo = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            val total = max(1L, endUs - startUs).toFloat()
            var rendered = 0

            while (!outputDone) {
                if (cancel.requested) return false

                if (!inputDone) {
                    val ii = d.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        val ib = d.getInputBuffer(ii)!!
                        val n = vex.readSampleData(ib, 0)
                        val t = vex.sampleTime
                        if (n < 0 || t < 0 || t > endUs) {
                            d.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            d.queueInputBuffer(ii, 0, n, t, 0)
                            vex.advance()
                        }
                    }
                }

                val oi = d.dequeueOutputBuffer(dInfo, 10_000)
                if (oi >= 0) {
                    val eos = dInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                    val pts = dInfo.presentationTimeUs
                    val inRange = dInfo.size > 0 && pts >= startUs && pts <= endUs
                    d.releaseOutputBuffer(oi, inRange)   // true = kirim ke SurfaceTexture

                    if (inRange) {
                        // tunggu frame tiba di SurfaceTexture
                        if (!frames.tryAcquire(3, TimeUnit.SECONDS)) error("Frame decoder tidak tiba")
                        s.updateTexImage()
                        s.getTransformMatrix(stMat)

                        // koreksi rotasi metadata (rekaman LayarKita rotasinya 0)
                        Matrix.setIdentityM(rotMat, 0)
                        if (rot != 0) {
                            Matrix.translateM(rotMat, 0, 0.5f, 0.5f, 0f)
                            Matrix.rotateM(rotMat, 0, -rot.toFloat(), 0f, 0f, 1f)
                            Matrix.translateM(rotMat, 0, -0.5f, -0.5f, 0f)
                        }
                        Matrix.multiplyMM(texMat, 0, stMat, 0, rotMat, 0)

                        g.draw(
                            tex = tex, texMat = texMat,
                            resW = canvasW.toFloat(), resH = canvasH.toFloat(),
                            cx = canvasW / 2f, cy = canvasH / 2f, hw = rw / 2f, hh = rh / 2f,
                            radius = radius, top = style.top, bottom = style.bottom, shadow = style.shadow,
                        )
                        g.setPresentationTime((pts - startUs) * 1000L)
                        g.swap()
                        rendered++
                        onProgress(((pts - startUs) / total).coerceIn(0f, 1f))
                        drainEncoder(false)
                    }
                    if (eos) {
                        e.signalEndOfInputStream()
                        outputDone = true
                    }
                }
            }

            if (rendered == 0) error("Tidak ada frame pada rentang yang dipilih")
            drainEncoder(true)
            pumpAudio(Long.MAX_VALUE)
            onProgress(1f)
            return true
        } finally {
            try { dec?.stop() } catch (_: Exception) {}
            try { dec?.release() } catch (_: Exception) {}
            try { enc?.stop() } catch (_: Exception) {}
            try { enc?.release() } catch (_: Exception) {}
            try { if (muxerStarted) muxer?.stop() } catch (_: Exception) {}
            try { muxer?.release() } catch (_: Exception) {}
            try { st?.release() } catch (_: Exception) {}
            try { decSurface?.release() } catch (_: Exception) {}
            try { gl?.release() } catch (_: Exception) {}
            try { encSurface?.release() } catch (_: Exception) {}
            try { vex.release() } catch (_: Exception) {}
            try { aex.release() } catch (_: Exception) {}
        }
    }

    // ---------------------------------------------------------------------------------------------
    // Helper EGL/GLES minimal
    // ---------------------------------------------------------------------------------------------

    private class Gl(private val target: Surface, private val w: Int, private val h: Int) {
        private var dpy: EGLDisplay = EGL14.EGL_NO_DISPLAY
        private var ctx: EGLContext = EGL14.EGL_NO_CONTEXT
        private var surf: EGLSurface = EGL14.EGL_NO_SURFACE
        private var prog = 0
        private val quad = ByteBuffer.allocateDirect(8 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
            put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)); position(0)
        }

        private var uTex = 0; private var uTexMat = 0; private var uRes = 0; private var uRect = 0
        private var uRadius = 0; private var uTop = 0; private var uBottom = 0; private var uShadow = 0

        init {
            dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
            check(dpy != EGL14.EGL_NO_DISPLAY) { "EGL display tidak tersedia" }
            val ver = IntArray(2)
            check(EGL14.eglInitialize(dpy, ver, 0, ver, 1)) { "EGL init gagal" }
            val attribs = intArrayOf(
                EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
                EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                0x3142 /* EGL_RECORDABLE_ANDROID */, 1,
                EGL14.EGL_NONE,
            )
            val cfgs = arrayOfNulls<EGLConfig>(1)
            val num = IntArray(1)
            check(EGL14.eglChooseConfig(dpy, attribs, 0, cfgs, 0, 1, num, 0) && num[0] > 0) { "EGL config tidak ada" }
            ctx = EGL14.eglCreateContext(
                dpy, cfgs[0], EGL14.EGL_NO_CONTEXT,
                intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0,
            )
            check(ctx != EGL14.EGL_NO_CONTEXT) { "EGL context gagal" }
            surf = EGL14.eglCreateWindowSurface(dpy, cfgs[0], target, intArrayOf(EGL14.EGL_NONE), 0)
            check(surf != EGL14.EGL_NO_SURFACE) { "EGL surface gagal" }
        }

        fun makeCurrent() {
            check(EGL14.eglMakeCurrent(dpy, surf, surf, ctx)) { "eglMakeCurrent gagal" }
        }

        private fun compile(type: Int, src: String): Int {
            val s = GLES20.glCreateShader(type)
            GLES20.glShaderSource(s, src.trimIndent())
            GLES20.glCompileShader(s)
            val ok = IntArray(1)
            GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
            check(ok[0] != 0) { "Shader gagal: " + GLES20.glGetShaderInfoLog(s) }
            return s
        }

        fun setup(vert: String, frag: String) {
            val vs = compile(GLES20.GL_VERTEX_SHADER, vert)
            val fs = compile(GLES20.GL_FRAGMENT_SHADER, frag)
            prog = GLES20.glCreateProgram()
            GLES20.glAttachShader(prog, vs)
            GLES20.glAttachShader(prog, fs)
            GLES20.glLinkProgram(prog)
            val ok = IntArray(1)
            GLES20.glGetProgramiv(prog, GLES20.GL_LINK_STATUS, ok, 0)
            check(ok[0] != 0) { "Link shader gagal: " + GLES20.glGetProgramInfoLog(prog) }
            uTex = GLES20.glGetUniformLocation(prog, "uTex")
            uTexMat = GLES20.glGetUniformLocation(prog, "uTexMat")
            uRes = GLES20.glGetUniformLocation(prog, "uRes")
            uRect = GLES20.glGetUniformLocation(prog, "uRect")
            uRadius = GLES20.glGetUniformLocation(prog, "uRadius")
            uTop = GLES20.glGetUniformLocation(prog, "uTop")
            uBottom = GLES20.glGetUniformLocation(prog, "uBottom")
            uShadow = GLES20.glGetUniformLocation(prog, "uShadow")
        }

        fun createExternalTexture(): Int {
            val t = IntArray(1)
            GLES20.glGenTextures(1, t, 0)
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, t[0])
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
            return t[0]
        }

        private fun rgb(loc: Int, c: Int) =
            GLES20.glUniform3f(loc, ((c shr 16) and 0xFF) / 255f, ((c shr 8) and 0xFF) / 255f, (c and 0xFF) / 255f)

        fun draw(
            tex: Int, texMat: FloatArray, resW: Float, resH: Float,
            cx: Float, cy: Float, hw: Float, hh: Float,
            radius: Float, top: Int, bottom: Int, shadow: Boolean,
        ) {
            GLES20.glViewport(0, 0, w, h)
            GLES20.glUseProgram(prog)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex)
            GLES20.glUniform1i(uTex, 0)
            GLES20.glUniformMatrix4fv(uTexMat, 1, false, texMat, 0)
            GLES20.glUniform2f(uRes, resW, resH)
            GLES20.glUniform4f(uRect, cx, cy, hw, hh)
            GLES20.glUniform1f(uRadius, radius)
            rgb(uTop, top)
            rgb(uBottom, bottom)
            GLES20.glUniform1f(uShadow, if (shadow) 1f else 0f)
            val aPos = GLES20.glGetAttribLocation(prog, "aPos")
            GLES20.glEnableVertexAttribArray(aPos)
            GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 8, quad)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            GLES20.glDisableVertexAttribArray(aPos)
        }

        fun setPresentationTime(ns: Long) { EGLExt.eglPresentationTimeANDROID(dpy, surf, ns) }
        fun swap() { EGL14.eglSwapBuffers(dpy, surf) }

        fun release() {
            if (dpy != EGL14.EGL_NO_DISPLAY) {
                EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                if (surf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(dpy, surf)
                if (ctx != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(dpy, ctx)
                EGL14.eglReleaseThread()
                EGL14.eglTerminate(dpy)
            }
            dpy = EGL14.EGL_NO_DISPLAY; ctx = EGL14.EGL_NO_CONTEXT; surf = EGL14.EGL_NO_SURFACE
        }
    }
}
