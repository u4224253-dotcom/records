package com.layarkita

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

/**
 * Activity transparan tanpa UI. Dibuka dari HUD karena izin rekam layar (dialog MediaProjection)
 * dan izin mikrofon hanya bisa diminta lewat Activity. Setelah izin beres, langsung menyalakan
 * RecorderService lalu menutup diri.
 */
class CaptureActivity : ComponentActivity() {

    companion object {
        const val X_PERM_ONLY = "perm_only"
        @Volatile var alive = false
    }

    private var s = RecSettings()
    private var useInternal = false
    private var useMic = false
    private var permOnly = false

    private val projLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == Activity.RESULT_OK && data != null) {
            ContextCompat.startForegroundService(
                this,
                Intent(this, RecorderService::class.java).setAction(RecorderService.A_START)
                    .putExtra(RecorderService.X_CODE, r.resultCode)
                    .putExtra(RecorderService.X_DATA, data)
                    .putExtra(RecorderService.X_RES, s.res)
                    .putExtra(RecorderService.X_FPS, s.fps)
                    .putExtra(RecorderService.X_ORIENT, s.orient)
                    .putExtra(RecorderService.X_INTERNAL, useInternal)
                    .putExtra(RecorderService.X_MIC, useMic)
                    .putExtra(RecorderService.X_MIC_DEV, s.micDev),
            )
            HudService.releaseLaunchLater()
        } else {
            HudService.launching.value = false
        }
        finish()
    }

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        val rec = granted(Manifest.permission.RECORD_AUDIO)
        if (permOnly) {
            if (rec) RecPrefs.save(this, RecPrefs.load(this).copy(mic = true))
            HudService.refresh.value++
            finish()
        } else {
            useInternal = s.internal && rec
            useMic = s.mic && rec
            askProjection()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        alive = true
        s = RecPrefs.load(this)
        permOnly = intent.getBooleanExtra(X_PERM_ONLY, false)
        if (permOnly) {
            permLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            return
        }
        val need = mutableListOf<String>()
        if ((s.internal || s.mic) && !granted(Manifest.permission.RECORD_AUDIO)) need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isEmpty()) {
            useInternal = s.internal; useMic = s.mic
            askProjection()
        } else {
            permLauncher.launch(need.toTypedArray())
        }
    }

    override fun onDestroy() {
        alive = false
        super.onDestroy()
    }

    private fun askProjection() {
        projLauncher.launch(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent())
    }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
}
