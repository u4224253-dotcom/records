package com.layarkita

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

data class RecConfig(
    val width: Int, val height: Int, val dpi: Int, val fps: Int, val videoBps: Int,
    val internalAudio: Boolean, val mic: Boolean,
    val micDeviceId: Int = -1,
)

/**
 * Pipeline: layar -> VirtualDisplay -> encoder H.264 (Surface)
 *           audio internal (+ mic) -> mix PCM -> encoder AAC
 *           keduanya -> MediaMuxer -> MediaStore (Movies/LayarKita)
 */
class Recorder(
    private val ctx: Context,
    private val projection: MediaProjection,
    private val cfg: RecConfig,
    private val onProjectionStopped: () -> Unit,
) {
    companion object { private const val SR = 44100 }

    var name = ""
        private set

    @Volatile private var running = false
    @Volatile private var paused = false
    @Volatile private var audioRebase = true
    @Volatile private var pauseTotalUs = 0L
    private var pauseStartUs = 0L
    private var baseUs = 0L

    private var venc: MediaCodec? = null
    private var aenc: MediaCodec? = null
    private var sys: AudioRecord? = null
    private var mic: AudioRecord? = null
    private var vdisplay: VirtualDisplay? = null
    private var muxer: MediaMuxer? = null
    private var pfd: ParcelFileDescriptor? = null
    private var uri: Uri? = null
    private var vThread: Thread? = null
    private var aThread: Thread? = null

    private val lock = Any()
    private val ready = CountDownLatch(1)
    private var need = 1
    private var added = 0
    @Volatile private var started = false

    private fun nowUs() = System.nanoTime() / 1000
    private fun relNow() = nowUs() - baseUs - pauseTotalUs
    private inline fun quiet(block: () -> Unit) { try { block() } catch (e: Exception) { /* abaikan */ } }

    fun start() {
        try {
            init()
        } catch (e: Exception) {
            running = false
            cleanup(deleteFile = true)
            throw e
        }
    }

    private fun init() {
        baseUs = nowUs()
        buildAudio()
        need = if (aenc != null) 2 else 1

        name = "LayarKita_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        val cv = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/LayarKita")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val u = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv) ?: error("MediaStore gagal")
        uri = u
        val p = ctx.contentResolver.openFileDescriptor(u, "rw") ?: error("File gagal dibuka")
        pfd = p
        muxer = MediaMuxer(p.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

        val vf = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, cfg.width, cfg.height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, cfg.videoBps)
            setInteger(MediaFormat.KEY_FRAME_RATE, cfg.fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
            // layar diam tetap menghasilkan frame (supaya rekaman tidak "beku" dan frame pertama selalu ada)
            setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 1_000_000L / cfg.fps)
        }
        val ve = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        venc = ve
        ve.configure(vf, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val surface = ve.createInputSurface()
        ve.start()

        // Android 14+: callback wajib didaftarkan sebelum createVirtualDisplay
        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { onProjectionStopped() }
        }, Handler(Looper.getMainLooper()))
        vdisplay = projection.createVirtualDisplay(
            "LayarKita", cfg.width, cfg.height, cfg.dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, surface, null, null,
        )

        running = true
        vThread = thread(name = "rec-video") { drainVideo(ve) }
        if (aenc != null) aThread = thread(name = "rec-audio") { audioLoop() }
    }

    /** Waktu pada jam video (ms, tanpa waktu jeda). -1 kalau belum jalan atau sedang jeda. Dipakai [TouchLog]. */
    fun clockMs(): Long = if (!running || paused) -1L else relNow() / 1000

    fun pause() {
        if (!running || paused) return
        pauseStartUs = nowUs()
        paused = true
    }

    fun resume() {
        if (!running || !paused) return
        pauseTotalUs += nowUs() - pauseStartUs
        audioRebase = true
        paused = false
        // frame yang dibuang saat jeda: minta keyframe baru supaya tidak ada artefak
        quiet { venc?.setParameters(Bundle().apply { putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0) }) }
    }

    /** true = file tersimpan utuh */
    fun stop(): Boolean {
        if (!running) return false
        running = false
        quiet { vdisplay?.release() }
        quiet { venc?.signalEndOfInputStream() }
        vThread?.join(5000)
        aThread?.join(5000)
        return cleanup(deleteFile = false)
    }

    // ---------------- video ----------------

    private fun drainVideo(enc: MediaCodec) {
        val bi = MediaCodec.BufferInfo()
        var track = -1
        var anchor = -1L
        var offset = 0L
        var last = -1L
        while (true) {
            val i = enc.dequeueOutputBuffer(bi, 10_000)
            if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) { track = addTrack(enc.outputFormat); continue }
            if (i < 0) continue
            val buf = enc.getOutputBuffer(i)
            val eos = (bi.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
            val config = (bi.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0
            if (buf != null && bi.size > 0 && !config && !paused && track >= 0) {
                if (anchor < 0) { anchor = bi.presentationTimeUs; offset = relNow() }
                var t = bi.presentationTimeUs - anchor + offset - pauseTotalUs
                if (t <= last) t = last + 1
                last = t
                bi.presentationTimeUs = t
                write(track, buf, bi)
            }
            enc.releaseOutputBuffer(i, false)
            if (eos) break
        }
    }

    // ---------------- audio ----------------

    @SuppressLint("MissingPermission")
    private fun buildAudio() {
        if (!cfg.internalAudio && !cfg.mic) return
        val fmt = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(SR)
            .setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build()
        val bufSize = maxOf(
            AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT) * 2, 16384,
        )
        if (cfg.internalAudio) {
            sys = try {
                val pc = AudioPlaybackCaptureConfiguration.Builder(projection)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN).build()
                AudioRecord.Builder().setAudioFormat(fmt).setBufferSizeInBytes(bufSize)
                    .setAudioPlaybackCaptureConfig(pc).build()
                    .takeIf { it.state == AudioRecord.STATE_INITIALIZED }
            } catch (e: Exception) { null }
        }
        if (cfg.mic) {
            mic = try {
                AudioRecord.Builder().setAudioSource(MediaRecorder.AudioSource.MIC)
                    .setAudioFormat(fmt).setBufferSizeInBytes(bufSize).build()
                    .takeIf { it.state == AudioRecord.STATE_INITIALIZED }
                    ?.also { ar ->
                        if (cfg.micDeviceId >= 0) {
                            ctx.getSystemService(android.media.AudioManager::class.java)
                                .getDevices(android.media.AudioManager.GET_DEVICES_INPUTS)
                                .firstOrNull { it.id == cfg.micDeviceId }
                                ?.let { ar.setPreferredDevice(it) }
                        }
                    }
            } catch (e: Exception) { null }
        }
        if (sys == null && mic == null) return   // audio gagal: lanjut video saja
        val af = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, SR, 2).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }
        val ae = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        ae.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        ae.start()
        aenc = ae
    }

    private fun audioLoop() {
        val enc = aenc ?: return
        val bi = MediaCodec.BufferInfo()
        val n = 2048                      // 1024 frame stereo per putaran
        val a = ShortArray(n); val b = ShortArray(n); val o = ShortArray(n)
        var track = -1
        var base = 0L
        var frames = 0L
        var last = -1L

        fun drain(): Boolean {            // true = EOS tercapai
            while (true) {
                val i = enc.dequeueOutputBuffer(bi, 0)
                if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) { track = addTrack(enc.outputFormat); continue }
                if (i < 0) return false
                val buf = enc.getOutputBuffer(i)
                val eos = (bi.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                val config = (bi.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0
                if (buf != null && bi.size > 0 && !config && track >= 0) {
                    if (bi.presentationTimeUs <= last) bi.presentationTimeUs = last + 1
                    last = bi.presentationTimeUs
                    write(track, buf, bi)
                }
                enc.releaseOutputBuffer(i, false)
                if (eos) return true
            }
        }

        sys?.startRecording(); mic?.startRecording()
        while (running) {
            val ra = sys?.read(a, 0, n) ?: 0
            val rb = mic?.read(b, 0, n) ?: 0
            val m = maxOf(ra, rb, 0) and 1.inv()          // genap (stereo)
            if (m <= 0) { Thread.sleep(5); continue }
            if (paused) continue                           // tetap dibaca (dikuras), tidak dienkode
            for (k in 0 until m) {
                val s = (if (k < ra) a[k].toInt() else 0) + (if (k < rb) b[k].toInt() else 0)
                o[k] = s.coerceIn(-32768, 32767).toShort()
            }
            if (audioRebase) {
                base = (relNow() - (m / 2) * 1_000_000L / SR).coerceAtLeast(0)
                frames = 0
                audioRebase = false
            }
            val idx = enc.dequeueInputBuffer(20_000)
            if (idx >= 0) {
                val ib = enc.getInputBuffer(idx)!!
                ib.clear()
                ib.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(o, 0, m)
                enc.queueInputBuffer(idx, 0, m * 2, base + frames * 1_000_000L / SR, 0)
                frames += m / 2
            }
            drain()
        }
        quiet { sys?.stop() }; quiet { mic?.stop() }

        // kirim EOS lalu kuras sisa output
        val deadline = System.currentTimeMillis() + 3000
        var idx = -1
        while (idx < 0 && System.currentTimeMillis() < deadline) idx = enc.dequeueInputBuffer(20_000)
        if (idx >= 0) enc.queueInputBuffer(idx, 0, 0, base + frames * 1_000_000L / SR, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
        while (System.currentTimeMillis() < deadline) { if (drain()) break; Thread.sleep(5) }
    }

    // ---------------- muxer ----------------

    private fun addTrack(f: MediaFormat): Int = synchronized(lock) {
        val i = muxer!!.addTrack(f)
        if (++added == need) { muxer!!.start(); started = true; ready.countDown() }
        i
    }

    private fun write(track: Int, buf: ByteBuffer, bi: MediaCodec.BufferInfo) {
        if (!started && !ready.await(10, TimeUnit.SECONDS)) return
        buf.position(bi.offset); buf.limit(bi.offset + bi.size)
        synchronized(lock) { if (started) quiet { muxer?.writeSampleData(track, buf, bi) } }
    }

    private fun cleanup(deleteFile: Boolean): Boolean {
        var ok = started && !deleteFile
        quiet { vdisplay?.release() }
        try { if (started) muxer?.stop() } catch (e: Exception) { ok = false }
        quiet { muxer?.release() }
        quiet { venc?.stop() }; quiet { venc?.release() }
        quiet { aenc?.stop() }; quiet { aenc?.release() }
        quiet { sys?.release() }; quiet { mic?.release() }
        quiet { pfd?.close() }
        uri?.let { u ->
            quiet {
                if (ok) ctx.contentResolver.update(u, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
                else ctx.contentResolver.delete(u, null, null)
            }
        }
        return ok
    }
}
