package com.layarkita

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Kamera 3D per blok zoom. Port LANGSUNG dari Openscreen (docs/3d-effects-v2.md, regions.rs, camera.rs), bukan tebakan.
 *
 * Satu konvensi untuk pratinjau dan ekspor, sama dengan `rotate_point` Openscreen:
 *  - sistem koordinat bidang: x ke kanan, y ke bawah, z ke arah kamera;
 *  - rotasi titik: Z (roll), lalu Y (yaw), lalu X (pitch): R = Rx(pitch) * Ry(yaw) * Rz(roll);
 *  - proyeksi perspektif: x' = P * x / (P - z), dengan P = [PERSPECTIVE_FACTOR] x sisi terpendek bidang;
 *  - bidang diskala dulu oleh [contain] (supaya hasil miring tetap muat di kotaknya), BARU diputar.
 */
object Cam {
    const val OFF = 0
    const val LEFT = 1     // layar menghadap kiri, dilihat dari atas
    const val RIGHT = 2    // layar menghadap kanan, dilihat dari atas
    const val ORBIT = 3    // kamera mengorbit; sudutnya dari titik fokus zoom

    /** PERSPECTIVE_FACTOR Openscreen: jarak kamera P = 1,6 x sisi terpendek kartu (~35° bidang pandang). Sebelumnya 2,6 x lebar: terlalu datar. */
    const val PERSPECTIVE_FACTOR = 1.6f

    /**
     * Satuan jarak kamera Android: `graphicsLayer.cameraDistance = d` memberi jarak NYATA 72 x d px
     * (RenderProperties::setCameraDistance -> Sk3DView::setCameraLocation: "passed in inches, set in pt", x72;
     * bawaannya 8 -> 576). Jadi untuk jarak P px, kirim P / 72.
     */
    const val ANDROID_CAMERA_UNIT = 72f

    // Preset sudut tetap Openscreen (regions::rotation3d_for), derajat [X tangage, Y lacet, Z roll]:
    //  left  = [-12, -18, -2], right = [-12, 18, 2]
    private const val FIXED_PITCH = -12f
    private const val FIXED_YAW = 18f
    private const val FIXED_ROLL = 2f

    // Orbit (camera.rs): azimut +-22° di tepi kiri/kanan, elevasi 4° saat diam + ayunan +-12° di tepi atas/bawah.
    const val ORBIT_AZIMUTH = 22f
    const val ORBIT_EL_REST = 4f
    const val ORBIT_EL_SWING = 12f

    /** Rotasi bidang dalam derajat, sama dengan `rot` Openscreen: [x] tangage, [y] lacet, [z] roll. */
    data class Rot(val x: Float, val y: Float, val z: Float) {
        operator fun times(k: Float) = Rot(x * k, y * k, z * k)
        val isFlat get() = abs(x) < 1e-4f && abs(y) < 1e-4f && abs(z) < 1e-4f
        companion object { val FLAT = Rot(0f, 0f, 0f) }
    }

    /**
     * Pose bidang untuk kamera [cam] dengan titik fokus ([fx],[fy]) (0..1 pada layar) pada bobot [w] (0..1, kekuatan zoom).
     * Orbit: mata di (azimut, elevasi) memandang pusat layar = bidang diputar [-elevasi, -azimut, 0] (camera.rs `quad()`).
     * Semua sudut berbanding lurus dengan bobot, jadi transisi masuk/keluar mulus tanpa lompatan.
     */
    fun pose(cam: Int, fx: Float, fy: Float, w: Float = 1f): Rot = when (cam) {
        LEFT -> Rot(FIXED_PITCH, -FIXED_YAW, -FIXED_ROLL) * w
        RIGHT -> Rot(FIXED_PITCH, FIXED_YAW, FIXED_ROLL) * w
        ORBIT -> {
            val ox = fx.coerceIn(0f, 1f)
            val oy = fy.coerceIn(0f, 1f)
            val az = ORBIT_AZIMUTH * (2f * ox - 1f)
            val el = ORBIT_EL_REST + ORBIT_EL_SWING * (1f - 2f * oy)   // pointer di atas -> kamera naik, memandang dari atas
            Rot(-el, -az, 0f) * w
        }
        else -> Rot.FLAT
    }

    fun perspectivePx(w: Float, h: Float) = PERSPECTIVE_FACTOR * min(w, h)

    /** Nilai `cameraDistance` Compose supaya jarak kamera nyata = [perspectivePx] px. */
    fun composeCameraDistance(w: Float, h: Float) = perspectivePx(w, h) / ANDROID_CAMERA_UNIT

    // ------------------------------------------------------------------ matematika proyeksi (port regions.rs)

    /** Kolom-kolom R = Rx(a) Ry(b) Rz(g) (derajat), kolom-mayor 3x3: [R·x̂, R·ŷ, R·ẑ]. Sama dengan `rotate_point`. */
    fun rotationColumns(rot: Rot): FloatArray {
        val a = Math.toRadians(rot.x.toDouble()); val b = Math.toRadians(rot.y.toDouble()); val g = Math.toRadians(rot.z.toDouble())
        val ca = cos(a); val sa = sin(a); val cb = cos(b); val sb = sin(b); val cg = cos(g); val sg = sin(g)
        return floatArrayOf(
            (cg * cb).toFloat(), (sg * ca + cg * sb * sa).toFloat(), (sg * sa - cg * sb * ca).toFloat(),
            (-sg * cb).toFloat(), (cg * ca - sg * sb * sa).toFloat(), (cg * sa + sg * sb * ca).toFloat(),
            sb.toFloat(), (-cb * sa).toFloat(), (cb * ca).toFloat(),
        )
    }

    /** Titik (x0,y0,0) diputar [rot] lalu diproyeksikan; null kalau jatuh di belakang kamera. Hasil: x, y. */
    private fun project(x0: Double, y0: Double, r: FloatArray, p: Double, out: DoubleArray): Boolean {
        val px = r[0] * x0 + r[3] * y0
        val py = r[1] * x0 + r[4] * y0
        val pz = r[2] * x0 + r[5] * y0
        val den = p - pz
        if (den <= 0.0) return false
        val f = p / den
        out[0] = px * f; out[1] = py * f
        return true
    }

    /**
     * Faktor containment (contain_scale): bidang [width]x[height] diskala [fit] (<= 1) lalu diputar [rot] sehingga hasil
     * proyeksinya TIDAK keluar dari kotak aslinya. Iterasi sampai 8x pada sudut yang benar-benar terproyeksi (divisi
     * perspektifnya tidak linear, jadi sekali hitung tidak cukup). Rata (1) kalau sudut jatuh di belakang kamera.
     */
    fun contain(width: Float, height: Float, rot: Rot): Float {
        if (rot.isFlat) return 1f
        val p = perspectivePx(width, height).toDouble()
        val r = rotationColumns(rot)
        val hw = width * 0.5; val hh = height * 0.5
        val xs = doubleArrayOf(-hw, hw, hw, -hw); val ys = doubleArrayOf(-hh, -hh, hh, hh)
        val o = DoubleArray(2)
        fun extents(s: Double): DoubleArray? {
            var mx = 0.0; var my = 0.0
            for (i in 0 until 4) {
                if (!project(xs[i] * s, ys[i] * s, r, p, o)) return null
                mx = max(mx, abs(o[0])); my = max(my, abs(o[1]))
            }
            return doubleArrayOf(mx, my)
        }
        var scale = 1.0
        var e = extents(scale) ?: return 1f
        for (i in 0 until 8) {
            if (e[0] <= 0.0 || e[1] <= 0.0) break
            val fit = min(hw / e[0], hh / e[1])
            if (fit >= 0.999) break
            scale *= fit
            e = extents(scale) ?: break
        }
        return scale.toFloat()
    }

    /** Margin containment envelope (FIT_MARGIN Openscreen): envelope hanya disampel 3x3. */
    private const val FIT_MARGIN = 0.995f

    /**
     * Skala containment untuk satu blok pada bobot [w]. Sudut tetap: skala pose-nya (konstan sepanjang blok, "skala beku").
     * Orbit: pose berubah mengikuti titik fokus, jadi skalanya diambil dari SELURUH envelope orbit (9 pose) supaya layar
     * tidak "bernapas" saat kamera berputar (envelope_fit). Satu nilai per blok.
     */
    fun fit(cam: Int, fx: Float, fy: Float, w: Float, cardW: Float, cardH: Float): Float = when (cam) {
        LEFT, RIGHT -> contain(cardW, cardH, pose(cam, fx, fy, w))
        ORBIT -> {
            var f = 1f
            for (ox in floatArrayOf(0f, 0.5f, 1f)) for (oy in floatArrayOf(0f, 0.5f, 1f)) {
                f = min(f, contain(cardW, cardH, pose(ORBIT, ox, oy, w)))
            }
            if (f < 1f) f * FIT_MARGIN else 1f
        }
        else -> 1f
    }
}

/**
 * Cadreur Orbit (camera::follow Openscreen): pointer yang dibaca dari jejak kursor dilicinkan dengan respons impuls pegas kritis
 * h(τ) = ω²·τ·e^(−ωτ), ω = 5 rad/s, atas 2 detik jejak (120 cuplikan), dengan antisipasi 0,25 detik: perekaman dipasang
 * setelah kejadian, jadi kamera berangkat sebelum gerakan. Fungsi MURNI dari t (tanpa memori antar-frame), biaya tetap 120
 * pembacaan berapa pun panjang bloknya. Tanpa zona mati: kamera hidup bersama pointer, pelicinan yang menenangkannya.
 */
object Follow {
    const val OMEGA = 5f
    const val LOOKAHEAD_S = 0.25f
    const val STEP_S = 1f / 60f
    const val TAPS = 120

    /** Pointer terlicinkan (0..1, 0..1) pada [tMs]; null kalau tidak ada jejak (kamera lalu memakai titik fokus blok). */
    fun smoothed(events: List<TouchEvent>, tMs: Double): Pair<Float, Float>? {
        if (events.isEmpty()) return null
        var ox = 0f; var oy = 0f; var total = 0f
        for (k in 1..TAPS) {
            val tau = k * STEP_S
            val weight = tau * kotlin.math.exp(-OMEGA * tau)
            val at = (tMs + LOOKAHEAD_S * 1000.0 - tau * 1000.0).coerceAtLeast(0.0)
            val (px, py) = CursorMath.pointerAt(events, at.toLong()) ?: return null
            ox += weight * px.coerceIn(0f, 1f); oy += weight * py.coerceIn(0f, 1f)
            total += weight
        }
        return (ox / total) to (oy / total)
    }
}
