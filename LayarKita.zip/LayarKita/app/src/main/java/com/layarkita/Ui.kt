package com.layarkita

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Pilihan segmen: satu baris pil, yang dipilih berwarna aksen. */
@Composable
internal fun <T> Seg(items: List<Pair<String, T>>, sel: T, enabled: Boolean, onPick: (T) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.clip(RoundedCornerShape(10.dp)).background(cs.surfaceVariant).padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        items.forEach { (label, v) ->
            val on = sel == v
            Box(
                Modifier.clip(RoundedCornerShape(8.dp))
                    .background(if (on) cs.primary else Color.Transparent)
                    .clickable(enabled = enabled) { onPick(v) }
                    .padding(horizontal = 11.dp, vertical = 7.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    label,
                    style = MaterialTheme.typography.labelLarge,
                    color = if (on) cs.onPrimary else cs.onSurfaceVariant.copy(alpha = if (enabled) 1f else 0.5f),
                )
            }
        }
    }
}

/** Tombol/chip datar berbentuk pil. */
@Composable
internal fun Pill(label: String, selected: Boolean = false, enabled: Boolean = true, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val bg = if (selected) cs.primary else cs.surfaceVariant
    val fg = if (selected) cs.onPrimary else cs.onSurface
    Box(
        Modifier.clip(RoundedCornerShape(50))
            .background(bg)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, style = MaterialTheme.typography.labelLarge, color = fg.copy(alpha = if (enabled) 1f else 0.4f))
    }
}

@Composable
internal fun PlayPauseIcon(playing: Boolean, color: Color, iconSize: Dp = 20.dp) {
    Canvas(Modifier.size(iconSize)) {
        val w = this.size.width
        val h = this.size.height
        if (playing) {
            val bar = Size(w * 0.28f, h * 0.76f)
            drawRect(color, Offset(w * 0.16f, h * 0.12f), bar)
            drawRect(color, Offset(w * 0.56f, h * 0.12f), bar)
        } else {
            val p = Path().apply {
                moveTo(w * 0.22f, h * 0.10f)
                lineTo(w * 0.90f, h * 0.50f)
                lineTo(w * 0.22f, h * 0.90f)
                close()
            }
            drawPath(p, color)
        }
    }
}
