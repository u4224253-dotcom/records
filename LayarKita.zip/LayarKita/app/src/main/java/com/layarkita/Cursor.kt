package com.layarkita

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/**
 * Keadaan kursor sintetis pada satu waktu. x,y dinormalisasi 0..1 pada frame video (asal kiri-atas), sama seperti [TouchEvent].
 * [rp] = progres riak ketukan 0..1 (negatif = tidak ada riak) di posisi ([rx],[ry]); [press] = 0..1 saat jari "menekan".
 */
data class CursorState(
    val x: Float, val y: Float, val alpha: Float, val press: Float,
    val rx: Float, val ry: Float, val rp: Float,
)

/**
 * Kursor buatan dari data ketukan (Android tidak memberi koordinat jari mentah ke app biasa, lihat README).
 * Kursor muncul sedikit sebelum ketukan, meluncur halus dari ketukan ke ketukan, memberi riak saat mengetuk,
 * dan menghilang kalau lama tidak ada ketukan. Fungsi murni dari waktu SUMBER: pratinjau dan ekspor memakai rumus yang sama.
 */
object CursorMath {
    const val MOVE_MS = 380L      // lama meluncur ke ketukan berikutnya
    const val LEAD_MS = 500L      // kursor muncul sebelum ketukan (kalau tadinya sembunyi)
    const val HOLD_MS = 1400L     // kursor bertahan setelah ketukan terakhir
    const val FADE_MS = 220L
    const val IDLE_MS = HOLD_MS + LEAD_MS + FADE_MS   // jeda lebih lama dari ini = kursor sembunyi di antaranya
    const val PRESS_MS = 160L
    const val RIPPLE_MS = 520L
    const val SIZE_FRAC = 0.055f  // tinggi kursor, fraksi sisi terpendek bingkai video

    private fun smooth(x: Float): Float { val t = x.coerceIn(0f, 1f); return t * t * (3f - 2f * t) }

    /** [events] harus terurut menurut tMs (TouchLog.decode/end sudah mengurutkan). Null = kursor tidak terlihat. */
    fun at(events: List<TouchEvent>, tMs: Long): CursorState? {
        val n = events.size
        if (n == 0) return null
        var lo = 0; var hi = n
        while (lo < hi) { val m = (lo + hi) ushr 1; if (events[m].tMs > tMs) hi = m else lo = m + 1 }
        val prev = events.getOrNull(lo - 1)
        val next = events.getOrNull(lo)

        val x: Float; val y: Float; val alpha: Float
        if (prev != null && next != null && next.tMs - prev.tMs <= IDLE_MS) {
            // ketukan berdekatan: meluncur terus, tidak pernah sembunyi
            val dur = min(MOVE_MS, next.tMs - prev.tMs)
            val k = if (dur <= 0L) 1f else smooth((tMs - (next.tMs - dur)).toFloat() / dur)
            x = prev.x + (next.x - prev.x) * k
            y = prev.y + (next.y - prev.y) * k
            alpha = 1f
        } else {
            val aPrev = if (prev != null) (1f - (tMs - prev.tMs - HOLD_MS).toFloat() / FADE_MS).coerceIn(0f, 1f) else 0f
            val aNext = if (next != null) ((tMs - (next.tMs - LEAD_MS)).toFloat() / FADE_MS).coerceIn(0f, 1f) else 0f
            alpha = max(aPrev, aNext)
            if (alpha <= 0f) return null
            val src = if (aNext > 0f) next!! else prev!!
            x = src.x; y = src.y
        }

        var press = 0f; var rp = -1f
        var rx = 0f; var ry = 0f
        if (prev != null && prev.kind == TouchLog.TAP) {
            val dt = tMs - prev.tMs
            if (dt < PRESS_MS) press = sin(PI.toFloat() * dt / PRESS_MS)
            if (dt < RIPPLE_MS) { rp = dt.toFloat() / RIPPLE_MS; rx = prev.x; ry = prev.y }
        }
        return CursorState(x, y, alpha, press, rx, ry, rp)
    }
}

/** Bentuk panah (satuan = tinggi kursor, ujung di (0,0), sumbu y ke bawah). HARUS sama dengan sdArrow di shader Exporter. */
private val ARROW = arrayOf(
    0f to 0f, 0f to 0.82f, 0.205f to 0.64f, 0.374f to 1f, 0.497f to 0.944f, 0.333f to 0.6f, 0.59f to 0.59f,
)

private val ACCENT = Color(0xFF4F8CFF)

/** Gambar kursor di pratinjau. Ukuran [size] = bingkai video; [zoom] dipakai untuk memetakan koordinat video ke bingkai. */
internal fun DrawScope.drawCursor(c: CursorState, zoom: ZoomState) {
    fun px(nx: Float) = ((nx - zoom.left) / zoom.size) * size.width
    fun py(ny: Float) = ((ny - zoom.top) / zoom.size) * size.height
    val s0 = CursorMath.SIZE_FRAC * min(size.width, size.height)

    if (c.rp >= 0f) {
        val pr = 1f - (1f - c.rp).pow(3)
        val r = s0 * (0.25f + 0.75f * pr)
        val a = 1f - c.rp
        val o = Offset(px(c.rx), py(c.ry))
        drawCircle(ACCENT.copy(alpha = 0.25f * a), r, o)
        drawCircle(ACCENT.copy(alpha = 0.85f * a), r, o, style = Stroke(width = 0.06f * s0 + 1f))
    }
    val s = s0 * (1f - 0.14f * c.press)
    val ox = px(c.x); val oy = py(c.y)
    val path = Path().apply {
        ARROW.forEachIndexed { i, (ax, ay) -> if (i == 0) moveTo(ox + ax * s, oy + ay * s) else lineTo(ox + ax * s, oy + ay * s) }
        close()
    }
    val bw = max(1f, 0.07f * s)
    drawPath(path, Color.Black.copy(alpha = c.alpha), style = Stroke(width = bw * 2f))
    drawPath(path, Color.White.copy(alpha = c.alpha))
}
