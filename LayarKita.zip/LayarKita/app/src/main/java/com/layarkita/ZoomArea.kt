package com.layarkita

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp

/**
 * Pemilih area zoom di atas pratinjau (padanan ZoomFocusOverlay Openscreen). Dipasang di dalam bingkai video yang
 * sedang ditampilkan TANPA zoom, jadi koordinat sentuhan = koordinat frame video (0..1).
 *
 *  - geser (1 jari)  : memindah jendela zoom
 *  - cubit (2 jari)  : ubah skala (jendela mengecil saat zoom makin dalam)
 *  - ketuk           : taruh pusat jendela di titik itu
 * Persegi panjang = persis bagian yang akan memenuhi layar saat zoom penuh; di luarnya digelapkan.
 */
@Composable
internal fun ZoomAreaOverlay(region: ZoomRegion, onChange: (fx: Float, fy: Float, scale: Float) -> Unit) {
    val cur by rememberUpdatedState(region)
    val change by rememberUpdatedState(onChange)
    Box(
        Modifier.fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures { p ->
                    val w = size.width.toFloat(); val h = size.height.toFloat()
                    if (w > 0f && h > 0f) {
                        val r = cur
                        val (fx, fy) = ZoomMath.clampCenter(p.x / w, p.y / h, r.scale)
                        change(fx, fy, r.scale)
                    }
                }
            }
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    val w = size.width.toFloat(); val h = size.height.toFloat()
                    if (w > 0f && h > 0f) {
                        val r = cur
                        val s = (r.scale * zoom).coerceIn(ZoomMath.MIN_SCALE, ZoomMath.MAX_SCALE)
                        val (fx, fy) = ZoomMath.clampCenter(r.fx + pan.x / w, r.fy + pan.y / h, s)
                        change(fx, fy, s)
                    }
                }
            },
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val win = ZoomMath.window(cur.scale, cur.fx, cur.fy)
            val x = win.left * size.width; val y = win.top * size.height
            val ww = win.size * size.width; val hh = win.size * size.height
            // gelapkan di luar jendela
            val hole = Path().apply { addRect(Rect(x, y, x + ww, y + hh)) }
            clipPath(hole, clipOp = ClipOp.Difference) { drawRect(Color.Black.copy(alpha = 0.55f)) }
            // bingkai jendela + garis sepertiga + titik pusat
            drawRect(Color.White, Offset(x, y), Size(ww, hh), style = Stroke(width = 2.dp.toPx()))
            val thin = 1.dp.toPx()
            val guide = Color.White.copy(alpha = 0.35f)
            for (i in 1..2) {
                drawLine(guide, Offset(x + ww * i / 3f, y), Offset(x + ww * i / 3f, y + hh), strokeWidth = thin)
                drawLine(guide, Offset(x, y + hh * i / 3f), Offset(x + ww, y + hh * i / 3f), strokeWidth = thin)
            }
            val c = Offset(x + ww / 2f, y + hh / 2f)
            drawCircle(Color.White, 3.dp.toPx(), c)
            // pegangan sudut (penanda visual)
            val r = 4.dp.toPx()
            listOf(Offset(x, y), Offset(x + ww, y), Offset(x, y + hh), Offset(x + ww, y + hh)).forEach { drawCircle(Color.White, r, it) }
        }
        Text(
            "Geser · cubit · ketuk",
            style = MaterialTheme.typography.labelSmall,
            color = Color.White.copy(alpha = 0.85f),
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 6.dp),
        )
    }
}
