package com.layarkita

import android.graphics.Bitmap
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.net.Uri
import android.view.Surface
import android.view.TextureView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val PRESETS = listOf(
    0xFF1E3A8A.toInt() to 0xFF7C3AED.toInt(),   // biru-ungu
    0xFFF97316.toInt() to 0xFFDB2777.toInt(),   // sunset
    0xFF059669.toInt() to 0xFF0E7490.toInt(),   // tosca
    0xFF0F172A.toInt() to 0xFF334155.toInt(),   // malam
    0xFFF8FAFC.toInt() to 0xFFCBD5E1.toInt(),   // terang
    0xFF000000.toInt() to 0xFF000000.toInt(),   // hitam
)

private val SOLIDS = listOf(
    0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFF0F172A.toInt(), 0xFF1E293B.toInt(),
    0xFFEF4444.toInt(), 0xFFF97316.toInt(), 0xFFEAB308.toInt(), 0xFF22C55E.toInt(),
    0xFF06B6D4.toInt(), 0xFF3B82F6.toInt(), 0xFF8B5CF6.toInt(), 0xFFEC4899.toInt(),
)

// wallpaper "mesh": warna dasar, warna tengah, warna sudut bawah
private val WALLS = listOf(
    Triple(0xFF0B1026.toInt(), 0xFF22D3AE.toInt(), 0xFF7C3AED.toInt()),   // aurora
    Triple(0xFF2B1055.toInt(), 0xFFFB7185.toInt(), 0xFFFBBF24.toInt()),   // senja
    Triple(0xFF03045E.toInt(), 0xFF0096C7.toInt(), 0xFF90E0EF.toInt()),   // laut
    Triple(0xFF111827.toInt(), 0xFFF472B6.toInt(), 0xFF38BDF8.toInt()),   // neon
    Triple(0xFF052E16.toInt(), 0xFF16A34A.toInt(), 0xFFA3E635.toInt()),   // hutan
    Triple(0xFFFDE68A.toInt(), 0xFFF9A8D4.toInt(), 0xFFA5B4FC.toInt()),   // pastel
)

/** Wallpaper foto bawaan (res/raw/wallpaper1..18.jpg), diambil dari Openscreen (MIT), diperkecil ke 1600 px. */
private const val WALLPAPER_COUNT = 18

private fun wallpaperUri(ctx: android.content.Context, n: Int): Uri =
    Uri.parse("android.resource://${ctx.packageName}/raw/wallpaper$n")

@Composable
private fun WallThumb(ctx: android.content.Context, uri: Uri, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val bmp by produceState<Bitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) { Exporter.loadImage(ctx, uri, 160) }
    }
    Box(
        Modifier.size(width = 64.dp, height = 40.dp).clip(RoundedCornerShape(8.dp))
            .background(Color.Gray.copy(alpha = 0.3f))
            .then(if (selected) Modifier.border(3.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(8.dp))
                  else Modifier.border(1.dp, Color.Gray.copy(alpha = 0.5f), RoundedCornerShape(8.dp)))
            .clickable(enabled = enabled, onClick = onClick),
    ) {
        bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
    }
}

private val BG_TYPES = listOf("Gradient", "Warna", "Wallpaper", "Foto", "Blur")

private val ASPECTS = listOf<Pair<String, Float?>>(
    "Asli" to null, "16:9" to 16f / 9f, "9:16" to 9f / 16f, "1:1" to 1f, "4:5" to 4f / 5f,
)

private class PlayerState {
    var mp: MediaPlayer? = null
    var surface: Surface? = null
    var ready by mutableStateOf(false)
    var playing by mutableStateOf(false)
    /** Pesan kalau pemutar gagal (ditampilkan di editor), null = normal. */
    var failed by mutableStateOf<String?>(null)
    /** Play ditekan sebelum video siap: mulai otomatis begitu siap. */
    var playWhenReady = false
    /** Pemutaran sudah sampai habis (MediaPlayer ada di keadaan PlaybackCompleted). */
    var completed = false
    var positionMs by mutableLongStateOf(0L)
    /** Posisi pratinjau (ms) yang HALUS: diperbarui tiap frame layar lewat ekstrapolasi, dipakai zoom dan kursor. */
    var smoothMs by mutableFloatStateOf(0f)

    /**
     * Buat MediaPlayer SEKALI per video. Sebelumnya pemutar dibuat/dibuang oleh callback TextureView, sehingga setiap kali
     * TextureView dilepas/dipasang ulang (ganti layout, mode pilih area, dsb.) pemutar ikut dibuang dan Play tidak jalan.
     * Sekarang siklus hidup pemutar terpisah dari surface: surface cukup dipasang ([attach]) atau dilepas ([detach]).
     */
    fun open(ctx: android.content.Context, uri: Uri) {
        release()
        failed = null
        val player = MediaPlayer()
        try {
            player.setDataSource(ctx, uri)
            surface?.let { player.setSurface(it) }
            player.setOnPreparedListener {
                ready = true
                try { it.seekTo(0) } catch (_: Exception) {}
                if (playWhenReady) {
                    playWhenReady = false
                    try { it.start(); playing = true } catch (_: Exception) {}
                }
            }
            player.setOnCompletionListener { playing = false; completed = true }
            player.setOnErrorListener { _, what, extra ->
                ready = false; playing = false
                failed = "Pemutar gagal ($what/$extra)"
                true
            }
            player.prepareAsync()
            mp = player
        } catch (e: Exception) {
            failed = "Video tidak bisa dibuka"
            try { player.release() } catch (_: Exception) {}
        }
    }

    fun attach(s: Surface) {
        surface = s
        try { mp?.setSurface(s) } catch (_: Exception) {}
    }

    fun detach() {
        try { mp?.setSurface(null) } catch (_: Exception) {}
        try { surface?.release() } catch (_: Exception) {}
        surface = null
    }

    fun release() {
        ready = false
        playing = false
        playWhenReady = false
        completed = false
        try { mp?.release() } catch (_: Exception) {}
        mp = null
    }
}

private val TOOLS = listOf("Zoom", "Background", "Bingkai", "Rasio")

/** Ikon garis 24x24 untuk toolbar bawah (digambar sendiri, urutan sama dengan [TOOLS]). */
private val TOOL_ICONS = listOf(
    // Zoom: kaca pembesar dengan tanda plus
    listOf("M11 4.5a6.5 6.5 0 1 0 0 13a6.5 6.5 0 0 0 0 -13Z", "M16 16L20.5 20.5", "M11 8.5V13.5", "M8.5 11H13.5"),
    // Background: gambar dengan gunung
    listOf("M5 4H19a2 2 0 0 1 2 2V18a2 2 0 0 1 -2 2H5a2 2 0 0 1 -2 -2V6a2 2 0 0 1 2 -2Z", "M3 16L8 11L12 15L15 12L21 18"),
    // Bingkai: dua persegi bersarang
    listOf("M4 4H20V20H4Z", "M8 8H16V16H8Z"),
    // Rasio: persegi panjang dengan tanda sudut
    listOf("M3 7H21V17H3Z", "M7 11V9H9", "M17 13V15H15"),
)

// Ikon kartu player
private val ICON_FULLSCREEN = listOf("M4 9V4H9", "M20 9V4H15", "M4 15V20H9", "M20 15V20H15")
private val ICON_VOLUME = listOf("M4 10V14H8L13 18V6L8 10Z", "M16.5 9.5a3.5 3.5 0 0 1 0 5")
private val ICON_VOLUME_OFF = listOf("M4 10V14H8L13 18V6L8 10Z", "M17 9L21 15", "M21 9L17 15")
private val ICON_UNDO = listOf("M9 14L4 9L9 4", "M4 9H15a5 5 0 0 1 0 10H11")
private val ICON_REDO = listOf("M15 14L20 9L15 4", "M20 9H9a5 5 0 0 0 0 10H13")

/** Satu keadaan edit lengkap, dipakai untuk undo/redo. */
private data class EditSnap(
    val zooms: List<ZoomRegion>, val startMs: Float, val endMs: Float,
    val bgUi: Int, val preset: Int, val solid: Int, val wall: Int, val imageUri: Uri?, val blurAmt: Float,
    val padding: Float, val corner: Float, val shadow: Boolean, val aspectIdx: Int, val cursorOn: Boolean,
)

/** Palet editor: hitam pekat, kartu abu gelap, aksen teal muda, tombol Ekspor oranye. Datar, tanpa bayangan. */
private val EditorColors = darkColorScheme(
    primary = Color(0xFFBFE0DC),
    onPrimary = Color(0xFF0B0B0B),
    secondaryContainer = Color(0xFF26262A),
    onSecondaryContainer = Color(0xFFF2F2F2),
    tertiary = Color(0xFFFF6A13),
    background = Color(0xFF0B0B0B),
    onBackground = Color(0xFFF2F2F2),
    surface = Color(0xFF0B0B0B),
    onSurface = Color(0xFFF2F2F2),
    surfaceVariant = Color(0xFF1C1C1E),
    onSurfaceVariant = Color(0xFF8E8E93),
    surfaceContainerLow = Color(0xFF131315),
    surfaceContainer = Color(0xFF161618),
    surfaceContainerHighest = Color(0xFF26262A),
    outline = Color(0xFF3A3A3E),
    outlineVariant = Color(0xFF2A2A2D),
    error = Color(0xFFFF6369),
    onError = Color(0xFF1A0505),
)

@Composable
private fun ToolIcon(paths: List<String>, color: Color, iconSize: Dp = 22.dp) {
    val parsed = remember(paths) { paths.map { PathParser().parsePathString(it).toPath() } }
    Canvas(Modifier.size(iconSize)) {
        scale(this.size.width / 24f, pivot = Offset.Zero) {
            parsed.forEach { drawPath(it, color, style = Stroke(width = 1.6f, cap = StrokeCap.Round, join = StrokeJoin.Round)) }
        }
    }
}

@Composable
fun EditorScreen(uri: Uri, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val player = remember { PlayerState() }
    DisposableEffect(Unit) { onDispose { player.release(); player.detach() } }

    // Editor selalu gelap: ikon status bar dibuat terang selama editor terbuka, lalu dikembalikan.
    val view = LocalView.current
    DisposableEffect(Unit) {
        val win = view.context.findActivity()?.window
        val ctrl = win?.let { WindowCompat.getInsetsController(it, view) }
        val prevStatus = ctrl?.isAppearanceLightStatusBars
        val prevNav = ctrl?.isAppearanceLightNavigationBars
        ctrl?.isAppearanceLightStatusBars = false
        ctrl?.isAppearanceLightNavigationBars = false
        onDispose {
            if (ctrl != null && prevStatus != null) ctrl.isAppearanceLightStatusBars = prevStatus
            if (ctrl != null && prevNav != null) ctrl.isAppearanceLightNavigationBars = prevNav
        }
    }

    val info by produceState<VideoInfo?>(null, uri) {
        value = withContext(Dispatchers.IO) { Exporter.probe(ctx, uri) }
    }

    var cancel by remember { mutableStateOf<Exporter.Cancel?>(null) }
    val back = { cancel?.requested = true; onBack() }
    BackHandler { back() }

    MaterialTheme(colorScheme = EditorColors) {
        Box(Modifier.fillMaxSize().background(EditorColors.background).systemBarsPadding()) {
            val vi = info
            if (vi == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                IconButton(onClick = { back() }, modifier = Modifier.padding(4.dp)) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali", tint = EditorColors.onBackground)
                }
            } else {
                EditorContent(ctx, scope, uri, vi, player, { cancel = it }, cancel, back, Modifier.fillMaxSize())
            }
        }
    }
}

@Composable
private fun EditorContent(
    ctx: android.content.Context,
    scope: kotlinx.coroutines.CoroutineScope,
    uri: Uri,
    vi: VideoInfo,
    player: PlayerState,
    setCancel: (Exporter.Cancel?) -> Unit,
    cancel: Exporter.Cancel?,
    onBack: () -> Unit,
    modifier: Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val durMs = vi.durationMs.coerceAtLeast(1000L)
    DisposableEffect(uri) {
        player.open(ctx, uri)
        onDispose { player.release() }
    }
    var startMs by remember(uri) { mutableFloatStateOf(0f) }
    var endMs by remember(uri) { mutableFloatStateOf(durMs.toFloat()) }

    var tool by remember { mutableIntStateOf(-1) }   // -1 = panel tertutup

    var bgUi by remember { mutableIntStateOf(0) }       // 0 gradient, 1 warna, 2 wallpaper, 3 gambar, 4 blur
    var preset by remember { mutableIntStateOf(0) }
    var solid by remember { mutableIntStateOf(0) }
    var wall by remember { mutableIntStateOf(0) }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var blurAmt by remember { mutableFloatStateOf(0.04f) }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u ->
        if (u != null) imageUri = u
    }
    val imgBmp by produceState<Bitmap?>(null, imageUri) {
        val u = imageUri
        value = if (u == null) null else withContext(Dispatchers.IO) { Exporter.loadImage(ctx, u, 1024) }
    }
    val frameBmp by produceState<Bitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) { Exporter.firstFrame(ctx, uri) }
    }
    var padding by remember { mutableFloatStateOf(0.08f) }
    var corner by remember { mutableFloatStateOf(0.03f) }
    var shadow by remember { mutableStateOf(true) }
    var aspectIdx by remember { mutableIntStateOf(0) }

    // ---- zoom ----
    var zooms by remember(uri) { mutableStateOf<List<ZoomRegion>>(emptyList()) }
    var selectedZoom by remember(uri) { mutableStateOf<Int?>(null) }
    var nextZoomId by remember(uri) { mutableIntStateOf(1) }
    var zoomMsg by remember(uri) { mutableStateOf<String?>(null) }
    var areaEdit by remember(uri) { mutableStateOf(false) }   // mode pilih area zoom di pratinjau
    val touches by produceState<List<TouchEvent>>(emptyList(), uri) {
        value = withContext(Dispatchers.IO) {
            val name = Library.nameOf(ctx, uri)
            if (name == null) emptyList() else TouchLog.load(ctx.filesDir, name)
        }
    }

    var exporting by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var resultUri by remember { mutableStateOf<Uri?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    var cursorOn by remember { mutableStateOf(true) }

    // ---- toast kecil di atas pratinjau, mode fokus (fullscreen), mute pratinjau ----
    var toast by remember { mutableStateOf<String?>(null) }
    var toastKey by remember { mutableIntStateOf(0) }
    fun showToast(m: String) { toast = m; toastKey++ }
    LaunchedEffect(toastKey) {
        if (toast != null) { delay(2000); toast = null }
    }
    var focus by remember { mutableStateOf(false) }
    BackHandler(enabled = focus) { focus = false }
    BackHandler(enabled = !focus && tool >= 0) { tool = -1 }   // Back menutup panel dulu sebelum keluar editor
    var muted by remember { mutableStateOf(false) }
    var toolbarH by remember { mutableIntStateOf(0) }    // px, untuk menempatkan panel overlay tepat di atas toolbar
    var timelineH by remember { mutableIntStateOf(0) }   // px, tinggi maksimum panel overlay = tinggi timeline
    LaunchedEffect(muted, player.ready) {
        val v = if (muted) 0f else 1f
        try { player.mp?.setVolume(v, v) } catch (_: Exception) {}
    }

    // ---- undo / redo: perubahan digabung per 350 ms, lalu disimpan sebagai satu langkah ----
    val snap = EditSnap(
        zooms, startMs, endMs, bgUi, preset, solid, wall, imageUri, blurAmt,
        padding, corner, shadow, aspectIdx, cursorOn,
    )
    var committed by remember(uri) { mutableStateOf<EditSnap?>(null) }
    var undoStack by remember(uri) { mutableStateOf<List<EditSnap>>(emptyList()) }
    var redoStack by remember(uri) { mutableStateOf<List<EditSnap>>(emptyList()) }
    fun commitNow(s: EditSnap) {
        val c = committed
        if (c == null) { committed = s; return }
        if (s == c) return
        undoStack = (undoStack + c).takeLast(60)
        redoStack = emptyList()
        committed = s
    }
    LaunchedEffect(snap) {
        if (committed == null) { committed = snap; return@LaunchedEffect }
        delay(350)
        commitNow(snap)
    }
    fun applySnap(s: EditSnap) {
        zooms = s.zooms; startMs = s.startMs; endMs = s.endMs
        bgUi = s.bgUi; preset = s.preset; solid = s.solid; wall = s.wall; imageUri = s.imageUri; blurAmt = s.blurAmt
        padding = s.padding; corner = s.corner; shadow = s.shadow; aspectIdx = s.aspectIdx; cursorOn = s.cursorOn
        selectedZoom = null; areaEdit = false
    }
    fun undo() {
        commitNow(snap)   // simpan dulu perubahan yang belum sempat tercatat
        val c = committed ?: return
        val target = undoStack.lastOrNull() ?: return
        undoStack = undoStack.dropLast(1)
        redoStack = redoStack + c
        committed = target
        applySnap(target)
        showToast("Dibatalkan")
    }
    fun redo() {
        val c = committed ?: return
        val target = redoStack.lastOrNull() ?: return
        redoStack = redoStack.dropLast(1)
        undoStack = undoStack + c
        committed = target
        applySnap(target)
        showToast("Diulangi")
    }
    val canUndo = undoStack.isNotEmpty() || (committed != null && committed != snap)
    val canRedo = redoStack.isNotEmpty()

    // Sumber kursor: data ketukan; kalau rekaman tidak punya (layanan sentuhan mati / elemen tidak terbaca),
    // kursor memakai titik fokus tiap blok zoom, jadi saklar Kursor tetap bisa dipakai.
    val cursorTrack = remember(touches, zooms) {
        if (touches.isNotEmpty()) touches
        else zooms.map { TouchEvent(it.startMs, it.fx.coerceIn(0f, 1f), it.fy.coerceIn(0f, 1f), TouchLog.TAP) }.sortedBy { it.tMs }
    }
    val base = FrameStyle(padding = padding, corner = corner, shadow = shadow, aspect = ASPECTS[aspectIdx].second, cursor = cursorOn && cursorTrack.isNotEmpty())
    val style = when (bgUi) {
        1 -> base.copy(top = SOLIDS[solid], bottom = SOLIDS[solid])
        2 -> base.copy(bgType = 1, top = WALLS[wall].first, mid = WALLS[wall].second, bottom = WALLS[wall].third)
        3 -> base.copy(bgType = 2, image = imageUri)
        4 -> base.copy(bgType = 3, blur = blurAmt)
        else -> base.copy(top = PRESETS[preset].first, bottom = PRESETS[preset].second)
    }
    val videoAspect = vi.width.toFloat() / vi.height.toFloat()

    // loop pemutaran di dalam rentang potong + jam halus untuk zoom/kursor.
    // MediaPlayer.currentPosition kasar dan bisa loncat; zoom yang dibaca darinya (dulu tiap 40 ms) patah-patah.
    // Saat memutar: waktu diekstrapolasi tiap frame layar, lalu dikoreksi pelan-pelan oleh currentPosition.
    val curStart by rememberUpdatedState(startMs)
    val curEnd by rememberUpdatedState(endMs)
    LaunchedEffect(Unit) {
        var est = 0f
        var lastFrameNs = 0L
        var lastSampleNs = 0L
        var ignoreUntilNs = 0L
        while (true) {
            val mp = player.mp
            if (mp == null || !player.ready) { delay(50); continue }
            if (!player.playing) {
                // jeda / scrub: ikuti posisi pemutar apa adanya
                try {
                    val p = mp.currentPosition.toFloat()
                    est = p
                    player.smoothMs = p
                    player.positionMs = p.toLong()
                } catch (_: Exception) {}
                lastFrameNs = 0L
                delay(30)
                continue
            }
            withFrameNanos { now ->
                if (lastFrameNs == 0L) {
                    // frame pertama setelah Play: langsung selaraskan dengan pemutar (tanpa koreksi pelan)
                    lastFrameNs = now; lastSampleNs = 0L
                    try { est = mp.currentPosition.toFloat() } catch (_: Exception) {}
                }
                val dt = ((now - lastFrameNs) / 1_000_000f).coerceIn(0f, 50f)
                lastFrameNs = now
                est += dt
                if (now - lastSampleNs > 50_000_000L && now > ignoreUntilNs) {
                    lastSampleNs = now
                    try {
                        val p = mp.currentPosition.toFloat()
                        if (p >= curEnd) {
                            mp.seekTo(curStart.toLong(), MediaPlayer.SEEK_CLOSEST)
                            est = curStart
                            ignoreUntilNs = now + 200_000_000L   // abaikan pembacaan lama sampai seek selesai
                        } else {
                            val err = p - est
                            est = if (kotlin.math.abs(err) > 250f) p else est + err * 0.15f
                        }
                    } catch (_: Exception) {}
                }
                if (est > curEnd) est = curEnd
                player.smoothMs = est
                // state yang memicu recompose (timeline, teks waktu) cukup ~25 Hz
                if (kotlin.math.abs(est - player.positionMs) >= 40f) player.positionMs = est.toLong()
            }
        }
    }

    fun seek(ms: Float) {
        try { player.mp?.seekTo(ms.toLong(), MediaPlayer.SEEK_CLOSEST) } catch (_: Exception) {}
    }

    fun togglePlay() {
        val mp = player.mp
        if (mp == null) return
        if (!player.ready) {
            // video belum siap: ingat niatnya, mulai otomatis begitu siap
            player.playWhenReady = !player.playWhenReady
            if (player.playWhenReady) areaEdit = false
            return
        }
        try {
            if (player.playing) {
                mp.pause(); player.playing = false
            } else {
                areaEdit = false
                // setelah habis (atau di luar rentang potong) mulai lagi dari awal rentang
                if (player.completed || mp.currentPosition < startMs || mp.currentPosition >= endMs) {
                    mp.seekTo(startMs.toLong(), MediaPlayer.SEEK_CLOSEST)
                }
                player.completed = false
                mp.start(); player.playing = true
            }
        } catch (e: Exception) {
            player.playing = false
            player.failed = "Tidak bisa memutar: ${e.javaClass.simpleName}"
        }
    }

    fun addZoom() {
        val added = ZoomOps.add(zooms, ZoomRegion(id = nextZoomId, startMs = 0L, endMs = 0L), player.positionMs, 3000L, durMs)
        if (added == null) {
            zoomMsg = "Tidak ada ruang kosong"
            showToast("Tidak ada ruang kosong")
        } else {
            val newId = nextZoomId
            zooms = added; selectedZoom = newId; nextZoomId++; zoomMsg = null
            showToast("Zoom ditambahkan")
            tool = 0
            added.firstOrNull { it.id == newId }?.let { nr ->
                try { player.mp?.pause(); player.playing = false } catch (_: Exception) {}
                seek(nr.startMs.toFloat())
                areaEdit = true
            }
        }
    }

    val doExport: () -> Unit = {
        try { player.mp?.pause(); player.playing = false } catch (_: Exception) {}
        val c = Exporter.Cancel()
        setCancel(c)
        exporting = true; progress = 0f; resultUri = null; error = null
        val st = style
        val zl = zooms
        val tl = cursorTrack
        val s = (startMs * 1000f).toLong()
        val e = (endMs * 1000f).toLong()
        scope.launch(Dispatchers.Default) {
            val out = Exporter.export(ctx, uri, s, e, st, zl, tl, c, { p -> progress = p }, { m -> error = m })
            withContext(Dispatchers.Main) {
                exporting = false
                resultUri = out
                if (out == null && error == null) error = "Ekspor dibatalkan"
            }
        }
    }

    // ---------------------------------------------------------------- bagian-bagian layar
    val title by produceState("Rekaman", uri) {
        value = withContext(Dispatchers.IO) { Library.nameOf(ctx, uri)?.substringBeforeLast('.') ?: "Rekaman" }
    }

    val topBar: @Composable () -> Unit = {
        Row(
            Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Box(
                Modifier.size(40.dp).clip(CircleShape).background(cs.surfaceVariant).clickable(onClick = onBack),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali", tint = cs.onBackground, modifier = Modifier.size(20.dp))
            }
            Text(
                "$title  |  ${ASPECTS[aspectIdx].first}",
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            if (exporting) {
                Text("${(progress * 100).toInt()}%", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                Box(
                    Modifier.height(36.dp).clip(RoundedCornerShape(50)).background(cs.surfaceVariant)
                        .clickable { cancel?.requested = true }.padding(horizontal = 16.dp),
                    contentAlignment = Alignment.Center,
                ) { Text("Batal", style = MaterialTheme.typography.labelLarge, color = cs.onBackground) }
            } else {
                resultUri?.let { out ->
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(cs.surfaceVariant).clickable { Library.share(ctx, out) },
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Default.Share, contentDescription = "Bagikan", tint = cs.primary, modifier = Modifier.size(20.dp)) }
                }
                Box(
                    Modifier.height(36.dp).clip(RoundedCornerShape(50)).background(cs.tertiary)
                        .clickable(onClick = doExport).padding(horizontal = 18.dp),
                    contentAlignment = Alignment.Center,
                ) { Text("Ekspor", style = MaterialTheme.typography.labelLarge, color = Color.White, fontWeight = FontWeight.SemiBold) }
            }
        }
        Box(Modifier.fillMaxWidth().height(2.dp)) {
            if (exporting) LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth(), color = cs.tertiary, trackColor = cs.surfaceVariant)
        }
    }

    val preview: @Composable () -> Unit = {
        FramePreview(
            uri, videoAspect, style, player, imgBmp, frameBmp, zooms,
            cursorTrack, { player.smoothMs },
            if (areaEdit) zooms.firstOrNull { it.id == selectedZoom } else null,
        ) { fx, fy, sc ->
            selectedZoom?.let { id -> zooms = ZoomOps.update(zooms, id) { it.copy(fx = fx, fy = fy, scale = sc, auto = false) } }
        }
    }

    val timeline: @Composable () -> Unit = {
        Box(Modifier.padding(horizontal = 16.dp).onSizeChanged { timelineH = it.height }) {
            TimelineEditor(
                uri = uri,
                durMs = durMs,
                positionMs = player.positionMs,
                playing = player.playing,
                startMs = startMs,
                endMs = endMs,
                zooms = zooms,
                touches = touches,
                selectedId = selectedZoom,
                enabled = !exporting,
                onSeek = { seek(it.toFloat()) },
                onTrimStart = { v ->
                    val s = v.coerceIn(0f, endMs - 500f)
                    startMs = s; seek(s)
                },
                onTrimEnd = { v ->
                    val e = v.coerceIn(startMs + 500f, durMs.toFloat())
                    endMs = e; seek((e - 500f).coerceAtLeast(startMs))
                },
                onSelect = { id ->
                    selectedZoom = id
                    // di mode pilih area, pindah blok = lompat ke frame awal blok itu
                    if (areaEdit) zooms.firstOrNull { it.id == id }?.let { seek(it.startMs.toFloat()) }
                },
                onZooms = { zooms = it },
                leading = {
                    Text(
                        "${Library.fmtTime(player.positionMs)}  /  ${Library.fmtTime(durMs)}",
                        style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant,
                    )
                },
            )
        }
    }

    // Kartu player: fullscreen + mute | Play besar | undo + redo
    val playerCard: @Composable () -> Unit = {
        val cardShape = RoundedCornerShape(28.dp)
        val dim = cs.onSurfaceVariant.copy(alpha = 0.35f)
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).height(56.dp)
                .clip(cardShape).background(cs.surfaceVariant).border(1.dp, cs.outlineVariant, cardShape)
                .padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.Start) {
                Box(Modifier.size(44.dp).clip(CircleShape).clickable { focus = !focus }, contentAlignment = Alignment.Center) {
                    ToolIcon(ICON_FULLSCREEN, if (focus) cs.primary else cs.onSurfaceVariant, 20.dp)
                }
                Box(Modifier.size(44.dp).clip(CircleShape).clickable { muted = !muted }, contentAlignment = Alignment.Center) {
                    ToolIcon(if (muted) ICON_VOLUME_OFF else ICON_VOLUME, if (muted) cs.primary else cs.onSurfaceVariant, 20.dp)
                }
            }
            Box(
                Modifier.size(48.dp).clip(CircleShape).clickable { togglePlay() },
                contentAlignment = Alignment.Center,
            ) { PlayPauseIcon(player.playing, cs.onBackground, 26.dp) }
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.End) {
                Box(Modifier.size(44.dp).clip(CircleShape).clickable(enabled = canUndo && !exporting) { undo() }, contentAlignment = Alignment.Center) {
                    ToolIcon(ICON_UNDO, if (canUndo) cs.onSurfaceVariant else dim, 20.dp)
                }
                Box(Modifier.size(44.dp).clip(CircleShape).clickable(enabled = canRedo && !exporting) { redo() }, contentAlignment = Alignment.Center) {
                    ToolIcon(ICON_REDO, if (canRedo) cs.onSurfaceVariant else dim, 20.dp)
                }
            }
        }
    }

    // Toolbar bawah: ikon + label, yang aktif berwarna aksen
    val toolbar: @Composable () -> Unit = {
        Column(Modifier.fillMaxWidth().background(cs.background).onSizeChanged { toolbarH = it.height }) {
            HorizontalDivider(color = cs.outlineVariant)
            Row(Modifier.fillMaxWidth()) {
                TOOLS.forEachIndexed { i, t ->
                    val c = if (tool == i) cs.primary else cs.onBackground
                    Column(
                        Modifier.weight(1f).clickable { tool = if (tool == i) -1 else i }.padding(vertical = 5.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(2.dp),
                    ) {
                        ToolIcon(TOOL_ICONS[i], c, 20.dp)
                        Text(t, fontSize = 10.sp, color = c, maxLines = 1)
                    }
                }
            }
        }
    }

    val panel: @Composable () -> Unit = {
      if (tool in TOOLS.indices) {
        val sheetShape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
        Column(Modifier.fillMaxWidth().clip(sheetShape).background(cs.surfaceContainer).border(1.dp, cs.outlineVariant, sheetShape)) {
            Row(Modifier.fillMaxWidth().height(40.dp).padding(start = 16.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(TOOLS[tool], Modifier.weight(1f), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold, color = cs.onBackground)
                Box(Modifier.size(40.dp).clip(CircleShape).clickable { tool = -1 }, contentAlignment = Alignment.Center) {
                    ToolIcon(listOf("M6 6L18 18", "M18 6L6 18"), cs.onSurfaceVariant, 18.dp)
                }
            }
            Box(Modifier.fillMaxWidth().heightIn(min = 72.dp).padding(start = 16.dp, end = 16.dp, bottom = 12.dp)) {
            when (tool) {
                0 -> Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill("Auto-zoom", enabled = !exporting && touches.isNotEmpty()) {
                            val auto = AutoZoom.build(touches, durMs)
                            zooms = auto
                            nextZoomId = (auto.maxOfOrNull { it.id } ?: 0) + 1
                            selectedZoom = null
                            zoomMsg = if (auto.isEmpty()) "Ketukan terlalu sedikit" else null
                            if (auto.isNotEmpty()) showToast("Auto-zoom dibuat")
                        }
                        Pill("+ Zoom", enabled = !exporting) { addZoom() }
                        Pill("Hapus", enabled = !exporting && selectedZoom != null) {
                            selectedZoom?.let { zooms = ZoomOps.remove(zooms, it); selectedZoom = null; areaEdit = false; showToast("Zoom dihapus") }
                        }
                        Pill(if (areaEdit) "Selesai" else "Pilih area", selected = areaEdit, enabled = !exporting && selectedZoom != null) {
                            if (areaEdit) areaEdit = false
                            else zooms.firstOrNull { it.id == selectedZoom }?.let { sr ->
                                // jeda dan lompat ke awal blok, supaya yang dipilih adalah frame yang akan di-zoom
                                try { player.mp?.pause(); player.playing = false } catch (_: Exception) {}
                                seek(sr.startMs.toFloat())
                                areaEdit = true
                            }
                        }
                        zooms.firstOrNull { it.id == selectedZoom }?.let { cur ->
                            Seg(
                                listOf("3D mati" to Cam.OFF, "Kiri" to Cam.LEFT, "Kanan" to Cam.RIGHT, "Orbit" to Cam.ORBIT),
                                cur.cam, !exporting,
                            ) { c -> zooms = ZoomOps.update(zooms, cur.id) { it.copy(cam = c) } }
                        }
                    }
                    val sel = zooms.firstOrNull { it.id == selectedZoom }
                    if (sel != null) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            MiniSlider("Skala %.1f×".format(sel.scale), sel.scale, ZoomMath.MIN_SCALE..ZoomMath.MAX_SCALE, !exporting, Modifier.weight(1f)) { v ->
                                zooms = ZoomOps.update(zooms, sel.id) { it.copy(scale = v, auto = false) }
                            }
                            MiniSlider("X", sel.fx, ZoomMath.FOCUS_MIN..ZoomMath.FOCUS_MAX, !exporting, Modifier.weight(1f)) { v ->
                                zooms = ZoomOps.update(zooms, sel.id) { it.copy(fx = v, auto = false) }
                            }
                            MiniSlider("Y", sel.fy, ZoomMath.FOCUS_MIN..ZoomMath.FOCUS_MAX, !exporting, Modifier.weight(1f)) { v ->
                                zooms = ZoomOps.update(zooms, sel.id) { it.copy(fy = v, auto = false) }
                            }
                        }
                    } else {
                        zoomMsg?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant) }
                    }
                }

                1 -> Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        BG_TYPES.forEachIndexed { i, label -> Pill(label, selected = bgUi == i, enabled = !exporting) { bgUi = i } }
                    }
                    when (bgUi) {
                        0 -> Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            PRESETS.forEachIndexed { i, (a, b) ->
                                Swatch(Brush.verticalGradient(listOf(Color(a), Color(b))), i == preset, !exporting) { preset = i }
                            }
                        }
                        1 -> Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            SOLIDS.forEachIndexed { i, c ->
                                Swatch(Brush.verticalGradient(listOf(Color(c), Color(c))), i == solid, !exporting) { solid = i }
                            }
                        }
                        2 -> Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            WALLS.forEachIndexed { i, w ->
                                Swatch(Brush.linearGradient(listOf(Color(w.first), Color(w.second), Color(w.third))), i == wall, !exporting) { wall = i }
                            }
                        }
                        3 -> Row(
                            Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Pill("Galeri", enabled = !exporting) {
                                pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            }
                            for (n in 1..WALLPAPER_COUNT) {
                                val u = wallpaperUri(ctx, n)
                                WallThumb(ctx, u, imageUri == u, !exporting) { imageUri = u }
                            }
                        }
                        4 -> Slider(value = blurAmt, onValueChange = { blurAmt = it }, valueRange = 0.01f..0.08f, enabled = !exporting)
                    }
                }

                2 -> Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        LabeledSlider("Jarak", padding, 0f..0.25f, !exporting) { padding = it }
                        LabeledSlider("Sudut", corner, 0f..0.10f, !exporting) { corner = it }
                    }
                    Column(Modifier.padding(start = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Bayangan", style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                        Switch(checked = shadow, onCheckedChange = { shadow = it }, enabled = !exporting)
                    }
                    Column(Modifier.padding(start = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Kursor", style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                        Switch(checked = cursorOn, onCheckedChange = { cursorOn = it }, enabled = !exporting)
                        if (cursorOn && cursorTrack.isEmpty()) {
                            Text("Butuh ketukan\natau blok zoom", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                        }
                    }
                }

                3 -> Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ASPECTS.forEachIndexed { i, (label, _) -> Pill(label, selected = aspectIdx == i, enabled = !exporting) { aspectIdx = i } }
                }
            }
            }
        }
      }
    }

    val toastChip: @Composable () -> Unit = {
        toast?.let { m ->
            Box(
                Modifier.clip(RoundedCornerShape(50)).background(cs.surfaceContainerHighest.copy(alpha = 0.92f))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            ) { Text(m, style = MaterialTheme.typography.labelMedium, color = cs.onBackground, maxLines = 1) }
        }
    }

    val errorChip: @Composable () -> Unit = {
        (error ?: player.failed)?.let { m ->
            Box(
                Modifier.clip(RoundedCornerShape(50)).background(cs.surfaceContainerHighest.copy(alpha = 0.92f))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            ) { Text(m, style = MaterialTheme.typography.labelMedium, color = cs.error, maxLines = 1, overflow = TextOverflow.Ellipsis) }
        }
    }

    // Kanvas dan kartu player TERKUNCI: ukuran dan posisinya tidak bergantung pada panel yang dibuka.
    // Panel tool melayang (overlay) tepat di atas toolbar, tingginya paling banyak setinggi timeline.
    BoxWithConstraints(modifier) {
        val land = maxWidth > maxHeight
        Column(Modifier.fillMaxSize()) {
            topBar()
            if (land) {
                Row(Modifier.weight(1f).fillMaxWidth()) {
                    Column(Modifier.weight(if (focus) 1f else 0.42f).fillMaxHeight()) {
                        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { preview() }
                            Box(Modifier.align(Alignment.BottomStart).padding(8.dp)) { toastChip() }
                            Box(Modifier.align(Alignment.TopCenter).padding(8.dp)) { errorChip() }
                        }
                        playerCard()
                    }
                    if (!focus) Column(Modifier.weight(0.58f).fillMaxHeight()) {
                        Box(
                            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),
                            contentAlignment = Alignment.BottomCenter,
                        ) { timeline() }
                        toolbar()
                    }
                }
            } else {
                Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp)) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { preview() }
                    Box(Modifier.align(Alignment.BottomStart).padding(8.dp)) { toastChip() }
                    Box(Modifier.align(Alignment.TopCenter).padding(8.dp)) { errorChip() }
                }
                playerCard()
                if (!focus) {
                    timeline()
                    toolbar()
                }
            }
        }
        if (!focus && tool in TOOLS.indices) {
            val maxH = with(LocalDensity.current) { timelineH.toDp() }.coerceAtLeast(160.dp)
            Box(
                Modifier.align(Alignment.BottomEnd)
                    .then(if (land) Modifier.fillMaxWidth(0.58f) else Modifier.fillMaxWidth())
                    .offset { IntOffset(0, -toolbarH) }
                    .heightIn(max = maxH)
                    .verticalScroll(rememberScrollState()),
            ) { panel() }
        }
    }
}

@Composable
private fun MiniSlider(
    label: String, value: Float, range: ClosedFloatingPointRange<Float>, enabled: Boolean,
    modifier: Modifier = Modifier, onChange: (Float) -> Unit,
) {
    Column(modifier) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        Slider(value = value, onValueChange = onChange, valueRange = range, enabled = enabled)
    }
}

@Composable
private fun LabeledSlider(
    label: String, value: Float, range: ClosedFloatingPointRange<Float>, enabled: Boolean, onChange: (Float) -> Unit,
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.width(52.dp), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Slider(value = value, onValueChange = onChange, valueRange = range, enabled = enabled, modifier = Modifier.weight(1f))
    }
}

/** Pratinjau: kanvas berlatar + video dengan padding/sudut/bayangan (perkiraan dari hasil ekspor). */
@Composable
private fun FramePreview(
    uri: Uri, videoAspect: Float, style: FrameStyle, player: PlayerState, img: Bitmap?, frame: Bitmap?, zooms: List<ZoomRegion>,
    cursorTrack: List<TouchEvent>, timeMs: () -> Float,
    editRegion: ZoomRegion?, onEdit: (fx: Float, fy: Float, scale: Float) -> Unit,
) {
    val canvasAspect = style.aspect ?: videoAspect
    BoxWithConstraints(Modifier.aspectRatio(canvasAspect).clip(RoundedCornerShape(12.dp)).clipToBounds()) {
        BackgroundLayer(style, img, frame)
        val short = min(maxWidth, maxHeight)
        val pad = short * style.padding
        val shape = RoundedCornerShape(short * style.corner)
        // ukuran kanvas (px): diambil di sini, karena `constraints` tidak bisa dipanggil dari lambda graphicsLayer (beda scope)
        val cw = constraints.maxWidth.toFloat()
        val ch = constraints.maxHeight.toFloat()
        // ukuran kartu video (px) untuk pemilih area: kartu muat di dalam kanvas dikurangi padding, rasio = rasio video
        val padPx = with(LocalDensity.current) { pad.toPx() }
        val availW = (cw - 2f * padPx).coerceAtLeast(1f)
        val availH = (ch - 2f * padPx).coerceAtLeast(1f)
        val cardW = if (availW / availH > videoAspect) availH * videoAspect else availW
        val cardH = cardW / videoAspect
        Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.Center) {
            Box(
                Modifier.aspectRatio(videoAspect)
                    .graphicsLayer {
                        // zoom kartu: seluruh bingkai dibesarkan dari pojok kiri-atasnya lalu digeser (rumus sama dengan ekspor)
                        // timeMs() dibaca DI SINI (fase layer): tiap frame hanya layer yang dihitung ulang, bukan seluruh UI
                        val hw = this.size.width / 2f; val hh = this.size.height / 2f
                        val cz = if (editRegion != null) CardZoom.NONE else ZoomMath.camera(zooms, timeMs().toDouble(), CardGeo(cw, ch, cw / 2f, ch / 2f, hw, hh))
                        transformOrigin = TransformOrigin(0f, 0f)
                        scaleX = cz.s
                        scaleY = cz.s
                        translationX = (cz.s - 1f) * (cw / 2f - hw) + cz.tx
                        translationY = (cz.s - 1f) * (ch / 2f - hh) + cz.ty
                    }
                    .graphicsLayer {
                        // kamera 3D: SAMA dengan shader ekspor (uRot/uPers). Kartu diskala `fit` (containment) lalu diputar
                        // R = Rx(pitch) Ry(yaw) Rz(roll); jarak kamera nyata P = 1,6 x sisi terpendek.
                        // graphicsLayer: rotationX/Y/Z = pitch/yaw/roll, scale lebih dulu dari rotasi, cameraDistance = P / 72 (lihat Cam).
                        val hw = this.size.width / 2f; val hh = this.size.height / 2f
                        val cz = if (editRegion != null) CardZoom.NONE else ZoomMath.camera(zooms, timeMs().toDouble(), CardGeo(cw, ch, cw / 2f, ch / 2f, hw, hh), if (style.cursor) cursorTrack else emptyList())
                        if (cz.tilted) {
                            rotationX = cz.pitchDeg
                            rotationY = cz.yawDeg
                            rotationZ = cz.rollDeg
                            scaleX = cz.fit
                            scaleY = cz.fit
                            cameraDistance = Cam.composeCameraDistance(this.size.width, this.size.height)
                        }
                    }
                    .then(if (style.shadow) Modifier.shadow(short * 0.04f, shape) else Modifier)
                    .clip(shape),
            ) {
                // Bingkai di atas sudah clip(shape) dan ikut dibesarkan bersama isinya (zoom kartu, bukan crop isi video).
                VideoSurface(player, Modifier.fillMaxSize())
                // kursor sintetis: di dalam bingkai yang sama, jadi ikut terpotong dan ikut miring (kamera 3D)
                if (style.cursor) Canvas(Modifier.fillMaxSize()) {
                    CursorMath.at(cursorTrack, timeMs().toLong())?.let { drawCursor(it) }
                }
            }
        }
        // pemilih area zoom: di atas SELURUH kanvas (bukan hanya kartu), kartu tampil tanpa zoom.
        // Jendela boleh keluar dari kartu ke area background.
        if (editRegion != null) ZoomAreaOverlay(editRegion, CardGeo(cw, ch, cw / 2f, ch / 2f, cardW / 2f, cardH / 2f), onEdit)
    }
}

@Composable
private fun BackgroundLayer(style: FrameStyle, img: Bitmap?, frame: Bitmap?) {
    when {
        style.bgType == 2 && img != null ->
            Image(img.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        style.bgType == 3 && frame != null ->
            Image(frame.asImageBitmap(), null, Modifier.fillMaxSize().blur(24.dp), contentScale = ContentScale.Crop)
        style.bgType == 1 ->
            Box(
                Modifier.fillMaxSize().drawBehind {
                    drawRect(Color(style.top))
                    val r = size.maxDimension * 0.95f
                    drawRect(Brush.radialGradient(listOf(Color(style.mid), Color.Transparent),
                        center = Offset(size.width * 0.15f, size.height * 0.15f), radius = r))
                    drawRect(Brush.radialGradient(listOf(Color(style.bottom), Color.Transparent),
                        center = Offset(size.width * 0.85f, size.height * 0.85f), radius = r))
                },
            )
        else ->
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(style.top), Color(style.bottom)))))
    }
}

@Composable
private fun Swatch(brush: Brush, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).clip(CircleShape)
            .background(brush)
            .then(if (selected) Modifier.border(3.dp, MaterialTheme.colorScheme.primary, CircleShape)
                  else Modifier.border(1.dp, Color.Gray.copy(alpha = 0.5f), CircleShape))
            .clickable(enabled = enabled, onClick = onClick),
    )
}

@Composable
private fun VideoSurface(state: PlayerState, modifier: Modifier) {
    AndroidView(
        modifier = modifier,
        factory = { c ->
            TextureView(c).apply {
                surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                        state.attach(Surface(st))
                    }

                    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}

                    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                        // pemutar TIDAK dibuang, hanya dilepas dari surface; surface baru dipasang saat tersedia lagi
                        state.detach()
                        return true
                    }

                    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
                }
            }
        },
    )
}
