package com.layarkita

import android.graphics.Bitmap
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.net.Uri
import android.view.Surface
import android.view.TextureView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val PRESETS = listOf(
    0xFF1E3A8A.toInt() to 0xFF7C3AED.toInt(),   // biru-ungu
    0xFFF97316.toInt() to 0xFFDB2777.toInt(),   // sunset
    0xFF059669.toInt() to 0xFF0E7490.toInt(),   // tosca
    0xFF0F172A.toInt() to 0xFF334155.toInt(),   // malam
    0xFFF8FAFC.toInt() to 0xFFCBD5E1.toInt(),   // terang
    0xFF000000.toInt() to 0xFF000000.toInt(),   // hitam
)

private val SOLIDS = listOf(
    0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFF0F172A.toInt(), 0xFF1E293B.toInt(),
    0xFFEF4444.toInt(), 0xFFF97316.toInt(), 0xFFEAB308.toInt(), 0xFF22C55E.toInt(),
    0xFF06B6D4.toInt(), 0xFF3B82F6.toInt(), 0xFF8B5CF6.toInt(), 0xFFEC4899.toInt(),
)

// wallpaper "mesh": warna dasar, warna tengah, warna sudut bawah
private val WALLS = listOf(
    Triple(0xFF0B1026.toInt(), 0xFF22D3AE.toInt(), 0xFF7C3AED.toInt()),   // aurora
    Triple(0xFF2B1055.toInt(), 0xFFFB7185.toInt(), 0xFFFBBF24.toInt()),   // senja
    Triple(0xFF03045E.toInt(), 0xFF0096C7.toInt(), 0xFF90E0EF.toInt()),   // laut
    Triple(0xFF111827.toInt(), 0xFFF472B6.toInt(), 0xFF38BDF8.toInt()),   // neon
    Triple(0xFF052E16.toInt(), 0xFF16A34A.toInt(), 0xFFA3E635.toInt()),   // hutan
    Triple(0xFFFDE68A.toInt(), 0xFFF9A8D4.toInt(), 0xFFA5B4FC.toInt()),   // pastel
)

private val BG_TYPES = listOf("Gradient", "Warna", "Wallpaper", "Gambar", "Blur")

private val ASPECTS = listOf<Pair<String, Float?>>(
    "Asli" to null, "16:9" to 16f / 9f, "9:16" to 9f / 16f, "1:1" to 1f, "4:5" to 4f / 5f,
)

private class PlayerState {
    var mp: MediaPlayer? = null
    var surface: Surface? = null
    var ready by mutableStateOf(false)
    var playing by mutableStateOf(false)
    var positionMs by mutableLongStateOf(0L)

    fun release() {
        ready = false
        playing = false
        try { mp?.release() } catch (_: Exception) {}
        mp = null
        try { surface?.release() } catch (_: Exception) {}
        surface = null
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(uri: Uri, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val player = remember { PlayerState() }
    DisposableEffect(Unit) { onDispose { player.release() } }

    val info by produceState<VideoInfo?>(null, uri) {
        value = withContext(Dispatchers.IO) { Exporter.probe(ctx, uri) }
    }

    var cancel by remember { mutableStateOf<Exporter.Cancel?>(null) }
    BackHandler { cancel?.requested = true; onBack() }

    val vi = info
    if (vi == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }

    val durMs = vi.durationMs.coerceAtLeast(1000L)
    var startMs by remember(uri) { mutableFloatStateOf(0f) }
    var endMs by remember(uri) { mutableFloatStateOf(durMs.toFloat()) }

    var bgUi by remember { mutableIntStateOf(0) }       // 0 gradient, 1 warna, 2 wallpaper, 3 gambar, 4 blur
    var preset by remember { mutableIntStateOf(0) }
    var solid by remember { mutableIntStateOf(0) }
    var wall by remember { mutableIntStateOf(0) }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var blurAmt by remember { mutableFloatStateOf(0.04f) }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u ->
        if (u != null) imageUri = u
    }
    val imgBmp by produceState<Bitmap?>(null, imageUri) {
        val u = imageUri
        value = if (u == null) null else withContext(Dispatchers.IO) { Exporter.loadImage(ctx, u, 1024) }
    }
    val frameBmp by produceState<Bitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) { Exporter.firstFrame(ctx, uri) }
    }
    var padding by remember { mutableFloatStateOf(0.08f) }
    var corner by remember { mutableFloatStateOf(0.03f) }
    var shadow by remember { mutableStateOf(true) }
    var aspectIdx by remember { mutableIntStateOf(0) }

    var exporting by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var resultUri by remember { mutableStateOf<Uri?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    val base = FrameStyle(padding = padding, corner = corner, shadow = shadow, aspect = ASPECTS[aspectIdx].second)
    val style = when (bgUi) {
        1 -> base.copy(top = SOLIDS[solid], bottom = SOLIDS[solid])
        2 -> base.copy(bgType = 1, top = WALLS[wall].first, mid = WALLS[wall].second, bottom = WALLS[wall].third)
        3 -> base.copy(bgType = 2, image = imageUri)
        4 -> base.copy(bgType = 3, blur = blurAmt)
        else -> base.copy(top = PRESETS[preset].first, bottom = PRESETS[preset].second)
    }
    val videoAspect = vi.width.toFloat() / vi.height.toFloat()

    // loop pemutaran di dalam rentang potong
    val curStart by rememberUpdatedState(startMs)
    val curEnd by rememberUpdatedState(endMs)
    LaunchedEffect(Unit) {
        while (true) {
            delay(80)
            val mp = player.mp ?: continue
            if (!player.ready) continue
            try {
                val pos = mp.currentPosition
                player.positionMs = pos.toLong()
                if (player.playing && pos >= curEnd) mp.seekTo(curStart.toLong(), MediaPlayer.SEEK_CLOSEST)
            } catch (_: Exception) {}
        }
    }

    fun seek(ms: Float) {
        try { player.mp?.seekTo(ms.toLong(), MediaPlayer.SEEK_CLOSEST) } catch (_: Exception) {}
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { cancel?.requested = true; onBack() }) { Text("‹ Kembali") }
            Text("Edit video", style = MaterialTheme.typography.titleLarge)
        }

        // ---- preview dengan frame ----
        Box(Modifier.fillMaxWidth().height(360.dp), contentAlignment = Alignment.Center) {
            FramePreview(uri, videoAspect, style, player, imgBmp, frameBmp)
        }

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = {
                val mp = player.mp
                if (mp != null && player.ready) {
                    try {
                        if (player.playing) { mp.pause(); player.playing = false }
                        else {
                            if (mp.currentPosition < startMs || mp.currentPosition >= endMs) seek(startMs)
                            mp.start(); player.playing = true
                        }
                    } catch (_: Exception) {}
                }
            }) { Text(if (player.playing) "Jeda" else "Putar") }
            Text("${Library.fmtTime(player.positionMs)} / ${Library.fmtTime(durMs)}")
        }

        // ---- potong ----
        Text("Potong: ${Library.fmtTime(startMs.toLong())} – ${Library.fmtTime(endMs.toLong())}  (${Library.fmtTime((endMs - startMs).toLong())})",
            style = MaterialTheme.typography.labelLarge)
        RangeSlider(
            value = startMs..endMs,
            onValueChange = { r ->
                var s = r.start
                var e = r.endInclusive
                if (e - s < 500f) { if (s != startMs) s = e - 500f else e = s + 500f }
                s = s.coerceIn(0f, durMs.toFloat()); e = e.coerceIn(0f, durMs.toFloat())
                if (s != startMs) seek(s) else if (e != endMs) seek((e - 500f).coerceAtLeast(s))
                startMs = s; endMs = e
            },
            valueRange = 0f..durMs.toFloat(),
            enabled = !exporting,
        )

        // ---- background ----
        Text("Background", style = MaterialTheme.typography.labelLarge)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BG_TYPES.forEachIndexed { i, label ->
                FilterChip(selected = bgUi == i, onClick = { bgUi = i }, label = { Text(label) }, enabled = !exporting)
            }
        }
        when (bgUi) {
            0 -> Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PRESETS.forEachIndexed { i, (a, b) ->
                    Swatch(Brush.verticalGradient(listOf(Color(a), Color(b))), i == preset, !exporting) { preset = i }
                }
            }
            1 -> Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SOLIDS.forEachIndexed { i, c ->
                    Swatch(Brush.verticalGradient(listOf(Color(c), Color(c))), i == solid, !exporting) { solid = i }
                }
            }
            2 -> Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                WALLS.forEachIndexed { i, w ->
                    Swatch(Brush.linearGradient(listOf(Color(w.first), Color(w.second), Color(w.third))), i == wall, !exporting) { wall = i }
                }
            }
            3 -> Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    enabled = !exporting,
                ) { Text(if (imageUri == null) "Pilih gambar dari galeri" else "Ganti gambar") }
                if (imageUri == null) Text("Belum ada gambar dipilih (sementara dipakai gradient).", style = MaterialTheme.typography.bodySmall)
            }
            4 -> Column {
                Text("Blur diambil dari video itu sendiri. Kekuatan: ${(blurAmt * 1000).toInt()}", style = MaterialTheme.typography.bodySmall)
                Slider(value = blurAmt, onValueChange = { blurAmt = it }, valueRange = 0.01f..0.08f, enabled = !exporting)
                Text("Pratinjau blur hanya perkiraan (di Android < 12 tampil tajam); hasil ekspor tetap blur.", style = MaterialTheme.typography.bodySmall)
            }
        }

        Text("Jarak tepi (padding): ${(padding * 100).toInt()}%", style = MaterialTheme.typography.labelLarge)
        Slider(value = padding, onValueChange = { padding = it }, valueRange = 0f..0.25f, enabled = !exporting)

        Text("Sudut membulat: ${(corner * 1000).toInt()}", style = MaterialTheme.typography.labelLarge)
        Slider(value = corner, onValueChange = { corner = it }, valueRange = 0f..0.10f, enabled = !exporting)

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Bayangan", Modifier.weight(1f))
            Switch(checked = shadow, onCheckedChange = { shadow = it }, enabled = !exporting)
        }

        Text("Rasio", style = MaterialTheme.typography.labelLarge)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ASPECTS.forEachIndexed { i, (label, _) ->
                FilterChip(selected = aspectIdx == i, onClick = { aspectIdx = i }, label = { Text(label) }, enabled = !exporting)
            }
        }

        // ---- ekspor ----
        if (exporting) {
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
            Text("Mengekspor… ${(progress * 100).toInt()}%")
            OutlinedButton(onClick = { cancel?.requested = true }, modifier = Modifier.fillMaxWidth()) { Text("Batal") }
        } else {
            Button(
                onClick = {
                    try { player.mp?.pause(); player.playing = false } catch (_: Exception) {}
                    val c = Exporter.Cancel()
                    cancel = c
                    exporting = true; progress = 0f; resultUri = null; error = null
                    val st = style
                    val s = (startMs * 1000f).toLong()
                    val e = (endMs * 1000f).toLong()
                    scope.launch(Dispatchers.Default) {
                        val out = Exporter.export(ctx, uri, s, e, st, c, { p -> progress = p }, { m -> error = m })
                        withContext(Dispatchers.Main) {
                            exporting = false
                            resultUri = out
                            if (out == null && error == null) error = "Ekspor dibatalkan"
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Ekspor video") }
        }

        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        resultUri?.let { out ->
            Text("Selesai. Tersimpan di Movies/LayarKita.", color = MaterialTheme.colorScheme.primary)
            OutlinedButton(onClick = { Library.share(ctx, out) }, modifier = Modifier.fillMaxWidth()) { Text("Bagikan hasil") }
        }
    }
}

/** Pratinjau: kanvas berlatar + video dengan padding/sudut/bayangan (perkiraan dari hasil ekspor). */
@Composable
private fun FramePreview(uri: Uri, videoAspect: Float, style: FrameStyle, player: PlayerState, img: Bitmap?, frame: Bitmap?) {
    val canvasAspect = style.aspect ?: videoAspect
    BoxWithConstraints(Modifier.aspectRatio(canvasAspect).clipToBounds()) {
        BackgroundLayer(style, img, frame)
        val short = min(maxWidth, maxHeight)
        val pad = short * style.padding
        val shape = RoundedCornerShape(short * style.corner)
        Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.Center) {
            Box(
                Modifier.aspectRatio(videoAspect)
                    .then(if (style.shadow) Modifier.shadow(short * 0.04f, shape) else Modifier)
                    .clip(shape),
            ) {
                VideoSurface(uri, player, Modifier.fillMaxSize())
            }
        }
    }
}

@Composable
private fun BackgroundLayer(style: FrameStyle, img: Bitmap?, frame: Bitmap?) {
    when {
        style.bgType == 2 && img != null ->
            Image(img.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        style.bgType == 3 && frame != null ->
            Image(frame.asImageBitmap(), null, Modifier.fillMaxSize().blur(24.dp), contentScale = ContentScale.Crop)
        style.bgType == 1 ->
            Box(
                Modifier.fillMaxSize().drawBehind {
                    drawRect(Color(style.top))
                    val r = size.maxDimension * 0.95f
                    drawRect(Brush.radialGradient(listOf(Color(style.mid), Color.Transparent),
                        center = Offset(size.width * 0.15f, size.height * 0.15f), radius = r))
                    drawRect(Brush.radialGradient(listOf(Color(style.bottom), Color.Transparent),
                        center = Offset(size.width * 0.85f, size.height * 0.85f), radius = r))
                },
            )
        else ->
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(style.top), Color(style.bottom)))))
    }
}

@Composable
private fun Swatch(brush: Brush, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(CircleShape)
            .background(brush)
            .then(if (selected) Modifier.border(3.dp, MaterialTheme.colorScheme.primary, CircleShape)
                  else Modifier.border(1.dp, Color.Gray.copy(alpha = 0.5f), CircleShape))
            .clickable(enabled = enabled, onClick = onClick),
    )
}

@Composable
private fun VideoSurface(uri: Uri, state: PlayerState, modifier: Modifier) {
    val ctx = LocalContext.current
    AndroidView(
        modifier = modifier,
        factory = { c ->
            TextureView(c).apply {
                surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                        val mp = MediaPlayer()
                        try {
                            val s = Surface(st)
                            state.surface = s
                            mp.setDataSource(ctx, uri)
                            mp.setSurface(s)
                            mp.setOnPreparedListener { state.ready = true; it.seekTo(0) }
                            mp.setOnCompletionListener { state.playing = false }
                            mp.prepareAsync()
                            state.mp = mp
                        } catch (e: Exception) {
                            try { mp.release() } catch (_: Exception) {}
                        }
                    }

                    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}

                    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                        state.release()
                        return true
                    }

                    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
                }
            }
        },
    )
}
