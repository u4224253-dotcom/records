package com.layarkita

import android.graphics.Bitmap
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.net.Uri
import android.view.Surface
import android.view.TextureView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val PRESETS = listOf(
    0xFF1E3A8A.toInt() to 0xFF7C3AED.toInt(),   // biru-ungu
    0xFFF97316.toInt() to 0xFFDB2777.toInt(),   // sunset
    0xFF059669.toInt() to 0xFF0E7490.toInt(),   // tosca
    0xFF0F172A.toInt() to 0xFF334155.toInt(),   // malam
    0xFFF8FAFC.toInt() to 0xFFCBD5E1.toInt(),   // terang
    0xFF000000.toInt() to 0xFF000000.toInt(),   // hitam
)

private val SOLIDS = listOf(
    0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFF0F172A.toInt(), 0xFF1E293B.toInt(),
    0xFFEF4444.toInt(), 0xFFF97316.toInt(), 0xFFEAB308.toInt(), 0xFF22C55E.toInt(),
    0xFF06B6D4.toInt(), 0xFF3B82F6.toInt(), 0xFF8B5CF6.toInt(), 0xFFEC4899.toInt(),
)

// wallpaper "mesh": warna dasar, warna tengah, warna sudut bawah
private val WALLS = listOf(
    Triple(0xFF0B1026.toInt(), 0xFF22D3AE.toInt(), 0xFF7C3AED.toInt()),   // aurora
    Triple(0xFF2B1055.toInt(), 0xFFFB7185.toInt(), 0xFFFBBF24.toInt()),   // senja
    Triple(0xFF03045E.toInt(), 0xFF0096C7.toInt(), 0xFF90E0EF.toInt()),   // laut
    Triple(0xFF111827.toInt(), 0xFFF472B6.toInt(), 0xFF38BDF8.toInt()),   // neon
    Triple(0xFF052E16.toInt(), 0xFF16A34A.toInt(), 0xFFA3E635.toInt()),   // hutan
    Triple(0xFFFDE68A.toInt(), 0xFFF9A8D4.toInt(), 0xFFA5B4FC.toInt()),   // pastel
)

private val BG_TYPES = listOf("Gradient", "Warna", "Wallpaper", "Gambar", "Blur")

private val ASPECTS = listOf<Pair<String, Float?>>(
    "Asli" to null, "16:9" to 16f / 9f, "9:16" to 9f / 16f, "1:1" to 1f, "4:5" to 4f / 5f,
)

private class PlayerState {
    var mp: MediaPlayer? = null
    var surface: Surface? = null
    var ready by mutableStateOf(false)
    var playing by mutableStateOf(false)
    /** Pesan kalau pemutar gagal (ditampilkan di editor), null = normal. */
    var failed by mutableStateOf<String?>(null)
    /** Play ditekan sebelum video siap: mulai otomatis begitu siap. */
    var playWhenReady = false
    /** Pemutaran sudah sampai habis (MediaPlayer ada di keadaan PlaybackCompleted). */
    var completed = false
    var positionMs by mutableLongStateOf(0L)
    /** Posisi pratinjau (ms) yang HALUS: diperbarui tiap frame layar lewat ekstrapolasi, dipakai zoom dan kursor. */
    var smoothMs by mutableFloatStateOf(0f)

    /**
     * Buat MediaPlayer SEKALI per video. Sebelumnya pemutar dibuat/dibuang oleh callback TextureView, sehingga setiap kali
     * TextureView dilepas/dipasang ulang (ganti layout, mode pilih area, dsb.) pemutar ikut dibuang dan Play tidak jalan.
     * Sekarang siklus hidup pemutar terpisah dari surface: surface cukup dipasang ([attach]) atau dilepas ([detach]).
     */
    fun open(ctx: android.content.Context, uri: Uri) {
        release()
        failed = null
        val player = MediaPlayer()
        try {
            player.setDataSource(ctx, uri)
            surface?.let { player.setSurface(it) }
            player.setOnPreparedListener {
                ready = true
                try { it.seekTo(0) } catch (_: Exception) {}
                if (playWhenReady) {
                    playWhenReady = false
                    try { it.start(); playing = true } catch (_: Exception) {}
                }
            }
            player.setOnCompletionListener { playing = false; completed = true }
            player.setOnErrorListener { _, what, extra ->
                ready = false; playing = false
                failed = "Pemutar gagal ($what/$extra)"
                true
            }
            player.prepareAsync()
            mp = player
        } catch (e: Exception) {
            failed = "Video tidak bisa dibuka"
            try { player.release() } catch (_: Exception) {}
        }
    }

    fun attach(s: Surface) {
        surface = s
        try { mp?.setSurface(s) } catch (_: Exception) {}
    }

    fun detach() {
        try { mp?.setSurface(null) } catch (_: Exception) {}
        try { surface?.release() } catch (_: Exception) {}
        surface = null
    }

    fun release() {
        ready = false
        playing = false
        playWhenReady = false
        completed = false
        try { mp?.release() } catch (_: Exception) {}
        mp = null
    }
}

private val TOOLS = listOf("Zoom", "Background", "Bingkai", "Rasio")

@Composable
fun EditorScreen(uri: Uri, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val player = remember { PlayerState() }
    DisposableEffect(Unit) { onDispose { player.release(); player.detach() } }

    val info by produceState<VideoInfo?>(null, uri) {
        value = withContext(Dispatchers.IO) { Exporter.probe(ctx, uri) }
    }

    var cancel by remember { mutableStateOf<Exporter.Cancel?>(null) }
    val back = { cancel?.requested = true; onBack() }
    BackHandler { back() }

    Box(Modifier.fillMaxSize().systemBarsPadding()) {
        val vi = info
        if (vi == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            IconButton(onClick = { back() }, modifier = Modifier.padding(4.dp)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali")
            }
        } else {
            EditorContent(ctx, scope, uri, vi, player, { cancel = it }, cancel, back, Modifier.fillMaxSize())
        }
    }
}

@Composable
private fun EditorContent(
    ctx: android.content.Context,
    scope: kotlinx.coroutines.CoroutineScope,
    uri: Uri,
    vi: VideoInfo,
    player: PlayerState,
    setCancel: (Exporter.Cancel?) -> Unit,
    cancel: Exporter.Cancel?,
    onBack: () -> Unit,
    modifier: Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val durMs = vi.durationMs.coerceAtLeast(1000L)
    DisposableEffect(uri) {
        player.open(ctx, uri)
        onDispose { player.release() }
    }
    var startMs by remember(uri) { mutableFloatStateOf(0f) }
    var endMs by remember(uri) { mutableFloatStateOf(durMs.toFloat()) }

    var tool by remember { mutableIntStateOf(0) }

    var bgUi by remember { mutableIntStateOf(0) }       // 0 gradient, 1 warna, 2 wallpaper, 3 gambar, 4 blur
    var preset by remember { mutableIntStateOf(0) }
    var solid by remember { mutableIntStateOf(0) }
    var wall by remember { mutableIntStateOf(0) }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var blurAmt by remember { mutableFloatStateOf(0.04f) }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u ->
        if (u != null) imageUri = u
    }
    val imgBmp by produceState<Bitmap?>(null, imageUri) {
        val u = imageUri
        value = if (u == null) null else withContext(Dispatchers.IO) { Exporter.loadImage(ctx, u, 1024) }
    }
    val frameBmp by produceState<Bitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) { Exporter.firstFrame(ctx, uri) }
    }
    var padding by remember { mutableFloatStateOf(0.08f) }
    var corner by remember { mutableFloatStateOf(0.03f) }
    var shadow by remember { mutableStateOf(true) }
    var aspectIdx by remember { mutableIntStateOf(0) }

    // ---- zoom ----
    var zooms by remember(uri) { mutableStateOf<List<ZoomRegion>>(emptyList()) }
    var selectedZoom by remember(uri) { mutableStateOf<Int?>(null) }
    var nextZoomId by remember(uri) { mutableIntStateOf(1) }
    var zoomMsg by remember(uri) { mutableStateOf<String?>(null) }
    var areaEdit by remember(uri) { mutableStateOf(false) }   // mode pilih area zoom di pratinjau
    val touches by produceState<List<TouchEvent>>(emptyList(), uri) {
        value = withContext(Dispatchers.IO) {
            val name = Library.nameOf(ctx, uri)
            if (name == null) emptyList() else TouchLog.load(ctx.filesDir, name)
        }
    }

    var exporting by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var resultUri by remember { mutableStateOf<Uri?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    var cursorOn by remember { mutableStateOf(true) }
    // Sumber kursor: data ketukan; kalau rekaman tidak punya (layanan sentuhan mati / elemen tidak terbaca),
    // kursor memakai titik fokus tiap blok zoom, jadi saklar Kursor tetap bisa dipakai.
    val cursorTrack = remember(touches, zooms) {
        if (touches.isNotEmpty()) touches
        else zooms.map { TouchEvent(it.startMs, it.fx.coerceIn(0f, 1f), it.fy.coerceIn(0f, 1f), TouchLog.TAP) }.sortedBy { it.tMs }
    }
    val base = FrameStyle(padding = padding, corner = corner, shadow = shadow, aspect = ASPECTS[aspectIdx].second, cursor = cursorOn && cursorTrack.isNotEmpty())
    val style = when (bgUi) {
        1 -> base.copy(top = SOLIDS[solid], bottom = SOLIDS[solid])
        2 -> base.copy(bgType = 1, top = WALLS[wall].first, mid = WALLS[wall].second, bottom = WALLS[wall].third)
        3 -> base.copy(bgType = 2, image = imageUri)
        4 -> base.copy(bgType = 3, blur = blurAmt)
        else -> base.copy(top = PRESETS[preset].first, bottom = PRESETS[preset].second)
    }
    val videoAspect = vi.width.toFloat() / vi.height.toFloat()

    // loop pemutaran di dalam rentang potong + jam halus untuk zoom/kursor.
    // MediaPlayer.currentPosition kasar dan bisa loncat; zoom yang dibaca darinya (dulu tiap 40 ms) patah-patah.
    // Saat memutar: waktu diekstrapolasi tiap frame layar, lalu dikoreksi pelan-pelan oleh currentPosition.
    val curStart by rememberUpdatedState(startMs)
    val curEnd by rememberUpdatedState(endMs)
    LaunchedEffect(Unit) {
        var est = 0f
        var lastFrameNs = 0L
        var lastSampleNs = 0L
        var ignoreUntilNs = 0L
        while (true) {
            val mp = player.mp
            if (mp == null || !player.ready) { delay(50); continue }
            if (!player.playing) {
                // jeda / scrub: ikuti posisi pemutar apa adanya
                try {
                    val p = mp.currentPosition.toFloat()
                    est = p
                    player.smoothMs = p
                    player.positionMs = p.toLong()
                } catch (_: Exception) {}
                lastFrameNs = 0L
                delay(30)
                continue
            }
            withFrameNanos { now ->
                if (lastFrameNs == 0L) {
                    // frame pertama setelah Play: langsung selaraskan dengan pemutar (tanpa koreksi pelan)
                    lastFrameNs = now; lastSampleNs = 0L
                    try { est = mp.currentPosition.toFloat() } catch (_: Exception) {}
                }
                val dt = ((now - lastFrameNs) / 1_000_000f).coerceIn(0f, 50f)
                lastFrameNs = now
                est += dt
                if (now - lastSampleNs > 50_000_000L && now > ignoreUntilNs) {
                    lastSampleNs = now
                    try {
                        val p = mp.currentPosition.toFloat()
                        if (p >= curEnd) {
                            mp.seekTo(curStart.toLong(), MediaPlayer.SEEK_CLOSEST)
                            est = curStart
                            ignoreUntilNs = now + 200_000_000L   // abaikan pembacaan lama sampai seek selesai
                        } else {
                            val err = p - est
                            est = if (kotlin.math.abs(err) > 250f) p else est + err * 0.15f
                        }
                    } catch (_: Exception) {}
                }
                if (est > curEnd) est = curEnd
                player.smoothMs = est
                // state yang memicu recompose (timeline, teks waktu) cukup ~25 Hz
                if (kotlin.math.abs(est - player.positionMs) >= 40f) player.positionMs = est.toLong()
            }
        }
    }

    fun seek(ms: Float) {
        try { player.mp?.seekTo(ms.toLong(), MediaPlayer.SEEK_CLOSEST) } catch (_: Exception) {}
    }

    fun togglePlay() {
        val mp = player.mp
        if (mp == null) return
        if (!player.ready) {
            // video belum siap: ingat niatnya, mulai otomatis begitu siap
            player.playWhenReady = !player.playWhenReady
            if (player.playWhenReady) areaEdit = false
            return
        }
        try {
            if (player.playing) {
                mp.pause(); player.playing = false
            } else {
                areaEdit = false
                // setelah habis (atau di luar rentang potong) mulai lagi dari awal rentang
                if (player.completed || mp.currentPosition < startMs || mp.currentPosition >= endMs) {
                    mp.seekTo(startMs.toLong(), MediaPlayer.SEEK_CLOSEST)
                }
                player.completed = false
                mp.start(); player.playing = true
            }
        } catch (e: Exception) {
            player.playing = false
            player.failed = "Tidak bisa memutar: ${e.javaClass.simpleName}"
        }
    }

    val doExport: () -> Unit = {
        try { player.mp?.pause(); player.playing = false } catch (_: Exception) {}
        val c = Exporter.Cancel()
        setCancel(c)
        exporting = true; progress = 0f; resultUri = null; error = null
        val st = style
        val zl = zooms
        val tl = cursorTrack
        val s = (startMs * 1000f).toLong()
        val e = (endMs * 1000f).toLong()
        scope.launch(Dispatchers.Default) {
            val out = Exporter.export(ctx, uri, s, e, st, zl, tl, c, { p -> progress = p }, { m -> error = m })
            withContext(Dispatchers.Main) {
                exporting = false
                resultUri = out
                if (out == null && error == null) error = "Ekspor dibatalkan"
            }
        }
    }

    // ---------------------------------------------------------------- bagian-bagian layar
    val topBar: @Composable () -> Unit = {
        Row(
            Modifier.fillMaxWidth().height(52.dp).padding(start = 4.dp, end = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali") }
            Spacer(Modifier.weight(1f))
            if (exporting) {
                Text("${(progress * 100).toInt()}%", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                TextButton(onClick = { cancel?.requested = true }) { Text("Batal") }
            } else {
                resultUri?.let { out ->
                    Text("Tersimpan", style = MaterialTheme.typography.labelLarge, color = cs.primary)
                    IconButton(onClick = { Library.share(ctx, out) }) {
                        Icon(Icons.Default.Share, contentDescription = "Bagikan", tint = cs.primary)
                    }
                }
                Button(
                    onClick = doExport,
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    modifier = Modifier.height(36.dp),
                ) { Text("Ekspor") }
            }
        }
        Box(Modifier.fillMaxWidth().height(2.dp)) {
            if (exporting) LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
        }
        (error ?: player.failed)?.let {
            Text(
                it, style = MaterialTheme.typography.bodySmall, color = cs.error,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 2.dp),
            )
        }
    }

    val preview: @Composable () -> Unit = {
        FramePreview(
            uri, videoAspect, style, player, imgBmp, frameBmp, zooms,
            cursorTrack, { player.smoothMs },
            if (areaEdit) zooms.firstOrNull { it.id == selectedZoom } else null,
        ) { fx, fy, sc ->
            selectedZoom?.let { id -> zooms = ZoomOps.update(zooms, id) { it.copy(fx = fx, fy = fy, scale = sc, auto = false) } }
        }
    }

    val timeline: @Composable () -> Unit = {
        Box(Modifier.padding(horizontal = 16.dp)) {
            TimelineEditor(
                durMs = durMs,
                positionMs = player.positionMs,
                playing = player.playing,
                startMs = startMs,
                endMs = endMs,
                zooms = zooms,
                touches = touches,
                selectedId = selectedZoom,
                enabled = !exporting,
                onSeek = { seek(it.toFloat()) },
                onTrimStart = { v ->
                    val s = v.coerceIn(0f, endMs - 500f)
                    startMs = s; seek(s)
                },
                onTrimEnd = { v ->
                    val e = v.coerceIn(startMs + 500f, durMs.toFloat())
                    endMs = e; seek((e - 500f).coerceAtLeast(startMs))
                },
                onSelect = { id ->
                    selectedZoom = id
                    // di mode pilih area, pindah blok = lompat ke frame awal blok itu
                    if (areaEdit) zooms.firstOrNull { it.id == id }?.let { seek(it.startMs.toFloat()) }
                },
                onZooms = { zooms = it },
                leading = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(
                            Modifier.size(36.dp).clip(CircleShape).background(cs.primary).clickable { togglePlay() },
                            contentAlignment = Alignment.Center,
                        ) { PlayPauseIcon(player.playing, cs.onPrimary, 16.dp) }
                        Text(
                            "${Library.fmtTime(player.positionMs)} / ${Library.fmtTime(durMs)}",
                            style = MaterialTheme.typography.labelLarge,
                            color = cs.onSurfaceVariant,
                        )
                    }
                },
            )
        }
    }

    val tabs: @Composable () -> Unit = {
        Column {
            HorizontalDivider(color = cs.outlineVariant)
            Row(Modifier.fillMaxWidth()) {
                TOOLS.forEachIndexed { i, t ->
                    val on = tool == i
                    Column(
                        Modifier.weight(1f).clickable { tool = i }.padding(top = 10.dp, bottom = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text(
                            t,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (on) cs.onBackground else cs.onSurfaceVariant,
                        )
                        Spacer(Modifier.height(5.dp))
                        Box(Modifier.width(22.dp).height(2.dp).background(if (on) cs.primary else Color.Transparent, RoundedCornerShape(1.dp)))
                    }
                }
            }
        }
    }

    val panel: @Composable () -> Unit = {
        Box(Modifier.fillMaxWidth().height(112.dp).padding(horizontal = 16.dp, vertical = 4.dp)) {
            when (tool) {
                0 -> Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill("Auto-zoom", enabled = !exporting && touches.isNotEmpty()) {
                            val auto = AutoZoom.build(touches, durMs)
                            zooms = auto
                            nextZoomId = (auto.maxOfOrNull { it.id } ?: 0) + 1
                            selectedZoom = null
                            zoomMsg = if (auto.isEmpty()) "Ketukan terlalu sedikit" else null
                        }
                        Pill("+ Zoom", enabled = !exporting) {
                            val added = ZoomOps.add(zooms, ZoomRegion(id = nextZoomId, startMs = 0L, endMs = 0L), player.positionMs, 3000L, durMs)
                            if (added == null) {
                                zoomMsg = "Tidak ada ruang kosong"
                            } else {
                                val newId = nextZoomId
                                zooms = added; selectedZoom = newId; nextZoomId++; zoomMsg = null
                                added.firstOrNull { it.id == newId }?.let { nr ->
                                    try { player.mp?.pause(); player.playing = false } catch (_: Exception) {}
                                    seek(nr.startMs.toFloat())
                                    areaEdit = true
                                }
                            }
                        }
                        Pill("Hapus", enabled = !exporting && selectedZoom != null) {
                            selectedZoom?.let { zooms = ZoomOps.remove(zooms, it); selectedZoom = null; areaEdit = false }
                        }
                        Pill(if (areaEdit) "Selesai" else "Pilih area", selected = areaEdit, enabled = !exporting && selectedZoom != null) {
                            if (areaEdit) areaEdit = false
                            else zooms.firstOrNull { it.id == selectedZoom }?.let { sr ->
                                // jeda dan lompat ke awal blok, supaya yang dipilih adalah frame yang akan di-zoom
                                try { player.mp?.pause(); player.playing = false } catch (_: Exception) {}
                                seek(sr.startMs.toFloat())
                                areaEdit = true
                            }
                        }
                        zooms.firstOrNull { it.id == selectedZoom }?.let { cur ->
                            Seg(
                                listOf("3D mati" to Cam.OFF, "Kiri" to Cam.LEFT, "Kanan" to Cam.RIGHT, "Orbit" to Cam.ORBIT),
                                cur.cam, !exporting,
                            ) { c -> zooms = ZoomOps.update(zooms, cur.id) { it.copy(cam = c) } }
                        }
                    }
                    val sel = zooms.firstOrNull { it.id == selectedZoom }
                    if (sel != null) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            MiniSlider("Skala %.1f×".format(sel.scale), sel.scale, ZoomMath.MIN_SCALE..ZoomMath.MAX_SCALE, !exporting, Modifier.weight(1f)) { v ->
                                zooms = ZoomOps.update(zooms, sel.id) { it.copy(scale = v, auto = false) }
                            }
                            MiniSlider("X", sel.fx, ZoomMath.FOCUS_MIN..ZoomMath.FOCUS_MAX, !exporting, Modifier.weight(1f)) { v ->
                                zooms = ZoomOps.update(zooms, sel.id) { it.copy(fx = v, auto = false) }
                            }
                            MiniSlider("Y", sel.fy, ZoomMath.FOCUS_MIN..ZoomMath.FOCUS_MAX, !exporting, Modifier.weight(1f)) { v ->
                                zooms = ZoomOps.update(zooms, sel.id) { it.copy(fy = v, auto = false) }
                            }
                        }
                    } else {
                        zoomMsg?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant) }
                    }
                }

                1 -> Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        BG_TYPES.forEachIndexed { i, label -> Pill(label, selected = bgUi == i, enabled = !exporting) { bgUi = i } }
                    }
                    when (bgUi) {
                        0 -> Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            PRESETS.forEachIndexed { i, (a, b) ->
                                Swatch(Brush.verticalGradient(listOf(Color(a), Color(b))), i == preset, !exporting) { preset = i }
                            }
                        }
                        1 -> Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            SOLIDS.forEachIndexed { i, c ->
                                Swatch(Brush.verticalGradient(listOf(Color(c), Color(c))), i == solid, !exporting) { solid = i }
                            }
                        }
                        2 -> Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            WALLS.forEachIndexed { i, w ->
                                Swatch(Brush.linearGradient(listOf(Color(w.first), Color(w.second), Color(w.third))), i == wall, !exporting) { wall = i }
                            }
                        }
                        3 -> Row {
                            Pill(if (imageUri == null) "Pilih gambar" else "Ganti gambar", enabled = !exporting) {
                                pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            }
                        }
                        4 -> Slider(value = blurAmt, onValueChange = { blurAmt = it }, valueRange = 0.01f..0.08f, enabled = !exporting)
                    }
                }

                2 -> Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        LabeledSlider("Jarak", padding, 0f..0.25f, !exporting) { padding = it }
                        LabeledSlider("Sudut", corner, 0f..0.10f, !exporting) { corner = it }
                    }
                    Column(Modifier.padding(start = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Bayangan", style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                        Switch(checked = shadow, onCheckedChange = { shadow = it }, enabled = !exporting)
                    }
                    Column(Modifier.padding(start = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Kursor", style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                        Switch(checked = cursorOn, onCheckedChange = { cursorOn = it }, enabled = !exporting)
                        if (cursorOn && cursorTrack.isEmpty()) {
                            Text("Butuh ketukan\natau blok zoom", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                        }
                    }
                }

                else -> Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ASPECTS.forEachIndexed { i, (label, _) -> Pill(label, selected = aspectIdx == i, enabled = !exporting) { aspectIdx = i } }
                }
            }
        }
    }

    BoxWithConstraints(modifier) {
        val land = maxWidth > maxHeight
        Column(Modifier.fillMaxSize()) {
            topBar()
            if (land) {
                Row(Modifier.weight(1f).fillMaxWidth()) {
                    Box(Modifier.weight(0.42f).fillMaxHeight().padding(horizontal = 16.dp, vertical = 4.dp), contentAlignment = Alignment.Center) { preview() }
                    Column(Modifier.weight(0.58f).fillMaxHeight().verticalScroll(rememberScrollState())) {
                        timeline(); tabs(); panel()
                    }
                }
            } else {
                Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp), contentAlignment = Alignment.Center) { preview() }
                timeline(); tabs(); panel()
            }
        }
    }
}

@Composable
private fun MiniSlider(
    label: String, value: Float, range: ClosedFloatingPointRange<Float>, enabled: Boolean,
    modifier: Modifier = Modifier, onChange: (Float) -> Unit,
) {
    Column(modifier) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        Slider(value = value, onValueChange = onChange, valueRange = range, enabled = enabled)
    }
}

@Composable
private fun LabeledSlider(
    label: String, value: Float, range: ClosedFloatingPointRange<Float>, enabled: Boolean, onChange: (Float) -> Unit,
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.width(52.dp), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Slider(value = value, onValueChange = onChange, valueRange = range, enabled = enabled, modifier = Modifier.weight(1f))
    }
}

/** Pratinjau: kanvas berlatar + video dengan padding/sudut/bayangan (perkiraan dari hasil ekspor). */
@Composable
private fun FramePreview(
    uri: Uri, videoAspect: Float, style: FrameStyle, player: PlayerState, img: Bitmap?, frame: Bitmap?, zooms: List<ZoomRegion>,
    cursorTrack: List<TouchEvent>, timeMs: () -> Float,
    editRegion: ZoomRegion?, onEdit: (fx: Float, fy: Float, scale: Float) -> Unit,
) {
    val canvasAspect = style.aspect ?: videoAspect
    BoxWithConstraints(Modifier.aspectRatio(canvasAspect).clip(RoundedCornerShape(12.dp)).clipToBounds()) {
        BackgroundLayer(style, img, frame)
        val short = min(maxWidth, maxHeight)
        val pad = short * style.padding
        val shape = RoundedCornerShape(short * style.corner)
        // ukuran kanvas (px): diambil di sini, karena `constraints` tidak bisa dipanggil dari lambda graphicsLayer (beda scope)
        val cw = constraints.maxWidth.toFloat()
        val ch = constraints.maxHeight.toFloat()
        // ukuran kartu video (px) untuk pemilih area: kartu muat di dalam kanvas dikurangi padding, rasio = rasio video
        val padPx = with(LocalDensity.current) { pad.toPx() }
        val availW = (cw - 2f * padPx).coerceAtLeast(1f)
        val availH = (ch - 2f * padPx).coerceAtLeast(1f)
        val cardW = if (availW / availH > videoAspect) availH * videoAspect else availW
        val cardH = cardW / videoAspect
        Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.Center) {
            Box(
                Modifier.aspectRatio(videoAspect)
                    .graphicsLayer {
                        // zoom kartu: seluruh bingkai dibesarkan dari pojok kiri-atasnya lalu digeser (rumus sama dengan ekspor)
                        // timeMs() dibaca DI SINI (fase layer): tiap frame hanya layer yang dihitung ulang, bukan seluruh UI
                        val hw = this.size.width / 2f; val hh = this.size.height / 2f
                        val cz = if (editRegion != null) CardZoom.NONE else ZoomMath.camera(zooms, timeMs().toDouble(), CardGeo(cw, ch, cw / 2f, ch / 2f, hw, hh))
                        transformOrigin = TransformOrigin(0f, 0f)
                        scaleX = cz.s
                        scaleY = cz.s
                        translationX = (cz.s - 1f) * (cw / 2f - hw) + cz.tx
                        translationY = (cz.s - 1f) * (ch / 2f - hh) + cz.ty
                    }
                    .graphicsLayer {
                        // kamera 3D: rumus dan jarak sama dengan shader ekspor (uTilt)
                        val hw = this.size.width / 2f; val hh = this.size.height / 2f
                        val cz = if (editRegion != null) CardZoom.NONE else ZoomMath.camera(zooms, timeMs().toDouble(), CardGeo(cw, ch, cw / 2f, ch / 2f, hw, hh))
                        if (cz.yawDeg != 0f || cz.pitchDeg != 0f) {
                            rotationY = cz.yawDeg
                            rotationX = cz.pitchDeg
                            cameraDistance = Cam.DIST * this.size.width
                        }
                    }
                    .then(if (style.shadow) Modifier.shadow(short * 0.04f, shape) else Modifier)
                    .clip(shape),
            ) {
                // Bingkai di atas sudah clip(shape) dan ikut dibesarkan bersama isinya (zoom kartu, bukan crop isi video).
                VideoSurface(player, Modifier.fillMaxSize())
                // kursor sintetis: di dalam bingkai yang sama, jadi ikut terpotong dan ikut miring (kamera 3D)
                if (style.cursor) Canvas(Modifier.fillMaxSize()) {
                    CursorMath.at(cursorTrack, timeMs().toLong())?.let { drawCursor(it) }
                }
            }
        }
        // pemilih area zoom: di atas SELURUH kanvas (bukan hanya kartu), kartu tampil tanpa zoom.
        // Jendela boleh keluar dari kartu ke area background.
        if (editRegion != null) ZoomAreaOverlay(editRegion, CardGeo(cw, ch, cw / 2f, ch / 2f, cardW / 2f, cardH / 2f), onEdit)
    }
}

@Composable
private fun BackgroundLayer(style: FrameStyle, img: Bitmap?, frame: Bitmap?) {
    when {
        style.bgType == 2 && img != null ->
            Image(img.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        style.bgType == 3 && frame != null ->
            Image(frame.asImageBitmap(), null, Modifier.fillMaxSize().blur(24.dp), contentScale = ContentScale.Crop)
        style.bgType == 1 ->
            Box(
                Modifier.fillMaxSize().drawBehind {
                    drawRect(Color(style.top))
                    val r = size.maxDimension * 0.95f
                    drawRect(Brush.radialGradient(listOf(Color(style.mid), Color.Transparent),
                        center = Offset(size.width * 0.15f, size.height * 0.15f), radius = r))
                    drawRect(Brush.radialGradient(listOf(Color(style.bottom), Color.Transparent),
                        center = Offset(size.width * 0.85f, size.height * 0.85f), radius = r))
                },
            )
        else ->
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(style.top), Color(style.bottom)))))
    }
}

@Composable
private fun Swatch(brush: Brush, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).clip(CircleShape)
            .background(brush)
            .then(if (selected) Modifier.border(3.dp, MaterialTheme.colorScheme.primary, CircleShape)
                  else Modifier.border(1.dp, Color.Gray.copy(alpha = 0.5f), CircleShape))
            .clickable(enabled = enabled, onClick = onClick),
    )
}

@Composable
private fun VideoSurface(state: PlayerState, modifier: Modifier) {
    AndroidView(
        modifier = modifier,
        factory = { c ->
            TextureView(c).apply {
                surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                        state.attach(Surface(st))
                    }

                    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}

                    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                        // pemutar TIDAK dibuang, hanya dilepas dari surface; surface baru dipasang saat tersedia lagi
                        state.detach()
                        return true
                    }

                    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
                }
            }
        },
    )
}
