package com.layarkita

import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * Satu blok zoom di timeline. Waktu dalam ms pada jam video SUMBER (bukan setelah dipotong).
 * Fokus (fx, fy) = pusat jendela zoom, dinormalisasi pada frame video (0..1, asal kiri-atas). Nilai BOLEH di luar 0..1:
 * itu berarti pusat zoom ada di area background (padding) di luar kartu video. Batas akhirnya: jendela tidak keluar dari KANVAS.
 *
 * [startMs]..[endMs] adalah fase TAHAN (zoom penuh). Transisi masuk selesai tepat di [startMs] dan transisi keluar
 * mulai tepat di [endMs], jadi keduanya berada DI LUAR blok (sama seperti Openscreen). Lamanya: [ZoomMath.transitionMs].
 */
data class ZoomRegion(
    val id: Int,
    val startMs: Long,
    val endMs: Long,
    val scale: Float = 2f,
    val fx: Float = 0.5f,
    val fy: Float = 0.5f,
    val auto: Boolean = false,
    val cam: Int = Cam.OFF,
    /** Sudut kamera bebas (derajat), hanya dipakai kalau [cam] == [Cam.CUSTOM]. yaw + = menghadap kanan, pitch + = menghadap atas. */
    val camYaw: Float = 0f,
    val camPitch: Float = 0f,
    val camRoll: Float = 0f,
)

/** Satu ketukan/ketikan yang tercatat saat merekam. x,y dinormalisasi 0..1 pada layar. */
data class TouchEvent(val tMs: Long, val x: Float, val y: Float, val kind: Int)

/** Geometri kanvas dan kartu video, semua dalam px: kanvas [w]x[h], kartu berpusat di ([cx],[cy]) dengan setengah ukuran [hw],[hh]. */
data class CardGeo(val w: Float, val h: Float, val cx: Float, val cy: Float, val hw: Float, val hh: Float)

/**
 * Kamera "kartu": seluruh bingkai video (padding, sudut membulat, bayangan ikut) dibesarkan [s]x, bukan hanya isinya di-crop.
 * Titik P pada kartu pindah ke s*P + (tx,ty), semua dalam px kanvas.
 * Kamera 3D (konvensi Openscreen, lihat [Cam] dan [CamView]): [pitchDeg] = rot X, [yawDeg] = rot Y, [rollDeg] = rot Z, dan [fit] = skala
 * bidang (containment untuk sudut tetap; fokus/jarak untuk kamera nyata) yang diterapkan SEBELUM rotasi. Titik bidang p = fit*s*(titik kartu)
 * jatuh di `P * (R p + (ox, oy, 0)).xy / (P - (R p).z)` dari titik utama.
 */
data class CardZoom(
    val s: Float, val tx: Float, val ty: Float,
    val yawDeg: Float = 0f, val pitchDeg: Float = 0f, val rollDeg: Float = 0f, val fit: Float = 1f,
    /** Jarak kamera P (px layar, pada kartu yang sudah di-zoom). 0 = turunkan dari ukuran kartu (sudut tetap). */
    val persp: Float = 0f,
    /** Kamera nyata (Orbit): jatuhnya pusat layar di gambar (px layar, relatif titik utama), dipakai SEBELUM pembagian perspektif. */
    val ox: Float = 0f, val oy: Float = 0f,
) {
    /** Ada kemiringan 3D, atau kamera nyata yang menggeser layar, yang harus digambar. */
    val tilted get() = !Cam.Rot(pitchDeg, yawDeg, rollDeg).isFlat || ox != 0f || oy != 0f
    val rot get() = Cam.Rot(pitchDeg, yawDeg, rollDeg)

    companion object {
        val NONE = CardZoom(1f, 0f, 0f)
    }
}

/**
 * Rumus zoom, mengikuti logika Openscreen (zoomRegionUtils.ts / regions.rs). Dipakai SAMA PERSIS oleh pratinjau dan ekspor.
 *
 *  - Kurva: pegas teredam kritis ([spring]): kecepatan awal 0, tanpa overshoot, tiba tepat di 1. Bukan smoothstep.
 *  - Lama transisi bergantung skala: [transitionMs] = 600 + 550*ln(skala) ms.
 *  - Skala diinterpolasi di ruang LOG ([scaleLerp]), titik fokus bergerak LURUS ke posisi akhirnya di layar.
 *  - Posisi akhir dihitung sekali per blok (jepit supaya kartu menutupi kanvas); tidak ada jepit lagi selama transisi,
 *    jadi lintasannya mulus (tanpa patahan kecepatan).
 *  - Dua blok yang jaraknya <= [CHAIN_GAP_MS] disambung: kamera menggeser (pan) selama [CHAIN_PAN_MS], tanpa zoom-out dulu.
 *  - Transisi dua blok yang bertumpuk dicampur dengan bobot kekuatan masing-masing, jadi tidak ada lompatan.
 */
object ZoomMath {
    const val BASE_MS = 600.0
    const val PER_LN_MS = 550.0
    const val CHAIN_GAP_MS = 1500.0   // blok yang jaraknya <= ini disambung dengan pan
    const val CHAIN_PAN_MS = 1000.0   // lama pan antar blok yang tersambung
    const val MIN_LEN_MS = 1000L
    const val MIN_SCALE = 1.2f
    const val MAX_SCALE = 3f
    const val FOCUS_MIN = -1f   // batas slider fokus: boleh di luar kartu (area background)
    const val FOCUS_MAX = 2f

    /** Lama transisi masuk/keluar (ms) untuk skala [scale]: ~0,6 s di 1x, ~0,98 s di 2x, ~1,2 s di 3x. */
    fun transitionMs(scale: Float): Double = BASE_MS + PER_LN_MS * ln(max(1f, scale).toDouble())

    private const val OMEGA_T = 7.0
    private val SPRING_END = 1.0 - (1.0 + OMEGA_T) * exp(-OMEGA_T)

    /** Naik teredam kritis 0..1, dinormalkan supaya tiba persis di 1 pada t=1 (port easeSpring Openscreen). */
    fun spring(t: Double): Double {
        val x = OMEGA_T * t.coerceIn(0.0, 1.0)
        return (1.0 - (1.0 + x) * exp(-x)) / SPRING_END
    }

    /** Skala a..b di ruang log: zoom terasa sebagai rasio, jadi lajunya tidak bergantung level. */
    fun scaleLerp(a: Float, b: Float, t: Float): Float {
        val from = max(a, 1e-3f)
        return from * (max(b, 1e-3f) / from).pow(t)
    }

    // cubic-bezier CSS (Newton + bisection), port cubicBezier Openscreen. Dipakai untuk pan antar blok.
    private fun bz(a1: Double, a2: Double, t: Double): Double {
        val m = 1 - t
        return 3 * a1 * m * m * t + 3 * a2 * m * t * t + t * t * t
    }
    private fun bzd(a1: Double, a2: Double, t: Double): Double {
        val m = 1 - t
        return 3 * a1 * m * m + 6 * (a2 - a1) * m * t + 3 * (1 - a2) * t * t
    }
    fun cubicBezier(x1: Double, y1: Double, x2: Double, y2: Double, t: Double): Double {
        val x = t.coerceIn(0.0, 1.0)
        var s = x
        for (i in 0 until 8) {
            val cx = bz(x1, x2, s) - x
            val d = bzd(x1, x2, s)
            if (kotlin.math.abs(cx) < 1e-6 || kotlin.math.abs(d) < 1e-6) break
            s -= cx / d
        }
        var lo = 0.0; var hi = 1.0
        s = s.coerceIn(0.0, 1.0)
        for (i in 0 until 10) {
            val cx = bz(x1, x2, s)
            if (kotlin.math.abs(cx - x) < 1e-6) break
            if (cx < x) lo = s else hi = s
            s = (lo + hi) / 2
        }
        return bz(y1, y2, s)
    }

    /** Easing pan antar blok tersambung: cubic-bezier(0.1, 0, 0.2, 1) seperti Openscreen. */
    fun panEase(t: Double): Double = cubicBezier(0.1, 0.0, 0.2, 1.0, t)

    // ------------------------------------------------------------------ kamera

    /** Kamera sesaat: titik kanvas ([vx],[vy]) berada di tengah layar, diperbesar [s]x. */
    private class View(
        val s: Float, val vx: Float, val vy: Float, val pitch: Float, val yaw: Float, val roll: Float, val fit: Float,
        val persp: Float = 0f, val ox: Float = 0f, val oy: Float = 0f,
    )

    /** Keadaan akhir (zoom penuh) satu blok. ([fx],[fy]) = titik fokus di kanvas; ([dx],[dy]) = di mana ia berakhir di layar. */
    private class Target(
        val s: Float, val fx: Float, val fy: Float, val dx: Float, val dy: Float, val tx: Float, val ty: Float,
        val cam: Int, val camFx: Float, val camFy: Float, val custom: Cam.Rot = Cam.Rot.FLAT,
    )

    /**
     * Jendela zoom pada KANVAS (0..1 dari lebar/tinggi kanvas, asal kiri-atas): bagian kanvas yang memenuhi layar saat zoom penuh.
     * Persegi (sama [size] di kedua sumbu), boleh sebagian di luar kartu video.
     */
    data class ZoomWindow(val left: Float, val top: Float, val size: Float)

    /** Jendela yang BENAR-BENAR dipakai kamera untuk blok [r] (sudah dijepit), jadi yang digambar pemilih area = hasil zoom. */
    fun window(r: ZoomRegion, g: CardGeo): ZoomWindow {
        val tg = target(r, g)
        return ZoomWindow(-tg.tx / (tg.s * g.w), -tg.ty / (tg.s * g.h), 1f / tg.s)
    }

    /**
     * Fokus (fx, fy) pada frame video untuk pusat jendela di titik kanvas ([px],[py]) (px kanvas), dijepit supaya jendela
     * berskala [scale] tetap di dalam kanvas. Hasilnya boleh di luar 0..1 (di atas background).
     */
    fun focusFromCanvas(px: Float, py: Float, scale: Float, g: CardGeo): Pair<Float, Float> {
        val s = max(scale, 1f)
        val hx = g.w / (2f * s); val hy = g.h / (2f * s)
        val x = px.coerceIn(hx, g.w - hx); val y = py.coerceIn(hy, g.h - hy)
        return ((x - (g.cx - g.hw)) / (2f * g.hw)) to ((y - (g.cy - g.hh)) / (2f * g.hh))
    }

    /**
     * Geser akhir (tx atau ty) sumbu ini: titik fokus [f] (px kanvas) dibawa ke tengah layar, lalu dijepit.
     *  - blok biasa: jendela tetap di dalam kanvas (kanvas yang diperbesar menutupi layar), jadi fokus boleh di luar kartu;
     *  - blok otomatis ([coverCard]): kartu yang diperbesar menutupi kanvas, seperti sebelumnya (background tidak terlihat).
     */
    private fun axisShift(s: Float, len: Float, c: Float, half: Float, f: Float, coverCard: Boolean): Float {
        val free = len / 2f - s * f
        val lo: Float; val hi: Float
        if (coverCard) {
            val a = len - s * (c + half)
            val b = -s * (c - half)
            lo = min(a, b); hi = max(a, b)
        } else {
            lo = min(len * (1f - s), 0f); hi = 0f
        }
        return free.coerceIn(lo, hi)
    }

    private fun target(r: ZoomRegion, g: CardGeo): Target {
        val s = max(r.scale, 1f)
        // titik fokus di kanvas (px); fx/fy di luar 0..1 jatuh di area background
        val fx = g.cx - g.hw + 2f * g.hw * r.fx
        val fy = g.cy - g.hh + 2f * g.hh * r.fy
        val tx = axisShift(s, g.w, g.cx, g.hw, fx, r.auto)
        val ty = axisShift(s, g.h, g.cy, g.hh, fy, r.auto)
        return Target(s, fx, fy, s * fx + tx, s * fy + ty, tx, ty, r.cam, r.fx, r.fy, Cam.customRot(r.camYaw, r.camPitch, r.camRoll))
    }

    /** Zoom penuh. */
    private fun full(tg: Target, g: CardGeo, t: Double, ev: List<TouchEvent>) = partial3d(tg, 1f, g, tg.s, (g.w / 2f - tg.tx) / tg.s, (g.h / 2f - tg.ty) / tg.s, t, ev)

    /** Pointer/bidikan Orbit blok [tg] pada [t]: jejak kursor kalau ada, kalau tidak titik fokus blok (Follow.aimed / Follow.fixed). */
    private fun orbitAim(tg: Target, t: Double, ev: List<TouchEvent>): Follow.Aim =
        Follow.aimed(ev, t, tg.s) ?: Follow.fixed(tg.camFx, tg.camFy, tg.s)

    /**
     * Kamera Orbit nyata (View::new + quad Openscreen) pada bobot [w], zoom sekarang [s] dan bidikan/pointer [f] (belum dibobot).
     * Zoom dan pan ditangani KAMERA: kartu diskala [s] terhadap titik utama (pusat kartu), titik bidik menggeser gambar lewat offset.
     */
    private fun orbitView(g: CardGeo, w: Float, s: Float, f: Follow.Aim): View {
        val pose = CamView.Pose(
            w, CamView.weighted(f.ax, w), CamView.weighted(f.ay, w), CamView.weighted(f.ox, w), CamView.weighted(f.oy, w), s,
        )
        val q = CamView.quad(CamView.view(2f * g.hw * s, 2f * g.hh * s, pose))
        // pusat kartu jatuh di titik utama (CardZoom.tx = (1 - s) * cx), jadi bergeraknya layar sepenuhnya lewat offset kamera
        val vx = (g.w / 2f - (1f - s) * g.cx) / s
        val vy = (g.h / 2f - (1f - s) * g.cy) / s
        return View(s, vx, vy, q.pitchDeg, q.yawDeg, 0f, q.scale, q.focal, q.offX, q.offY)
    }

    /** View dengan kamera 3D blok [tg] pada kekuatan [p]: sudut tetap ~ p; Orbit = kamera nyata pada bobot p. */
    private fun partial3d(tg: Target, p: Float, g: CardGeo, s: Float, vx: Float, vy: Float, t: Double, ev: List<TouchEvent>): View {
        if (tg.cam == Cam.ORBIT) return orbitView(g, p, s, orbitAim(tg, t, ev))
        val rot = Cam.pose(tg.cam, p, tg.custom)
        val fit = Cam.fit(tg.cam, p, 2f * g.hw, 2f * g.hh, tg.custom)
        // P pada kartu yang sudah di-zoom, sama dengan sebelum kamera nyata
        return View(s, vx, vy, rot.x, rot.y, rot.z, fit, Cam.perspectivePx(2f * g.hw * s, 2f * g.hh * s))
    }

    /**
     * Zoom pada kekuatan [p] (0..1): skala di ruang log, dan titik fokus bergerak LURUS dari posisi awalnya ke posisi akhirnya
     * di layar (padanan computeZoomTransform Openscreen).
     */
    private fun partial(tg: Target, p: Float, g: CardGeo, t: Double, ev: List<TouchEvent>): View {
        val s = scaleLerp(1f, tg.s, p)
        val sx = tg.fx + (tg.dx - tg.fx) * p
        val sy = tg.fy + (tg.dy - tg.fy) * p
        val tx = sx - s * tg.fx
        val ty = sy - s * tg.fy
        return partial3d(tg, p, g, s, (g.w / 2f - tx) / s, (g.h / 2f - ty) / s, t, ev)
    }

    private fun lerpView(a: View, b: View, q: Float) = View(
        scaleLerp(a.s, b.s, q), a.vx + (b.vx - a.vx) * q, a.vy + (b.vy - a.vy) * q,
        a.pitch + (b.pitch - a.pitch) * q, a.yaw + (b.yaw - a.yaw) * q, a.roll + (b.roll - a.roll) * q,
        a.fit + (b.fit - a.fit) * q,
        a.persp + (b.persp - a.persp) * q, a.ox + (b.ox - a.ox) * q, a.oy + (b.oy - a.oy) * q,
    )

    /** Kekuatan blok pada [t]: 0 di luar jendela, spring masuk yang tiba tepat di startMs, 1 selama tahan, spring keluar dari endMs. */
    private fun strength(r: ZoomRegion, t: Double): Double {
        val w = transitionMs(r.scale)
        val start = r.startMs.toDouble(); val end = r.endMs.toDouble()
        if (t < start - w || t > end + w) return 0.0
        if (t < start) return spring((t - (start - w)) / w)
        if (t <= end) return 1.0
        return 1.0 - spring((t - end) / w)
    }

    private fun chained(a: ZoomRegion, b: ZoomRegion) = (b.startMs - a.endMs).toDouble() <= CHAIN_GAP_MS

    /**
     * Kamera kartu pada waktu SUMBER [tMs] (ms, boleh pecahan). [regions] harus terurut menurut startMs dan tidak tumpang tindih
     * (dijamin [ZoomOps] dan [AutoZoom]).
     */
    fun camera(regions: List<ZoomRegion>, tMs: Double, g: CardGeo, events: List<TouchEvent> = emptyList()): CardZoom {
        if (regions.isEmpty()) return CardZoom.NONE
        val v = viewAt(regions, tMs, g, events) ?: return CardZoom.NONE
        return CardZoom(v.s, g.w / 2f - v.s * v.vx, g.h / 2f - v.s * v.vy, v.yaw, v.pitch, v.roll, v.fit, v.persp, v.ox, v.oy)
    }

    private fun viewAt(rs: List<ZoomRegion>, t: Double, g: CardGeo, ev: List<TouchEvent>): View? {
        val n = rs.size
        // 1) blok tersambung: pan dari blok ini ke berikutnya, tanpa zoom-out dulu
        for (i in 0 until n - 1) {
            val a = rs[i]; val b = rs[i + 1]
            if (!chained(a, b)) continue
            val ps = a.endMs.toDouble()
            if (t >= ps && t <= ps + CHAIN_PAN_MS) {
                val q = panEase((t - ps) / CHAIN_PAN_MS).toFloat()
                val ta = target(a, g); val tb = target(b, g)
                if (ta.cam == Cam.ORBIT && tb.cam == Cam.ORBIT) {
                    // dua blok Orbit: yang dicampur POSE-nya (zoom di ruang log, bidikan dan pointer linear), lalu satu kamera
                    // (regions.rs: scale_lerp + mix(a.aim, b.aim)); bukan dua kamera jadi yang dicampur
                    val fa = orbitAim(ta, t, ev); val fb = orbitAim(tb, t, ev)
                    val f = Follow.Aim(
                        fa.ax + (fb.ax - fa.ax) * q, fa.ay + (fb.ay - fa.ay) * q, fa.ox + (fb.ox - fa.ox) * q, fa.oy + (fb.oy - fa.oy) * q,
                    )
                    return orbitView(g, 1f, scaleLerp(ta.s, tb.s, q), f)
                }
                return lerpView(full(ta, g, t, ev), full(tb, g, t, ev), q)
            }
        }
        // 2) setelah pan selesai tapi sebelum blok berikutnya resmi mulai: sudah penuh
        for (i in 0 until n - 1) {
            val a = rs[i]; val b = rs[i + 1]
            if (!chained(a, b)) continue
            if (t > a.endMs + CHAIN_PAN_MS && t < b.startMs) return full(target(b, g), g, t, ev)
        }
        // 3) blok mandiri: campur menurut kekuatan (satu blok aktif = kamera blok itu; transisi bertumpuk = campuran mulus)
        var sumW = 0.0
        var lnS = 0.0; var vx = 0.0; var vy = 0.0; var pitch = 0.0; var yaw = 0.0; var roll = 0.0; var fit = 0.0
        var persp = 0.0; var ox = 0.0; var oy = 0.0
        for (i in 0 until n) {
            val r = rs[i]
            val outPast = i + 1 < n && chained(r, rs[i + 1]) && t > r.endMs
            val inEarly = i > 0 && chained(rs[i - 1], r) && t < rs[i - 1].endMs + CHAIN_PAN_MS
            if (outPast || inEarly) continue
            val st = strength(r, t)
            if (st <= 0.0) continue
            val v = partial(target(r, g), st.toFloat(), g, t, ev)
            sumW += st
            lnS += st * ln(v.s.toDouble()); vx += st * v.vx; vy += st * v.vy; pitch += st * v.pitch; yaw += st * v.yaw; roll += st * v.roll; fit += st * v.fit
            persp += st * v.persp; ox += st * v.ox; oy += st * v.oy
        }
        if (sumW <= 0.0) return null
        return View(exp(lnS / sumW).toFloat(), (vx / sumW).toFloat(), (vy / sumW).toFloat(), (pitch / sumW).toFloat(), (yaw / sumW).toFloat(), (roll / sumW).toFloat(), (fit / sumW).toFloat(),
            (persp / sumW).toFloat(), (ox / sumW).toFloat(), (oy / sumW).toFloat(),
        )
    }
}

/** Operasi edit blok zoom: hasil selalu terurut, tidak tumpang tindih, dan berada di dalam [0, durMs]. */
object ZoomOps {

    private fun sorted(l: List<ZoomRegion>) = l.sortedBy { it.startMs }

    /**
     * Tambah blok sepanjang [lenMs] di sekitar [atMs] pada slot kosong terdekat.
     * Mengembalikan null kalau tidak ada ruang kosong minimal [ZoomMath.MIN_LEN_MS].
     */
    fun add(list: List<ZoomRegion>, region: ZoomRegion, atMs: Long, lenMs: Long, durMs: Long): List<ZoomRegion>? {
        val l = sorted(list)
        // celah kosong: [gs, ge]
        val gaps = mutableListOf<Pair<Long, Long>>()
        var cursor = 0L
        for (r in l) {
            if (r.startMs > cursor) gaps += cursor to r.startMs
            cursor = max(cursor, r.endMs)
        }
        if (durMs > cursor) gaps += cursor to durMs
        val usable = gaps.filter { it.second - it.first >= ZoomMath.MIN_LEN_MS }
        if (usable.isEmpty()) return null

        val gap = usable.firstOrNull { atMs >= it.first && atMs <= it.second }
            ?: usable.minByOrNull { g -> if (atMs < g.first) g.first - atMs else atMs - g.second }!!
        val s = max(gap.first, min(atMs, gap.second - ZoomMath.MIN_LEN_MS))
        val e = min(gap.second, s + max(lenMs, ZoomMath.MIN_LEN_MS))
        return sorted(l + region.copy(startMs = s, endMs = e))
    }

    private inline fun edit(list: List<ZoomRegion>, id: Int, f: (r: ZoomRegion, lo: Long, hi: Long) -> ZoomRegion): List<ZoomRegion> {
        val l = sorted(list)
        val i = l.indexOfFirst { it.id == id }
        if (i < 0) return l
        val lo = if (i > 0) l[i - 1].endMs else 0L
        val hi = l.getOrNull(i + 1)?.startMs ?: Long.MAX_VALUE
        return l.toMutableList().also { it[i] = f(l[i], lo, hi) }
    }

    /** Geser seluruh blok (panjang tetap) supaya mulai di [newStart]. */
    fun move(list: List<ZoomRegion>, id: Int, newStart: Long, durMs: Long): List<ZoomRegion> =
        edit(list, id) { r, lo, hi ->
            val len = r.endMs - r.startMs
            val maxStart = min(hi, durMs) - len
            val s = if (maxStart < lo) lo else newStart.coerceIn(lo, maxStart)
            r.copy(startMs = s, endMs = s + len, auto = false)
        }

    fun resizeStart(list: List<ZoomRegion>, id: Int, newStart: Long): List<ZoomRegion> =
        edit(list, id) { r, lo, _ ->
            val maxS = max(lo, r.endMs - ZoomMath.MIN_LEN_MS)
            r.copy(startMs = newStart.coerceIn(lo, maxS), auto = false)
        }

    fun resizeEnd(list: List<ZoomRegion>, id: Int, newEnd: Long, durMs: Long): List<ZoomRegion> =
        edit(list, id) { r, _, hi ->
            val top = min(hi, durMs)
            val minE = min(top, r.startMs + ZoomMath.MIN_LEN_MS)
            r.copy(endMs = newEnd.coerceIn(minE, top), auto = false)
        }

    fun update(list: List<ZoomRegion>, id: Int, f: (ZoomRegion) -> ZoomRegion): List<ZoomRegion> =
        sorted(list.map { if (it.id == id) f(it) else it })

    fun remove(list: List<ZoomRegion>, id: Int): List<ZoomRegion> = sorted(list.filter { it.id != id })
}

/**
 * Membuat blok zoom otomatis dari ketukan, dengan penempatan seperti auto-zoom Openscreen:
 *  - ketukan yang berdekatan waktunya digabung jadi satu cluster,
 *  - zoom sudah PENUH [LEAD_MS] sebelum ketukan pertama dan bertahan [HOLD_MS] setelah yang terakhir (blok = fase tahan;
 *    transisi masuk/keluar ada di luar blok, lihat [ZoomRegion]),
 *  - video dibuka dan ditutup dalam keadaan lebar: transisi tidak dipotong oleh awal/akhir video,
 *  - fokus = tengah sebaran ketukan; skala mengecil kalau sebarannya lebar.
 * Blok yang jaraknya <= [ZoomMath.CHAIN_GAP_MS] otomatis disambung dengan pan (tidak zoom-out lalu masuk lagi).
 */
object AutoZoom {
    const val GAP_MS = 2000L          // jeda maksimum antar ketukan dalam satu cluster
    const val LEAD_MS = 500L          // zoom sudah penuh sekian ms sebelum ketukan pertama
    const val HOLD_MS = 1500L         // zoom bertahan setelah ketukan terakhir
    const val MIN_HOLD_MS = 1500L     // tahan terpendek untuk blok otomatis
    const val EDGE_PAD_MS = 200L      // jarak aman tambahan dari awal/akhir video
    const val FIT = 0.5f              // sebaran maksimum (fraksi layar) yang masih muat dalam satu zoom
    const val MIN_AUTO_SCALE = 1.5f

    private class Cluster(var first: Long, var last: Long, var x0: Float, var x1: Float, var y0: Float, var y1: Float)

    fun build(events: List<TouchEvent>, durMs: Long, baseScale: Float = 2f, firstId: Int = 1): List<ZoomRegion> {
        val evs = events.filter { it.tMs in 0..durMs }.sortedBy { it.tMs }
        if (evs.isEmpty() || durMs < ZoomMath.MIN_LEN_MS) return emptyList()

        val clusters = mutableListOf<Cluster>()
        var cur: Cluster? = null
        for (e in evs) {
            val c = cur
            if (c != null && e.tMs - c.last <= GAP_MS) {
                val nx0 = min(c.x0, e.x); val nx1 = max(c.x1, e.x)
                val ny0 = min(c.y0, e.y); val ny1 = max(c.y1, e.y)
                if (max(nx1 - nx0, ny1 - ny0) <= FIT) {
                    c.last = e.tMs; c.x0 = nx0; c.x1 = nx1; c.y0 = ny0; c.y1 = ny1
                    continue
                }
            }
            cur?.let { clusters += it }
            cur = Cluster(e.tMs, e.tMs, e.x, e.x, e.y, e.y)
        }
        cur?.let { clusters += it }

        val out = mutableListOf<ZoomRegion>()
        var prevCluster: Cluster? = null
        var id = firstId
        for (c in clusters) {
            val spread = max(c.x1 - c.x0, c.y1 - c.y0)
            val scale = if (spread <= 0.001f) baseScale
            else (0.7f / spread).coerceIn(MIN_AUTO_SCALE, baseScale)
            // transisi (di luar blok) tidak boleh keluar dari video: tahan mulai >= lo dan berakhir <= hi
            val w = ZoomMath.transitionMs(scale).toLong()
            val lo = w + EDGE_PAD_MS
            val hi = durMs - w - EDGE_PAD_MS
            var start = max(lo, c.first - LEAD_MS)
            var end = min(hi, c.last + HOLD_MS)

            val prev = out.lastOrNull()
            if (prev != null && start < prev.endMs) {
                // tumpang tindih dengan blok sebelumnya: batas di tengah antara ketukan terakhir lama dan pertama baru
                val boundary = ((prevCluster!!.last + c.first) / 2).coerceIn(prev.startMs, max(prev.startMs, end))
                if (boundary - prev.startMs < MIN_HOLD_MS) {
                    out.removeAt(out.size - 1)        // terlalu pendek: blok yang lebih baru menang
                } else {
                    out[out.size - 1] = prev.copy(endMs = boundary)
                    start = boundary
                }
            }
            val lastEnd = out.lastOrNull()?.endMs ?: 0L
            if (start < lastEnd) start = lastEnd
            if (end - start < MIN_HOLD_MS) end = min(hi, start + MIN_HOLD_MS)
            if (end - start < MIN_HOLD_MS) { prevCluster = c; continue }

            out += ZoomRegion(
                id = id++, startMs = start, endMs = end, scale = scale,
                fx = ((c.x0 + c.x1) / 2f).coerceIn(0f, 1f), fy = ((c.y0 + c.y1) / 2f).coerceIn(0f, 1f),
                auto = true,
            )
            prevCluster = c
        }
        return out
    }
}
