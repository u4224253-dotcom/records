package com.layarkita

import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * Satu blok zoom di timeline. Waktu dalam ms pada jam video SUMBER (bukan setelah dipotong).
 * Fokus (fx, fy) dinormalisasi 0..1 pada frame video, asal kiri-atas.
 *
 * [startMs]..[endMs] adalah fase TAHAN (zoom penuh). Transisi masuk selesai tepat di [startMs] dan transisi keluar
 * mulai tepat di [endMs], jadi keduanya berada DI LUAR blok (sama seperti Openscreen). Lamanya: [ZoomMath.transitionMs].
 */
data class ZoomRegion(
    val id: Int,
    val startMs: Long,
    val endMs: Long,
    val scale: Float = 2f,
    val fx: Float = 0.5f,
    val fy: Float = 0.5f,
    val auto: Boolean = false,
    val cam: Int = Cam.OFF,
)

/** Kamera 3D per blok zoom: bingkai video dimiringkan dengan perspektif (meniru "3D camera" Openscreen). */
object Cam {
    const val OFF = 0
    const val LEFT = 1     // layar menghadap kiri
    const val RIGHT = 2    // layar menghadap kanan
    const val ORBIT = 3    // kamera mengorbit mengikuti titik fokus zoom

    const val DIST = 2.6f          // jarak kamera, dalam lebar bingkai (makin besar = perspektif makin datar)
    const val FIXED_YAW = 18f      // derajat
    const val FIXED_PITCH = 8f
    const val ORBIT_AZIMUTH = 22f  // fokus paling kiri/kanan -> -22 / +22 derajat
    const val ORBIT_EL_MIN = 4f    // elevasi di tepi atas
    const val ORBIT_EL_MAX = 12f   // elevasi di tepi bawah

    /** Pose (yaw, pitch) dalam derajat untuk satu blok. */
    fun pose(r: ZoomRegion): Pair<Float, Float> = when (r.cam) {
        LEFT -> -FIXED_YAW to FIXED_PITCH
        RIGHT -> FIXED_YAW to FIXED_PITCH
        ORBIT -> ((r.fx - 0.5f) * 2f * ORBIT_AZIMUTH) to (ORBIT_EL_MIN + r.fy * (ORBIT_EL_MAX - ORBIT_EL_MIN))
        else -> 0f to 0f
    }
}

/** Satu ketukan/ketikan yang tercatat saat merekam. x,y dinormalisasi 0..1 pada layar. */
data class TouchEvent(val tMs: Long, val x: Float, val y: Float, val kind: Int)

/** Geometri kanvas dan kartu video, semua dalam px: kanvas [w]x[h], kartu berpusat di ([cx],[cy]) dengan setengah ukuran [hw],[hh]. */
data class CardGeo(val w: Float, val h: Float, val cx: Float, val cy: Float, val hw: Float, val hh: Float)

/**
 * Kamera "kartu": seluruh bingkai video (padding, sudut membulat, bayangan ikut) dibesarkan [s]x, bukan hanya isinya di-crop.
 * Titik P pada kartu pindah ke s*P + (tx,ty), semua dalam px kanvas. [yawDeg]/[pitchDeg] = kemiringan kamera 3D.
 */
data class CardZoom(val s: Float, val tx: Float, val ty: Float, val yawDeg: Float = 0f, val pitchDeg: Float = 0f) {
    companion object {
        val NONE = CardZoom(1f, 0f, 0f)
    }
}

/**
 * Rumus zoom, mengikuti logika Openscreen (zoomRegionUtils.ts / regions.rs). Dipakai SAMA PERSIS oleh pratinjau dan ekspor.
 *
 *  - Kurva: pegas teredam kritis ([spring]): kecepatan awal 0, tanpa overshoot, tiba tepat di 1. Bukan smoothstep.
 *  - Lama transisi bergantung skala: [transitionMs] = 600 + 550*ln(skala) ms.
 *  - Skala diinterpolasi di ruang LOG ([scaleLerp]), titik fokus bergerak LURUS ke posisi akhirnya di layar.
 *  - Posisi akhir dihitung sekali per blok (jepit supaya kartu menutupi kanvas); tidak ada jepit lagi selama transisi,
 *    jadi lintasannya mulus (tanpa patahan kecepatan).
 *  - Dua blok yang jaraknya <= [CHAIN_GAP_MS] disambung: kamera menggeser (pan) selama [CHAIN_PAN_MS], tanpa zoom-out dulu.
 *  - Transisi dua blok yang bertumpuk dicampur dengan bobot kekuatan masing-masing, jadi tidak ada lompatan.
 */
object ZoomMath {
    const val BASE_MS = 600.0
    const val PER_LN_MS = 550.0
    const val CHAIN_GAP_MS = 1500.0   // blok yang jaraknya <= ini disambung dengan pan
    const val CHAIN_PAN_MS = 1000.0   // lama pan antar blok yang tersambung
    const val MIN_LEN_MS = 1000L
    const val MIN_SCALE = 1.2f
    const val MAX_SCALE = 3f

    /** Lama transisi masuk/keluar (ms) untuk skala [scale]: ~0,6 s di 1x, ~0,98 s di 2x, ~1,2 s di 3x. */
    fun transitionMs(scale: Float): Double = BASE_MS + PER_LN_MS * ln(max(1f, scale).toDouble())

    private const val OMEGA_T = 7.0
    private val SPRING_END = 1.0 - (1.0 + OMEGA_T) * exp(-OMEGA_T)

    /** Naik teredam kritis 0..1, dinormalkan supaya tiba persis di 1 pada t=1 (port easeSpring Openscreen). */
    fun spring(t: Double): Double {
        val x = OMEGA_T * t.coerceIn(0.0, 1.0)
        return (1.0 - (1.0 + x) * exp(-x)) / SPRING_END
    }

    /** Skala a..b di ruang log: zoom terasa sebagai rasio, jadi lajunya tidak bergantung level. */
    fun scaleLerp(a: Float, b: Float, t: Float): Float {
        val from = max(a, 1e-3f)
        return from * (max(b, 1e-3f) / from).pow(t)
    }

    // cubic-bezier CSS (Newton + bisection), port cubicBezier Openscreen. Dipakai untuk pan antar blok.
    private fun bz(a1: Double, a2: Double, t: Double): Double {
        val m = 1 - t
        return 3 * a1 * m * m * t + 3 * a2 * m * t * t + t * t * t
    }
    private fun bzd(a1: Double, a2: Double, t: Double): Double {
        val m = 1 - t
        return 3 * a1 * m * m + 6 * (a2 - a1) * m * t + 3 * (1 - a2) * t * t
    }
    fun cubicBezier(x1: Double, y1: Double, x2: Double, y2: Double, t: Double): Double {
        val x = t.coerceIn(0.0, 1.0)
        var s = x
        for (i in 0 until 8) {
            val cx = bz(x1, x2, s) - x
            val d = bzd(x1, x2, s)
            if (kotlin.math.abs(cx) < 1e-6 || kotlin.math.abs(d) < 1e-6) break
            s -= cx / d
        }
        var lo = 0.0; var hi = 1.0
        s = s.coerceIn(0.0, 1.0)
        for (i in 0 until 10) {
            val cx = bz(x1, x2, s)
            if (kotlin.math.abs(cx - x) < 1e-6) break
            if (cx < x) lo = s else hi = s
            s = (lo + hi) / 2
        }
        return bz(y1, y2, s)
    }

    /** Easing pan antar blok tersambung: cubic-bezier(0.1, 0, 0.2, 1) seperti Openscreen. */
    fun panEase(t: Double): Double = cubicBezier(0.1, 0.0, 0.2, 1.0, t)

    // ------------------------------------------------------------------ kamera

    /** Kamera sesaat: titik kanvas ([vx],[vy]) berada di tengah layar, diperbesar [s]x. */
    private class View(val s: Float, val vx: Float, val vy: Float, val yaw: Float, val pitch: Float)

    /** Keadaan akhir (zoom penuh) satu blok. ([fx],[fy]) = titik fokus di kanvas; ([dx],[dy]) = di mana ia berakhir di layar. */
    private class Target(val s: Float, val fx: Float, val fy: Float, val dx: Float, val dy: Float, val tx: Float, val ty: Float, val yaw: Float, val pitch: Float)

    private fun target(r: ZoomRegion, g: CardGeo): Target {
        val s = max(r.scale, 1f)
        val size = 1f / s
        // jendela fokus dijepit SEKALI pada skala akhir (clampFocusToScale Openscreen)
        val left = (r.fx - size / 2f).coerceIn(0f, 1f - size)
        val top = (r.fy - size / 2f).coerceIn(0f, 1f - size)
        // geser akhir: jendela fokus memenuhi kartu, lalu dijepit supaya kartu yang membesar menutupi kanvas
        fun axis(len: Float, c: Float, half: Float, l: Float): Float {
            val t = (1f - s) * (c - half) - s * l * 2f * half
            val a = len - s * (c + half)
            val b = -s * (c - half)
            return t.coerceIn(min(a, b), max(a, b))
        }
        val tx = axis(g.w, g.cx, g.hw, left)
        val ty = axis(g.h, g.cy, g.hh, top)
        val fx = g.cx - g.hw + 2f * g.hw * (left + size / 2f)
        val fy = g.cy - g.hh + 2f * g.hh * (top + size / 2f)
        val (yaw, pitch) = Cam.pose(r)
        return Target(s, fx, fy, s * fx + tx, s * fy + ty, tx, ty, yaw, pitch)
    }

    /** Zoom penuh. */
    private fun full(tg: Target, g: CardGeo) = View(tg.s, (g.w / 2f - tg.tx) / tg.s, (g.h / 2f - tg.ty) / tg.s, tg.yaw, tg.pitch)

    /**
     * Zoom pada kekuatan [p] (0..1): skala di ruang log, dan titik fokus bergerak LURUS dari posisi awalnya ke posisi akhirnya
     * di layar (padanan computeZoomTransform Openscreen).
     */
    private fun partial(tg: Target, p: Float, g: CardGeo): View {
        val s = scaleLerp(1f, tg.s, p)
        val sx = tg.fx + (tg.dx - tg.fx) * p
        val sy = tg.fy + (tg.dy - tg.fy) * p
        val tx = sx - s * tg.fx
        val ty = sy - s * tg.fy
        return View(s, (g.w / 2f - tx) / s, (g.h / 2f - ty) / s, tg.yaw * p, tg.pitch * p)
    }

    private fun lerpView(a: View, b: View, q: Float) = View(
        scaleLerp(a.s, b.s, q), a.vx + (b.vx - a.vx) * q, a.vy + (b.vy - a.vy) * q,
        a.yaw + (b.yaw - a.yaw) * q, a.pitch + (b.pitch - a.pitch) * q,
    )

    /** Kekuatan blok pada [t]: 0 di luar jendela, spring masuk yang tiba tepat di startMs, 1 selama tahan, spring keluar dari endMs. */
    private fun strength(r: ZoomRegion, t: Double): Double {
        val w = transitionMs(r.scale)
        val start = r.startMs.toDouble(); val end = r.endMs.toDouble()
        if (t < start - w || t > end + w) return 0.0
        if (t < start) return spring((t - (start - w)) / w)
        if (t <= end) return 1.0
        return 1.0 - spring((t - end) / w)
    }

    private fun chained(a: ZoomRegion, b: ZoomRegion) = (b.startMs - a.endMs).toDouble() <= CHAIN_GAP_MS

    /**
     * Kamera kartu pada waktu SUMBER [tMs] (ms, boleh pecahan). [regions] harus terurut menurut startMs dan tidak tumpang tindih
     * (dijamin [ZoomOps] dan [AutoZoom]).
     */
    fun camera(regions: List<ZoomRegion>, tMs: Double, g: CardGeo): CardZoom {
        if (regions.isEmpty()) return CardZoom.NONE
        val v = viewAt(regions, tMs, g) ?: return CardZoom.NONE
        return CardZoom(v.s, g.w / 2f - v.s * v.vx, g.h / 2f - v.s * v.vy, v.yaw, v.pitch)
    }

    private fun viewAt(rs: List<ZoomRegion>, t: Double, g: CardGeo): View? {
        val n = rs.size
        // 1) blok tersambung: pan dari blok ini ke berikutnya, tanpa zoom-out dulu
        for (i in 0 until n - 1) {
            val a = rs[i]; val b = rs[i + 1]
            if (!chained(a, b)) continue
            val ps = a.endMs.toDouble()
            if (t >= ps && t <= ps + CHAIN_PAN_MS) {
                val q = panEase((t - ps) / CHAIN_PAN_MS).toFloat()
                return lerpView(full(target(a, g), g), full(target(b, g), g), q)
            }
        }
        // 2) setelah pan selesai tapi sebelum blok berikutnya resmi mulai: sudah penuh
        for (i in 0 until n - 1) {
            val a = rs[i]; val b = rs[i + 1]
            if (!chained(a, b)) continue
            if (t > a.endMs + CHAIN_PAN_MS && t < b.startMs) return full(target(b, g), g)
        }
        // 3) blok mandiri: campur menurut kekuatan (satu blok aktif = kamera blok itu; transisi bertumpuk = campuran mulus)
        var sumW = 0.0
        var lnS = 0.0; var vx = 0.0; var vy = 0.0; var yaw = 0.0; var pitch = 0.0
        for (i in 0 until n) {
            val r = rs[i]
            val outPast = i + 1 < n && chained(r, rs[i + 1]) && t > r.endMs
            val inEarly = i > 0 && chained(rs[i - 1], r) && t < rs[i - 1].endMs + CHAIN_PAN_MS
            if (outPast || inEarly) continue
            val st = strength(r, t)
            if (st <= 0.0) continue
            val v = partial(target(r, g), st.toFloat(), g)
            sumW += st
            lnS += st * ln(v.s.toDouble()); vx += st * v.vx; vy += st * v.vy; yaw += st * v.yaw; pitch += st * v.pitch
        }
        if (sumW <= 0.0) return null
        return View(exp(lnS / sumW).toFloat(), (vx / sumW).toFloat(), (vy / sumW).toFloat(), (yaw / sumW).toFloat(), (pitch / sumW).toFloat())
    }
}

/** Operasi edit blok zoom: hasil selalu terurut, tidak tumpang tindih, dan berada di dalam [0, durMs]. */
object ZoomOps {

    private fun sorted(l: List<ZoomRegion>) = l.sortedBy { it.startMs }

    /**
     * Tambah blok sepanjang [lenMs] di sekitar [atMs] pada slot kosong terdekat.
     * Mengembalikan null kalau tidak ada ruang kosong minimal [ZoomMath.MIN_LEN_MS].
     */
    fun add(list: List<ZoomRegion>, region: ZoomRegion, atMs: Long, lenMs: Long, durMs: Long): List<ZoomRegion>? {
        val l = sorted(list)
        // celah kosong: [gs, ge]
        val gaps = mutableListOf<Pair<Long, Long>>()
        var cursor = 0L
        for (r in l) {
            if (r.startMs > cursor) gaps += cursor to r.startMs
            cursor = max(cursor, r.endMs)
        }
        if (durMs > cursor) gaps += cursor to durMs
        val usable = gaps.filter { it.second - it.first >= ZoomMath.MIN_LEN_MS }
        if (usable.isEmpty()) return null

        val gap = usable.firstOrNull { atMs >= it.first && atMs <= it.second }
            ?: usable.minByOrNull { g -> if (atMs < g.first) g.first - atMs else atMs - g.second }!!
        val s = max(gap.first, min(atMs, gap.second - ZoomMath.MIN_LEN_MS))
        val e = min(gap.second, s + max(lenMs, ZoomMath.MIN_LEN_MS))
        return sorted(l + region.copy(startMs = s, endMs = e))
    }

    private inline fun edit(list: List<ZoomRegion>, id: Int, f: (r: ZoomRegion, lo: Long, hi: Long) -> ZoomRegion): List<ZoomRegion> {
        val l = sorted(list)
        val i = l.indexOfFirst { it.id == id }
        if (i < 0) return l
        val lo = if (i > 0) l[i - 1].endMs else 0L
        val hi = l.getOrNull(i + 1)?.startMs ?: Long.MAX_VALUE
        return l.toMutableList().also { it[i] = f(l[i], lo, hi) }
    }

    /** Geser seluruh blok (panjang tetap) supaya mulai di [newStart]. */
    fun move(list: List<ZoomRegion>, id: Int, newStart: Long, durMs: Long): List<ZoomRegion> =
        edit(list, id) { r, lo, hi ->
            val len = r.endMs - r.startMs
            val maxStart = min(hi, durMs) - len
            val s = if (maxStart < lo) lo else newStart.coerceIn(lo, maxStart)
            r.copy(startMs = s, endMs = s + len, auto = false)
        }

    fun resizeStart(list: List<ZoomRegion>, id: Int, newStart: Long): List<ZoomRegion> =
        edit(list, id) { r, lo, _ ->
            val maxS = max(lo, r.endMs - ZoomMath.MIN_LEN_MS)
            r.copy(startMs = newStart.coerceIn(lo, maxS), auto = false)
        }

    fun resizeEnd(list: List<ZoomRegion>, id: Int, newEnd: Long, durMs: Long): List<ZoomRegion> =
        edit(list, id) { r, _, hi ->
            val top = min(hi, durMs)
            val minE = min(top, r.startMs + ZoomMath.MIN_LEN_MS)
            r.copy(endMs = newEnd.coerceIn(minE, top), auto = false)
        }

    fun update(list: List<ZoomRegion>, id: Int, f: (ZoomRegion) -> ZoomRegion): List<ZoomRegion> =
        sorted(list.map { if (it.id == id) f(it) else it })

    fun remove(list: List<ZoomRegion>, id: Int): List<ZoomRegion> = sorted(list.filter { it.id != id })
}

/**
 * Membuat blok zoom otomatis dari ketukan, dengan penempatan seperti auto-zoom Openscreen:
 *  - ketukan yang berdekatan waktunya digabung jadi satu cluster,
 *  - zoom sudah PENUH [LEAD_MS] sebelum ketukan pertama dan bertahan [HOLD_MS] setelah yang terakhir (blok = fase tahan;
 *    transisi masuk/keluar ada di luar blok, lihat [ZoomRegion]),
 *  - video dibuka dan ditutup dalam keadaan lebar: transisi tidak dipotong oleh awal/akhir video,
 *  - fokus = tengah sebaran ketukan; skala mengecil kalau sebarannya lebar.
 * Blok yang jaraknya <= [ZoomMath.CHAIN_GAP_MS] otomatis disambung dengan pan (tidak zoom-out lalu masuk lagi).
 */
object AutoZoom {
    const val GAP_MS = 2000L          // jeda maksimum antar ketukan dalam satu cluster
    const val LEAD_MS = 500L          // zoom sudah penuh sekian ms sebelum ketukan pertama
    const val HOLD_MS = 1500L         // zoom bertahan setelah ketukan terakhir
    const val MIN_HOLD_MS = 1500L     // tahan terpendek untuk blok otomatis
    const val EDGE_PAD_MS = 200L      // jarak aman tambahan dari awal/akhir video
    const val FIT = 0.5f              // sebaran maksimum (fraksi layar) yang masih muat dalam satu zoom
    const val MIN_AUTO_SCALE = 1.5f

    private class Cluster(var first: Long, var last: Long, var x0: Float, var x1: Float, var y0: Float, var y1: Float)

    fun build(events: List<TouchEvent>, durMs: Long, baseScale: Float = 2f, firstId: Int = 1): List<ZoomRegion> {
        val evs = events.filter { it.tMs in 0..durMs }.sortedBy { it.tMs }
        if (evs.isEmpty() || durMs < ZoomMath.MIN_LEN_MS) return emptyList()

        val clusters = mutableListOf<Cluster>()
        var cur: Cluster? = null
        for (e in evs) {
            val c = cur
            if (c != null && e.tMs - c.last <= GAP_MS) {
                val nx0 = min(c.x0, e.x); val nx1 = max(c.x1, e.x)
                val ny0 = min(c.y0, e.y); val ny1 = max(c.y1, e.y)
                if (max(nx1 - nx0, ny1 - ny0) <= FIT) {
                    c.last = e.tMs; c.x0 = nx0; c.x1 = nx1; c.y0 = ny0; c.y1 = ny1
                    continue
                }
            }
            cur?.let { clusters += it }
            cur = Cluster(e.tMs, e.tMs, e.x, e.x, e.y, e.y)
        }
        cur?.let { clusters += it }

        val out = mutableListOf<ZoomRegion>()
        var prevCluster: Cluster? = null
        var id = firstId
        for (c in clusters) {
            val spread = max(c.x1 - c.x0, c.y1 - c.y0)
            val scale = if (spread <= 0.001f) baseScale
            else (0.7f / spread).coerceIn(MIN_AUTO_SCALE, baseScale)
            // transisi (di luar blok) tidak boleh keluar dari video: tahan mulai >= lo dan berakhir <= hi
            val w = ZoomMath.transitionMs(scale).toLong()
            val lo = w + EDGE_PAD_MS
            val hi = durMs - w - EDGE_PAD_MS
            var start = max(lo, c.first - LEAD_MS)
            var end = min(hi, c.last + HOLD_MS)

            val prev = out.lastOrNull()
            if (prev != null && start < prev.endMs) {
                // tumpang tindih dengan blok sebelumnya: batas di tengah antara ketukan terakhir lama dan pertama baru
                val boundary = ((prevCluster!!.last + c.first) / 2).coerceIn(prev.startMs, max(prev.startMs, end))
                if (boundary - prev.startMs < MIN_HOLD_MS) {
                    out.removeAt(out.size - 1)        // terlalu pendek: blok yang lebih baru menang
                } else {
                    out[out.size - 1] = prev.copy(endMs = boundary)
                    start = boundary
                }
            }
            val lastEnd = out.lastOrNull()?.endMs ?: 0L
            if (start < lastEnd) start = lastEnd
            if (end - start < MIN_HOLD_MS) end = min(hi, start + MIN_HOLD_MS)
            if (end - start < MIN_HOLD_MS) { prevCluster = c; continue }

            out += ZoomRegion(
                id = id++, startMs = start, endMs = end, scale = scale,
                fx = ((c.x0 + c.x1) / 2f).coerceIn(0f, 1f), fy = ((c.y0 + c.y1) / 2f).coerceIn(0f, 1f),
                auto = true,
            )
            prevCluster = c
        }
        return out
    }
}
