package com.layarkita

import kotlin.math.max
import kotlin.math.min

/**
 * Satu blok zoom di timeline. Waktu dalam ms pada jam video SUMBER (bukan setelah dipotong).
 * Fokus (fx, fy) dinormalisasi 0..1 pada frame video, asal kiri-atas.
 */
data class ZoomRegion(
    val id: Int,
    val startMs: Long,
    val endMs: Long,
    val scale: Float = 2f,
    val fx: Float = 0.5f,
    val fy: Float = 0.5f,
    val auto: Boolean = false,
)

/** Satu ketukan/ketikan yang tercatat saat merekam. x,y dinormalisasi 0..1 pada layar. */
data class TouchEvent(val tMs: Long, val x: Float, val y: Float, val kind: Int)

/** Keadaan zoom pada satu waktu. [left]/[top]/[size] = jendela crop (0..1) pada video. */
data class ZoomState(val scale: Float, val fx: Float, val fy: Float) {
    val size: Float get() = 1f / max(scale, 1f)
    val left: Float get() = (fx - size / 2f).coerceIn(0f, 1f - size)
    val top: Float get() = (fy - size / 2f).coerceIn(0f, 1f - size)

    companion object {
        val NONE = ZoomState(1f, 0.5f, 0.5f)
    }
}

/** Rumus zoom. Dipakai SAMA PERSIS oleh pratinjau (Compose) dan ekspor (shader), supaya hasilnya cocok. */
object ZoomMath {
    const val EASE_MS = 450L        // lama transisi masuk/keluar di dalam blok
    const val BRIDGE_MS = 120L      // blok yang jaraknya <= ini digeser langsung (pan), tanpa zoom-out dulu
    const val MIN_LEN_MS = 1000L
    const val MIN_SCALE = 1.2f
    const val MAX_SCALE = 3f

    fun smooth(x: Float): Float {
        val t = x.coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    /** [regions] harus terurut menurut startMs dan tidak tumpang tindih. */
    fun at(regions: List<ZoomRegion>, tMs: Long): ZoomState {
        if (regions.isEmpty()) return ZoomState.NONE
        var idx = -1
        for (i in regions.indices) {
            val r = regions[i]
            if (tMs >= r.startMs && tMs <= r.endMs) { idx = i; break }
            // celah sempit (<= BRIDGE_MS) di antara dua blok berurutan: anggap milik blok berikutnya (kIn = 0 => keadaan akhir
            // blok sebelumnya dipertahankan), supaya tidak melompat ke 1x sesaat lalu kembali (kedip)
            val p = regions.getOrNull(i - 1)
            if (p != null && tMs > p.endMs && tMs < r.startMs && r.startMs - p.endMs <= BRIDGE_MS) { idx = i; break }
        }
        if (idx < 0) return ZoomState.NONE

        val r = regions[idx]
        val prev = regions.getOrNull(idx - 1)
        val next = regions.getOrNull(idx + 1)
        val bridgedFrom = if (prev != null && r.startMs - prev.endMs <= BRIDGE_MS) prev else null
        val bridgedNext = next != null && next.startMs - r.endMs <= BRIDGE_MS

        val ramp = min(EASE_MS, (r.endMs - r.startMs) / 2)   // blok pendek: transisi ikut diperpendek
        val kIn = if (ramp <= 0L) 1f else smooth((tMs - r.startMs).toFloat() / ramp)
        val kOut = if (bridgedNext || ramp <= 0L) 1f else smooth((r.endMs - tMs).toFloat() / ramp)

        return if (bridgedFrom != null) {
            // blok berurutan: geser (pan) halus dari fokus/skala blok sebelumnya
            val s = bridgedFrom.scale + (r.scale - bridgedFrom.scale) * kIn
            val x = bridgedFrom.fx + (r.fx - bridgedFrom.fx) * kIn
            val y = bridgedFrom.fy + (r.fy - bridgedFrom.fy) * kIn
            ZoomState(1f + (s - 1f) * kOut, x, y)
        } else {
            ZoomState(1f + (r.scale - 1f) * kIn * kOut, r.fx, r.fy)
        }
    }
}

/** Operasi edit blok zoom: hasil selalu terurut, tidak tumpang tindih, dan berada di dalam [0, durMs]. */
object ZoomOps {

    private fun sorted(l: List<ZoomRegion>) = l.sortedBy { it.startMs }

    /**
     * Tambah blok sepanjang [lenMs] di sekitar [atMs] pada slot kosong terdekat.
     * Mengembalikan null kalau tidak ada ruang kosong minimal [ZoomMath.MIN_LEN_MS].
     */
    fun add(list: List<ZoomRegion>, region: ZoomRegion, atMs: Long, lenMs: Long, durMs: Long): List<ZoomRegion>? {
        val l = sorted(list)
        // celah kosong: [gs, ge]
        val gaps = mutableListOf<Pair<Long, Long>>()
        var cursor = 0L
        for (r in l) {
            if (r.startMs > cursor) gaps += cursor to r.startMs
            cursor = max(cursor, r.endMs)
        }
        if (durMs > cursor) gaps += cursor to durMs
        val usable = gaps.filter { it.second - it.first >= ZoomMath.MIN_LEN_MS }
        if (usable.isEmpty()) return null

        val gap = usable.firstOrNull { atMs >= it.first && atMs <= it.second }
            ?: usable.minByOrNull { g -> if (atMs < g.first) g.first - atMs else atMs - g.second }!!
        val s = max(gap.first, min(atMs, gap.second - ZoomMath.MIN_LEN_MS))
        val e = min(gap.second, s + max(lenMs, ZoomMath.MIN_LEN_MS))
        return sorted(l + region.copy(startMs = s, endMs = e))
    }

    private inline fun edit(list: List<ZoomRegion>, id: Int, f: (r: ZoomRegion, lo: Long, hi: Long) -> ZoomRegion): List<ZoomRegion> {
        val l = sorted(list)
        val i = l.indexOfFirst { it.id == id }
        if (i < 0) return l
        val lo = if (i > 0) l[i - 1].endMs else 0L
        val hi = l.getOrNull(i + 1)?.startMs ?: Long.MAX_VALUE
        return l.toMutableList().also { it[i] = f(l[i], lo, hi) }
    }

    /** Geser seluruh blok (panjang tetap) supaya mulai di [newStart]. */
    fun move(list: List<ZoomRegion>, id: Int, newStart: Long, durMs: Long): List<ZoomRegion> =
        edit(list, id) { r, lo, hi ->
            val len = r.endMs - r.startMs
            val maxStart = min(hi, durMs) - len
            val s = if (maxStart < lo) lo else newStart.coerceIn(lo, maxStart)
            r.copy(startMs = s, endMs = s + len, auto = false)
        }

    fun resizeStart(list: List<ZoomRegion>, id: Int, newStart: Long): List<ZoomRegion> =
        edit(list, id) { r, lo, _ ->
            val maxS = max(lo, r.endMs - ZoomMath.MIN_LEN_MS)
            r.copy(startMs = newStart.coerceIn(lo, maxS), auto = false)
        }

    fun resizeEnd(list: List<ZoomRegion>, id: Int, newEnd: Long, durMs: Long): List<ZoomRegion> =
        edit(list, id) { r, _, hi ->
            val top = min(hi, durMs)
            val minE = min(top, r.startMs + ZoomMath.MIN_LEN_MS)
            r.copy(endMs = newEnd.coerceIn(minE, top), auto = false)
        }

    fun update(list: List<ZoomRegion>, id: Int, f: (ZoomRegion) -> ZoomRegion): List<ZoomRegion> =
        sorted(list.map { if (it.id == id) f(it) else it })

    fun remove(list: List<ZoomRegion>, id: Int): List<ZoomRegion> = sorted(list.filter { it.id != id })
}

/**
 * Membuat blok zoom otomatis dari ketukan. Mirip pendekatan Recordly:
 *  - ketukan yang berdekatan waktunya digabung jadi satu cluster,
 *  - zoom mulai sedikit SEBELUM ketukan pertama dan bertahan sebentar SETELAH ketukan terakhir,
 *  - fokus = tengah sebaran ketukan; skala mengecil kalau sebarannya lebar.
 */
object AutoZoom {
    const val GAP_MS = 2000L      // jeda maksimum antar ketukan dalam satu cluster
    const val LEAD_MS = 600L      // zoom mulai sebelum ketukan pertama
    const val HOLD_MS = 1300L     // zoom bertahan setelah ketukan terakhir
    const val FIT = 0.5f          // sebaran maksimum (fraksi layar) yang masih muat dalam satu zoom
    const val MIN_AUTO_SCALE = 1.5f

    private class Cluster(var first: Long, var last: Long, var x0: Float, var x1: Float, var y0: Float, var y1: Float)

    fun build(events: List<TouchEvent>, durMs: Long, baseScale: Float = 2f, firstId: Int = 1): List<ZoomRegion> {
        val evs = events.filter { it.tMs in 0..durMs }.sortedBy { it.tMs }
        if (evs.isEmpty() || durMs < ZoomMath.MIN_LEN_MS) return emptyList()

        val clusters = mutableListOf<Cluster>()
        var cur: Cluster? = null
        for (e in evs) {
            val c = cur
            if (c != null && e.tMs - c.last <= GAP_MS) {
                val nx0 = min(c.x0, e.x); val nx1 = max(c.x1, e.x)
                val ny0 = min(c.y0, e.y); val ny1 = max(c.y1, e.y)
                if (max(nx1 - nx0, ny1 - ny0) <= FIT) {
                    c.last = e.tMs; c.x0 = nx0; c.x1 = nx1; c.y0 = ny0; c.y1 = ny1
                    continue
                }
            }
            cur?.let { clusters += it }
            cur = Cluster(e.tMs, e.tMs, e.x, e.x, e.y, e.y)
        }
        cur?.let { clusters += it }

        val out = mutableListOf<ZoomRegion>()
        var prevCluster: Cluster? = null
        var id = firstId
        for (c in clusters) {
            val spread = max(c.x1 - c.x0, c.y1 - c.y0)
            val scale = if (spread <= 0.001f) baseScale
            else (0.7f / spread).coerceIn(MIN_AUTO_SCALE, baseScale)
            var start = max(0L, c.first - LEAD_MS)
            var end = min(durMs, c.last + HOLD_MS)

            val prev = out.lastOrNull()
            if (prev != null && start < prev.endMs) {
                // tumpang tindih dengan blok sebelumnya: batas di tengah antara ketukan terakhir lama dan pertama baru
                val boundary = ((prevCluster!!.last + c.first) / 2).coerceIn(prev.startMs, end)
                if (boundary - prev.startMs < ZoomMath.MIN_LEN_MS) {
                    out.removeAt(out.size - 1)        // terlalu pendek: blok yang lebih baru menang
                } else {
                    out[out.size - 1] = prev.copy(endMs = boundary)
                    start = boundary
                }
            }
            if (end - start < ZoomMath.MIN_LEN_MS) end = min(durMs, start + ZoomMath.MIN_LEN_MS)
            if (end - start < ZoomMath.MIN_LEN_MS) start = max(0L, end - ZoomMath.MIN_LEN_MS)
            if (end - start < ZoomMath.MIN_LEN_MS) { prevCluster = c; continue }
            // pastikan tidak menabrak blok sebelumnya setelah penyesuaian durasi minimum
            val lastEnd = out.lastOrNull()?.endMs ?: 0L
            if (start < lastEnd) start = lastEnd
            if (end - start < ZoomMath.MIN_LEN_MS) { prevCluster = c; continue }

            out += ZoomRegion(
                id = id++, startMs = start, endMs = end, scale = scale,
                fx = ((c.x0 + c.x1) / 2f).coerceIn(0f, 1f), fy = ((c.y0 + c.y1) / 2f).coerceIn(0f, 1f),
                auto = true,
            )
            prevCluster = c
        }
        return out
    }
}
