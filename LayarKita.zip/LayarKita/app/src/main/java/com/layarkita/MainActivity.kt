package com.layarkita

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.produceState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Root() } }
    }
}

@Composable
private fun Root() {
    var editing by rememberSaveable { mutableStateOf<Uri?>(null) }
    val e = editing
    if (e != null) EditorScreen(e) { editing = null } else Screen { editing = it }
}

@Composable
private fun Screen(onEdit: (Uri) -> Unit) {
    val ctx = LocalContext.current
    val ui by RecorderService.ui.collectAsState()

    var res by remember { mutableIntStateOf(1080) }
    var fps by remember { mutableIntStateOf(30) }
    var internal by remember { mutableStateOf(true) }
    var mic by remember { mutableStateOf(false) }
    var useInternal by remember { mutableStateOf(false) }   // hasil akhir setelah izin
    var useMic by remember { mutableStateOf(false) }
    var overlayOk by remember { mutableStateOf(Settings.canDrawOverlays(ctx)) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { overlayOk = Settings.canDrawOverlays(ctx) }

    val mediaPerm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE
    var items by remember { mutableStateOf(emptyList<RecItem>()) }
    var tick by remember { mutableIntStateOf(0) }
    var mediaOk by remember { mutableStateOf(granted(ctx, mediaPerm)) }
    val libPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { mediaOk = it; tick++ }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { mediaOk = granted(ctx, mediaPerm); tick++ }
    LaunchedEffect(tick, ui.phase) {
        if (ui.phase == Phase.IDLE) items = withContext(Dispatchers.IO) { Library.list(ctx) }
    }

    val projLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == Activity.RESULT_OK && data != null) {
            ContextCompat.startForegroundService(
                ctx,
                Intent(ctx, RecorderService::class.java).setAction(RecorderService.A_START)
                    .putExtra(RecorderService.X_CODE, r.resultCode)
                    .putExtra(RecorderService.X_DATA, data)
                    .putExtra(RecorderService.X_RES, res)
                    .putExtra(RecorderService.X_FPS, fps)
                    .putExtra(RecorderService.X_INTERNAL, useInternal)
                    .putExtra(RecorderService.X_MIC, useMic),
            )
        }
    }
    val askProjection = {
        projLauncher.launch(ctx.getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent())
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        val rec = granted(ctx, Manifest.permission.RECORD_AUDIO)
        useInternal = internal && rec
        useMic = mic && rec
        askProjection()
    }

    fun start() {
        val need = mutableListOf<String>()
        if ((internal || mic) && !granted(ctx, Manifest.permission.RECORD_AUDIO)) need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 && !granted(ctx, Manifest.permission.POST_NOTIFICATIONS)) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isEmpty()) { useInternal = internal; useMic = mic; askProjection() }
        else permLauncher.launch(need.toTypedArray())
    }

    val idle = ui.phase == Phase.IDLE
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("Layar Kita", style = MaterialTheme.typography.headlineMedium)
        Text(
            when (ui.phase) {
                Phase.IDLE -> "Siap merekam"
                Phase.COUNTDOWN -> "Mulai dalam ${ui.seconds}…"
                Phase.RECORDING -> "● Merekam  %02d:%02d".format(ui.seconds / 60, ui.seconds % 60)
                Phase.PAUSED -> "Dijeda  %02d:%02d".format(ui.seconds / 60, ui.seconds % 60)
                Phase.SAVING -> "Menyimpan…"
            },
            style = MaterialTheme.typography.titleLarge,
        )

        Button(
            onClick = { if (idle) start() else ctx.startService(Intent(ctx, RecorderService::class.java).setAction(RecorderService.A_STOP)) },
            enabled = ui.phase != Phase.SAVING,
            modifier = Modifier.fillMaxWidth(),
        ) { Text(if (idle) "Mulai rekam" else "Stop") }

        ui.msg?.let { Text(it, color = MaterialTheme.colorScheme.primary) }

        Choice("Resolusi", listOf("720p" to 720, "1080p" to 1080, "Asli" to 0), res, idle) { res = it }
        Choice("Frame rate", listOf("30 fps" to 30, "60 fps" to 60), fps, idle) { fps = it }
        SwitchRow("Audio internal (suara dari app lain)", internal, idle) { internal = it }
        SwitchRow("Mikrofon", mic, idle) { mic = it }

        if (!overlayOk) {
            Text("Hitung mundur 3-2-1 butuh izin \"tampil di atas app lain\". Tanpa izin ini rekaman langsung mulai.",
                style = MaterialTheme.typography.bodySmall)
            OutlinedButton(onClick = {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
            }) { Text("Beri izin hitung mundur") }
        }
        Text("Kontrol Jeda/Stop ada di notifikasi. Rotasi layar (portrait/landscape) sebelum mulai; selama merekam ukuran video tetap.",
            style = MaterialTheme.typography.bodySmall)

        // ---- daftar rekaman ----
        Text("Rekaman", style = MaterialTheme.typography.titleLarge)
        if (!mediaOk) {
            Text("Beri izin akses video supaya semua rekaman (termasuk dari versi app sebelumnya) tampil di sini.",
                style = MaterialTheme.typography.bodySmall)
            OutlinedButton(onClick = { libPerm.launch(mediaPerm) }) { Text("Izinkan akses rekaman") }
        }
        if (items.isEmpty()) {
            Text("Belum ada rekaman.", style = MaterialTheme.typography.bodyMedium)
        }
        items.forEach { it ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Thumb(it.uri)
                Column(Modifier.weight(1f)) {
                    Text(it.name, style = MaterialTheme.typography.bodyMedium, maxLines = 1)
                    Text("${Library.fmtTime(it.durationMs)} · ${it.sizeBytes / 1024 / 1024} MB", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { onEdit(it.uri) }) { Text("Edit") }
                        OutlinedButton(onClick = { Library.share(ctx, it.uri) }) { Text("Bagikan") }
                    }
                }
            }
        }
    }
}

@Composable
private fun Thumb(uri: Uri) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, uri) { value = withContext(Dispatchers.IO) { Library.thumbnail(ctx, uri) } }
    Box(Modifier.size(88.dp).clip(RoundedCornerShape(8.dp)).background(Color.LightGray)) {
        bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
    }
}

private fun granted(ctx: android.content.Context, p: String) =
    ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun <T> Choice(title: String, items: List<Pair<String, T>>, sel: T, enabled: Boolean, onPick: (T) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, style = MaterialTheme.typography.labelLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items.forEach { (label, v) ->
                FilterChip(selected = sel == v, onClick = { onPick(v) }, label = { Text(label) }, enabled = enabled)
            }
        }
    }
}

@Composable
private fun SwitchRow(label: String, on: Boolean, enabled: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, Modifier.weight(1f))
        Switch(checked = on, onCheckedChange = onChange, enabled = enabled)
    }
}
