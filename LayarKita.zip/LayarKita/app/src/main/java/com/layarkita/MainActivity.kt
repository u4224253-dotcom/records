package com.layarkita

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.produceState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Root() } }
    }
}

@Composable
private fun Root() {
    var editing by rememberSaveable { mutableStateOf<Uri?>(null) }
    val e = editing
    if (e != null) EditorScreen(e) { editing = null } else Screen { editing = it }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun Screen(onEdit: (Uri) -> Unit) {
    val ctx = LocalContext.current
    val ui by RecorderService.ui.collectAsState()

    var res by remember { mutableIntStateOf(1080) }
    var fps by remember { mutableIntStateOf(30) }
    var orient by remember { mutableIntStateOf(0) }
    var internal by remember { mutableStateOf(true) }
    var mic by remember { mutableStateOf(false) }
    var useInternal by remember { mutableStateOf(false) }   // hasil akhir setelah izin
    var useMic by remember { mutableStateOf(false) }
    var overlayOk by remember { mutableStateOf(Settings.canDrawOverlays(ctx)) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { overlayOk = Settings.canDrawOverlays(ctx) }
    var touchOk by remember { mutableStateOf(TouchService.isEnabled(ctx)) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { touchOk = TouchService.isEnabled(ctx) }

    val mediaPerm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE
    var items by remember { mutableStateOf(emptyList<RecItem>()) }
    var tick by remember { mutableIntStateOf(0) }
    var mediaOk by remember { mutableStateOf(granted(ctx, mediaPerm)) }
    val libPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { mediaOk = it; tick++ }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { mediaOk = granted(ctx, mediaPerm); tick++ }
    LaunchedEffect(tick, ui.phase) {
        if (ui.phase == Phase.IDLE) items = withContext(Dispatchers.IO) { Library.list(ctx) }
    }

    val projLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == Activity.RESULT_OK && data != null) {
            ContextCompat.startForegroundService(
                ctx,
                Intent(ctx, RecorderService::class.java).setAction(RecorderService.A_START)
                    .putExtra(RecorderService.X_CODE, r.resultCode)
                    .putExtra(RecorderService.X_DATA, data)
                    .putExtra(RecorderService.X_RES, res)
                    .putExtra(RecorderService.X_FPS, fps)
                    .putExtra(RecorderService.X_ORIENT, orient)
                    .putExtra(RecorderService.X_INTERNAL, useInternal)
                    .putExtra(RecorderService.X_MIC, useMic),
            )
        }
    }
    val askProjection = {
        projLauncher.launch(ctx.getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent())
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        val rec = granted(ctx, Manifest.permission.RECORD_AUDIO)
        useInternal = internal && rec
        useMic = mic && rec
        askProjection()
    }

    fun start() {
        val need = mutableListOf<String>()
        if ((internal || mic) && !granted(ctx, Manifest.permission.RECORD_AUDIO)) need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 && !granted(ctx, Manifest.permission.POST_NOTIFICATIONS)) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isEmpty()) { useInternal = internal; useMic = mic; askProjection() }
        else permLauncher.launch(need.toTypedArray())
    }

    val idle = ui.phase == Phase.IDLE

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Layar Kita", fontWeight = FontWeight.SemiBold) })
        },
    ) { inner ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(inner),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                StatusCard(
                    phase = ui.phase,
                    seconds = ui.seconds,
                    msg = ui.msg,
                    idle = idle,
                    onToggle = {
                        if (idle) start()
                        else ctx.startService(Intent(ctx, RecorderService::class.java).setAction(RecorderService.A_STOP))
                    },
                )
            }

            item {
                SettingsCard(
                    res = res, onRes = { res = it },
                    orient = orient, onOrient = { orient = it },
                    fps = fps, onFps = { fps = it },
                    internal = internal, onInternal = { internal = it },
                    mic = mic, onMic = { mic = it },
                    enabled = idle,
                )
            }

            if (!overlayOk || !touchOk) {
                item {
                    TipsCard(
                        overlayOk = overlayOk,
                        touchOk = touchOk,
                        onAskOverlay = {
                            ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
                        },
                        onAskTouch = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
                    )
                }
            }

            item { SectionHeader("Rekaman") }

            if (!mediaOk) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                "Beri izin akses video supaya semua rekaman (termasuk dari versi app sebelumnya) tampil di sini.",
                                style = MaterialTheme.typography.bodyMedium,
                            )
                            OutlinedButton(onClick = { libPerm.launch(mediaPerm) }) { Text("Izinkan akses rekaman") }
                        }
                    }
                }
            }

            if (items.isEmpty()) {
                item {
                    Box(Modifier.fillMaxWidth().padding(vertical = 24.dp), contentAlignment = Alignment.Center) {
                        Text("Belum ada rekaman.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            items(items, key = { it.uri.toString() }) { rec ->
                RecordingCard(rec, onEdit = { onEdit(rec.uri) }, onShare = { Library.share(ctx, rec.uri) })
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
}

@Composable
private fun StatusCard(phase: Phase, seconds: Int, msg: String?, idle: Boolean, onToggle: () -> Unit) {
    Card(elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (phase == Phase.RECORDING) {
                    Box(Modifier.size(10.dp).clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.error))
                }
                Text(
                    when (phase) {
                        Phase.IDLE -> "Siap merekam"
                        Phase.COUNTDOWN -> "Mulai dalam ${seconds}…"
                        Phase.RECORDING -> "Merekam  %02d:%02d".format(seconds / 60, seconds % 60)
                        Phase.PAUSED -> "Dijeda  %02d:%02d".format(seconds / 60, seconds % 60)
                        Phase.SAVING -> "Menyimpan…"
                    },
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold,
                )
            }
            Button(
                onClick = onToggle,
                enabled = phase != Phase.SAVING,
                modifier = Modifier.fillMaxWidth(),
                colors = if (idle) ButtonDefaults.buttonColors()
                         else ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
            ) { Text(if (idle) "Mulai rekam" else "Stop", style = MaterialTheme.typography.titleMedium) }
            msg?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary) }
            Text(
                "Kontrol Jeda/Stop ada di notifikasi. Rotasi layar sebelum mulai; selama merekam ukuran video tetap.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SettingsCard(
    res: Int, onRes: (Int) -> Unit,
    orient: Int, onOrient: (Int) -> Unit,
    fps: Int, onFps: (Int) -> Unit,
    internal: Boolean, onInternal: (Boolean) -> Unit,
    mic: Boolean, onMic: (Boolean) -> Unit,
    enabled: Boolean,
) {
    Card {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Text("Pengaturan rekaman", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Choice("Resolusi", listOf("720p" to 720, "1080p" to 1080, "Asli" to 0), res, enabled, onRes)
            Choice("Orientasi video", listOf("Otomatis" to 0, "Portrait" to 1, "Landscape" to 2), orient, enabled, onOrient)
            Choice("Frame rate", listOf("30 fps" to 30, "60 fps" to 60), fps, enabled, onFps)
            HorizontalDivider()
            SwitchRow("Audio internal (suara dari app lain)", internal, enabled, onInternal)
            SwitchRow("Mikrofon", mic, enabled, onMic)
        }
    }
}

@Composable
private fun TipsCard(overlayOk: Boolean, touchOk: Boolean, onAskOverlay: () -> Unit, onAskTouch: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            if (!overlayOk) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Hitung mundur 3-2-1 butuh izin \"tampil di atas app lain\". Tanpa izin ini rekaman langsung mulai.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    OutlinedButton(onClick = onAskOverlay) { Text("Beri izin hitung mundur") }
                }
            }
            if (overlayOk && !touchOk) HorizontalDivider()
            if (touchOk) {
                Text(
                    "Pencatat sentuhan aktif: ketukan saat merekam dipakai untuk Auto-zoom di editor.",
                    style = MaterialTheme.typography.bodySmall,
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Auto-zoom butuh layanan Aksesibilitas \"Layar Kita\" untuk mencatat posisi ketukan saat merekam " +
                            "(isi teks layar tidak dibaca). Kalau tombol di pengaturan abu-abu: Info app > menu ⋮ > " +
                            "Izinkan pengaturan terbatas.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    OutlinedButton(onClick = onAskTouch) { Text("Aktifkan pencatat sentuhan") }
                }
            }
        }
    }
}

@Composable
private fun RecordingCard(item: RecItem, onEdit: () -> Unit, onShare: () -> Unit) {
    Card {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Thumb(item.uri)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(item.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, maxLines = 1)
                Text(
                    "${Library.fmtTime(item.durationMs)} · ${item.sizeBytes / 1024 / 1024} MB",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onEdit, contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp)) { Text("Edit") }
                    OutlinedButton(onClick = onShare, contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp)) { Text("Bagikan") }
                }
            }
        }
    }
}

@Composable
private fun Thumb(uri: Uri) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, uri) { value = withContext(Dispatchers.IO) { Library.thumbnail(ctx, uri) } }
    Box(Modifier.size(72.dp).clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
        bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
    }
}

private fun granted(ctx: android.content.Context, p: String) =
    ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun <T> Choice(title: String, items: List<Pair<String, T>>, sel: T, enabled: Boolean, onPick: (T) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, style = MaterialTheme.typography.labelLarge)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items.forEach { (label, v) ->
                FilterChip(selected = sel == v, onClick = { onPick(v) }, label = { Text(label) }, enabled = enabled)
            }
        }
    }
}

@Composable
private fun SwitchRow(label: String, on: Boolean, enabled: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Switch(checked = on, onCheckedChange = onChange, enabled = enabled)
    }
}
