# Layar Kita (tahap 2)

Perekam layar Android native (Kotlin + Jetpack Compose). Minimal Android 10 (API 29).

## Build
1. Buka folder ini di **Android Studio** (Koala atau lebih baru), tunggu Gradle sync.
2. Sambungkan HP (USB debugging) lalu Run. Atau: Build > Build APK(s).

## Tampilan (v0.5)
- Layar utama dan editor dibuat ulang: datar tanpa card, muat satu layar (tanpa scroll halaman), potret dan lanskap
- Pengaturan (ikon gir di layar utama): tampilan Sistem / Terang / Gelap, plus pengaturan rekaman

## Fitur tahap 1
- Mulai / Jeda / Lanjut / Stop (Jeda dan Stop lewat notifikasi)
- Hitung mundur 3-2-1 (butuh izin overlay; tanpa izin langsung mulai)
- Audio internal (AudioPlaybackCapture) + mikrofon, dicampur
- Resolusi 720p / 1080p / asli, 30 / 60 fps
- Simpan otomatis ke galeri: Movies/LayarKita/*.mp4

## Fitur tahap 2 (editor)
- Daftar rekaman di layar utama (Movies/LayarKita), tombol Edit dan Bagikan
- Editor: pratinjau langsung, **potong (trim)**, **background** (gradient, warna solid, wallpaper mesh, gambar dari galeri, blur dari video), padding, sudut membulat, bayangan, rasio kanvas (Asli/16:9/9:16/1:1/4:5)
- Ekspor ke MP4 baru (video di-render ulang lewat OpenGL, audio disalin tanpa re-encode)

## HUD melayang (v0.6)
Bar kontrol gelap membulat yang tampil di atas app mana pun, untuk mulai merekam tanpa membuka Layar Kita.
- Buka lewat tombol **HUD** di layar utama (butuh izin overlay). Tutup lewat tombol X atau aksi "Tutup" di notifikasi.
- Tampilan dan susunan mengikuti HUD Recordly: tombol **Rekam** bulat merah, chip sumber (ikon monitor + resolusi; ketuk = ganti 720p / 1080p / Asli), toggle audio internal, toggle mikrofon, **Home** (buka daftar rekaman, rekaman terbaru di paling atas untuk di-edit), dan tutup. Seluruh bar bisa digeser.
- Saat mikrofon aktif muncul panel di atas bar: dropdown pilih perangkat mic + 5 titik level suara.
- **HUD hilang total begitu Rekam ditekan** (tidak pernah ikut terekam). Selama merekam, kontrol Jeda/Stop lewat notifikasi. Setelah rekaman tersimpan HUD muncul lagi di posisi yang sama.
- Pengaturan (resolusi, audio, mic, perangkat mic, posisi HUD) dibagi dengan layar utama lewat `RecPrefs`.
- Dialog izin rekam layar dibuka lewat `CaptureActivity` (transparan), karena hanya Activity yang bisa meminta izin itu.

## Zoom halus (v0.9)
Logika zoom disamakan dengan Openscreen (`zoomRegionUtils.ts`, `regions.rs`), supaya gerak kamera mulus (sebelumnya terasa bergejolak):
- **Blok = fase tahan.** Transisi masuk selesai tepat di awal blok, transisi keluar mulai tepat di akhir blok (keduanya di luar blok).
- **Kurva = pegas teredam kritis** (kecepatan awal 0, tanpa overshoot, tiba tepat di 1), bukan smoothstep. Lama transisi bergantung skala: `600 + 550·ln(skala)` ms (~1 detik di 2x).
- **Skala diinterpolasi di ruang log**; titik fokus bergerak lurus ke posisi akhirnya. Posisi akhir dijepit sekali per blok (kartu menutupi kanvas), tidak ada jepit lagi selama transisi, jadi tidak ada patahan kecepatan.
- **Blok berjarak <= 1,5 detik disambung** dengan pan 1 detik (easing `cubic-bezier(0.1, 0, 0.2, 1)`), tanpa zoom-out lalu masuk lagi. Transisi yang bertumpuk dicampur menurut kekuatannya, tanpa lompatan.
- **Pratinjau memakai jam per frame layar**: posisi pemutar diekstrapolasi tiap frame dan dikoreksi pelan-pelan oleh `currentPosition` (dulu dibaca tiap 40 ms langsung). Zoom dan kursor dibaca di fase gambar, jadi tidak membuat seluruh UI recompose tiap frame.

## Wallpaper foto (v0.9.2)
Tab Background > **Foto**: 18 wallpaper bawaan + tombol **Galeri** untuk gambar sendiri. File ada di `res/raw/wallpaper1..18.jpg` (diperkecil ke 1600 px, total ~1,4 MB), dipakai lewat Uri `android.resource://`, jadi pratinjau dan ekspor memakai jalur gambar yang sama. Sumber: `public/wallpapers` di [Openscreen](https://github.com/getopenscreen/openscreen) (lisensi kode MIT; asal tiap foto tidak didokumentasikan di repo itu).

## Pemutar pratinjau (v0.9.2)
Bug Play di editor: `MediaPlayer` dulu dibuat dan dibuang oleh callback `TextureView`, jadi setiap `TextureView` dilepas/dipasang ulang pemutar ikut dibuang dan Play tidak jalan. Sekarang `PlayerState.open` membuat pemutar sekali per video (`DisposableEffect(uri)`), dan `TextureView` hanya memasang/melepas surface (`attach`/`detach`). Play sebelum video siap diingat (`playWhenReady`), Play setelah video habis mulai lagi dari awal rentang potong, dan kegagalan pemutar tampil sebagai pesan di bar atas.

## Pilih area zoom manual (v0.9.1, diperluas di v0.9.2)
Untuk rekaman tanpa data ketukan (atau data yang kurang akurat), area zoom dipilih langsung di pratinjau:
1. Editor > Zoom > **+ Zoom** (atau pilih blok di timeline lalu **Pilih area**). Video dijeda di awal blok dan tampil tanpa zoom.
2. Persegi panjang putih = bagian **kanvas** yang akan memenuhi layar saat zoom penuh; di luarnya digelapkan. **Geser** untuk memindah, **cubit** untuk ubah skala, **ketuk** untuk menaruh pusat di titik itu.
3. **Selesai** (atau tekan Play) untuk melihat hasil zoom. Slider Skala/X/Y tetap ada untuk koreksi halus.

**v0.9.2: seleksi ke seluruh kanvas.** Pemilih area kini dipasang di atas seluruh kanvas (bukan di dalam kartu video), jadi jendela boleh keluar dari kartu ke area background. Ketentuan:
- Fokus (`fx`,`fy`) tetap dinormalisasi pada frame video, tetapi **boleh di luar 0..1** (di atas background). Jendela hanya dijepit supaya tidak keluar dari **kanvas** (`ZoomMath.focusFromCanvas`, `axisShift`).
- Jendela yang digambar = jendela yang dipakai kamera (`ZoomMath.window(region, geo)`), termasuk saat ada padding (sebelumnya jendela digambar terhadap kartu sehingga lebih kecil dari hasil zoom yang sebenarnya).
- Blok **otomatis** (dari ketukan) tetap memakai aturan lama: kartu menutupi kanvas, background tidak terlihat. Begitu blok diedit manual (`auto=false`), aturan kanvas yang berlaku.
- Slider X/Y diperlebar ke `-1..2`. Kamera 3D mode Orbit dan kursor sintetis menjepit fokus ke 0..1.
Komponen: `ZoomArea.kt` (overlay), `ZoomMath.window` / `ZoomMath.focusFromCanvas` (jendela yang digambar = jendela yang dipakai kamera).

## Fitur tahap 3 (zoom otomatis)
- **Timeline** di editor: ruler, baris video dengan handle potong, penanda sentuhan, dan baris blok zoom (geser badan = pindah, geser tepi = ubah panjang)
- **Auto-zoom dari ketukan**: ketukan yang berdekatan digabung jadi satu blok; zoom sudah penuh 0,5 detik sebelum ketukan pertama dan bertahan 1,5 detik setelah yang terakhir; fokus = tengah sebaran ketukan. Video dibuka dan ditutup dalam keadaan lebar
- Blok zoom bisa ditambah/dihapus manual, skala dan fokusnya diatur dengan slider
- Pratinjau dan ekspor memakai rumus yang sama (`ZoomMath.camera`), jadi hasil ekspor cocok dengan pratinjau
- **Zoom kartu** (v0.8.1): yang membesar adalah seluruh bingkai video (padding, sudut membulat, bayangan ikut), bukan hanya isinya di-crop di dalam bingkai yang diam, seperti di Openscreen. Saat zoom cukup besar kartu menutupi kanvas sehingga background tidak terlihat (`ZoomMath.cardZoom`)
- Data ketukan dicatat oleh layanan Aksesibilitas "Layar Kita (penanda sentuhan)" selama merekam dan disimpan di folder privat app (`touch/<nama-video>.csv`)

### Mengaktifkan pencatat sentuhan
1. Di layar utama tekan **Aktifkan pencatat sentuhan**, lalu nyalakan "Layar Kita" di Pengaturan > Aksesibilitas.
2. Jika tombolnya abu-abu (APK di-sideload, Android 13+): Info app > menu ⋮ > **Izinkan pengaturan terbatas**, lalu ulangi langkah 1.
3. Rekam seperti biasa. Di editor, tombol **Auto-zoom** aktif kalau rekaman punya data ketukan.

Layanan ini hanya membaca posisi (kotak) elemen yang diketuk, bukan isi teks layar, dan hanya mencatat saat rekaman berjalan.

## Kamera 3D dan kursor (v0.8)
- **Kamera 3D** per blok zoom (editor > Zoom > pilih blok): Mati / Kiri / Kanan / Orbit. Bingkai video dimiringkan dengan perspektif; Orbit memakai titik fokus zoom (X/Y). Pratinjau memakai `graphicsLayer`, ekspor memakai shader (`uTilt`). Efek ini terinspirasi fitur "3D camera" Openscreen (kodenya tidak disalin).
- **Kursor sintetis** (editor > Bingkai > Kursor). Saklar selalu bisa ditekan; kalau rekaman tidak punya data ketukan, kursor memakai titik fokus tiap blok zoom: panah + riak ketukan yang meluncur dari ketukan ke ketukan, dibuat dari data ketukan (`CursorMath` di `Cursor.kt`). Posisi = titik tengah elemen yang diketuk, jalur di antara ketukan adalah perkiraan, bukan gerakan jari asli. Ikut miring bersama bingkai di mode 3D.

## Editor baru, tahap 1 (v0.10.0)
Tampilan editor mengikuti referensi (gelap, datar, tanpa bayangan di UI):
- Editor selalu gelap (palet `EditorColors` di `Editor.kt`), terpisah dari pilihan tema aplikasi.
- Top bar: tombol kembali bulat, judul rekaman + rasio, tombol **Ekspor** oranye.
- Kartu player berbentuk pil di bawah pratinjau: waktu sekarang, tombol Play besar, durasi total.
- Toolbar ikon di paling bawah (Zoom, Background, Bingkai, Rasio); panel opsi tool ada tepat di atasnya.

## Editor baru, tahap 2 (v0.10.1)
Kartu player dilengkapi seperti referensi:
- Kiri: **layar penuh** (menyembunyikan timeline, panel, dan toolbar supaya pratinjau selebar mungkin; Back keluar dari mode ini) dan **mute**. Mute hanya memengaruhi pratinjau; hasil ekspor tetap membawa audio asli.
- Tengah: Play besar. Kanan: **undo** dan **redo**.
- Undo/redo mencatat semua perubahan editor (blok zoom, potongan, background, bingkai, rasio, kursor). Perubahan beruntun digabung per 350 ms (geser slider = satu langkah), maksimal 60 langkah.
- Notifikasi kecil di pojok kiri bawah pratinjau: Zoom ditambahkan / dihapus, Auto-zoom dibuat, Dibatalkan, Diulangi.
- Waktu "sekarang / total" dipindah ke atas timeline.

## Editor baru, tahap 3: timeline (v0.10.2)
`Timeline.kt` ditulis ulang mengikuti referensi:
- **Klip video berthumbnail** (16 potongan, diambil dengan `MediaMetadataRetriever`), sudut membulat. Bagian di luar potongan digelapkan; handle potong putih dengan garis grip di kedua ujung.
- **Gelombang suara asli** di bawah klip (audio AAC diurai dengan `MediaCodec`, hasilnya puncak amplitudo). Bagian dalam potongan berwarna aksen, di luarnya redup. Video lebih dari 20 menit melewati langkah ini.
- **Playhead putih** dengan bulatan di atas, ruler tipis tanpa kotak latar.
- **Tombol + teal** di kanan klip: menambah blok zoom di posisi playhead (sama dengan "+ Zoom" di panel).
- Baris Sentuh hanya muncul kalau rekaman punya data ketukan. Tanpa label kolom, jadi timeline lebih lebar. Tombol zoom timeline (− dan +) jadi bulat dan datar.

## Editor baru, tahap 4: panel tool (v0.10.3)
- Panel opsi tool kini **bottom sheet**: tertutup saat editor dibuka, sehingga pratinjau memakai hampir seluruh ruang tengah. Ketuk ikon di toolbar untuk membuka, ketuk lagi (atau tombol X, atau Back) untuk menutup. Tinggi mengikuti isi, tidak lagi dikunci 112 dp.
- Menambah blok zoom (tombol + di timeline atau "+ Zoom") otomatis membuka panel Zoom.
- Layar penuh (kartu player) menyembunyikan timeline, panel, dan toolbar.

## Struktur
- `Cursor.kt`          kursor sintetis dari ketukan: `CursorMath` + gambar panah/riak untuk pratinjau
- `ZoomModel.kt`       blok zoom, kamera zoom (`ZoomMath.camera`: pegas, log-scale, pan antar blok), operasi edit (`ZoomOps`), pembuat zoom otomatis (`AutoZoom`)
- `ZoomArea.kt`        pemilih area zoom di atas seluruh kanvas pratinjau (geser/cubit/ketuk)
- `Timeline.kt`        timeline editor (Compose)
- `TouchLog.kt`        pencatat ketukan + penyimpanan sidecar
- `TouchService.kt`    layanan Aksesibilitas yang mengirim posisi ketukan ke `TouchLog`
- `Exporter.kt`        trim + frame/background: MediaCodec decode -> shader GLES -> encode H.264 -> MediaMuxer
- `Editor.kt`          layar editor (Compose) + pratinjau MediaPlayer/TextureView
- `Library.kt`         daftar rekaman dari MediaStore
- `Recorder.kt`        pipeline: VirtualDisplay -> H.264, audio -> AAC, MediaMuxer -> MediaStore
- `HudService.kt`      HUD melayang (overlay View biasa)
- `SolarIcons.kt`      data path ikon Solar (CC BY 4.0, lihat kredit)
- `CaptureActivity.kt` Activity transparan: izin rekam layar / mikrofon untuk HUD
- `RecPrefs.kt`        pengaturan rekaman + posisi HUD (SharedPreferences)
- `RecorderService.kt` foreground service, state, notifikasi, hitung mundur
- `MainActivity.kt`    UI Compose + alur izin

## Batasan yang diketahui
- Ukuran video terkunci saat mulai (rotasi saat merekam tidak mengubah ukuran). Untuk app/game landscape pilih Orientasi video = Landscape.
- App yang memblokir capture audio (mis. beberapa app streaming/DRM) tidak akan terekam suaranya.
- Posisi ketukan = titik tengah elemen yang diketuk (Android tidak memberi koordinat sentuhan mentah ke app biasa). Elemen yang tidak dikenali aksesibilitas (sebagian game / kanvas custom) tidak tercatat.
- Koordinat ketukan dinormalisasi terhadap layar saat itu; jika Orientasi video dipaksa berbeda dari orientasi layar, fokus auto-zoom bisa meleset.
- Rekaman lama (sebelum tahap 3) dan hasil ekspor tidak punya data ketukan; zoom manual tetap bisa dipakai.
- Level mic di HUD bisa datar saat app lain di depan, tergantung aturan mikrofon Android; rekaman tidak terpengaruh.
- Belum ada: webcam. Kursor di hasil video adalah kursor sintetis, bukan jari asli.

## Kredit
Wallpaper foto: dari Openscreen (MIT), lihat bagian Wallpaper foto.
Ikon HUD: [Solar Icon Set](https://github.com/480-Design/Solar-Icon-Set) oleh 480 Design, lisensi [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). Path SVG dikonversi ke Android Path; ikon mikrofon mati ditambah coretan diagonal. Susunan HUD terinspirasi Recordly (kode Recordly tidak disalin).
