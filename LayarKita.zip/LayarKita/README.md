# Layar Kita (tahap 2)

Perekam layar Android native (Kotlin + Jetpack Compose). Minimal Android 10 (API 29).

## Build
1. Buka folder ini di **Android Studio** (Koala atau lebih baru), tunggu Gradle sync.
2. Sambungkan HP (USB debugging) lalu Run. Atau: Build > Build APK(s).

## Fitur tahap 1
- Mulai / Jeda / Lanjut / Stop (Jeda dan Stop lewat notifikasi)
- Hitung mundur 3-2-1 (butuh izin overlay; tanpa izin langsung mulai)
- Audio internal (AudioPlaybackCapture) + mikrofon, dicampur
- Resolusi 720p / 1080p / asli, 30 / 60 fps
- Simpan otomatis ke galeri: Movies/LayarKita/*.mp4

## Fitur tahap 2 (editor)
- Daftar rekaman di layar utama (Movies/LayarKita), tombol Edit dan Bagikan
- Editor: pratinjau langsung, **potong (trim)**, **background** (gradient/solid), padding, sudut membulat, bayangan, rasio kanvas (Asli/16:9/9:16/1:1/4:5)
- Ekspor ke MP4 baru (video di-render ulang lewat OpenGL, audio disalin tanpa re-encode)

## Struktur
- `Exporter.kt`        trim + frame/background: MediaCodec decode -> shader GLES -> encode H.264 -> MediaMuxer
- `Editor.kt`          layar editor (Compose) + pratinjau MediaPlayer/TextureView
- `Library.kt`         daftar rekaman dari MediaStore
- `Recorder.kt`        pipeline: VirtualDisplay -> H.264, audio -> AAC, MediaMuxer -> MediaStore
- `RecorderService.kt` foreground service, state, notifikasi, hitung mundur
- `MainActivity.kt`    UI Compose + alur izin

## Batasan yang diketahui
- Ukuran video terkunci saat mulai (rotasi saat merekam tidak mengubah ukuran).
- App yang memblokir capture audio (mis. beberapa app streaming/DRM) tidak akan terekam suaranya.
- Belum ada: daftar rekaman, trim, frame/background, webcam, indikator sentuhan (tahap 2-3).
