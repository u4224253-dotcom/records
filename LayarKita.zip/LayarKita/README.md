# Layar Kita (tahap 2)

Perekam layar Android native (Kotlin + Jetpack Compose). Minimal Android 10 (API 29).

## Build
1. Buka folder ini di **Android Studio** (Koala atau lebih baru), tunggu Gradle sync.
2. Sambungkan HP (USB debugging) lalu Run. Atau: Build > Build APK(s).

## Tampilan (v0.5)
- Layar utama dan editor dibuat ulang: datar tanpa card, muat satu layar (tanpa scroll halaman), potret dan lanskap
- Pengaturan (ikon gir di layar utama): tampilan Sistem / Terang / Gelap, plus pengaturan rekaman

## Fitur tahap 1
- Mulai / Jeda / Lanjut / Stop (Jeda dan Stop lewat notifikasi)
- Hitung mundur 3-2-1 (butuh izin overlay; tanpa izin langsung mulai)
- Audio internal (AudioPlaybackCapture) + mikrofon, dicampur
- Resolusi 720p / 1080p / asli, 30 / 60 fps
- Simpan otomatis ke galeri: Movies/LayarKita/*.mp4

## Fitur tahap 2 (editor)
- Daftar rekaman di layar utama (Movies/LayarKita), tombol Edit dan Bagikan
- Editor: pratinjau langsung, **potong (trim)**, **background** (gradient, warna solid, wallpaper mesh, gambar dari galeri, blur dari video), padding, sudut membulat, bayangan, rasio kanvas (Asli/16:9/9:16/1:1/4:5)
- Ekspor ke MP4 baru (video di-render ulang lewat OpenGL, audio disalin tanpa re-encode)

## HUD melayang (v0.6)
Bar kontrol gelap membulat yang tampil di atas app mana pun, untuk mulai merekam tanpa membuka Layar Kita.
- Buka lewat tombol **HUD** di layar utama (butuh izin overlay). Tutup lewat tombol X atau aksi "Tutup" di notifikasi.
- Tampilan dan susunan mengikuti HUD Recordly: tombol **Rekam** bulat merah, chip sumber (ikon monitor + resolusi; ketuk = ganti 720p / 1080p / Asli), toggle audio internal, toggle mikrofon, **Home** (buka daftar rekaman, rekaman terbaru di paling atas untuk di-edit), dan tutup. Seluruh bar bisa digeser.
- Saat mikrofon aktif muncul panel di atas bar: dropdown pilih perangkat mic + 5 titik level suara.
- **HUD hilang total begitu Rekam ditekan** (tidak pernah ikut terekam). Selama merekam, kontrol Jeda/Stop lewat notifikasi. Setelah rekaman tersimpan HUD muncul lagi di posisi yang sama.
- Pengaturan (resolusi, audio, mic, perangkat mic, posisi HUD) dibagi dengan layar utama lewat `RecPrefs`.
- Dialog izin rekam layar dibuka lewat `CaptureActivity` (transparan), karena hanya Activity yang bisa meminta izin itu.

## Fitur tahap 3 (zoom otomatis)
- **Timeline** di editor: ruler, baris video dengan handle potong, penanda sentuhan, dan baris blok zoom (geser badan = pindah, geser tepi = ubah panjang)
- **Auto-zoom dari ketukan**: ketukan yang berdekatan digabung jadi satu blok; zoom mulai sedikit sebelum ketukan pertama dan bertahan sebentar setelah yang terakhir; fokus = tengah sebaran ketukan
- Blok zoom bisa ditambah/dihapus manual, skala dan fokusnya diatur dengan slider
- Pratinjau dan ekspor memakai rumus yang sama (`ZoomMath`), jadi hasil ekspor cocok dengan pratinjau
- **Zoom kartu** (v0.8.1): yang membesar adalah seluruh bingkai video (padding, sudut membulat, bayangan ikut), bukan hanya isinya di-crop di dalam bingkai yang diam, seperti di Openscreen. Saat zoom cukup besar kartu menutupi kanvas sehingga background tidak terlihat (`ZoomMath.cardZoom`)
- Data ketukan dicatat oleh layanan Aksesibilitas "Layar Kita (penanda sentuhan)" selama merekam dan disimpan di folder privat app (`touch/<nama-video>.csv`)

### Mengaktifkan pencatat sentuhan
1. Di layar utama tekan **Aktifkan pencatat sentuhan**, lalu nyalakan "Layar Kita" di Pengaturan > Aksesibilitas.
2. Jika tombolnya abu-abu (APK di-sideload, Android 13+): Info app > menu ⋮ > **Izinkan pengaturan terbatas**, lalu ulangi langkah 1.
3. Rekam seperti biasa. Di editor, tombol **Auto-zoom** aktif kalau rekaman punya data ketukan.

Layanan ini hanya membaca posisi (kotak) elemen yang diketuk, bukan isi teks layar, dan hanya mencatat saat rekaman berjalan.

## Kamera 3D dan kursor (v0.8)
- **Kamera 3D** per blok zoom (editor > Zoom > pilih blok): Mati / Kiri / Kanan / Orbit. Bingkai video dimiringkan dengan perspektif; Orbit memakai titik fokus zoom (X/Y). Pratinjau memakai `graphicsLayer`, ekspor memakai shader (`uTilt`). Efek ini terinspirasi fitur "3D camera" Openscreen (kodenya tidak disalin).
- **Kursor sintetis** (editor > Bingkai > Kursor): panah + riak ketukan yang meluncur dari ketukan ke ketukan, dibuat dari data ketukan (`CursorMath` di `Cursor.kt`). Posisi = titik tengah elemen yang diketuk, jalur di antara ketukan adalah perkiraan, bukan gerakan jari asli. Ikut miring bersama bingkai di mode 3D.

## Struktur
- `Cursor.kt`          kursor sintetis dari ketukan: `CursorMath` + gambar panah/riak untuk pratinjau
- `ZoomModel.kt`       blok zoom, rumus easing (`ZoomMath`), operasi edit (`ZoomOps`), pembuat zoom otomatis (`AutoZoom`)
- `Timeline.kt`        timeline editor (Compose)
- `TouchLog.kt`        pencatat ketukan + penyimpanan sidecar
- `TouchService.kt`    layanan Aksesibilitas yang mengirim posisi ketukan ke `TouchLog`
- `Exporter.kt`        trim + frame/background: MediaCodec decode -> shader GLES -> encode H.264 -> MediaMuxer
- `Editor.kt`          layar editor (Compose) + pratinjau MediaPlayer/TextureView
- `Library.kt`         daftar rekaman dari MediaStore
- `Recorder.kt`        pipeline: VirtualDisplay -> H.264, audio -> AAC, MediaMuxer -> MediaStore
- `HudService.kt`      HUD melayang (overlay View biasa)
- `SolarIcons.kt`      data path ikon Solar (CC BY 4.0, lihat kredit)
- `CaptureActivity.kt` Activity transparan: izin rekam layar / mikrofon untuk HUD
- `RecPrefs.kt`        pengaturan rekaman + posisi HUD (SharedPreferences)
- `RecorderService.kt` foreground service, state, notifikasi, hitung mundur
- `MainActivity.kt`    UI Compose + alur izin

## Batasan yang diketahui
- Ukuran video terkunci saat mulai (rotasi saat merekam tidak mengubah ukuran). Untuk app/game landscape pilih Orientasi video = Landscape.
- App yang memblokir capture audio (mis. beberapa app streaming/DRM) tidak akan terekam suaranya.
- Posisi ketukan = titik tengah elemen yang diketuk (Android tidak memberi koordinat sentuhan mentah ke app biasa). Elemen yang tidak dikenali aksesibilitas (sebagian game / kanvas custom) tidak tercatat.
- Koordinat ketukan dinormalisasi terhadap layar saat itu; jika Orientasi video dipaksa berbeda dari orientasi layar, fokus auto-zoom bisa meleset.
- Rekaman lama (sebelum tahap 3) dan hasil ekspor tidak punya data ketukan; zoom manual tetap bisa dipakai.
- Level mic di HUD bisa datar saat app lain di depan, tergantung aturan mikrofon Android; rekaman tidak terpengaruh.
- Belum ada: webcam. Kursor di hasil video adalah kursor sintetis, bukan jari asli.

## Kredit
Ikon HUD: [Solar Icon Set](https://github.com/480-Design/Solar-Icon-Set) oleh 480 Design, lisensi [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). Path SVG dikonversi ke Android Path; ikon mikrofon mati ditambah coretan diagonal. Susunan HUD terinspirasi Recordly (kode Recordly tidak disalin).
