# Layar Kita (tahap 2)

Perekam layar Android native (Kotlin + Jetpack Compose). Minimal Android 10 (API 29).

## Build
1. Buka folder ini di **Android Studio** (Koala atau lebih baru), tunggu Gradle sync.
2. Sambungkan HP (USB debugging) lalu Run. Atau: Build > Build APK(s).

## Fitur tahap 1
- Mulai / Jeda / Lanjut / Stop (Jeda dan Stop lewat notifikasi)
- Hitung mundur 3-2-1 (butuh izin overlay; tanpa izin langsung mulai)
- Audio internal (AudioPlaybackCapture) + mikrofon, dicampur
- Resolusi 720p / 1080p / asli, 30 / 60 fps
- Simpan otomatis ke galeri: Movies/LayarKita/*.mp4

## Fitur tahap 2 (editor)
- Daftar rekaman di layar utama (Movies/LayarKita), tombol Edit dan Bagikan
- Editor: pratinjau langsung, **potong (trim)**, **background** (gradient, warna solid, wallpaper mesh, gambar dari galeri, blur dari video), padding, sudut membulat, bayangan, rasio kanvas (Asli/16:9/9:16/1:1/4:5)
- Ekspor ke MP4 baru (video di-render ulang lewat OpenGL, audio disalin tanpa re-encode)

## Fitur tahap 3 (zoom otomatis)
- **Timeline** di editor: ruler, baris video dengan handle potong, penanda sentuhan, dan baris blok zoom (geser badan = pindah, geser tepi = ubah panjang)
- **Auto-zoom dari ketukan**: ketukan yang berdekatan digabung jadi satu blok; zoom mulai sedikit sebelum ketukan pertama dan bertahan sebentar setelah yang terakhir; fokus = tengah sebaran ketukan
- Blok zoom bisa ditambah/dihapus manual, skala dan fokusnya diatur dengan slider
- Pratinjau dan ekspor memakai rumus yang sama (`ZoomMath`), jadi hasil ekspor cocok dengan pratinjau
- Data ketukan dicatat oleh layanan Aksesibilitas "Layar Kita (penanda sentuhan)" selama merekam dan disimpan di folder privat app (`touch/<nama-video>.csv`)

### Mengaktifkan pencatat sentuhan
1. Di layar utama tekan **Aktifkan pencatat sentuhan**, lalu nyalakan "Layar Kita" di Pengaturan > Aksesibilitas.
2. Jika tombolnya abu-abu (APK di-sideload, Android 13+): Info app > menu ⋮ > **Izinkan pengaturan terbatas**, lalu ulangi langkah 1.
3. Rekam seperti biasa. Di editor, tombol **Auto-zoom** aktif kalau rekaman punya data ketukan.

Layanan ini hanya membaca posisi (kotak) elemen yang diketuk, bukan isi teks layar, dan hanya mencatat saat rekaman berjalan.

## Struktur
- `ZoomModel.kt`       blok zoom, rumus easing (`ZoomMath`), operasi edit (`ZoomOps`), pembuat zoom otomatis (`AutoZoom`)
- `Timeline.kt`        timeline editor (Compose)
- `TouchLog.kt`        pencatat ketukan + penyimpanan sidecar
- `TouchService.kt`    layanan Aksesibilitas yang mengirim posisi ketukan ke `TouchLog`
- `Exporter.kt`        trim + frame/background: MediaCodec decode -> shader GLES -> encode H.264 -> MediaMuxer
- `Editor.kt`          layar editor (Compose) + pratinjau MediaPlayer/TextureView
- `Library.kt`         daftar rekaman dari MediaStore
- `Recorder.kt`        pipeline: VirtualDisplay -> H.264, audio -> AAC, MediaMuxer -> MediaStore
- `RecorderService.kt` foreground service, state, notifikasi, hitung mundur
- `MainActivity.kt`    UI Compose + alur izin

## Batasan yang diketahui
- Ukuran video terkunci saat mulai (rotasi saat merekam tidak mengubah ukuran). Untuk app/game landscape pilih Orientasi video = Landscape.
- App yang memblokir capture audio (mis. beberapa app streaming/DRM) tidak akan terekam suaranya.
- Posisi ketukan = titik tengah elemen yang diketuk (Android tidak memberi koordinat sentuhan mentah ke app biasa). Elemen yang tidak dikenali aksesibilitas (sebagian game / kanvas custom) tidak tercatat.
- Koordinat ketukan dinormalisasi terhadap layar saat itu; jika Orientasi video dipaksa berbeda dari orientasi layar, fokus auto-zoom bisa meleset.
- Rekaman lama (sebelum tahap 3) dan hasil ekspor tidak punya data ketukan; zoom manual tetap bisa dipakai.
- Belum ada: webcam, indikator sentuhan di hasil video.
