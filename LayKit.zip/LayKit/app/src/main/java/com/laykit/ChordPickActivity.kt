package com.laykit

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

/**
 * Activity transparan tanpa UI. Dibuka dari tool Chord Finder di HUD: pemilih file sistem hanya bisa dibuka lewat
 * Activity. File yang dipilih langsung dimasukkan ke [ChordTool], lalu activity menutup diri.
 */
class ChordPickActivity : ComponentActivity() {

    private val pick = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val d = r.data
        if (r.resultCode == Activity.RESULT_OK && d != null) {
            val cd = d.clipData
            val uris = if (cd != null) (0 until cd.itemCount).mapNotNull { cd.getItemAt(it).uri } else listOfNotNull(d.data)
            uris.forEach {
                try { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                catch (_: Exception) { /* tidak semua penyedia file mendukung; izin sementara cukup selama app hidup */ }
            }
            if (uris.isNotEmpty()) ChordTool.enqueue(this, uris)
        }
        ChordTool.pickDone.value++
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState != null) return   // activity dibuat ulang (mis. layar diputar): hasil pemilih tetap sampai ke launcher
        pick.launch(
            Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("audio/*", "video/*"))
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            },
        )
    }
}
