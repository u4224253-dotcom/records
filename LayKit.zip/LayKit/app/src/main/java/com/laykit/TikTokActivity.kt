package com.laykit

import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/** Layar TikTok Converter: tempel link -> Cari -> pilih simpan Video (MP4) atau Audio (MP3). Dibuka dari HUD > Tools. */
class TikTokActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { LayKitTheme(ThemePrefs.load(this)) { TikTokScreen(onClose = { finish() }) } }
    }
}

private sealed interface Step {
    object Input : Step
    object Loading : Step
    class Ready(val info: TikTokInfo, val cover: Bitmap?) : Step
    class Saving(val info: TikTokInfo, val cover: Bitmap?, val audio: Boolean, val progress: Float) : Step
    class Done(val info: TikTokInfo, val cover: Bitmap?, val audio: Boolean, val uri: Uri) : Step
}

@Composable
private fun TikTokScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    var link by rememberSaveable { mutableStateOf("") }
    var step by remember { mutableStateOf<Step>(Step.Input) }
    var error by remember { mutableStateOf<String?>(null) }
    var job by remember { mutableStateOf<Job?>(null) }

    fun search() {
        if (step is Step.Loading) return
        error = null
        step = Step.Loading
        job = scope.launch {
            try {
                val info = TikTokEngine.resolve(link)
                val cover = info.coverUrl?.let { TikTokEngine.loadCover(it) }
                step = Step.Ready(info, cover)
            } catch (e: CancellationException) {
                throw e
            } catch (e: TikTokException) {
                error = e.message; step = Step.Input
            } catch (e: Exception) {
                error = "Terjadi kesalahan: ${e.message}"; step = Step.Input
            }
        }
    }

    fun save(info: TikTokInfo, cover: Bitmap?, audio: Boolean) {
        val url = (if (audio) info.audioUrl else info.videoUrl) ?: return
        error = null
        step = Step.Saving(info, cover, audio, 0f)
        job = scope.launch {
            try {
                val uri = TikTokEngine.save(ctx, url, audio, info.title) { p -> step = Step.Saving(info, cover, audio, p) }
                step = Step.Done(info, cover, audio, uri)
            } catch (e: CancellationException) {
                throw e
            } catch (e: TikTokException) {
                error = e.message; step = Step.Ready(info, cover)
            } catch (e: Exception) {
                error = "Terjadi kesalahan: ${e.message}"; step = Step.Ready(info, cover)
            }
        }
    }

    Box(Modifier.fillMaxSize().background(cs.background).systemBarsPadding().imePadding()) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("TikTok Converter", style = MaterialTheme.typography.titleLarge, color = cs.onBackground, modifier = Modifier.weight(1f))
                Pill("Tutup") { job?.cancel(); onClose() }
            }

            val s = step
            val busy = s is Step.Loading || s is Step.Saving

            OutlinedTextField(
                value = link,
                onValueChange = { link = it; if (s is Step.Ready || s is Step.Done) step = Step.Input },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Link video TikTok") },
                placeholder = { Text("https://vt.tiktok.com/...") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                keyboardActions = androidx.compose.foundation.text.KeyboardActions(onGo = { search() }),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Pill("Tempel", enabled = !busy) {
                    val cm = ctx.getSystemService(ClipboardManager::class.java)
                    val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(ctx)?.toString().orEmpty()
                    if (t.isNotBlank()) { link = TikTokEngine.extractUrl(t) ?: t; error = null; if (s is Step.Ready || s is Step.Done) step = Step.Input }
                    else error = "Clipboard kosong. Salin link video TikTok dulu."
                }
                Pill("Cari video", selected = true, enabled = !busy && link.isNotBlank()) { search() }
            }

            error?.let { Text(it, color = cs.error, style = MaterialTheme.typography.bodyMedium) }

            when (s) {
                is Step.Input -> Text(
                    "Tempel link video TikTok, lalu ketuk Cari video. Setelah itu pilih mau disimpan sebagai video atau audio.",
                    color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium,
                )
                is Step.Loading -> Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                    Text("Membaca link…", color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                }
                is Step.Ready -> {
                    InfoCard(s.info, s.cover)
                    Text("Simpan sebagai:", color = cs.onSurfaceVariant, style = MaterialTheme.typography.labelLarge)
                    BigChoice("Simpan Video (MP4)", "Tanpa watermark, tersimpan di Movies/LayKit/TikTok", enabled = s.info.videoUrl != null) {
                        save(s.info, s.cover, audio = false)
                    }
                    BigChoice("Simpan Audio (MP3)", "Musik/suara videonya, tersimpan di Music/LayKit/TikTok", enabled = s.info.audioUrl != null) {
                        save(s.info, s.cover, audio = true)
                    }
                }
                is Step.Saving -> {
                    InfoCard(s.info, s.cover)
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (s.progress > 0f) LinearProgressIndicator(progress = { s.progress }, modifier = Modifier.fillMaxWidth())
                        else LinearProgressIndicator(Modifier.fillMaxWidth())
                        Text(
                            (if (s.audio) "Mengunduh audio… " else "Mengunduh video… ") + if (s.progress > 0f) "${(s.progress * 100).toInt()}%" else "",
                            color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium,
                        )
                        Pill("Batal") { job?.cancel(); step = Step.Ready(s.info, s.cover) }
                    }
                }
                is Step.Done -> {
                    InfoCard(s.info, s.cover)
                    Text(
                        if (s.audio) "Audio tersimpan di Music/LayKit/TikTok." else "Video tersimpan di Movies/LayKit/TikTok.",
                        color = cs.onBackground, style = MaterialTheme.typography.bodyLarge,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Pill("Buka", selected = true) { openFile(ctx, s.uri, s.audio) }
                        Pill("Bagikan") { Library.share(ctx, s.uri) }
                        Pill(if (s.audio) "Simpan video juga" else "Simpan audio juga", enabled = (if (s.audio) s.info.videoUrl else s.info.audioUrl) != null) {
                            save(s.info, s.cover, audio = !s.audio)
                        }
                    }
                    Pill("Convert link lain") { link = ""; error = null; step = Step.Input }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

private fun openFile(ctx: android.content.Context, uri: Uri, audio: Boolean) {
    try {
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, if (audio) "audio/mpeg" else "video/mp4")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION),
        )
    } catch (_: Exception) {
        android.widget.Toast.makeText(ctx, "Tidak ada aplikasi pemutar", android.widget.Toast.LENGTH_SHORT).show()
    }
}

@Composable
private fun InfoCard(info: TikTokInfo, cover: Bitmap?) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(cs.surfaceContainer).padding(10.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(72.dp, 96.dp).clip(RoundedCornerShape(10.dp)).background(cs.surfaceVariant)) {
            if (cover != null) Image(cover.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(info.title, color = cs.onSurface, style = MaterialTheme.typography.titleSmall, maxLines = 3, overflow = TextOverflow.Ellipsis)
            if (info.author.isNotBlank()) Text("@" + info.author.removePrefix("@"), color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            if (info.durationSec > 0) Text(Library.fmtTime(info.durationSec * 1000L), color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun BigChoice(title: String, sub: String, enabled: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .background(if (enabled) cs.primary else cs.surfaceVariant)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        val fg = if (enabled) cs.onPrimary else cs.onSurfaceVariant.copy(alpha = 0.6f)
        Text(title, color = fg, style = MaterialTheme.typography.titleMedium)
        Text(if (enabled) sub else "Tidak tersedia untuk video ini", color = fg.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Start)
    }
}
