package com.laykit

/**
 * Peak waveform untuk tool BPM Detector (audio internal). Sama dengan sisi "live" LiveWave (min/max per irisan 3 md,
 * buffer berputar), tetapi terpisah supaya tidak mengganggu waveform / draft rekaman audio.
 * Ditulis dari thread BpmService ([push]), dibaca dari thread UI ([read]).
 */
object BpmWave {
    private const val CAP = LiveWave.CAP
    private val mn = ByteArray(CAP)
    private val mx = ByteArray(CAP)
    @Volatile private var head = 0L

    private fun q8(v: Int): Byte = (v * 127 / 32768).coerceIn(-127, 127).toByte()

    fun reset() { mn.fill(0); mx.fill(0); head = 0L }

    /** lo <= 0 <= hi, skala sampel 16-bit. */
    fun push(lo: Int, hi: Int) {
        val i = (head % CAP).toInt()
        mn[i] = q8(lo); mx[i] = q8(hi)
        head += 1
    }

    /** Sama dengan [LiveWave.read]: kolom paling kanan = paling baru, mengembalikan jumlah kolom berisi. */
    fun read(cols: Int, outMin: FloatArray, outMax: FloatArray): Int {
        val n = cols.coerceIn(1, CAP)
        val h = head
        var valid = 0
        for (c in 0 until n) {
            val idx = h - n + c
            if (idx < 0) { outMin[c] = 0f; outMax[c] = 0f; continue }
            val k = (idx % CAP).toInt()
            outMin[c] = mn[k] / 127f; outMax[c] = mx[k] / 127f
            valid++
        }
        return valid
    }
}
