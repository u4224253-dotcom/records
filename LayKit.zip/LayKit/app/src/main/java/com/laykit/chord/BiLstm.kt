package com.laykit.chord

import kotlin.math.exp
import kotlin.math.min
import kotlin.math.tanh

/**
 * LSTM dua arah 1 layer dari ChordMini, satu fold: nn.LSTM(240, 96, bidirectional, batch_first).
 * State awal (h0, c0) nol. Urutan gate PyTorch: i, f, g, o.
 *
 *   i = sigmoid(Wii x + bii + Whi h + bhi)     f = sigmoid(...)
 *   g = tanh(...)                              o = sigmoid(...)
 *   c = f*c + i*g                              h = o*tanh(c)
 *
 * Masukan  : [frames * 240], urutan [frame][fitur]  (keluaran [CnnFeatureExtractor.extract])
 * Keluaran : [frames * 192], urutan [frame][arah maju 0..95 | arah mundur 96..191]
 *            (arah mundur di indeks t = keadaan setelah membaca frames-1 turun sampai t)
 *
 * Linear 192 -> 100 (final_fc1) BUKAN bagian kelas ini.
 */
internal class BiLstm(
    lkm: LkmFile,
    fold: Int,
    private val threads: Int = CnnFeatureExtractor.defaultThreads(),
) {

    private class Dir(
        /** [4*H][IN] baris gate urut i,f,g,o */
        val wIh: FloatArray,
        /** [4*H][H] */
        val wHh: FloatArray,
        /** bias_ih + bias_hh, [4*H] */
        val bias: FloatArray,
    )

    private val fwd: Dir
    private val bwd: Dir

    init {
        require(threads >= 1) { "threads harus >= 1" }
        fun load(sfx: String): Dir {
            val p = "f$fold.lstm1."
            val ih = lkm.tensor("${p}weight_ih_l0$sfx").data
            val hh = lkm.tensor("${p}weight_hh_l0$sfx").data
            val bi = lkm.tensor("${p}bias_ih_l0$sfx").data
            val bh = lkm.tensor("${p}bias_hh_l0$sfx").data
            require(ih.size == G * IN) { "weight_ih$sfx fold $fold ukurannya ${ih.size}, seharusnya ${G * IN}" }
            require(hh.size == G * H) { "weight_hh$sfx fold $fold ukurannya ${hh.size}, seharusnya ${G * H}" }
            require(bi.size == G && bh.size == G) { "bias LSTM$sfx fold $fold tidak $G" }
            return Dir(ih, hh, FloatArray(G) { bi[it] + bh[it] })
        }
        fwd = load("")
        bwd = load("_reverse")
    }

    fun forward(x: FloatArray, frames: Int): FloatArray {
        require(frames >= 1) { "frames harus >= 1" }
        require(x.size == frames * IN) { "Input ${x.size} != $frames * $IN" }
        val out = FloatArray(frames * 2 * H)

        // 1) proyeksi masukan untuk seluruh frame sekaligus (tidak bergantung urutan waktu), paralel di frame
        val gf = FloatArray(frames * G)
        val gb = FloatArray(frames * G)
        parallelFor(frames) { t0, t1 ->
            for (t in t0 until t1) {
                inputProjection(fwd, x, t, gf)
                inputProjection(bwd, x, t, gb)
            }
        }

        // 2) rekurensi: dua arah saling bebas, jalankan bersamaan bila ada >= 2 thread
        if (threads >= 2 && frames >= 2) {
            var failure: Throwable? = null
            val th = Thread {
                try { recurrence(bwd, gb, frames, out, reverse = true) } catch (e: Throwable) { failure = e }
            }
            th.start()
            recurrence(fwd, gf, frames, out, reverse = false)
            th.join()
            failure?.let { throw it }
        } else {
            recurrence(fwd, gf, frames, out, reverse = false)
            recurrence(bwd, gb, frames, out, reverse = true)
        }
        return out
    }

    private fun inputProjection(d: Dir, x: FloatArray, t: Int, g: FloatArray) {
        val xb = t * IN
        val gb = t * G
        for (j in 0 until G) {
            val wb = j * IN
            var a0 = 0f; var a1 = 0f; var a2 = 0f; var a3 = 0f
            var k = 0
            while (k < IN) { // IN = 240, kelipatan 4
                a0 += d.wIh[wb + k] * x[xb + k]
                a1 += d.wIh[wb + k + 1] * x[xb + k + 1]
                a2 += d.wIh[wb + k + 2] * x[xb + k + 2]
                a3 += d.wIh[wb + k + 3] * x[xb + k + 3]
                k += 4
            }
            g[gb + j] = d.bias[j] + ((a0 + a1) + (a2 + a3))
        }
    }

    /** gates = hasil proyeksi masukan [frames][G]; tulis h ke out[t][dir*H ..]. */
    private fun recurrence(d: Dir, gates: FloatArray, frames: Int, out: FloatArray, reverse: Boolean) {
        val h = FloatArray(H)
        val c = FloatArray(H)
        val z = FloatArray(G)
        val off = if (reverse) H else 0
        for (step in 0 until frames) {
            val t = if (reverse) frames - 1 - step else step
            val gb = t * G
            for (j in 0 until G) {
                val wb = j * H
                var a0 = 0f; var a1 = 0f; var a2 = 0f; var a3 = 0f
                var k = 0
                while (k < H) { // H = 96, kelipatan 4
                    a0 += d.wHh[wb + k] * h[k]
                    a1 += d.wHh[wb + k + 1] * h[k + 1]
                    a2 += d.wHh[wb + k + 2] * h[k + 2]
                    a3 += d.wHh[wb + k + 3] * h[k + 3]
                    k += 4
                }
                z[j] = gates[gb + j] + ((a0 + a1) + (a2 + a3))
            }
            val ob = t * 2 * H + off
            for (u in 0 until H) {
                val i = sigmoid(z[u])
                val f = sigmoid(z[H + u])
                val g = tanh(z[2 * H + u].toDouble()).toFloat()
                val o = sigmoid(z[3 * H + u])
                val cn = f * c[u] + i * g
                c[u] = cn
                val hn = o * tanh(cn.toDouble()).toFloat()
                h[u] = hn
                out[ob + u] = hn
            }
        }
    }

    private fun sigmoid(v: Float): Float = (1.0 / (1.0 + exp(-v.toDouble()))).toFloat()

    private fun parallelFor(n: Int, body: (Int, Int) -> Unit) {
        val nt = min(threads, maxOf(1, n / MIN_ROWS_PER_THREAD))
        if (nt <= 1) {
            body(0, n)
            return
        }
        val per = (n + nt - 1) / nt
        var failure: Throwable? = null
        val workers = ArrayList<Thread>(nt - 1)
        for (i in 1 until nt) {
            val a = i * per
            val b = min(n, a + per)
            if (a >= b) break
            workers += Thread {
                try { body(a, b) } catch (e: Throwable) { synchronized(workers) { failure = failure ?: e } }
            }.also { it.start() }
        }
        try { body(0, min(n, per)) } catch (e: Throwable) { synchronized(workers) { failure = failure ?: e } }
        for (t in workers) t.join()
        failure?.let { throw it }
    }

    companion object {
        const val IN = CnnFeatureExtractor.OUT_SIZE // 240
        const val H = 96
        const val G = 4 * H
        const val OUT_SIZE = 2 * H // 192
        private const val MIN_ROWS_PER_THREAD = 16
    }
}
