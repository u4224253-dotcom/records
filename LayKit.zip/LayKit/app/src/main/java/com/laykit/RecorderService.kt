package com.laykit

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.IntentCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlin.math.min

enum class Phase { IDLE, COUNTDOWN, RECORDING, PAUSED, SAVING }
data class RecUi(val phase: Phase = Phase.IDLE, val seconds: Int = 0, val msg: String? = null)

class RecorderService : Service() {

    companion object {
        val ui = MutableStateFlow(RecUi())
        const val A_START = "com.laykit.START"
        const val A_STOP = "com.laykit.STOP"
        const val A_PAUSE = "com.laykit.PAUSE"
        const val A_RESUME = "com.laykit.RESUME"
        const val X_CODE = "code"; const val X_DATA = "data"
        const val X_RES = "res"; const val X_FPS = "fps"
        const val X_INTERNAL = "internal"; const val X_MIC = "mic"; const val X_MIC_DEV = "micdev"
        const val X_ORIENT = "orient"   // 0 otomatis, 1 portrait, 2 landscape
        private const val CH = "rec"
        private const val NID = 1
    }

    private val main = Handler(Looper.getMainLooper())
    private var recorder: Recorder? = null
    private var projection: MediaProjection? = null
    private var overlay: TextView? = null
    private var counting = false
    private var seconds = 0

    private val tick = object : Runnable {
        override fun run() {
            if (ui.value.phase == Phase.RECORDING) {
                seconds++
                set(Phase.RECORDING)
                notify(fmt(seconds), paused = false)
            }
            main.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CH, "Perekaman layar", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            A_START -> if (ui.value.phase == Phase.IDLE) begin(intent) else stopSelfIfIdle()
            A_PAUSE -> if (ui.value.phase == Phase.RECORDING) {
                recorder?.pause(); set(Phase.PAUSED); notify(fmt(seconds), paused = true)
            }
            A_RESUME -> if (ui.value.phase == Phase.PAUSED) {
                recorder?.resume(); set(Phase.RECORDING); notify(fmt(seconds), paused = false)
            }
            A_STOP -> stopAll()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        removeOverlay()
        super.onDestroy()
    }

    // ---------- alur ----------

    private fun begin(i: Intent) {
        val data = IntentCompat.getParcelableExtra(i, X_DATA, Intent::class.java)
        if (data == null) { stopSelf(); return }
        val internal = i.getBooleanExtra(X_INTERNAL, false)
        val mic = i.getBooleanExtra(X_MIC, false)
        val micDev = i.getIntExtra(X_MIC_DEV, -1)

        // Android 14+: startForeground (tipe mediaProjection) HARUS dipanggil sebelum getMediaProjection
        var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        if (mic) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        ServiceCompat.startForeground(this, NID, build("Menyiapkan…", paused = false), type)

        val mpm = getSystemService(MediaProjectionManager::class.java)
        projection = mpm.getMediaProjection(i.getIntExtra(X_CODE, 0), data)

        val res = i.getIntExtra(X_RES, 1080)
        val fps = i.getIntExtra(X_FPS, 30)
        val orient = i.getIntExtra(X_ORIENT, 0)
        // konfigurasi dihitung SETELAH hitung mundur: mode "Otomatis" mengikuti orientasi layar saat itu
        // (jadi kamu bisa pindah ke app landscape selama 3-2-1)
        countdown(3) { startRecording(makeConfig(res, fps, internal, mic, orient, micDev)) }
    }

    @Suppress("DEPRECATION")
    private fun makeConfig(res: Int, fps: Int, internal: Boolean, mic: Boolean, orient: Int, micDev: Int): RecConfig {
        val dm = DisplayMetrics()
        getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(dm)
        val shortSide = minOf(dm.widthPixels, dm.heightPixels)
        val longSide = maxOf(dm.widthPixels, dm.heightPixels)
        val (rw, rh) = when (orient) {
            1 -> shortSide to longSide      // portrait
            2 -> longSide to shortSide      // landscape
            else -> dm.widthPixels to dm.heightPixels
        }
        val scale = if (res <= 0) 1.0 else min(1.0, res.toDouble() / shortSide)
        val w = (rw * scale).toInt() and 1.inv()
        val h = (rh * scale).toInt() and 1.inv()
        val bps = (w.toLong() * h * fps * 0.07).toLong().coerceIn(2_000_000L, 16_000_000L).toInt()
        return RecConfig(w, h, dm.densityDpi, fps, bps, internal, mic, micDev)
    }

    private fun startRecording(cfg: RecConfig) {
        val p = projection ?: return
        try {
            val r = Recorder(this, p, cfg) { main.post { if (recorder != null) stopAll() } }
            r.start()
            recorder = r
            TouchLog.begin { r.clockMs() }
            seconds = 0
            set(Phase.RECORDING)
            notify(fmt(0), paused = false)
            main.postDelayed(tick, 1000)
        } catch (e: Exception) {
            p.stop(); projection = null
            ui.value = RecUi(Phase.IDLE, 0, "Gagal mulai: ${e.message}")
            stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
        }
    }

    private fun stopAll() {
        counting = false
        removeOverlay()
        main.removeCallbacksAndMessages(null)
        val r = recorder; recorder = null
        val p = projection; projection = null
        val touches = TouchLog.end()
        if (r == null) {
            p?.stop(); ui.value = RecUi()
            stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return
        }
        ui.value = RecUi(Phase.SAVING, seconds)
        Thread {
            val ok = try { r.stop() } catch (e: Exception) { false }
            if (ok) TouchLog.save(filesDir, r.name, touches)
            p?.stop()
            main.post {
                ui.value = RecUi(Phase.IDLE, 0, if (ok) "Tersimpan: Movies/LayKit/${r.name}" else "Gagal menyimpan rekaman")
                stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
            }
        }.start()
    }

    private fun stopSelfIfIdle() { if (ui.value.phase == Phase.IDLE) stopSelf() }

    // ---------- hitung mundur (overlay, dilepas sebelum rekam mulai supaya tidak ikut terekam) ----------

    private fun countdown(from: Int, done: () -> Unit) {
        if (!Settings.canDrawOverlays(this)) { done(); return }
        counting = true
        ui.value = RecUi(Phase.COUNTDOWN, from)
        val tv = TextView(this).apply {
            textSize = 96f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setShadowLayer(16f, 0f, 0f, Color.BLACK)
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT,
        ).apply { gravity = Gravity.CENTER }
        getSystemService(WindowManager::class.java).addView(tv, lp)
        overlay = tv
        var n = from
        main.post(object : Runnable {
            override fun run() {
                if (!counting) return
                if (n == 0) {
                    removeOverlay(); counting = false
                    main.postDelayed({ done() }, 200)
                    return
                }
                tv.text = "$n"; ui.value = RecUi(Phase.COUNTDOWN, n); n--
                main.postDelayed(this, 1000)
            }
        })
    }

    private fun removeOverlay() {
        overlay?.let { v -> try { getSystemService(WindowManager::class.java).removeView(v) } catch (e: Exception) { /* sudah lepas */ } }
        overlay = null
    }

    // ---------- util ----------

    private fun set(p: Phase) { ui.value = RecUi(p, seconds) }
    private fun fmt(s: Int) = "%02d:%02d".format(s / 60, s % 60)

    private fun action(a: String, code: Int) = PendingIntent.getService(
        this, code, Intent(this, RecorderService::class.java).setAction(a),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun build(text: String, paused: Boolean): Notification {
        val b = NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(if (paused) "Rekaman dijeda" else "Merekam layar")
            .setContentText(text)
            .setOngoing(true).setOnlyAlertOnce(true)
            .setContentIntent(PendingIntent.getActivity(
                this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
        if (paused) b.addAction(0, "Lanjut", action(A_RESUME, 2)) else b.addAction(0, "Jeda", action(A_PAUSE, 1))
        b.addAction(0, "Stop", action(A_STOP, 3))
        return b.build()
    }

    private fun notify(text: String, paused: Boolean) {
        getSystemService(NotificationManager::class.java).notify(NID, build(text, paused))
    }
}
