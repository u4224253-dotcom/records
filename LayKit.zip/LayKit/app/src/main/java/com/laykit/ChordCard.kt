package com.laykit

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/*
 * Kartu "island" untuk tool Chord Finder di HUD: latar gradien hitam -> abu tipis + tekstur noise,
 * diagram akor gitar di kanan. Desainnya diport dari prototipe HTML (chord-gitar.html).
 * Ikon play/pause: Solar Icon Set oleh 480 Design, CC BY 4.0 (sudah dikreditkan di README).
 */

internal const val ISL_WHITE = 0xFFFFFFFF.toInt()
internal const val ISL_DIM = 0xB3FFFFFF.toInt()      // putih 70%
internal const val ISL_TRACK = 0x40FFFFFF            // jalur progres: putih 25%

/** "m:ss" dari detik. */
internal fun clock(sec: Double): String {
    val s = sec.toInt().coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

/** Ikon play/pause versi isi (bold), path sama dengan SolarIcons.PLAY / PAUSE. */
internal object IslandIcons {
    val PLAY = listOf(
        SolarPath("M20.4086 9.35258C22.5305 10.5065 22.5305 13.4935 20.4086 14.6474L7.59662 21.6145C5.53435 22.736 3 21.2763 3 18.9671L3 5.0329C3 2.72368 5.53435 1.26402 7.59661 2.38548L20.4086 9.35258Z", true),
    )
    val PAUSE = listOf(
        SolarPath("M2 6C2 4.11438 2 3.17157 2.58579 2.58579C3.17157 2 4.11438 2 6 2C7.88562 2 8.82843 2 9.41421 2.58579C10 3.17157 10 4.11438 10 6V18C10 19.8856 10 20.8284 9.41421 21.4142C8.82843 22 7.88562 22 6 22C4.11438 22 3.17157 22 2.58579 21.4142C2 20.8284 2 19.8856 2 18V6Z", true),
        SolarPath("M14 6C14 4.11438 14 3.17157 14.5858 2.58579C15.1716 2 16.1144 2 18 2C19.8856 2 20.8284 2 21.4142 2.58579C22 3.17157 22 4.11438 22 6V18C22 19.8856 22 20.8284 21.4142 21.4142C20.8284 22 19.8856 22 18 22C16.1144 22 15.1716 22 14.5858 21.4142C14 20.8284 14 19.8856 14 18V6Z", true),
    )
}

// ---------------------------------------------------------------------------------------------
// Bentuk akor gitar (satu bentuk per akor: terbuka bila ada, kalau tidak bentuk E, kalau tidak bentuk A)
// ---------------------------------------------------------------------------------------------

/** [frets]: 6 senar (E A D G B e), nilai relatif terhadap [baseFret]; -1 = tidak dimainkan, 0 = senar terbuka. */
internal class ChordShape(val frets: IntArray, val baseFret: Int, val barre: Int)

internal object GuitarChords {
    private const val X = -1

    private class Q(val e: IntArray?, val a: IntArray)

    // Offset fret dari posisi barre. Kunci = akhiran seperti yang dihasilkan chordName().
    private val QUAL: Map<String, Q> = mapOf(
        "" to Q(intArrayOf(0, 2, 2, 1, 0, 0), intArrayOf(X, 0, 2, 2, 2, 0)),
        "m" to Q(intArrayOf(0, 2, 2, 0, 0, 0), intArrayOf(X, 0, 2, 2, 1, 0)),
        "7" to Q(intArrayOf(0, 2, 0, 1, 0, 0), intArrayOf(X, 0, 2, 0, 2, 0)),
        "maj7" to Q(intArrayOf(0, 2, 1, 1, 0, 0), intArrayOf(X, 0, 2, 1, 2, 0)),
        "m7" to Q(intArrayOf(0, 2, 0, 0, 0, 0), intArrayOf(X, 0, 2, 0, 1, 0)),
        "sus4" to Q(intArrayOf(0, 2, 2, 2, 0, 0), intArrayOf(X, 0, 2, 2, 3, 0)),
        "sus2" to Q(null, intArrayOf(X, 0, 2, 2, 0, 0)),
        "6" to Q(intArrayOf(0, 2, 2, 1, 2, 0), intArrayOf(X, 0, 2, 2, 2, 2)),
        "m6" to Q(intArrayOf(0, 2, 2, 0, 2, 0), intArrayOf(X, 0, 2, 2, 1, 2)),
        "mM7" to Q(intArrayOf(0, 2, 1, 0, 0, 0), intArrayOf(X, 0, 2, 1, 1, 0)),
        "dim" to Q(null, intArrayOf(X, 0, 1, 2, 1, X)),
        "dim7" to Q(null, intArrayOf(X, 0, 1, 2, 1, 2)),
        "aug" to Q(null, intArrayOf(X, 0, 3, 2, 2, 1)),
        "m7\u266D5" to Q(null, intArrayOf(X, 0, 1, 0, 1, X)),
    )

    // Akor terbuka: "indeksNada|akhiran" -> fret absolut
    private val OPEN: Map<String, IntArray> = mapOf(
        "0|" to intArrayOf(X, 3, 2, 0, 1, 0), "0|7" to intArrayOf(X, 3, 2, 3, 1, 0), "0|maj7" to intArrayOf(X, 3, 2, 0, 0, 0),
        "2|" to intArrayOf(X, X, 0, 2, 3, 2), "2|m" to intArrayOf(X, X, 0, 2, 3, 1),
        "2|7" to intArrayOf(X, X, 0, 2, 1, 2), "2|maj7" to intArrayOf(X, X, 0, 2, 2, 2),
        "7|" to intArrayOf(3, 2, 0, 0, 0, 3), "7|7" to intArrayOf(3, 2, 0, 0, 0, 1), "7|maj7" to intArrayOf(3, 2, 0, 0, 0, 2),
    )

    private val BASE = mapOf('C' to 0, 'D' to 2, 'E' to 4, 'F' to 5, 'G' to 7, 'A' to 9, 'B' to 11)

    private fun build(frets: IntArray, b: Int): ChordShape {
        val pos = frets.filter { it > 0 }
        val m = pos.minOrNull() ?: 1
        val base = if ((pos.maxOrNull() ?: 0) <= 4) 1 else m
        val rel = IntArray(6) { val v = frets[it]; if (v > 0) v - base + 1 else v }
        return ChordShape(rel, base, if (b > 0) b - base + 1 else 0)
    }

    private fun shape(tpl: IntArray, b: Int) = build(IntArray(6) { if (tpl[it] == X) X else tpl[it] + b }, b)

    /** Nama seperti "Am", "D♭maj7", "F#m7"; null untuk "–" atau nama yang tidak dikenal. */
    fun pick(name: String): ChordShape? {
        if (name.isEmpty()) return null
        var root = BASE[name[0]] ?: return null
        var i = 1
        if (i < name.length) {
            when (name[i]) {
                '#' -> { root += 1; i++ }
                '\u266D', 'b' -> { root -= 1; i++ }
            }
        }
        root = (root + 12) % 12
        var suffix = name.substring(i)
        if (suffix == "maj") suffix = ""
        val q = QUAL[suffix] ?: return null
        OPEN["$root|$suffix"]?.let { return build(it, 0) }
        return if (q.e != null) shape(q.e, (root - 4 + 12) % 12) else shape(q.a, (root - 9 + 12) % 12)
    }
}

/** Diagram akor gitar: kisi bingkai membulat, garis tipis, pelana, barre, tanda x / o, titik jari. Koordinat 58 x 68. */
internal class ChordDiagramView(c: Context) : View(c) {
    var shape: ChordShape? = null
        set(v) { field = v; invalidate() }
    var color: Int = ISL_WHITE
        set(v) { field = v; invalidate() }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val names = arrayOf("E", "A", "D", "G", "B", "E")

    override fun onDraw(cv: Canvas) {
        val sh = shape ?: return
        val sc = min(width / 58f, height / 68f)
        val s = 7f; val f = 12f; val w = 35f; val h = 48f
        fun rowY(r: Int) = (r - 1) * f + f / 2f

        cv.save()
        cv.translate((width - 58f * sc) / 2f, (height - 68f * sc) / 2f)
        cv.scale(sc, sc)
        cv.translate(14f, 13f)

        p.color = color
        p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        p.style = Paint.Style.STROKE
        p.strokeWidth = 0.6f
        for (i in 1..3) cv.drawLine(0f, i * f, w, i * f, p)
        for (i in 1..4) cv.drawLine(i * s, 0f, i * s, h, p)
        cv.drawRoundRect(0f, 0f, w, h, 3f, 3f, p)

        if (sh.baseFret == 1) {
            p.strokeWidth = 1.8f
            cv.drawLine(3f, 0f, w - 3f, 0f, p)
        } else {
            p.style = Paint.Style.FILL; p.textSize = 4f; p.textAlign = Paint.Align.LEFT
            cv.drawText("${sh.baseFret}fr", -12f, 8f, p)
        }

        p.style = Paint.Style.FILL; p.textSize = 4.8f; p.textAlign = Paint.Align.CENTER
        for (i in 0..5) cv.drawText(names[i], i * s, 53f, p)

        if (sh.barre > 0) {
            val idx = (0..5).filter { sh.frets[it] == sh.barre }
            if (idx.size > 1) {
                val a = idx.first(); val z = idx.last(); val y = rowY(sh.barre)
                cv.drawRoundRect(a * s - 3.4f, y - 3.4f, z * s + 3.4f, y + 3.4f, 3.4f, 3.4f, p)
            }
        }

        for (i in 0..5) {
            val x = i * s
            val fr = sh.frets[i]
            when {
                fr == -1 -> {
                    p.style = Paint.Style.STROKE; p.strokeWidth = 1.1f
                    cv.drawLine(x - 2.2f, -7.4f, x + 2.2f, -3f, p)
                    cv.drawLine(x + 2.2f, -7.4f, x - 2.2f, -3f, p)
                }
                fr == 0 -> {
                    p.style = Paint.Style.STROKE; p.strokeWidth = 1f
                    cv.drawCircle(x, -5.2f, 2.2f, p)
                }
                else -> {
                    p.style = Paint.Style.FILL
                    cv.drawCircle(x, rowY(fr), 3.4f, p)
                }
            }
        }
        cv.restore()
    }
}

/**
 * Latar kartu island: gradien hitam pekat -> abu terang tipis di kanan (110 derajat, banyak titik supaya halus),
 * ditimpa tekstur noise (butiran abu acak, ubin 128 px diulang), plus garis tepi putih tipis.
 */
internal class IslandDrawable(private val radius: Float, private val strokeW: Float) : Drawable() {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val grain = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = BitmapShader(NOISE, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
        alpha = 46   // ~18%
    }
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = 0x1FFFFFFF; strokeWidth = strokeW
    }
    private val rect = RectF()
    private val edge = RectF()

    override fun onBoundsChange(b: Rect) {
        rect.set(b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), b.bottom.toFloat())
        edge.set(rect); edge.inset(strokeW / 2f, strokeW / 2f)
        // gradien CSS 110deg: arah (sin, -cos), panjang garis = |w sin| + |h cos|
        val a = Math.toRadians(110.0)
        val dx = sin(a).toFloat(); val dy = (-cos(a)).toFloat()
        val len = abs(rect.width() * dx) + abs(rect.height() * dy)
        val cx = rect.centerX(); val cy = rect.centerY()
        fill.shader = LinearGradient(
            cx - dx * len / 2f, cy - dy * len / 2f, cx + dx * len / 2f, cy + dy * len / 2f,
            COLORS, STOPS, Shader.TileMode.CLAMP,
        )
    }

    override fun draw(cv: Canvas) {
        cv.drawRoundRect(rect, radius, radius, fill)
        cv.drawRoundRect(rect, radius, radius, grain)
        cv.drawRoundRect(edge, radius - strokeW / 2f, radius - strokeW / 2f, border)
    }

    override fun setAlpha(alpha: Int) { fill.alpha = alpha }
    override fun setColorFilter(cf: ColorFilter?) { fill.colorFilter = cf }
    @Deprecated("Deprecated in Java")
    override fun getOpacity() = PixelFormat.TRANSLUCENT

    private companion object {
        val COLORS = intArrayOf(
            0xFF000000.toInt(), 0xFF000000.toInt(), 0xFF050506.toInt(), 0xFF0E0E10.toInt(), 0xFF1A1A1C.toInt(),
            0xFF2A2A2D.toInt(), 0xFF3D3D41.toInt(), 0xFF525257.toInt(), 0xFF68686D.toInt(), 0xFF7C7C80.toInt(),
        )
        val STOPS = floatArrayOf(0f, 0.38f, 0.46f, 0.54f, 0.62f, 0.70f, 0.78f, 0.86f, 0.93f, 1f)

        val NOISE: Bitmap by lazy {
            val n = 128
            val px = IntArray(n * n)
            val r = java.util.Random(7)
            for (i in px.indices) { val g = r.nextInt(256); px[i] = (0xFF shl 24) or (g shl 16) or (g shl 8) or g }
            Bitmap.createBitmap(px, n, n, Bitmap.Config.ARGB_8888)
        }
    }
}

/**
 * Bar progres kartu island: jalur putih 25%, isi putih, kepala bulat 12dp (sama dengan input range di prototipe HTML).
 * [interactive] = false: hanya penunjuk progres (tanpa kepala, tidak menangkap sentuhan), dipakai saat file masih dianalisis.
 * Geser: [onScrub] dipanggil terus selama jari bergerak, [onCommit] sekali saat jari diangkat.
 */
internal class IslandSeek(c: Context) : View(c) {
    var progress: Float = 0f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }
    var interactive: Boolean = true
        set(v) { field = v; invalidate() }
    var dragging: Boolean = false
        private set
    var onScrub: ((Float) -> Unit)? = null
    var onCommit: ((Float) -> Unit)? = null

    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thumbR get() = 6f * d
    private val pad get() = if (interactive) thumbR else 0f

    override fun onDraw(cv: Canvas) {
        val th = 4f * d
        val l = pad; val r = width - pad; val cy = height / 2f
        if (r <= l) return
        p.style = Paint.Style.FILL
        p.color = ISL_TRACK
        cv.drawRoundRect(l, cy - th / 2f, r, cy + th / 2f, th / 2f, th / 2f, p)
        val x = l + (r - l) * progress
        p.color = ISL_WHITE
        if (x > l) cv.drawRoundRect(l, cy - th / 2f, x, cy + th / 2f, th / 2f, th / 2f, p)
        if (interactive) cv.drawCircle(x, cy, thumbR, p)
    }

    private fun frac(e: MotionEvent): Float {
        val w = width - 2f * pad
        return if (w <= 0f) 0f else ((e.x - pad) / w).coerceIn(0f, 1f)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!interactive) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                dragging = true
                parent?.requestDisallowInterceptTouchEvent(true)   // panel bisa digulir; geser di bar = geser lagu
                progress = frac(e)
                onScrub?.invoke(progress)
            }
            MotionEvent.ACTION_UP -> {
                dragging = false
                progress = frac(e)
                onCommit?.invoke(progress)
            }
            MotionEvent.ACTION_CANCEL -> { dragging = false; invalidate() }
        }
        return true
    }
}
