package com.laykit.chord

import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/**
 * Tabel 301 akor (chord_table.json, disimpan di cnn.lkm sebagai blob "chord_table_json").
 * idx[s][h] = indeks kelas di head h (triad, bass, 7th, 9th, 11th, 13th); -1 = head tidak dipakai.
 */
internal class ChordTable(
    val names: Array<String>,
    val idx: Array<IntArray>,
    val penalty: Double,
    val hop: Int,
    val sampleRate: Int,
    val startState: Int,
) {
    val size get() = names.size

    init {
        require(names.size == idx.size) { "names dan idx beda jumlah" }
        for (r in idx) {
            require(r.size == ChordNetCnn.HEAD_SIZES.size) { "idx harus 6 kolom" }
            for (h in r.indices) require(r[h] < ChordNetCnn.HEAD_SIZES[h]) { "indeks head $h di luar rentang" }
        }
    }
}

/**
 * Pasca-proses ChordMini CNN+LSTM:
 *   1. [planChunks]  : rencana potong lagu jadi chunk (3000 frame, overlap 400)
 *   2. [Accumulator] : jumlahkan probabilitas 6 head dari tiap fold, tiap chunk hanya bagian tengahnya
 *   3. [decode]      : rata-rata fold -> Viterbi 301 kelas (penalti pindah state konstan) -> segmen
 *
 * Alur pemakaian (fold berurutan, hemat RAM):
 *   val plan = FlatChordDecoder.planChunks(frames)
 *   val acc = FlatChordDecoder.Accumulator(frames)
 *   for (fold in folds) { val net = ChordNetCnn(lkm, fold)
 *       for (c in plan) acc.add(net.forward(slice(x, c.start, c.end), c.end - c.start), c) }
 *   val segs = decoder.decode(acc, folds.size)
 */
internal class FlatChordDecoder(private val table: ChordTable) {

    /** Chunk [start,end) diproses model; hanya [keepFrom,keepTo) dipakai ke hasil. Semua indeks frame global. */
    class Chunk(val start: Int, val end: Int, val keepFrom: Int, val keepTo: Int)

    /** Jumlah probabilitas per head, [frame * ukuran head]. */
    class Accumulator(val frames: Int) {
        internal val sum: Array<FloatArray> = Array(ChordNetCnn.HEAD_SIZES.size) { FloatArray(frames * ChordNetCnn.HEAD_SIZES[it]) }

        /** Tambahkan keluaran satu chunk dari satu fold (frame lokal 0 = c.start). */
        fun add(r: ChordNetCnn.Heads, c: Chunk) {
            require(r.frames == c.end - c.start) { "jumlah frame hasil ${r.frames} != ukuran chunk ${c.end - c.start}" }
            val src = r.all()
            for (h in sum.indices) {
                val n = ChordNetCnn.HEAD_SIZES[h]
                val from = (c.keepFrom - c.start) * n
                val len = (c.keepTo - c.keepFrom) * n
                val dst = c.keepFrom * n
                val s = src[h]
                val d = sum[h]
                for (i in 0 until len) d[dst + i] += s[from + i]
            }
        }
    }

    /** Pilih satu akor per frame lewat Viterbi; kembalikan indeks state per frame. */
    fun viterbi(acc: Accumulator, nFolds: Int): IntArray {
        val frames = acc.frames
        val nS = table.size
        if (frames == 0) return IntArray(0)
        val inv = 1.0 / nFolds
        val sizes = ChordNetCnn.HEAD_SIZES
        val nH = sizes.size
        val logHead = Array(nH) { DoubleArray(sizes[it]) }
        val logp = DoubleArray(nS)
        var prev = DoubleArray(nS)
        var cur = DoubleArray(nS)
        val jump = ByteArray(frames * nS)   // 1 = datang dari state terbaik frame sebelumnya (pindah), 0 = bertahan
        val bestPrev = IntArray(frames)     // argmax dp[t] (dipakai frame t+1)

        for (t in 0 until frames) {
            for (h in 0 until nH) {
                val n = sizes[h]
                val s = acc.sum[h]
                val lh = logHead[h]
                for (k in 0 until n) lh[k] = ln(max(s[t * n + k] * inv, EPS))
            }
            for (s in 0 until nS) {
                val r = table.idx[s]
                var v = 0.0
                for (h in 0 until nH) if (r[h] >= 0) v += logHead[h][r[h]]
                logp[s] = v
            }
            if (t == 0) {
                for (s in 0 until nS) cur[s] = logp[s] - if (s == table.startState) 0.0 else table.penalty
            } else {
                val jumpScore = prev[bestPrev[t - 1]] - table.penalty
                for (s in 0 until nS) {
                    val stay = prev[s]
                    if (stay >= jumpScore) cur[s] = logp[s] + stay
                    else { cur[s] = logp[s] + jumpScore; jump[t * nS + s] = 1 }
                }
            }
            var b = 0
            for (s in 1 until nS) if (cur[s] > cur[b]) b = s
            bestPrev[t] = b
            val tmp = prev; prev = cur; cur = tmp
        }

        val path = IntArray(frames)
        var s = bestPrev[frames - 1]
        for (t in frames - 1 downTo 0) {
            path[t] = s
            if (t > 0 && jump[t * nS + s].toInt() == 1) s = bestPrev[t - 1]
        }
        return path
    }

    /** Viterbi lalu gabungkan frame berurutan yang akornya sama jadi segmen (detik). */
    fun decode(acc: Accumulator, nFolds: Int): List<ChordSegment> =
        toSegments(viterbi(acc, nFolds))

    fun toSegments(path: IntArray): List<ChordSegment> {
        val out = ArrayList<ChordSegment>()
        if (path.isEmpty()) return out
        val dt = table.hop.toDouble() / table.sampleRate
        var a = 0
        for (t in 1..path.size) {
            if (t == path.size || path[t] != path[a]) {
                out += ChordSegment(a * dt, t * dt, table.names[path[a]]) // kelas ChordSegment ada di ChordEngine.kt
                a = t
            }
        }
        return out
    }

    companion object {
        const val CHUNK = 3000
        const val OVERLAP = 400
        private const val EPS = 1e-10

        /**
         * Rencana chunk: awal tiap chunk maju (chunk-overlap) frame; chunk terakhir digeser mundur supaya
         * penuh [chunk] frame (statistik InstanceNorm tidak dari potongan pendek). Sambungan antar chunk
         * dipotong di tengah daerah yang tumpang tindih. Lagu <= chunk = satu chunk.
         */
        fun planChunks(frames: Int, chunk: Int = CHUNK, overlap: Int = OVERLAP): List<Chunk> {
            if (frames <= 0) return emptyList()
            if (frames <= chunk) return listOf(Chunk(0, frames, 0, frames))
            val step = chunk - overlap
            val starts = ArrayList<Int>()
            var s = 0
            while (true) {
                if (s + chunk >= frames) { starts += frames - chunk; break }
                starts += s
                s += step
            }
            val cuts = IntArray(starts.size - 1) { (starts[it + 1] + (starts[it] + chunk)) / 2 }
            return starts.indices.map { i ->
                Chunk(
                    start = starts[i], end = min(frames, starts[i] + chunk),
                    keepFrom = if (i == 0) 0 else cuts[i - 1],
                    keepTo = if (i == starts.size - 1) frames else cuts[i],
                )
            }
        }

        /** Format .lab: "mulai selesai nama" per baris. */
        fun toLab(segs: List<ChordSegment>): String = buildString {
            for (g in segs) append("%.6f %.6f %s\n".format(java.util.Locale.US, g.start, g.end, g.label))
        }
    }
}
