package com.laykit

import android.content.Context

/** Pengaturan rekaman yang dipakai bersama oleh layar utama dan HUD melayang. */
data class RecSettings(
    val res: Int = 1080,
    val fps: Int = 30,
    val orient: Int = 0,
    val internal: Boolean = true,
    val mic: Boolean = false,
    val micDev: Int = -1,        // id AudioDeviceInfo, -1 = bawaan sistem
)

object RecPrefs {
    private fun sp(c: Context) = c.getSharedPreferences("rec", Context.MODE_PRIVATE)

    fun load(c: Context): RecSettings {
        val p = sp(c)
        return RecSettings(
            res = p.getInt("res", 1080), fps = p.getInt("fps", 30), orient = p.getInt("orient", 0),
            internal = p.getBoolean("internal", true), mic = p.getBoolean("mic", false),
            micDev = p.getInt("micDev", -1),
        )
    }

    fun save(c: Context, s: RecSettings) {
        sp(c).edit()
            .putInt("res", s.res).putInt("fps", s.fps).putInt("orient", s.orient)
            .putBoolean("internal", s.internal).putBoolean("mic", s.mic).putInt("micDev", s.micDev)
            .apply()
    }

    fun hudPos(c: Context): Pair<Int, Int> = sp(c).let { it.getInt("hudX", -1) to it.getInt("hudY", -1) }

    fun saveHudPos(c: Context, x: Int, y: Int) {
        sp(c).edit().putInt("hudX", x).putInt("hudY", y).apply()
    }
}
