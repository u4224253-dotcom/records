package com.laykit

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/*
 * Komponen panel editor, mengikuti desain LayKit_PanelEditor.html (datar, gelap, tanpa bayangan):
 *  - PanelTabs   : tab teks + garis bawah aksen, ikon Reset (opsional) dan centang aksen di kanan
 *  - FlatSlider  : garis 2 dp, bulatan putih 20 dp
 *  - TickSlider  : skala 20 garis, penanda aksen 3x28 dp, label kiri 64 dp, nilai kanan 48 dp (di dalam PanelGroup)
 *  - ParamRow    : baris pilihan parameter (nama + nilai), satu slider di bawahnya
 *  - PanelSeg    : segmen (3D, kanal kurva); PanelPill : chip bulat; ActionCard / AspectCard : kartu pilihan
 *  - ToggleRow   : saklar 48x28 dp; PanelGroup : kelompok berlatar kartu
 *  - ToolNav     : nav bawah 5 tombol dengan indikator pil (desain LayKit_NavBawah)
 */

// Ikon garis 24x24 (urutan path digambar dengan ToolIcon)
internal val ICON_CHECK = listOf("M5 12.5L10 17.5L19 7")
internal val ICON_AUTO = listOf("M12 3L14 10L21 12L14 14L12 21L10 14L3 12L10 10Z")
internal val ICON_PLUS = listOf("M12 5V19", "M5 12H19")
internal val ICON_TRASH = listOf("M4 7H20", "M9 7V4H15V7", "M6 7L7 20H17L18 7")
internal val ICON_AREA = listOf("M7 7H17V17H7Z", "M12 3V7", "M12 17V21", "M3 12H7", "M17 12H21")
internal val ICON_RESET = listOf("M4 12a8 8 0 1 0 2.5 -5.8", "M4 4V9H9")

/** Easing buka panel (translateY 102% -> 0, .3 dtk) dan indikator nav. Sama dengan CSS desain. */
internal val PANEL_EASE = CubicBezierEasing(0.3f, 1.1f, 0.5f, 1f)
private val SPRING_EASE = CubicBezierEasing(0.3f, 1.4f, 0.5f, 1f)

/** Tombol Reset di header panel. */
internal class PanelReset(val enabled: Boolean, val onClick: () -> Unit)

/** Gestur geser horizontal yang mengubah nilai 0..1 menurut posisi jari. Ketukan juga memindahkan nilai. */
@Composable
private fun Modifier.fractionDrag(enabled: Boolean, padPx: Float, onFraction: (Float) -> Unit): Modifier {
    val en by rememberUpdatedState(enabled)
    val cb by rememberUpdatedState(onFraction)
    return this.pointerInput(Unit) {
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false)
            if (!en) return@awaitEachGesture
            fun f(x: Float) = ((x - padPx) / (size.width - 2f * padPx)).coerceIn(0f, 1f)
            // Arah diputuskan dulu: geser MENDATAR = menggeser slider; geser vertikal = dilepas ke panel (scroll).
            // Ketukan tanpa geser = langsung menaruh nilai di titik itu.
            val slop = viewConfiguration.touchSlop
            var decided = false
            while (true) {
                val ev = awaitPointerEvent()
                val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                if (!ch.pressed) { if (!decided) cb(f(ch.position.x)); break }
                if (ch.isConsumed) break   // panel mengambil alih (scroll)
                val dx = ch.position.x - down.position.x
                val dy = ch.position.y - down.position.y
                if (!decided && (kotlin.math.abs(dx) > slop || kotlin.math.abs(dy) > slop)) {
                    if (kotlin.math.abs(dy) > kotlin.math.abs(dx)) break   // vertikal: biarkan scroll
                    decided = true
                }
                if (decided) { cb(f(ch.position.x)); ch.consume() }
            }
        }
    }
}

/** Header panel 46 dp: tab (yang dipilih tebal + garis bawah aksen selebar teks), [reset] opsional, centang aksen. */
@Composable
internal fun PanelTabs(tabs: List<String>, sel: Int, onSel: (Int) -> Unit, onDone: () -> Unit, reset: PanelReset? = null) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().height(46.dp), verticalAlignment = Alignment.CenterVertically) {
        Row(Modifier.weight(1f).fillMaxHeight().horizontalScroll(rememberScrollState()).padding(start = 6.dp)) {
            tabs.forEachIndexed { i, t ->
                val on = i == sel
                Box(Modifier.fillMaxHeight().clickable(enabled = tabs.size > 1) { onSel(i) }) {
                    Text(
                        t, Modifier.align(Alignment.Center).padding(horizontal = 11.dp),
                        fontSize = 14.sp, maxLines = 1,
                        fontWeight = if (on) FontWeight(650) else FontWeight.Normal,
                        color = if (on) cs.onBackground else cs.onSurfaceVariant,
                    )
                    if (on) {
                        Box(Modifier.matchParentSize().padding(start = 11.dp, end = 11.dp, bottom = 4.dp)) {
                            Box(Modifier.align(Alignment.BottomStart).fillMaxWidth().height(2.dp).background(cs.primary, RoundedCornerShape(2.dp)))
                        }
                    }
                }
            }
        }
        if (reset != null) {
            Box(
                Modifier.width(44.dp).fillMaxHeight().clickable(enabled = reset.enabled, onClick = reset.onClick),
                contentAlignment = Alignment.Center,
            ) { ToolIcon(ICON_RESET, cs.onSurfaceVariant.copy(alpha = if (reset.enabled) 1f else 0.35f), 20.dp) }
        }
        Box(Modifier.width(44.dp).fillMaxHeight().clickable(onClick = onDone), contentAlignment = Alignment.Center) {
            ToolIcon(ICON_CHECK, cs.primary, 22.dp)
        }
    }
}

/** Slider tipis: garis 2 dp (aktif = aksen), bulatan putih 20 dp sebagai pegangan. */
@Composable
internal fun FlatSlider(
    value: Float,
    onChange: (Float) -> Unit,
    range: ClosedFloatingPointRange<Float>,
    enabled: Boolean = true,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val padPx = with(LocalDensity.current) { 10.dp.toPx() }
    val span = range.endInclusive - range.start
    val frac = if (span <= 0f) 0f else ((value - range.start) / span).coerceIn(0f, 1f)
    Canvas(
        modifier.fillMaxWidth().height(30.dp)
            .fractionDrag(enabled, padPx) { f -> onChange(range.start + f * span) },
    ) {
        val cy = size.height / 2f
        val x0 = padPx
        val x1 = size.width - padPx
        val x = x0 + frac * (x1 - x0)
        val a = if (enabled) 1f else 0.4f
        drawLine(cs.outline, Offset(x0, cy), Offset(x1, cy), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
        drawLine(cs.primary.copy(alpha = a), Offset(x0, cy), Offset(x, cy), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
        drawCircle(Color.Black.copy(alpha = 0.35f * a), 11.dp.toPx(), Offset(x, cy + 1.dp.toPx()))
        drawCircle(Color.White.copy(alpha = a), 10.dp.toPx(), Offset(x, cy))
    }
}

/** Slider berskala garis (20 garis rata), tinggi baris 46 dp: label 64 dp, penanda aksen 3x28 dp, nilai 48 dp. [divider] = garis tipis di atas baris. */
@Composable
internal fun TickSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    valueText: String,
    enabled: Boolean = true,
    divider: Boolean = false,
    onChange: (Float) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val padPx = with(LocalDensity.current) { 1.5.dp.toPx() }
    val span = range.endInclusive - range.start
    val frac = if (span <= 0f) 0f else ((value - range.start) / span).coerceIn(0f, 1f)
    val a = if (enabled) 1f else 0.4f
    val line = cs.outlineVariant
    Row(
        Modifier.fillMaxWidth().height(46.dp)
            .then(
                if (divider) Modifier.drawBehind {
                    drawLine(line, Offset(0f, 0.5f), Offset(size.width, 0.5f), strokeWidth = 1.dp.toPx())
                } else Modifier,
            ),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, Modifier.width(64.dp), fontSize = 13.sp, maxLines = 1, color = cs.onSurfaceVariant.copy(alpha = a))
        Canvas(
            Modifier.weight(1f).fillMaxHeight()
                .fractionDrag(enabled, padPx) { f -> onChange(range.start + f * span) },
        ) {
            val cy = size.height / 2f
            val x0 = padPx
            val x1 = size.width - padPx
            val tickC = cs.onSurfaceVariant.copy(alpha = 0.5f * a)
            for (i in 0 until 20) {
                val x = size.width * i / 20f + 0.5.dp.toPx()
                drawLine(tickC, Offset(x, cy - 7.dp.toPx()), Offset(x, cy + 7.dp.toPx()), strokeWidth = 1.dp.toPx())
            }
            val xv = x0 + frac * (x1 - x0)
            drawLine(cs.primary.copy(alpha = a), Offset(xv, cy - 14.dp.toPx()), Offset(xv, cy + 14.dp.toPx()), strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round)
        }
        Text(valueText, Modifier.width(48.dp), fontSize = 14.sp, maxLines = 1, textAlign = TextAlign.End, color = cs.onBackground.copy(alpha = a))
    }
}

/** Baris pilihan parameter: tiap tombol memuat nama + nilai. Yang dipilih berlatar abu terang dan berwarna aksen. */
@Composable
internal fun ParamRow(
    labels: List<String>,
    values: List<String>,
    sel: Int,
    enabled: Boolean = true,
    modifier: Modifier = Modifier,
    onSel: (Int) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    Row(
        modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(cs.surfaceVariant).padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        labels.forEachIndexed { i, l ->
            val on = i == sel
            Row(
                Modifier.weight(1f).height(32.dp).clip(RoundedCornerShape(9.dp))
                    .background(if (on) cs.surfaceContainerHighest else Color.Transparent)
                    .clickable(enabled = enabled) { onSel(i) },
                horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(l, fontSize = 13.sp, maxLines = 1, color = if (on) cs.primary else cs.onSurfaceVariant)
                Text(values[i], fontSize = 13.sp, maxLines = 1, fontWeight = FontWeight.SemiBold, color = if (on) cs.primary else cs.onBackground)
            }
        }
    }
}

/** Baris yang membagi sisa lebar rata ke semua anak kalau muat ([minWidth]); kalau tidak muat, lebar asli (bisa digulir). */
@Composable
private fun GrowRow(minWidth: Dp, gap: Dp, content: @Composable () -> Unit) {
    Layout(content = content) { measurables, constraints ->
        val g = gap.roundToPx()
        val nat = measurables.map { it.maxIntrinsicWidth(0) }
        val total = nat.sum() + g * (measurables.size - 1).coerceAtLeast(0)
        val target = maxOf(total, minWidth.roundToPx())
        val extra = if (measurables.isEmpty()) 0 else (target - total) / measurables.size
        val placeables = measurables.mapIndexed { i, m -> m.measure(Constraints.fixedWidth(nat[i] + extra)) }
        val hh = placeables.maxOfOrNull { it.height } ?: 0
        layout(target, hh) {
            var x = 0
            placeables.forEach { p -> p.placeRelative(x, 0); x += p.width + g }
        }
    }
}

/** Segmen: satu baris tombol dalam wadah membulat, yang dipilih berlatar abu terang + tebal. Bisa digulir kalau tidak muat. */
@Composable
internal fun <T> PanelSeg(
    items: List<Pair<String, T>>,
    sel: T,
    enabled: Boolean = true,
    modifier: Modifier = Modifier,
    fontSize: TextUnit = 13.sp,
    hPad: Dp = 12.dp,
    onPick: (T) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    BoxWithConstraints(modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(cs.surfaceVariant)) {
        val inner = maxWidth - 6.dp
        Box(Modifier.horizontalScroll(rememberScrollState()).padding(3.dp)) {
            GrowRow(inner, 4.dp) {
                items.forEach { (label, v) ->
                    val on = sel == v
                    Box(
                        Modifier.height(30.dp).clip(RoundedCornerShape(9.dp))
                            .background(if (on) cs.surfaceContainerHighest else Color.Transparent)
                            .clickable(enabled = enabled) { onPick(v) }
                            .padding(horizontal = hPad),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            label, fontSize = fontSize, maxLines = 1,
                            fontWeight = if (on) FontWeight(650) else FontWeight.Normal,
                            color = (if (on) cs.onBackground else cs.onSurfaceVariant).copy(alpha = if (enabled) 1f else 0.5f),
                        )
                    }
                }
            }
        }
    }
}

/** Chip bulat 34 dp: yang dipilih berlatar aksen. */
@Composable
internal fun PanelPill(label: String, selected: Boolean = false, enabled: Boolean = true, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        modifier.height(34.dp).alpha(if (enabled) 1f else 0.4f).clip(CircleShape)
            .background(if (selected) cs.primary else cs.surfaceVariant)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label, fontSize = 13.sp, maxLines = 1,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            color = if (selected) cs.onPrimary else cs.onBackground,
        )
    }
}

/** Kartu aksi 64 dp: ikon + label. Lebar diatur pemanggil (biasanya Modifier.weight(1f) di dalam Row). */
@Composable
internal fun ActionCard(
    icon: List<String>,
    label: String,
    selected: Boolean = false,
    enabled: Boolean = true,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val bg = if (selected) cs.primary else cs.surfaceVariant
    val fg = if (selected) cs.onPrimary else cs.onBackground
    Column(
        modifier.height(64.dp).alpha(if (enabled) 1f else 0.35f).clip(RoundedCornerShape(14.dp)).background(bg)
            .clickable(enabled = enabled, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        ToolIcon(icon, fg, 22.dp)
        Spacer(Modifier.height(4.dp))
        Text(label, fontSize = 11.sp, maxLines = 1, color = fg)
    }
}

/** Kartu rasio persegi: persegi panjang kecil dengan rasio sebenarnya + label. [ratio] null = "Asli". */
@Composable
internal fun AspectCard(label: String, ratio: Float?, selected: Boolean, enabled: Boolean = true, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val bg = if (selected) cs.primary else cs.surfaceVariant
    val fg = if (selected) cs.onPrimary else cs.onBackground
    val r = ratio ?: 1.3f
    val w = if (r >= 1f) 30f else 30f * r
    val h = if (r >= 1f) 30f / r else 30f
    Column(
        modifier.aspectRatio(1f).alpha(if (enabled) 1f else 0.35f).clip(RoundedCornerShape(14.dp)).background(bg)
            .clickable(enabled = enabled, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(Modifier.size(w.dp, h.dp).border(1.6.dp, fg, RoundedCornerShape(3.dp)))
        Spacer(Modifier.height(6.dp))
        Text(label, fontSize = 11.sp, maxLines = 1, color = fg)
    }
}

/** Kelompok berlatar kartu (radius 14, isi menjorok 14 dp). */
@Composable
internal fun PanelGroup(modifier: Modifier = Modifier, top: Dp = 4.dp, bottom: Dp = 4.dp, content: @Composable ColumnScope.() -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(
        modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(cs.surfaceVariant)
            .padding(start = 14.dp, end = 14.dp, top = top, bottom = bottom),
        content = content,
    )
}

/** Baris saklar 48 dp: label kiri, saklar 48x28 kanan (hidup = hijau teal), catatan kecil di bawah (opsional). */
@Composable
internal fun ToggleRow(label: String, checked: Boolean, enabled: Boolean = true, note: String? = null, onChecked: (Boolean) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val knob by animateDpAsState(if (checked) 23.dp else 3.dp, tween(220, easing = SPRING_EASE), label = "knob")
    val track by animateColorAsState(if (checked) Color(0xFF5E9C96) else cs.surfaceContainerHighest, tween(200), label = "track")
    Column {
        Row(Modifier.fillMaxWidth().height(48.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(label, Modifier.weight(1f), fontSize = 14.sp, color = cs.onBackground)
            Box(
                Modifier.size(48.dp, 28.dp).alpha(if (enabled) 1f else 0.4f).clip(CircleShape).background(track)
                    .toggleable(value = checked, enabled = enabled, role = Role.Switch, onValueChange = onChecked),
            ) {
                Box(Modifier.offset(x = knob, y = 3.dp).size(22.dp).clip(CircleShape).background(Color.White))
            }
        }
        if (note != null) Text(note, fontSize = 12.sp, lineHeight = 17.sp, color = cs.onSurfaceVariant)
    }
}

/** Petunjuk di dalam panel (13 sp). */
@Composable
internal fun PanelHint(text: String, modifier: Modifier = Modifier) {
    Text(text, modifier.padding(horizontal = 2.dp, vertical = 6.dp), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

/** Catatan kecil di dalam panel (12 sp). */
@Composable
internal fun PanelNote(text: String, modifier: Modifier = Modifier) {
    Text(text, modifier, fontSize = 12.sp, lineHeight = 17.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

/** Kisi [count] sel dalam [cols] kolom sama lebar. Sel terakhir yang kosong diisi spacer supaya lebar sel tetap. */
@Composable
internal fun GridRows(count: Int, cols: Int, gap: Dp, modifier: Modifier = Modifier, cell: @Composable (Int, Modifier) -> Unit) {
    val rows = (count + cols - 1) / cols
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(gap)) {
        for (r in 0 until rows) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(gap)) {
                for (c in 0 until cols) {
                    val i = r * cols + c
                    if (i < count) cell(i, Modifier.weight(1f)) else Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

/** Satu tombol nav: ikon dalam pil 52x30 (indikator tumbuh saat aktif) + label. */
@Composable
private fun NavItem(icon: List<String>, label: String, active: Boolean, modifier: Modifier, fontSize: TextUnit = 11.sp, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val p by animateFloatAsState(if (active) 1f else 0f, tween(280, easing = SPRING_EASE), label = "nav")
    val c = if (active) cs.primary else Color(0xFFC7C7CC)
    val indicator = cs.primary.copy(alpha = 0.14f)
    Column(
        modifier.height(56.dp).clip(RoundedCornerShape(16.dp))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp, Alignment.CenterVertically),
    ) {
        Box(Modifier.size(52.dp, 30.dp), contentAlignment = Alignment.Center) {
            Box(
                Modifier.matchParentSize()
                    .graphicsLayer {
                        scaleX = 0.4f + 0.6f * p
                        scaleY = 0.6f + 0.4f * p
                        alpha = p.coerceIn(0f, 1f)
                    }
                    .background(indicator, RoundedCornerShape(15.dp)),
            )
            Box(
                Modifier.graphicsLayer {
                    val s = 1f + 0.06f * p
                    scaleX = s
                    scaleY = s
                    translationY = -0.5.dp.toPx() * p
                },
            ) { ToolIcon(icon, c, 22.dp, strokeW = 1.75f) }
        }
        Text(label, fontSize = fontSize, lineHeight = fontSize, maxLines = 1, fontWeight = if (active) FontWeight.Bold else FontWeight.Medium, color = c)
    }
}

/** Nav bawah 72 dp: tombol sama lebar (label diperkecil bila lebih dari 5 supaya "Background" tetap muat). [active] = indeks tool yang panelnya terbuka (-1 = tidak ada). */
@Composable
internal fun ToolNav(labels: List<String>, icons: List<List<String>>, active: Int, onPick: (Int) -> Unit) {
    val fs = if (labels.size > 5) 10.sp else 11.sp
    if (labels.size <= 7) {
        Row(
            Modifier.fillMaxWidth().height(72.dp).padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            labels.forEachIndexed { i, l -> NavItem(icons[i], l, active == i, Modifier.weight(1f), fs) { onPick(i) } }
        }
    } else {
        // lebih dari 7 tool tidak muat rata di layar HP: tampilkan 7,5 tombol lalu bisa digeser mendatar (separuh tombol terakhir = petunjuk)
        BoxWithConstraints(Modifier.fillMaxWidth().height(72.dp)) {
            val itemW = (maxWidth - 16.dp) / 7.5f
            Row(
                Modifier.fillMaxWidth().fillMaxHeight().horizontalScroll(rememberScrollState()).padding(8.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                labels.forEachIndexed { i, l -> NavItem(icons[i], l, active == i, Modifier.width(itemW), fs) { onPick(i) } }
            }
        }
    }
}
