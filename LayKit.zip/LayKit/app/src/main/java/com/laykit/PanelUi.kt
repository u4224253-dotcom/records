package com.laykit

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/*
 * Komponen panel editor (datar, gelap, tanpa bayangan), mengikuti pola editor referensi:
 *  - PanelTabs   : tab teks dengan garis bawah + tombol centang di kanan (menutup panel)
 *  - FlatSlider  : garis tipis dengan bulatan putih
 *  - TickSlider  : skala bergaris-garis dengan penanda, label di kiri dan nilai di kanan
 *  - ParamCircle : lingkaran pilihan parameter (nilai di dalam, nama di bawah) + satu slider di bawahnya
 *  - ActionCard  : kartu aksi (ikon + label), AspectCard: kartu rasio
 */

// Ikon garis 24x24 (urutan path digambar dengan ToolIcon)
internal val ICON_CHECK = listOf("M5 12.5L10 17.5L19 7")
internal val ICON_AUTO = listOf("M12 3L14 10L21 12L14 14L12 21L10 14L3 12L10 10Z")
internal val ICON_PLUS = listOf("M12 5V19", "M5 12H19")
internal val ICON_TRASH = listOf("M4 7H20", "M9 7V4H15V7", "M6 7L7 20H17L18 7")
internal val ICON_AREA = listOf("M7 7H17V17H7Z", "M12 3V7", "M12 17V21", "M3 12H7", "M17 12H21")
internal val ICON_RESET = listOf("M4 12a8 8 0 1 0 2.5 -5.8", "M4 4V9H9")

/** Gestur geser horizontal yang mengubah nilai 0..1 menurut posisi jari. Ketukan juga memindahkan nilai. */
@Composable
private fun Modifier.fractionDrag(enabled: Boolean, padPx: Float, onFraction: (Float) -> Unit): Modifier {
    val en by rememberUpdatedState(enabled)
    val cb by rememberUpdatedState(onFraction)
    return this.pointerInput(Unit) {
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false)
            if (!en) return@awaitEachGesture
            fun f(x: Float) = ((x - padPx) / (size.width - 2f * padPx)).coerceIn(0f, 1f)
            // Arah diputuskan dulu: geser MENDATAR = menggeser slider; geser vertikal = dilepas ke panel (scroll).
            // Ketukan tanpa geser = langsung menaruh nilai di titik itu. Dulu slider menelan semua sentuhan, jadi panel tidak bisa di-scroll.
            val slop = viewConfiguration.touchSlop
            var decided = false
            while (true) {
                val ev = awaitPointerEvent()
                val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                if (!ch.pressed) { if (!decided) cb(f(ch.position.x)); break }
                if (ch.isConsumed) break   // panel mengambil alih (scroll)
                val dx = ch.position.x - down.position.x
                val dy = ch.position.y - down.position.y
                if (!decided && (kotlin.math.abs(dx) > slop || kotlin.math.abs(dy) > slop)) {
                    if (kotlin.math.abs(dy) > kotlin.math.abs(dx)) break   // vertikal: biarkan scroll
                    decided = true
                }
                if (decided) { cb(f(ch.position.x)); ch.consume() }
            }
        }
    }
}

/** Tab panel: teks (yang dipilih tebal + garis bawah aksen) dan centang di kanan. Satu tab saja = judul. */
@Composable
internal fun PanelTabs(tabs: List<String>, sel: Int, onSel: (Int) -> Unit, onDone: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().height(46.dp), verticalAlignment = Alignment.CenterVertically) {
        Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()).padding(start = 8.dp)) {
            tabs.forEachIndexed { i, t ->
                val on = i == sel
                Column(
                    Modifier.fillMaxHeight().clickable(enabled = tabs.size > 1) { onSel(i) }.padding(horizontal = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Text(
                        t, fontSize = 15.sp, maxLines = 1,
                        fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
                        color = if (on) cs.onBackground else cs.onSurfaceVariant,
                    )
                    Box(
                        Modifier.padding(top = 4.dp).width(24.dp).height(2.dp)
                            .background(if (on) cs.primary else Color.Transparent, RoundedCornerShape(1.dp)),
                    )
                }
            }
        }
        Box(Modifier.size(46.dp).clickable(onClick = onDone), contentAlignment = Alignment.Center) {
            ToolIcon(ICON_CHECK, cs.onBackground, 24.dp)
        }
    }
}

/** Slider tipis: garis 2 dp, bagian aktif berwarna aksen, bulatan putih sebagai pegangan. */
@Composable
internal fun FlatSlider(
    value: Float,
    onChange: (Float) -> Unit,
    range: ClosedFloatingPointRange<Float>,
    enabled: Boolean = true,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val padPx = with(LocalDensity.current) { 12.dp.toPx() }
    val span = range.endInclusive - range.start
    val frac = if (span <= 0f) 0f else ((value - range.start) / span).coerceIn(0f, 1f)
    Canvas(
        modifier.fillMaxWidth().height(34.dp)
            .fractionDrag(enabled, padPx) { f -> onChange(range.start + f * span) },
    ) {
        val cy = size.height / 2f
        val x0 = padPx
        val x1 = size.width - padPx
        val x = x0 + frac * (x1 - x0)
        val a = if (enabled) 1f else 0.4f
        drawLine(cs.outline, Offset(x0, cy), Offset(x1, cy), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
        drawLine(cs.primary.copy(alpha = 0.9f * a), Offset(x0, cy), Offset(x, cy), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
        drawCircle(Color.Black.copy(alpha = 0.35f * a), 11.dp.toPx(), Offset(x, cy + 1.dp.toPx()))
        drawCircle(Color.White.copy(alpha = a), 9.dp.toPx(), Offset(x, cy))
    }
}

/** Slider berskala garis: label kiri, penanda aksen di posisi nilai, angka kanan. */
@Composable
internal fun TickSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    valueText: String,
    enabled: Boolean = true,
    onChange: (Float) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val padPx = with(LocalDensity.current) { 8.dp.toPx() }
    val span = range.endInclusive - range.start
    val frac = if (span <= 0f) 0f else ((value - range.start) / span).coerceIn(0f, 1f)
    val a = if (enabled) 1f else 0.4f
    Row(Modifier.fillMaxWidth().height(44.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.width(64.dp), fontSize = 13.sp, maxLines = 1, color = cs.onSurfaceVariant.copy(alpha = a))
        Canvas(
            Modifier.weight(1f).fillMaxHeight()
                .fractionDrag(enabled, padPx) { f -> onChange(range.start + f * span) },
        ) {
            val cy = size.height / 2f
            val x0 = padPx
            val x1 = size.width - padPx
            val n = 40
            for (i in 0..n) {
                val x = x0 + (x1 - x0) * i / n
                val major = i % 5 == 0
                val h = (if (major) 16.dp else 9.dp).toPx()
                drawLine(
                    cs.onSurfaceVariant.copy(alpha = (if (major) 0.55f else 0.3f) * a),
                    Offset(x, cy - h / 2f), Offset(x, cy + h / 2f), strokeWidth = 1.dp.toPx(),
                )
            }
            val xv = x0 + frac * (x1 - x0)
            drawLine(cs.primary.copy(alpha = a), Offset(xv, cy - 14.dp.toPx()), Offset(xv, cy + 14.dp.toPx()), strokeWidth = 2.5.dp.toPx(), cap = StrokeCap.Round)
        }
        Text(valueText, Modifier.width(48.dp), fontSize = 14.sp, maxLines = 1, textAlign = TextAlign.End, color = cs.onBackground.copy(alpha = a))
    }
}

/** Lingkaran pilihan parameter: nilai di dalam, nama di bawah. Yang dipilih berwarna aksen. */
@Composable
internal fun ParamCircle(label: String, valueText: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier.width(66.dp).clip(RoundedCornerShape(12.dp)).clickable { onClick() }.padding(vertical = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Box(
            Modifier.size(46.dp).clip(CircleShape).border(1.5.dp, if (selected) cs.primary else cs.outline, CircleShape),
            contentAlignment = Alignment.Center,
        ) { Text(valueText, fontSize = 11.sp, maxLines = 1, color = if (selected) cs.primary else cs.onBackground) }
        Text(label, fontSize = 11.sp, maxLines = 1, color = if (selected) cs.primary else cs.onSurfaceVariant)
    }
}

/** Kartu aksi: ikon + label di dalam persegi membulat datar. */
@Composable
internal fun ActionCard(icon: List<String>, label: String, selected: Boolean = false, enabled: Boolean = true, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val bg = if (selected) cs.primary else cs.surfaceVariant
    val fg = (if (selected) cs.onPrimary else cs.onBackground).copy(alpha = if (enabled) 1f else 0.35f)
    Column(
        Modifier.width(76.dp).height(60.dp).clip(RoundedCornerShape(14.dp)).background(bg)
            .clickable(enabled = enabled, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        ToolIcon(icon, fg, 22.dp)
        Spacer(Modifier.height(4.dp))
        Text(label, fontSize = 11.sp, maxLines = 1, color = fg)
    }
}

/** Kartu rasio: persegi panjang kecil dengan rasio sebenarnya + label. [ratio] null = "Asli". */
@Composable
internal fun AspectCard(label: String, ratio: Float?, selected: Boolean, enabled: Boolean = true, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val bg = if (selected) cs.primary else cs.surfaceVariant
    val fg = (if (selected) cs.onPrimary else cs.onBackground).copy(alpha = if (enabled) 1f else 0.35f)
    Column(
        Modifier.width(72.dp).height(72.dp).clip(RoundedCornerShape(14.dp)).background(bg)
            .clickable(enabled = enabled, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Canvas(Modifier.size(30.dp)) {
            val r = ratio ?: 1.3f
            val w = if (r >= 1f) size.width else size.width * r
            val h = if (r >= 1f) size.width / r else size.height
            drawRoundRect(
                fg, Offset((size.width - w) / 2f, (size.height - h) / 2f), Size(w, h),
                CornerRadius(3.dp.toPx()), style = Stroke(1.6.dp.toPx()),
            )
        }
        Spacer(Modifier.height(5.dp))
        Text(label, fontSize = 11.sp, maxLines = 1, color = fg)
    }
}

/** Baris saklar: label di kiri, switch di kanan, catatan kecil di bawah (opsional). */
@Composable
internal fun ToggleRow(label: String, checked: Boolean, enabled: Boolean = true, note: String? = null, onChecked: (Boolean) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column {
        Row(Modifier.fillMaxWidth().height(48.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(label, Modifier.weight(1f), fontSize = 14.sp, color = cs.onBackground)
            Switch(checked = checked, onCheckedChange = onChecked, enabled = enabled)
        }
        if (note != null) Text(note, fontSize = 12.sp, color = cs.onSurfaceVariant)
    }
}

/** Tautan "Reset" kecil dengan ikon panah melingkar. */
@Composable
internal fun ResetLink(enabled: Boolean = true, onClick: () -> Unit) {
    val c = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = if (enabled) 1f else 0.4f)
    Row(
        Modifier.clip(RoundedCornerShape(50)).clickable(enabled = enabled, onClick = onClick).padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        ToolIcon(ICON_RESET, c, 18.dp)
        Text("Reset", fontSize = 13.sp, color = c)
    }
}

/** Teks petunjuk kecil di dalam panel. */
@Composable
internal fun PanelHint(text: String) {
    Text(text, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 8.dp))
}
