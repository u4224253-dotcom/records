package com.laykit.chord

import kotlin.math.exp
import kotlin.math.min

/**
 * ChordNet (ChordMini CNN+BiLSTM) lengkap untuk satu fold:
 *   |CQT| [T,252] -> [CnnFeatureExtractor] -> [T,240] -> [BiLstm] -> [T,192]
 *                 -> Linear(192 -> 100) -> pecah 6 head -> softmax per head per frame.
 *
 * Pembagian 100 keluaran (chord_limit 6/3/3/2/2 di source asli):
 *   triad [0,73)  bass [73,86)  7th [86,90)  9th [90,94)  11th [94,97)  13th [97,100)
 *
 * Panggil [forward] per chunk (3000 frame): InstanceNorm di CNN menghitung statistik per chunk.
 * Satu instance = satu fold; instance menyimpan bobot saja, jadi aman dipakai ulang antar chunk.
 */
internal class ChordNetCnn(
    lkm: LkmFile,
    val fold: Int,
    private val threads: Int = CnnFeatureExtractor.defaultThreads(),
) {

    /** Probabilitas per head, masing-masing [frames * ukuran head], urutan [frame][kelas]. */
    class Heads(
        val frames: Int,
        val triad: FloatArray,
        val bass: FloatArray,
        val s7: FloatArray,
        val s9: FloatArray,
        val s11: FloatArray,
        val s13: FloatArray,
    ) {
        /** Urutan sama dengan [HEAD_SIZES] dan idx[s][h] di chord_table. */
        fun all(): List<FloatArray> = listOf(triad, bass, s7, s9, s11, s13)
    }

    private val cnn = CnnFeatureExtractor(lkm, fold, threads)
    private val lstm = BiLstm(lkm, fold, threads)
    private val fcW: FloatArray // [100][192]
    private val fcB: FloatArray // [100]

    init {
        fcW = lkm.tensor("f$fold.final_fc1.weight").data
        fcB = lkm.tensor("f$fold.final_fc1.bias").data
        require(fcW.size == N_OUT * BiLstm.OUT_SIZE) { "final_fc1.weight fold $fold ukurannya ${fcW.size}, seharusnya ${N_OUT * BiLstm.OUT_SIZE}" }
        require(fcB.size == N_OUT) { "final_fc1.bias fold $fold ukurannya ${fcB.size}, seharusnya $N_OUT" }
    }

    /**
     * @param x |CQT| linear [frames * 252] (hasil [CqtCnn.netInput])
     * @param onProgress 0..1 (CNN = 85%, LSTM = 10%, sisanya Linear + softmax)
     */
    fun forward(x: FloatArray, frames: Int, onProgress: ((Float) -> Unit)? = null): Heads {
        val feat = cnn.extract(x, frames) { onProgress?.invoke(it * 0.85f) }
        val seq = lstm.forward(feat, frames)
        onProgress?.invoke(0.95f)

        val h = BiLstm.OUT_SIZE
        val outs = HEAD_SIZES.map { FloatArray(frames * it) }
        parallelFor(frames) { t0, t1 ->
            val z = FloatArray(N_OUT)
            for (t in t0 until t1) {
                val sb = t * h
                for (j in 0 until N_OUT) {
                    val wb = j * h
                    var a0 = 0f; var a1 = 0f; var a2 = 0f; var a3 = 0f
                    var k = 0
                    while (k < h) { // h = 192, kelipatan 4
                        a0 += fcW[wb + k] * seq[sb + k]
                        a1 += fcW[wb + k + 1] * seq[sb + k + 1]
                        a2 += fcW[wb + k + 2] * seq[sb + k + 2]
                        a3 += fcW[wb + k + 3] * seq[sb + k + 3]
                        k += 4
                    }
                    z[j] = fcB[j] + ((a0 + a1) + (a2 + a3))
                }
                for (hd in HEAD_SIZES.indices) softmax(z, HEAD_OFFSETS[hd], HEAD_SIZES[hd], outs[hd], t * HEAD_SIZES[hd])
            }
        }
        onProgress?.invoke(1f)
        return Heads(frames, outs[0], outs[1], outs[2], outs[3], outs[4], outs[5])
    }

    /** softmax stabil (kurangi maks), hitung dalam double, tulis float. */
    private fun softmax(z: FloatArray, off: Int, n: Int, out: FloatArray, outOff: Int) {
        var m = z[off]
        for (i in 1 until n) if (z[off + i] > m) m = z[off + i]
        var sum = 0.0
        for (i in 0 until n) sum += exp((z[off + i] - m).toDouble())
        for (i in 0 until n) out[outOff + i] = (exp((z[off + i] - m).toDouble()) / sum).toFloat()
    }

    private fun parallelFor(n: Int, body: (Int, Int) -> Unit) {
        val nt = min(threads, maxOf(1, n / MIN_ROWS_PER_THREAD))
        if (nt <= 1) {
            body(0, n)
            return
        }
        val per = (n + nt - 1) / nt
        var failure: Throwable? = null
        val workers = ArrayList<Thread>(nt - 1)
        for (i in 1 until nt) {
            val a = i * per
            val b = min(n, a + per)
            if (a >= b) break
            workers += Thread {
                try { body(a, b) } catch (e: Throwable) { synchronized(workers) { failure = failure ?: e } }
            }.also { it.start() }
        }
        try { body(0, min(n, per)) } catch (e: Throwable) { synchronized(workers) { failure = failure ?: e } }
        for (t in workers) t.join()
        failure?.let { throw it }
    }

    companion object {
        /** triad, bass, 7th, 9th, 11th, 13th */
        val HEAD_SIZES = intArrayOf(73, 13, 4, 4, 3, 3)
        val HEAD_OFFSETS = intArrayOf(0, 73, 86, 90, 94, 97)
        const val N_OUT = 100
        private const val MIN_ROWS_PER_THREAD = 16
    }
}
