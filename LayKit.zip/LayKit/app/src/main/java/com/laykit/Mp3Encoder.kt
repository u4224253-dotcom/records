package com.laykit

/** Encoder MP3 (LAME via JNI). PCM 16-bit interleaved masuk, byte MP3 keluar. */
class Mp3Encoder(private val sampleRate: Int, private val channels: Int, kbps: Int = 128) {
    companion object {
        init { System.loadLibrary("laykit_lame") }
        /** ukuran buffer keluaran aman untuk [frames] frame (aturan LAME: 1.25 * n + 7200) */
        fun outSize(frames: Int) = frames * 5 / 4 + 7200
    }

    private var h: Long = nInit(sampleRate, channels, kbps)
    val ok: Boolean get() = h != 0L

    /** @return jumlah byte yang terisi di [out] */
    fun encode(pcm: ShortArray, frames: Int, out: ByteArray): Int = if (h == 0L) -1 else nEncode(h, pcm, frames, channels, out)
    fun flush(out: ByteArray): Int = if (h == 0L) -1 else nFlush(h, out)
    fun close() { if (h != 0L) { nClose(h); h = 0L } }

    private external fun nInit(sampleRate: Int, channels: Int, kbps: Int): Long
    private external fun nEncode(h: Long, pcm: ShortArray, frames: Int, channels: Int, out: ByteArray): Int
    private external fun nFlush(h: Long, out: ByteArray): Int
    private external fun nClose(h: Long)
}
