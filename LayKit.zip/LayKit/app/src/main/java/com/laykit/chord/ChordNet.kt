package com.laykit.chord

import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Forward pass ChordNet (2E1D) dari ChordMini, ditulis ulang dalam Kotlin murni (mode eval:
 * dropout diabaikan). Semua matriks bobot disimpan seperti di PyTorch: [keluaran, masukan].
 *
 * Alur: encoder frekuensi (EncoderF) dan encoder waktu (EncoderT) memproses fitur yang sama,
 * lalu Decoder (self-attention + cross-attention ke EncoderT) dan lapisan linear akhir
 * menghasilkan logit 170 kelas per frame.
 *
 * Catatan kesetiaan terhadap kode asli (src/models/common/base_transformer.py):
 *  - Positional encoding: sudut = pos / 10000^(2j/dim) untuk SETIAP kolom j (bukan per pasangan),
 *    kolom genap sin, kolom ganjil cos. Dikali 0.01 (EncoderF), 0.02 (EncoderT), 0.01 (Decoder).
 *  - Semua blok bersifat ReZero: x + alpha * sublayer(x), alpha dipelajari (awal 0).
 *  - Keluaran ChordNet = fc( y decoder SEBELUM decoder.fc ); decoder.fc tidak dipakai.
 *  - Jumlah head tidak tersimpan di checkpoint; dibaca dari "net.meta".
 */
internal class ChordNet(lkm: LkmFile) {
    // ---------------------------------------------------------------- lapisan dasar
    private class Linear(val w: FloatArray, val b: FloatArray, val inn: Int, val out: Int) {
        constructor(lkm: LkmFile, name: String) : this(
            lkm.tensor("$name.weight").data,
            lkm.tensor("$name.bias").data,
            lkm.tensor("$name.weight").shape[1],
            lkm.tensor("$name.weight").shape[0],
        )

        /** y[r, outStart..outStart+outCount) = x[r] . W[outStart..]^T + b[outStart..] */
        fun apply(x: FloatArray, rows: Int, y: FloatArray, outStart: Int = 0, outCount: Int = out, yStride: Int = outCount) {
            for (r in 0 until rows) {
                val xo = r * inn
                val yo = r * yStride
                for (o in 0 until outCount) {
                    val wo = (outStart + o) * inn
                    var s0 = 0f
                    var s1 = 0f
                    var s2 = 0f
                    var s3 = 0f
                    var i = 0
                    val lim = inn - 3
                    while (i < lim) {
                        s0 += x[xo + i] * w[wo + i]
                        s1 += x[xo + i + 1] * w[wo + i + 1]
                        s2 += x[xo + i + 2] * w[wo + i + 2]
                        s3 += x[xo + i + 3] * w[wo + i + 3]
                        i += 4
                    }
                    while (i < inn) {
                        s0 += x[xo + i] * w[wo + i]
                        i++
                    }
                    y[yo + o] = (s0 + s1) + (s2 + s3) + b[outStart + o]
                }
            }
        }
    }

    private class LayerNorm(val g: FloatArray, val b: FloatArray, val eps: Float = 1e-5f) {
        constructor(lkm: LkmFile, name: String) : this(lkm.tensor("$name.weight").data, lkm.tensor("$name.bias").data)

        /** Normalisasi per baris (biased variance, sama dengan torch.nn.LayerNorm). */
        fun apply(x: FloatArray, rows: Int, dim: Int) {
            for (r in 0 until rows) {
                val o = r * dim
                var mean = 0f
                for (i in 0 until dim) mean += x[o + i]
                mean /= dim
                var v = 0f
                for (i in 0 until dim) {
                    val d = x[o + i] - mean
                    v += d * d
                }
                v /= dim
                val inv = 1f / sqrt(v + eps)
                for (i in 0 until dim) x[o + i] = (x[o + i] - mean) * inv * g[i] + b[i]
            }
        }
    }

    /** nn.MultiheadAttention(batch_first=True), mode eval, tanpa mask. */
    private class Mha(lkm: LkmFile, name: String, private val heads: Int) {
        private val inProj = Linear(
            lkm.tensor("$name.in_proj_weight").data,
            lkm.tensor("$name.in_proj_bias").data,
            lkm.tensor("$name.in_proj_weight").shape[1],
            lkm.tensor("$name.in_proj_weight").shape[0],
        )
        private val outProj = Linear(lkm, "$name.out_proj")
        private val d = inProj.inn

        init {
            require(d % heads == 0) { "Dimensi $d tidak habis dibagi $heads head ($name)" }
        }

        /**
         * @param q  [batch][qLen][d]   @param kv [batch][kvLen][d]  (boleh array yang sama)
         * @return   [batch][qLen][d]
         */
        fun forward(q: FloatArray, kv: FloatArray, batch: Int, qLen: Int, kvLen: Int): FloatArray {
            val qp = FloatArray(batch * qLen * d)
            val kp = FloatArray(batch * kvLen * d)
            val vp = FloatArray(batch * kvLen * d)
            inProj.apply(q, batch * qLen, qp, 0, d)
            inProj.apply(kv, batch * kvLen, kp, d, d)
            inProj.apply(kv, batch * kvLen, vp, 2 * d, d)

            val hd = d / heads
            val scale = 1f / sqrt(hd.toFloat())
            val ctx = FloatArray(batch * qLen * d)
            val sc = FloatArray(kvLen)
            for (bi in 0 until batch) {
                for (h in 0 until heads) {
                    val ho = h * hd
                    for (i in 0 until qLen) {
                        val qo = (bi * qLen + i) * d + ho
                        var mx = Float.NEGATIVE_INFINITY
                        for (j in 0 until kvLen) {
                            val ko = (bi * kvLen + j) * d + ho
                            var s = 0f
                            for (c in 0 until hd) s += qp[qo + c] * kp[ko + c]
                            s *= scale
                            sc[j] = s
                            if (s > mx) mx = s
                        }
                        var sum = 0f
                        for (j in 0 until kvLen) {
                            val e = exp(sc[j] - mx)
                            sc[j] = e
                            sum += e
                        }
                        val inv = 1f / sum
                        val co = (bi * qLen + i) * d + ho
                        for (c in 0 until hd) {
                            var a = 0f
                            for (j in 0 until kvLen) a += sc[j] * vp[(bi * kvLen + j) * d + ho + c]
                            ctx[co + c] = a * inv
                        }
                    }
                }
            }
            val out = FloatArray(batch * qLen * d)
            outProj.apply(ctx, batch * qLen, out)
            return out
        }
    }

    /** FeedForward ReZero: LN( x + alpha * W2( relu( LN(W1 x) ) ) ). */
    private class FeedForward(lkm: LkmFile, name: String, private val dim: Int) {
        private val l1 = Linear(lkm, "$name.linear1")
        private val l2 = Linear(lkm, "$name.linear2")
        private val norm = LayerNorm(lkm, "$name.norm")
        private val normOut = LayerNorm(lkm, "$name.norm_layer")
        private val alpha = lkm.tensor("$name.alpha").data[0]
        private val hidden = l1.out

        fun forward(x: FloatArray, rows: Int): FloatArray {
            val h = FloatArray(rows * hidden)
            l1.apply(x, rows, h)
            norm.apply(h, rows, hidden)
            for (i in h.indices) if (h[i] < 0f) h[i] = 0f
            val y = FloatArray(rows * dim)
            l2.apply(h, rows, y)
            for (i in y.indices) y[i] = x[i] + alpha * y[i]
            normOut.apply(y, rows, dim)
            return y
        }
    }

    // ---------------------------------------------------------------- positional encoding
    private val peCache = HashMap<String, FloatArray>()

    /** positional_encoding() asli: [n][dim], sudut = pos / 10000^(2j/dim) per kolom j, dikali scale. */
    private fun posEnc(n: Int, dim: Int, scale: Float): FloatArray =
        peCache.getOrPut("$n:$dim:$scale") {
            val out = FloatArray(n * dim)
            for (p in 0 until n) for (j in 0 until dim) {
                val a = p / 10000.0.pow(2.0 * j / dim)
                val v = if (j % 2 == 0) sin(a) else cos(a)
                out[p * dim + j] = v.toFloat() * scale
            }
            out
        }

    // ---------------------------------------------------------------- konfigurasi & bobot
    val nFreq: Int
    val nClasses: Int
    private val nGroup: Int
    private val dModelF: Int

    private val fAttn: List<Mha>
    private val fFf: List<FeedForward>
    private val fAlpha: FloatArray
    private val fFc: Linear
    private val fNorm: LayerNorm

    private val tAttn: List<Mha>
    private val tFf: List<FeedForward>
    private val tAlpha: FloatArray
    private val tFc: Linear
    private val tNorm: LayerNorm

    private val dAttn1: List<Mha>
    private val dAttn2: List<Mha>
    private val dFf: List<FeedForward>
    private val dAlpha1: FloatArray
    private val dAlpha2: FloatArray
    private val dNorm: LayerNorm

    private val fc: Linear

    init {
        // [n_freq, n_classes, n_group, f_layer, f_head, t_layer, t_head, d_layer, d_head]
        val m = lkm.ints("net.meta")
        nFreq = m[0]; nClasses = m[1]; nGroup = m[2]
        val fLayer = m[3]; val fHead = m[4]
        val tLayer = m[5]; val tHead = m[6]
        val dLayer = m[7]; val dHead = m[8]
        require(nFreq % nGroup == 0) { "n_freq $nFreq tidak habis dibagi n_group $nGroup" }
        dModelF = nFreq / nGroup

        val ef = "transformer.encoder_f.0"
        fAttn = List(fLayer) { Mha(lkm, "$ef.attn_layer.$it", fHead) }
        fFf = List(fLayer) { FeedForward(lkm, "$ef.ff_layer.$it", dModelF) }
        fAlpha = FloatArray(fLayer) { lkm.tensor("$ef.attn_alphas.$it").data[0] }
        fFc = Linear(lkm, "$ef.fc")
        fNorm = LayerNorm(lkm, "$ef.norm_layer")

        val et = "transformer.encoder_t.0"
        tAttn = List(tLayer) { Mha(lkm, "$et.attn_layer.$it", tHead) }
        tFf = List(tLayer) { FeedForward(lkm, "$et.ff_layer.$it", nFreq) }
        tAlpha = FloatArray(tLayer) { lkm.tensor("$et.attn_alphas.$it").data[0] }
        tFc = Linear(lkm, "$et.fc")
        tNorm = LayerNorm(lkm, "$et.norm_layer")

        val dc = "transformer.decoder"
        dAttn1 = List(dLayer) { Mha(lkm, "$dc.attn_layer1.$it", dHead) }
        dAttn2 = List(dLayer) { Mha(lkm, "$dc.attn_layer2.$it", dHead) }
        dFf = List(dLayer) { FeedForward(lkm, "$dc.ff_layer.$it", nFreq) }
        dAlpha1 = FloatArray(dLayer) { lkm.tensor("$dc.attn1_alphas.$it").data[0] }
        dAlpha2 = FloatArray(dLayer) { lkm.tensor("$dc.attn2_alphas.$it").data[0] }
        dNorm = LayerNorm(lkm, "$dc.norm_layer")

        fc = Linear(lkm, "fc")
        require(fc.out == nClasses && fc.inn == nFreq) { "Bentuk fc tidak cocok dengan net.meta" }
    }

    // ---------------------------------------------------------------- forward
    private fun encoderF(x: FloatArray, frames: Int): FloatArray {
        // [frames][nGroup][dModelF]; urutan memori sama dengan [frames][nFreq]
        val z0 = x.copyOf()
        val pe = posEnc(nGroup, dModelF, 0.01f)
        for (t in 0 until frames) for (i in 0 until nGroup * dModelF) z0[t * nFreq + i] += pe[i]
        var z = z0
        val rows = frames * nGroup
        for (l in fAttn.indices) {
            val out = fAttn[l].forward(z, z, frames, nGroup, nGroup)
            val a = fAlpha[l]
            val s = FloatArray(z.size) { z[it] + a * out[it] }
            z = fFf[l].forward(s, rows)
        }
        val y = FloatArray(frames * nFreq)
        fFc.apply(z, frames, y)
        fNorm.apply(y, frames, nFreq)
        return y
    }

    private fun encoderT(x: FloatArray, frames: Int): FloatArray {
        val pe = posEnc(frames, nFreq, 0.02f)
        var z = FloatArray(x.size) { x[it] + pe[it] }
        for (l in tAttn.indices) {
            val out = tAttn[l].forward(z, z, 1, frames, frames)
            val a = tAlpha[l]
            val s = FloatArray(z.size) { z[it] + a * out[it] }
            z = tFf[l].forward(s, frames)
        }
        val y = FloatArray(frames * nFreq)
        tFc.apply(z, frames, y)
        tNorm.apply(y, frames, nFreq)
        return y
    }

    /**
     * @param x fitur sudah ternormalisasi ((log|CQT| - mean) / (std + 1e-8)), [frames][nFreq] diratakan
     * @return logit [frames][nClasses] diratakan
     */
    fun forward(x: FloatArray, frames: Int): FloatArray {
        require(x.size == frames * nFreq) { "Ukuran masukan ${x.size} != $frames x $nFreq" }
        val y1 = encoderF(x, frames)
        val y2 = encoderT(x, frames)

        val pe = posEnc(frames, nFreq, 0.01f)
        var y = FloatArray(y1.size) { y1[it] + y2[it] + pe[it] }
        for (l in dAttn1.indices) {
            val o1 = dAttn1[l].forward(y, y, 1, frames, frames)
            val a1 = dAlpha1[l]
            y = FloatArray(y.size) { y[it] + a1 * o1[it] }
            dNorm.apply(y, frames, nFreq)

            val o2 = dAttn2[l].forward(y, y2, 1, frames, frames)
            val a2 = dAlpha2[l]
            y = FloatArray(y.size) { y[it] + a2 * o2[it] }
            dNorm.apply(y, frames, nFreq)

            y = dFf[l].forward(y, frames)
        }
        val logits = FloatArray(frames * nClasses)
        fc.apply(y, frames, logits)
        return logits
    }
}
