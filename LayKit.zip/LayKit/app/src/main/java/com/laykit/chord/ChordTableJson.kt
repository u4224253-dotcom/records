package com.laykit.chord

/** Pembaca JSON kecil tanpa dependensi (tidak memakai org.json supaya bisa diuji di PC). */
private class MiniJson(private val s: String) {
    private var i = 0
    fun parse(): Any? { val v = value(); ws(); require(i == s.length) { "JSON: sisa teks di $i" }; return v }
    private fun ws() { while (i < s.length && s[i].isWhitespace()) i++ }
    private fun value(): Any? {
        ws()
        return when (val c = s[i]) {
            '{' -> { i++; val m = LinkedHashMap<String, Any?>(); ws()
                if (s[i] == '}') { i++ } else while (true) {
                    ws(); val k = str(); ws(); require(s[i++] == ':'); m[k] = value(); ws()
                    if (s[i] == ',') i++ else { require(s[i++] == '}'); break }
                }; m }
            '[' -> { i++; val l = ArrayList<Any?>(); ws()
                if (s[i] == ']') { i++ } else while (true) {
                    l += value(); ws()
                    if (s[i] == ',') i++ else { require(s[i++] == ']'); break }
                }; l }
            '"' -> str()
            't' -> { i += 4; true }
            'f' -> { i += 5; false }
            'n' -> { i += 4; null }
            else -> { val a = i; while (i < s.length && (s[i].isDigit() || s[i] in "+-.eE")) i++
                require(i > a) { "JSON: karakter '$c' tak terduga di $a" }; s.substring(a, i).toDouble() }
        }
    }
    private fun str(): String {
        require(s[i++] == '"'); val b = StringBuilder()
        while (true) {
            val c = s[i++]
            when (c) {
                '"' -> return b.toString()
                '\\' -> when (val e = s[i++]) {
                    'n' -> b.append('\n'); 't' -> b.append('\t'); 'r' -> b.append('\r')
                    'b' -> b.append('\b'); 'f' -> b.append('\u000c')
                    'u' -> { b.append(s.substring(i, i + 4).toInt(16).toChar()); i += 4 }
                    else -> b.append(e)
                }
                else -> b.append(c)
            }
        }
    }
}

/** Baca chord_table.json (blob "chord_table_json" di cnn.lkm). */
@Suppress("UNCHECKED_CAST")
internal fun parseChordTable(json: String): ChordTable {
    val o = MiniJson(json).parse() as Map<String, Any?>
    val names = (o["names"] as List<Any?>).map { it as String }
    val idx = (o["idx"] as List<Any?>).map { r -> (r as List<Any?>).map { (it as Double).toInt() }.toIntArray() }
    return ChordTable(
        names = names.toTypedArray(),
        idx = idx.toTypedArray(),
        penalty = (o["penalty"] as Double),
        hop = (o["hop"] as Double).toInt(),
        sampleRate = (o["sr"] as Double).toInt(),
        startState = ((o["start_state"] as? Double) ?: 0.0).toInt(),
    )
}
