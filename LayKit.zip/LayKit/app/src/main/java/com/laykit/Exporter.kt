package com.laykit

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.SurfaceTexture
import android.media.ExifInterface
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLUtils
import android.opengl.Matrix
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Gaya "frame" di sekitar video. Warna ARGB. */
data class FrameStyle(
    val top: Int = 0xFF1E3A8A.toInt(),
    val bottom: Int = 0xFF7C3AED.toInt(),
    val padding: Float = 0.08f,   // 0..0.25 dari sisi terpendek kanvas
    val corner: Float = 0.03f,    // 0..0.10 dari sisi terpendek kanvas
    val shadow: Boolean = true,
    val shadowAmt: Float = 0.5f,  // 0..1 intensitas bayangan (0.5 = tampilan lama)
    val aspect: Float? = null,    // lebar/tinggi kanvas; null = sama dengan video
    val bgType: Int = 0,          // 0 gradient/solid, 1 wallpaper (mesh), 2 gambar, 3 blur dari video
    val mid: Int = 0,             // warna tengah (wallpaper)
    val image: Uri? = null,       // gambar background (bgType 2)
    val blur: Float = 0.04f,      // kekuatan blur (bgType 3), fraksi sisi terpendek
    val cursor: Boolean = false,  // gambar kursor sintetis dari data ketukan
    val look: Int = 0,            // indeks filter warna di [Looks.presets]; 0 = tanpa filter
    val lookAmt: Float = 1f,      // 0..1 intensitas filter
    val vignette: Float = 0f,     // 0..1 jumlah vignette
)

data class VideoInfo(val width: Int, val height: Int, val durationMs: Long)

object Exporter {

    /** Ukuran video setelah rotasi (yang dilihat penonton) + durasi. */
    fun probe(ctx: Context, uri: Uri): VideoInfo? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: return null
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: return null
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
            val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            VideoInfo(w, h, d)
        } catch (e: Exception) {
            null
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    /** Muat gambar (sudah diputar sesuai EXIF), diperkecil supaya sisi terpanjang <= [maxSide]. */
    fun loadImage(ctx: Context, uri: Uri?, maxSide: Int = 2048): Bitmap? {
        if (uri == null) return null
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
            val deg = try {
                ctx.contentResolver.openInputStream(uri)?.use {
                    when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                        ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                        ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                        ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                        else -> 0f
                    }
                } ?: 0f
            } catch (_: Exception) { 0f }
            if (deg == 0f) bmp
            else Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, android.graphics.Matrix().apply { postRotate(deg) }, true)
        } catch (_: Exception) {
            null
        }
    }

    /** Frame pertama video (kecil) untuk pratinjau background blur. */
    fun firstFrame(ctx: Context, uri: Uri): Bitmap? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            r.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
        } catch (e: Exception) {
            null
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    class Cancel { @Volatile var requested = false }

    /**
     * Ekspor [src] dari [startUs] sampai [endUs] dengan [style].
     * Dipanggil di thread background. Mengembalikan Uri hasil, atau null jika gagal/dibatalkan.
     */
    fun export(
        ctx: Context,
        src: Uri,
        startUs: Long,
        endUs: Long,
        style: FrameStyle,
        zooms: List<ZoomRegion>,
        touches: List<TouchEvent>,
        cancel: Cancel,
        onProgress: (Float) -> Unit,
        onError: (String) -> Unit,
    ): Uri? {
        val resolver = ctx.contentResolver
        val name = "LayKit_edit_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        val cv = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/LayKit")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val out = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)
        if (out == null) { onError("Gagal membuat file hasil"); return null }

        var ok = false
        try {
            val pfd = resolver.openFileDescriptor(out, "rw") ?: error("File hasil gagal dibuka")
            pfd.use { ok = doExport(ctx, src, pfd, startUs, endUs, style, zooms, touches, cancel, onProgress) }
        } catch (e: Throwable) {
            onError("Ekspor gagal: ${e.message ?: e.javaClass.simpleName}")
            ok = false
        }

        return if (ok && !cancel.requested) {
            resolver.update(out, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
            out
        } else {
            try { resolver.delete(out, null, null) } catch (_: Exception) {}
            null
        }
    }

    // ---------------------------------------------------------------------------------------------

    private const val VERT = """
        attribute vec2 aPos;
        varying vec2 vUV;
        void main() {
            gl_Position = vec4(aPos, 0.0, 1.0);
            vUV = aPos * 0.5 + 0.5;
        }
    """

    // Semua digambar di satu shader: background (gradient/wallpaper/gambar/blur), bayangan, video bersudut membulat.
    private const val FRAG = """
        #extension GL_OES_EGL_image_external : require
        precision highp float;
        uniform samplerExternalOES uTex;
        uniform sampler2D uImg;
        uniform mat4 uTexMat;
        uniform vec2 uRes;      // ukuran kanvas (px)
        uniform vec4 uRect;     // pusat x, pusat y, setengah lebar, setengah tinggi (px, asal kiri-atas)
        uniform float uRadius;  // px
        uniform vec3 uTop;
        uniform vec3 uMid;
        uniform vec3 uBottom;
        uniform float uShadow;  // 0 = mati, 0..1 = intensitas
        uniform int uBgType;    // 0 gradient, 1 wallpaper, 2 gambar, 3 blur video
        uniform vec2 uImgSize;
        uniform vec2 uVidSize;
        uniform float uBlur;
        uniform vec3 uZoom;     // jendela crop pada video: kiri, atas, ukuran (0..1, asal kiri-atas); (0,0,1) = tanpa zoom
        uniform vec4 uCur;      // kursor: x, y (px, bidang bingkai), tinggi (px), alpha
        uniform vec4 uRip;      // riak ketukan: x, y (px), progres 0..1 (negatif = mati), tekan 0..1
        uniform mat3 uRot;      // kamera 3D: R = Rx(pitch) Ry(yaw) Rz(roll), kolom-mayor (konvensi Openscreen, lihat Cam)
        uniform vec2 uPers;     // kamera 3D: jarak kamera P (px; 0 = datar), skala bidang S (containment / fokus kamera)
        uniform vec4 uLk0;      // filter warna: baris 0..2 dari [r g b offset] (lihat Looks)
        uniform vec4 uLk1;
        uniform vec4 uLk2;
        uniform float uVig;     // vignette 0..1
        uniform vec2 uOff;      // kamera 3D nyata: jatuhnya pusat bidang di gambar (px), dipakai SEBELUM pembagian perspektif
        varying vec2 vUV;

        // Panah kursor (satuan = tinggi kursor). Titik-titiknya harus sama dengan ARROW di Cursor.kt.
        void edgeD(vec2 p, vec2 a, vec2 b, inout float d, inout float sg) {
            vec2 e = b - a;
            vec2 w = p - a;
            vec2 q = w - e * clamp(dot(w, e) / dot(e, e), 0.0, 1.0);
            d = min(d, dot(q, q));
            bool c1 = p.y >= a.y;
            bool c2 = p.y < b.y;
            bool c3 = e.x * w.y > e.y * w.x;
            if ((c1 && c2 && c3) || (!c1 && !c2 && !c3)) sg = -sg;
        }

        float sdArrow(vec2 p) {
            vec2 v0 = vec2(0.0, 0.0);
            vec2 v1 = vec2(0.0, 0.82);
            vec2 v2 = vec2(0.205, 0.64);
            vec2 v3 = vec2(0.374, 1.0);
            vec2 v4 = vec2(0.497, 0.944);
            vec2 v5 = vec2(0.333, 0.6);
            vec2 v6 = vec2(0.59, 0.59);
            float d = dot(p - v0, p - v0);
            float sg = 1.0;
            edgeD(p, v0, v1, d, sg);
            edgeD(p, v1, v2, d, sg);
            edgeD(p, v2, v3, d, sg);
            edgeD(p, v3, v4, d, sg);
            edgeD(p, v4, v5, d, sg);
            edgeD(p, v5, v6, d, sg);
            edgeD(p, v6, v0, d, sg);
            return sg * sqrt(d);
        }

        float sdBox(vec2 p, vec2 b, float r) {
            vec2 q = abs(p) - b + r;
            return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;
        }

        vec3 background(vec2 p) {
            vec2 q = p / uRes;
            if (uBgType == 1) {
                vec2 s = vec2(uRes.x / uRes.y, 1.0);
                vec3 c = uTop;
                c = mix(c, uMid, smoothstep(0.95, 0.0, length((q - vec2(0.15, 0.15)) * s)));
                c = mix(c, uBottom, smoothstep(0.95, 0.0, length((q - vec2(0.85, 0.85)) * s)));
                c = mix(c, uMid, 0.5 * smoothstep(0.6, 0.0, length((q - vec2(0.9, 0.2)) * s)));
                return c;
            }
            if (uBgType == 2) {
                vec2 isz = uImgSize * max(uRes.x / uImgSize.x, uRes.y / uImgSize.y);
                vec2 uv = (p - uRes * 0.5) / isz + 0.5;
                return texture2D(uImg, uv).rgb;
            }
            if (uBgType == 3) {
                vec2 vsz = uVidSize * max(uRes.x / uVidSize.x, uRes.y / uVidSize.y);
                vec2 base = (p - uRes * 0.5) / vsz + 0.5;
                float rpx = uBlur * min(uRes.x, uRes.y);
                vec3 acc = vec3(0.0);
                for (int i = 0; i < 24; i++) {
                    float fi = float(i);
                    float ang = fi * 2.39996;
                    float rad = sqrt((fi + 0.5) / 24.0) * rpx;
                    vec2 u = clamp(base + vec2(cos(ang), sin(ang)) * rad / vsz, 0.0, 1.0);
                    vec4 t = uTexMat * vec4(u.x, 1.0 - u.y, 0.0, 1.0);
                    acc += texture2D(uTex, t.xy).rgb;
                }
                return acc / 24.0 * 0.75;
            }
            return mix(uTop, uBottom, q.y);
        }

        void main() {
            vec2 p0 = vec2(vUV.x * uRes.x, (1.0 - vUV.y) * uRes.y);   // piksel layar (untuk background)
            vec2 p = p0;                                              // titik di bidang bingkai (untuk bingkai/bayangan/video)
            vec2 c = uRect.xy;
            vec2 hb = uRect.zw;

            // Kamera 3D (konvensi Openscreen): titik bidang (x', y') yang sudah diskala S diputar w = R*(x', y', 0) + (o, 0), lalu
            // diproyeksikan q = P * w.xy / (P - (R*(x', y', 0)).z). Untuk tiap piksel kita cari (x', y') yang tampak di situ:
            // sistem linear 2x2 dari persamaan itu. o = 0 untuk sudut tetap.
            if (uPers.x > 0.0) {
                vec3 r1 = uRot[0];   // R * sumbu x bidang
                vec3 r2 = uRot[1];   // R * sumbu y bidang
                vec2 q = p0 - c;
                float P = uPers.x;
                float m00 = P * r1.x + q.x * r1.z;
                float m01 = P * r2.x + q.x * r2.z;
                float m10 = P * r1.y + q.y * r1.z;
                float m11 = P * r2.y + q.y * r2.z;
                float det = m00 * m11 - m01 * m10;
                if (abs(det) < 1e-6) {
                    p = c + vec2(1.0e5);
                } else {
                    vec2 rhs = (q - uOff) * P;
                    vec2 xy = vec2(rhs.x * m11 - m01 * rhs.y, m00 * rhs.y - rhs.x * m10) / det;
                    float zq = xy.x * r1.z + xy.y * r2.z;
                    if (P - zq <= 1e-3) p = c + vec2(1.0e5);   // di belakang kamera
                    else p = c + xy / uPers.y;                 // balik ke ukuran kartu asli (sebelum containment)
                }
            }

            float d = sdBox(p - c, hb, uRadius);
            float a = 1.0 - smoothstep(-1.0, 1.0, d);

            vec3 col = vec3(0.0);
            if (a < 1.0) {
                col = background(p0);
                float blur = (0.02 + 0.03 * uShadow) * min(uRes.x, uRes.y);
                float ds = sdBox(p - c - vec2(0.0, blur * 0.6), hb, uRadius);
                float sh = (1.0 - smoothstep(-blur, blur * 1.5, ds)) * 0.9 * uShadow;
                col = mix(col, vec3(0.0), sh);
            }
            if (a > 0.0) {
                vec2 local = clamp((p - c) / (2.0 * hb) + 0.5, 0.0, 1.0);
                local = clamp(uZoom.xy + local * uZoom.z, 0.0, 1.0);
                vec2 uv = vec2(local.x, 1.0 - local.y);
                vec4 t = uTexMat * vec4(uv, 0.0, 1.0);
                vec3 v = texture2D(uTex, t.xy).rgb;
                // efek: filter warna lalu vignette (rumus sama dengan pratinjau, lihat Looks)
                v = clamp(vec3(dot(uLk0.xyz, v) + uLk0.w, dot(uLk1.xyz, v) + uLk1.w, dot(uLk2.xyz, v) + uLk2.w), 0.0, 1.0);
                float vr = length(p - c) / length(hb);
                v *= 1.0 - uVig * 0.8 * smoothstep(0.35, 1.0, vr);
                col = mix(col, v, a);

                // riak ketukan lalu kursor, digambar di bidang bingkai (ikut miring di mode 3D)
                if (uRip.z >= 0.0) {
                    float pr = 1.0 - pow(1.0 - uRip.z, 3.0);
                    float rr = uCur.z * (0.25 + 0.75 * pr);
                    float dd = length(p - uRip.xy);
                    float ring = 1.0 - smoothstep(0.0, 0.06 * uCur.z + 1.0, abs(dd - rr));
                    float disc = 1.0 - smoothstep(rr - 1.0, rr + 1.0, dd);
                    float ra = (1.0 - uRip.z) * (0.25 * disc + 0.85 * ring);
                    col = mix(col, vec3(0.31, 0.55, 1.0), ra * a);
                }
                if (uCur.w > 0.0) {
                    float sz = uCur.z * (1.0 - 0.14 * uRip.w);
                    float dpx = sdArrow((p - uCur.xy) / sz) * sz;
                    float bw = max(1.0, 0.07 * sz);
                    float outer = 1.0 - smoothstep(bw - 0.7, bw + 0.7, dpx);
                    float fillc = 1.0 - smoothstep(-0.7, 0.7, dpx);
                    col = mix(col, vec3(0.0), outer * uCur.w * a);
                    col = mix(col, vec3(1.0), fillc * uCur.w * a);
                }
            }
            gl_FragColor = vec4(col, 1.0);
        }
    """

    private fun even(v: Int) = max(2, v and 1.inv())

    private fun doExport(
        ctx: Context,
        src: Uri,
        pfd: ParcelFileDescriptor,
        startUs: Long,
        endUs: Long,
        style: FrameStyle,
        zooms: List<ZoomRegion>,
        touches: List<TouchEvent>,
        cancel: Cancel,
        onProgress: (Float) -> Unit,
    ): Boolean {
        val vex = MediaExtractor()
        val aex = MediaExtractor()
        var dec: MediaCodec? = null
        var enc: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var muxerStarted = false
        var gl: Gl? = null
        var st: SurfaceTexture? = null
        var decSurface: Surface? = null
        var encSurface: Surface? = null

        try {
            vex.setDataSource(ctx, src, null)
            aex.setDataSource(ctx, src, null)

            var vIdx = -1
            var aIdx = -1
            for (i in 0 until vex.trackCount) {
                val m = vex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
                if (vIdx < 0 && m.startsWith("video/")) vIdx = i
                if (aIdx < 0 && m.startsWith("audio/")) aIdx = i
            }
            if (vIdx < 0) error("Video tidak ditemukan")
            val vFmt = vex.getTrackFormat(vIdx)
            val srcW = vFmt.getInteger(MediaFormat.KEY_WIDTH)
            val srcH = vFmt.getInteger(MediaFormat.KEY_HEIGHT)
            val rot = if (vFmt.containsKey(MediaFormat.KEY_ROTATION)) vFmt.getInteger(MediaFormat.KEY_ROTATION) else 0
            val dw = if (rot == 90 || rot == 270) srcH else srcW
            val dh = if (rot == 90 || rot == 270) srcW else srcH
            val fps = try {
                if (vFmt.containsKey(MediaFormat.KEY_FRAME_RATE)) vFmt.getInteger(MediaFormat.KEY_FRAME_RATE).coerceIn(15, 60) else 30
            } catch (_: Exception) { 30 }

            // --- ukuran kanvas ---
            val canvasW: Int
            val canvasH: Int
            val asp = style.aspect
            if (asp == null) {
                canvasW = even(dw); canvasH = even(dh)
            } else {
                val longSide = min(max(dw, dh), 1920).toFloat()
                if (asp >= 1f) { canvasW = even(longSide.roundToInt()); canvasH = even((longSide / asp).roundToInt()) }
                else { canvasH = even(longSide.roundToInt()); canvasW = even((longSide * asp).roundToInt()) }
            }
            val shortSide = min(canvasW, canvasH).toFloat()
            val pad = style.padding.coerceIn(0f, 0.25f) * shortSide
            val availW = canvasW - 2 * pad
            val availH = canvasH - 2 * pad
            val scale = min(availW / dw, availH / dh)
            val rw = dw * scale
            val rh = dh * scale
            val radius = min(style.corner.coerceIn(0f, 0.10f) * shortSide, min(rw, rh) / 2f)

            // --- encoder ---
            val bitrate = (canvasW.toLong() * canvasH * fps * 0.15).toLong().coerceIn(2_000_000L, 24_000_000L).toInt()
            val ef = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, canvasW, canvasH).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
                setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }
            val e = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            enc = e
            e.configure(ef, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            encSurface = e.createInputSurface()
            e.start()

            // --- EGL + shader ---
            val g = Gl(encSurface!!, canvasW, canvasH)
            gl = g
            g.makeCurrent()
            g.setup(VERT, FRAG)
            val tex = g.createExternalTexture()
            val bgBmp = if (style.bgType == 2) loadImage(ctx, style.image) else null
            val bgType = if (style.bgType == 2 && bgBmp == null) 0 else style.bgType   // gambar gagal dimuat -> gradient
            val imgTex = g.createImageTexture(bgBmp)
            val frames = Semaphore(0)
            val s = SurfaceTexture(tex)
            st = s
            s.setOnFrameAvailableListener({ frames.release() }, Handler(Looper.getMainLooper()))
            val ds = Surface(s)
            decSurface = ds

            // --- decoder ---
            val mime = vFmt.getString(MediaFormat.KEY_MIME)!!
            val d = MediaCodec.createDecoderByType(mime)
            dec = d
            d.configure(vFmt, ds, null, 0)
            d.start()

            // --- muxer ---
            val mx = MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = mx
            var audioTrack = -1
            if (aIdx >= 0) {
                try {
                    audioTrack = mx.addTrack(vex.getTrackFormat(aIdx))
                    aex.selectTrack(aIdx)
                    aex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
                } catch (_: Exception) {
                    audioTrack = -1   // format audio tidak didukung muxer: lanjut tanpa suara
                }
            }
            var videoTrack = -1

            // --- audio pump: salin sampel AAC apa adanya (tanpa decode) ---
            val aBuf = ByteBuffer.allocate(256 * 1024)
            val aInfo = MediaCodec.BufferInfo()
            var audioDone = audioTrack < 0
            fun pumpAudio(untilUs: Long) {
                while (!audioDone && muxerStarted) {
                    val t = aex.sampleTime
                    if (t < 0 || t > endUs) { audioDone = true; break }
                    if (t < startUs) { aex.advance(); continue }
                    if (t - startUs > untilUs) break
                    aBuf.clear()
                    val n = aex.readSampleData(aBuf, 0)
                    if (n < 0) { audioDone = true; break }
                    aInfo.set(0, n, t - startUs,
                        if (aex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                    mx.writeSampleData(audioTrack, aBuf, aInfo)
                    aex.advance()
                }
            }

            // --- kuras output encoder ---
            val eInfo = MediaCodec.BufferInfo()
            var lastVideoUs = 0L
            fun drainEncoder(untilEos: Boolean) {
                var idle = 0
                while (true) {
                    val i = e.dequeueOutputBuffer(eInfo, if (untilEos) 10_000L else 0L)
                    when {
                        i == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                            if (!untilEos) return
                            if (++idle > 500) error("Encoder tidak merespons")
                        }
                        i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            videoTrack = mx.addTrack(e.outputFormat)
                            mx.start()
                            muxerStarted = true
                        }
                        i >= 0 -> {
                            idle = 0
                            val buf = e.getOutputBuffer(i)!!
                            if (eInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) eInfo.size = 0
                            if (eInfo.size > 0 && muxerStarted) {
                                buf.position(eInfo.offset)
                                buf.limit(eInfo.offset + eInfo.size)
                                mx.writeSampleData(videoTrack, buf, eInfo)
                                lastVideoUs = eInfo.presentationTimeUs
                                pumpAudio(lastVideoUs)
                            }
                            val eos = eInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                            e.releaseOutputBuffer(i, false)
                            if (eos) return
                        }
                    }
                }
            }

            // --- loop utama: decode -> gambar -> encode ---
            vex.selectTrack(vIdx)
            vex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)

            val texMat = FloatArray(16)
            val stMat = FloatArray(16)
            val rotMat = FloatArray(16)
            val dInfo = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            val total = max(1L, endUs - startUs).toFloat()
            var rendered = 0

            while (!outputDone) {
                if (cancel.requested) return false

                if (!inputDone) {
                    val ii = d.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        val ib = d.getInputBuffer(ii)!!
                        val n = vex.readSampleData(ib, 0)
                        val t = vex.sampleTime
                        if (n < 0 || t < 0 || t > endUs) {
                            d.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            d.queueInputBuffer(ii, 0, n, t, 0)
                            vex.advance()
                        }
                    }
                }

                val oi = d.dequeueOutputBuffer(dInfo, 10_000)
                if (oi >= 0) {
                    val eos = dInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                    val pts = dInfo.presentationTimeUs
                    val inRange = dInfo.size > 0 && pts >= startUs && pts <= endUs
                    d.releaseOutputBuffer(oi, inRange)   // true = kirim ke SurfaceTexture

                    if (inRange) {
                        // tunggu frame tiba di SurfaceTexture
                        if (!frames.tryAcquire(3, TimeUnit.SECONDS)) error("Frame decoder tidak tiba")
                        s.updateTexImage()
                        s.getTransformMatrix(stMat)

                        // koreksi rotasi metadata (rekaman LayKit rotasinya 0)
                        Matrix.setIdentityM(rotMat, 0)
                        if (rot != 0) {
                            Matrix.translateM(rotMat, 0, 0.5f, 0.5f, 0f)
                            Matrix.rotateM(rotMat, 0, -rot.toFloat(), 0f, 0f, 1f)
                            Matrix.translateM(rotMat, 0, -0.5f, -0.5f, 0f)
                        }
                        Matrix.multiplyMM(texMat, 0, stMat, 0, rotMat, 0)

                        // kamera zoom pada waktu SUMBER (ms pecahan), rumus sama persis dengan pratinjau
                        val zc = ZoomMath.camera(
                            zooms, pts / 1000.0,
                            CardGeo(canvasW.toFloat(), canvasH.toFloat(), canvasW / 2f, canvasH / 2f, rw / 2f, rh / 2f),
                            if (style.cursor) touches else emptyList(),
                        )

                        g.draw(
                            tex = tex, imgTex = imgTex, texMat = texMat,
                            resW = canvasW.toFloat(), resH = canvasH.toFloat(),
                            cx = canvasW / 2f, cy = canvasH / 2f, hw = rw / 2f, hh = rh / 2f,
                            radius = radius, style = style, bgType = bgType,
                            imgW = (bgBmp?.width ?: 1).toFloat(), imgH = (bgBmp?.height ?: 1).toFloat(),
                            vidW = dw.toFloat(), vidH = dh.toFloat(),
                            cz = zc,
                            cursor = if (style.cursor) CursorMath.at(touches, pts / 1000L) else null,
                        )
                        g.setPresentationTime((pts - startUs) * 1000L)
                        g.swap()
                        rendered++
                        onProgress(((pts - startUs) / total).coerceIn(0f, 1f))
                        drainEncoder(false)
                    }
                    if (eos) {
                        e.signalEndOfInputStream()
                        outputDone = true
                    }
                }
            }

            if (rendered == 0) error("Tidak ada frame pada rentang yang dipilih")
            drainEncoder(true)
            pumpAudio(Long.MAX_VALUE)
            onProgress(1f)
            return true
        } finally {
            try { dec?.stop() } catch (_: Exception) {}
            try { dec?.release() } catch (_: Exception) {}
            try { enc?.stop() } catch (_: Exception) {}
            try { enc?.release() } catch (_: Exception) {}
            try { if (muxerStarted) muxer?.stop() } catch (_: Exception) {}
            try { muxer?.release() } catch (_: Exception) {}
            try { st?.release() } catch (_: Exception) {}
            try { decSurface?.release() } catch (_: Exception) {}
            try { gl?.release() } catch (_: Exception) {}
            try { encSurface?.release() } catch (_: Exception) {}
            try { vex.release() } catch (_: Exception) {}
            try { aex.release() } catch (_: Exception) {}
        }
    }

    // ---------------------------------------------------------------------------------------------
    // Helper EGL/GLES minimal
    // ---------------------------------------------------------------------------------------------

    private class Gl(private val target: Surface, private val w: Int, private val h: Int) {
        private var dpy: EGLDisplay = EGL14.EGL_NO_DISPLAY
        private var ctx: EGLContext = EGL14.EGL_NO_CONTEXT
        private var surf: EGLSurface = EGL14.EGL_NO_SURFACE
        private var prog = 0
        private val quad = ByteBuffer.allocateDirect(8 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
            put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)); position(0)
        }

        private val IDENTITY3 = floatArrayOf(1f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f)

        private var uTex = 0; private var uTexMat = 0; private var uRes = 0; private var uRect = 0
        private var uRadius = 0; private var uTop = 0; private var uBottom = 0; private var uShadow = 0
        private var uMid = 0; private var uImg = 0; private var uBgType = 0
        private var uImgSize = 0; private var uVidSize = 0; private var uBlur = 0; private var uZoom = 0; private var uRot = 0; private var uPers = 0; private var uOff = 0; private var uCur = 0; private var uRip = 0
        private var uLk0 = 0; private var uLk1 = 0; private var uLk2 = 0; private var uVig = 0

        init {
            dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
            check(dpy != EGL14.EGL_NO_DISPLAY) { "EGL display tidak tersedia" }
            val ver = IntArray(2)
            check(EGL14.eglInitialize(dpy, ver, 0, ver, 1)) { "EGL init gagal" }
            val attribs = intArrayOf(
                EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
                EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                0x3142 /* EGL_RECORDABLE_ANDROID */, 1,
                EGL14.EGL_NONE,
            )
            val cfgs = arrayOfNulls<EGLConfig>(1)
            val num = IntArray(1)
            check(EGL14.eglChooseConfig(dpy, attribs, 0, cfgs, 0, 1, num, 0) && num[0] > 0) { "EGL config tidak ada" }
            ctx = EGL14.eglCreateContext(
                dpy, cfgs[0], EGL14.EGL_NO_CONTEXT,
                intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0,
            )
            check(ctx != EGL14.EGL_NO_CONTEXT) { "EGL context gagal" }
            surf = EGL14.eglCreateWindowSurface(dpy, cfgs[0], target, intArrayOf(EGL14.EGL_NONE), 0)
            check(surf != EGL14.EGL_NO_SURFACE) { "EGL surface gagal" }
        }

        fun makeCurrent() {
            check(EGL14.eglMakeCurrent(dpy, surf, surf, ctx)) { "eglMakeCurrent gagal" }
        }

        private fun compile(type: Int, src: String): Int {
            val s = GLES20.glCreateShader(type)
            GLES20.glShaderSource(s, src.trimIndent())
            GLES20.glCompileShader(s)
            val ok = IntArray(1)
            GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
            check(ok[0] != 0) { "Shader gagal: " + GLES20.glGetShaderInfoLog(s) }
            return s
        }

        fun setup(vert: String, frag: String) {
            val vs = compile(GLES20.GL_VERTEX_SHADER, vert)
            val fs = compile(GLES20.GL_FRAGMENT_SHADER, frag)
            prog = GLES20.glCreateProgram()
            GLES20.glAttachShader(prog, vs)
            GLES20.glAttachShader(prog, fs)
            GLES20.glLinkProgram(prog)
            val ok = IntArray(1)
            GLES20.glGetProgramiv(prog, GLES20.GL_LINK_STATUS, ok, 0)
            check(ok[0] != 0) { "Link shader gagal: " + GLES20.glGetProgramInfoLog(prog) }
            uTex = GLES20.glGetUniformLocation(prog, "uTex")
            uTexMat = GLES20.glGetUniformLocation(prog, "uTexMat")
            uRes = GLES20.glGetUniformLocation(prog, "uRes")
            uRect = GLES20.glGetUniformLocation(prog, "uRect")
            uRadius = GLES20.glGetUniformLocation(prog, "uRadius")
            uTop = GLES20.glGetUniformLocation(prog, "uTop")
            uBottom = GLES20.glGetUniformLocation(prog, "uBottom")
            uShadow = GLES20.glGetUniformLocation(prog, "uShadow")
            uMid = GLES20.glGetUniformLocation(prog, "uMid")
            uImg = GLES20.glGetUniformLocation(prog, "uImg")
            uBgType = GLES20.glGetUniformLocation(prog, "uBgType")
            uImgSize = GLES20.glGetUniformLocation(prog, "uImgSize")
            uVidSize = GLES20.glGetUniformLocation(prog, "uVidSize")
            uBlur = GLES20.glGetUniformLocation(prog, "uBlur")
            uZoom = GLES20.glGetUniformLocation(prog, "uZoom")
            uRot = GLES20.glGetUniformLocation(prog, "uRot")
            uPers = GLES20.glGetUniformLocation(prog, "uPers")
            uOff = GLES20.glGetUniformLocation(prog, "uOff")
            uCur = GLES20.glGetUniformLocation(prog, "uCur")
            uRip = GLES20.glGetUniformLocation(prog, "uRip")
            uLk0 = GLES20.glGetUniformLocation(prog, "uLk0")
            uLk1 = GLES20.glGetUniformLocation(prog, "uLk1")
            uLk2 = GLES20.glGetUniformLocation(prog, "uLk2")
            uVig = GLES20.glGetUniformLocation(prog, "uVig")
        }

        /** Tekstur 2D untuk gambar background (unit 1). Tanpa gambar: 1x1 hitam sebagai pengganti. */
        fun createImageTexture(bmp: Bitmap?): Int {
            val t = IntArray(1)
            GLES20.glGenTextures(1, t, 0)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE1)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, t[0])
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
            val b = bmp ?: Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
            GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, b, 0)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            return t[0]
        }

        fun createExternalTexture(): Int {
            val t = IntArray(1)
            GLES20.glGenTextures(1, t, 0)
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, t[0])
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
            return t[0]
        }

        private fun rgb(loc: Int, c: Int) =
            GLES20.glUniform3f(loc, ((c shr 16) and 0xFF) / 255f, ((c shr 8) and 0xFF) / 255f, (c and 0xFF) / 255f)

        fun draw(
            tex: Int, imgTex: Int, texMat: FloatArray, resW: Float, resH: Float,
            cx: Float, cy: Float, hw: Float, hh: Float,
            radius: Float, style: FrameStyle, bgType: Int,
            imgW: Float, imgH: Float, vidW: Float, vidH: Float,
            cz: CardZoom,
            cursor: CursorState?,
        ) {
            // zoom kartu: seluruh bingkai dibesarkan (bukan isinya di-crop), lalu rect/sudut/bayangan mengikuti
            val zcx = cz.s * cx + cz.tx; val zcy = cz.s * cy + cz.ty
            val zhw = cz.s * hw; val zhh = cz.s * hh
            GLES20.glViewport(0, 0, w, h)
            GLES20.glUseProgram(prog)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE1)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, imgTex)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glUniform1i(uTex, 0)
            GLES20.glUniform1i(uImg, 1)
            GLES20.glUniformMatrix4fv(uTexMat, 1, false, texMat, 0)
            GLES20.glUniform2f(uRes, resW, resH)
            GLES20.glUniform4f(uRect, zcx, zcy, zhw, zhh)
            GLES20.glUniform1f(uRadius, radius * cz.s)
            rgb(uTop, style.top)
            rgb(uMid, style.mid)
            rgb(uBottom, style.bottom)
            GLES20.glUniform1f(uShadow, if (style.shadow) style.shadowAmt.coerceIn(0f, 1f) else 0f)
            GLES20.glUniform1i(uBgType, bgType)
            GLES20.glUniform2f(uImgSize, imgW, imgH)
            GLES20.glUniform2f(uVidSize, vidW, vidH)
            GLES20.glUniform1f(uBlur, style.blur.coerceIn(0.005f, 0.10f))
            GLES20.glUniform3f(uZoom, 0f, 0f, 1f)   // isi video tidak di-crop lagi
            // kamera 3D: rumus dan jarak SAMA dengan pratinjau (graphicsLayer: rotationX/Y/Z = pitch/yaw/roll, scale = fit,
            // cameraDistance = P / 72). P dihitung pada kartu yang sudah di-zoom; zoom hanya membesarkan hasil proyeksinya.
            // Kamera nyata: P = fokus kamera, S = skala bidang, (ox, oy) = offset pusat layar (cz.persp / cz.fit / cz.ox / cz.oy).
            val tilt = cz.tilted
            GLES20.glUniformMatrix3fv(uRot, 1, false, if (tilt) Cam.rotationColumns(cz.rot) else IDENTITY3, 0)
            GLES20.glUniform2f(uPers, if (tilt) (if (cz.persp > 0f) cz.persp else Cam.perspectivePx(2f * zhw, 2f * zhh)) else 0f, if (tilt) cz.fit else 1f)
            GLES20.glUniform2f(uOff, if (tilt) cz.ox else 0f, if (tilt) cz.oy else 0f)
            val lk = Looks.matrix(style.look, style.lookAmt) ?: Looks.ID
            GLES20.glUniform4f(uLk0, lk[0], lk[1], lk[2], lk[3])
            GLES20.glUniform4f(uLk1, lk[4], lk[5], lk[6], lk[7])
            GLES20.glUniform4f(uLk2, lk[8], lk[9], lk[10], lk[11])
            GLES20.glUniform1f(uVig, style.vignette.coerceIn(0f, 1f))
            // kursor: koordinat video (0..1) -> px di kartu yang sudah di-zoom
            val sPx = CursorMath.SIZE_FRAC * 2f * min(zhw, zhh)
            fun mx(nx: Float) = zcx + (nx - 0.5f) * 2f * zhw
            fun my(ny: Float) = zcy + (ny - 0.5f) * 2f * zhh
            if (cursor != null) {
                GLES20.glUniform4f(uCur, mx(cursor.x), my(cursor.y), sPx, cursor.alpha)
                GLES20.glUniform4f(uRip, mx(cursor.rx), my(cursor.ry), cursor.rp, cursor.press)
            } else {
                GLES20.glUniform4f(uCur, 0f, 0f, sPx, 0f)
                GLES20.glUniform4f(uRip, 0f, 0f, -1f, 0f)
            }
            val aPos = GLES20.glGetAttribLocation(prog, "aPos")
            GLES20.glEnableVertexAttribArray(aPos)
            GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 8, quad)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            GLES20.glDisableVertexAttribArray(aPos)
        }

        fun setPresentationTime(ns: Long) { EGLExt.eglPresentationTimeANDROID(dpy, surf, ns) }
        fun swap() { EGL14.eglSwapBuffers(dpy, surf) }

        fun release() {
            if (dpy != EGL14.EGL_NO_DISPLAY) {
                EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                if (surf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(dpy, surf)
                if (ctx != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(dpy, ctx)
                EGL14.eglReleaseThread()
                EGL14.eglTerminate(dpy)
            }
            dpy = EGL14.EGL_NO_DISPLAY; ctx = EGL14.EGL_NO_CONTEXT; surf = EGL14.EGL_NO_SURFACE
        }
    }
}
