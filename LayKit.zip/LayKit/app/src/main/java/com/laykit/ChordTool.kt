package com.laykit

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.laykit.chord.ChordEngine
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext

/** Label model ("A:min", "Db:maj7", "N") -> nama yang dibaca musisi ("Am", "D♭maj7", "–"). */
internal fun chordName(label: String): String {
    if (label == "N" || label == "X") return "–"
    val i = label.indexOf(':')
    val root = (if (i < 0) label else label.substring(0, i)).replace("b", "♭")
    if (i < 0) return root
    val q = when (val s = label.substring(i + 1)) {
        "min" -> "m"
        "min6" -> "m6"
        "min7" -> "m7"
        "minmaj7" -> "mM7"
        "hdim7" -> "m7♭5"
        "maj6" -> "6"
        else -> s   // maj7, 7, dim, dim7, aug, sus2, sus4
    }
    return root + q
}

private fun mmss(sec: Double): String {
    val s = sec.toInt().coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

/**
 * Tool "Chord Finder" di panel Tools HUD. Daftar file + hasilnya disimpan di sini (bukan di HudService)
 * supaya ChordPickActivity bisa menambah file dan HUD cukup membaca [items].
 * File diproses satu per satu oleh [work], yang dijalankan HudService.
 */
internal object ChordTool {
    sealed interface St {
        object Waiting : St
        class Working(val label: String, val p: Float) : St
        /** [segs] = akor per waktu mulai (detik), berurutan; [timeline] = daftar lengkap "waktu  akor" untuk disalin. */
        class Done(val segs: List<Seg>, val timeline: String) : St
        class Fail(val msg: String) : St
    }

    class Seg(val start: Double, val name: String)

    class Item(val id: Long, val uri: Uri, val name: String, val st: St)

    val items = MutableStateFlow<List<Item>>(emptyList())

    /** Naik tiap pemilih file selesai (dipilih atau dibatalkan): HUD membuka lagi panel Chord Finder. */
    val pickDone = MutableStateFlow(0)

    @Volatile private var gen = 0       // naik tiap daftar dibersihkan -> pekerjaan yang sedang jalan berhenti
    private var nextId = 0L

    fun enqueue(ctx: Context, uris: List<Uri>) {
        val add = uris.map { Item(++nextId, it, displayName(ctx, it), St.Waiting) }
        items.update { it + add }
    }

    fun clear() {
        gen++
        items.value = emptyList()
    }

    /** HUD baru menyala: file yang tadinya sedang dikerjakan (HUD keburu ditutup) diantrekan lagi. */
    fun resetStuck() {
        items.update { l -> l.map { if (it.st is St.Working) Item(it.id, it.uri, it.name, St.Waiting) else it } }
    }

    private fun set(id: Long, st: St) {
        items.update { l -> l.map { if (it.id == id) Item(it.id, it.uri, it.name, st) else it } }
    }

    private fun displayName(ctx: Context, uri: Uri): String {
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0)?.takeIf { it.isNotBlank() }?.let { return it }
            }
        } catch (_: Exception) { /* pakai nama dari path */ }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "Audio"
    }

    /** Mengerjakan semua file berstatus Waiting, satu per satu. Selesai saat tidak ada lagi yang menunggu. */
    suspend fun work(ctx: Context) {
        val app = ctx.applicationContext
        var engine: ChordEngine? = null
        while (true) {
            val item = items.value.firstOrNull { it.st is St.Waiting } ?: return
            val my = gen
            set(item.id, St.Working("Membaca audio", 0f))
            val result: St = try {
                withContext(Dispatchers.Default) {
                    val job = currentCoroutineContext()[Job]
                    val cancelled = { gen != my || job?.isActive == false }
                    var lastP = -1f
                    fun report(label: String, p: Float) {
                        if (p - lastP >= 0.01f || p >= 1f) { lastP = p; set(item.id, St.Working(label, p)) }
                    }
                    val pcm = AudioDecoder.decodeMono(app, item.uri, cancelled) { report("Membaca audio", it * 0.2f) }
                    report("Memuat model", 0.2f)
                    val eng = engine ?: app.assets.open("net.lkm").use { ChordEngine.load(it) }.also { engine = it }
                    val res = eng.analyze(pcm.samples, pcm.sampleRate, onProgress = { p ->
                        if (cancelled()) throw CancellationException("dibatalkan")
                        report("Mencari akor", 0.2f + 0.8f * p)
                    })
                    val segs = res.segments.map { Seg(it.start, chordName(it.label)) }
                    val timeline = segs.joinToString("\n") { mmss(it.start) + "  " + it.name }
                    St.Done(segs, timeline)
                }
            } catch (e: CancellationException) {
                currentCoroutineContext().ensureActive()   // HUD ditutup -> teruskan pembatalan
                continue                                   // hanya daftar yang dibersihkan -> lanjut ke file berikutnya
            } catch (e: OutOfMemoryError) {
                St.Fail("Memori HP tidak cukup untuk audio ini")
            } catch (e: Throwable) {
                St.Fail(e.message ?: "Gagal menganalisis audio")
            }
            set(item.id, result)
        }
    }
}
