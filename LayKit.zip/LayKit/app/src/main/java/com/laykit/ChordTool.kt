package com.laykit

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.laykit.chord.ChordAnalysis
import com.laykit.chord.ChordEngine
import com.laykit.chord.CnnChordEngine
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext

/** Interval bas ("b7", "5", ...) dari label CNN -> semitone. */
private fun bassSemis(iv: String): Int? = when (iv) {
    "1" -> 0; "b2" -> 1; "2" -> 2; "b3" -> 3; "3" -> 4; "4" -> 5; "b5" -> 6
    "5" -> 7; "b6" -> 8; "6" -> 9; "b7" -> 10; "7" -> 11; else -> null
}

private val NOTE_FLAT = arrayOf("C", "D♭", "D", "E♭", "E", "F", "G♭", "G", "A♭", "A", "B♭", "B")
private val NOTE_SHARP = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")

private fun rootSemis(root: String): Int {
    val base = when (root.firstOrNull()) { 'C' -> 0; 'D' -> 2; 'E' -> 4; 'F' -> 5; 'G' -> 7; 'A' -> 9; 'B' -> 11; else -> 0 }
    return (base + (if (root.contains('#')) 1 else 0) - (if (root.length > 1 && root[1] == 'b') 1 else 0) + 12) % 12
}

/**
 * Label model ("A:min", "Db:maj7", "C:min/b7", "N") -> nama yang dibaca musisi ("Am", "D♭maj7", "Cm/B♭", "–").
 * Label mesin CNN punya bas sebagai interval ("/b7"); diubah jadi nama nada.
 */
internal fun chordName(label: String): String {
    if (label == "N" || label == "X") return "–"
    val i = label.indexOf(':')
    val rootRaw = if (i < 0) label else label.substring(0, i)
    val root = rootRaw.replace("b", "♭")
    if (i < 0) return root
    val rest = label.substring(i + 1)
    val qual = rest.substringBefore('/')
    val bassIv = rest.substringAfter('/', "")
    val q = when (qual) {
        "min" -> "m"
        "min6" -> "m6"
        "min7" -> "m7"
        "min9" -> "m9"
        "minmaj7" -> "mM7"
        "hdim7" -> "m7♭5"
        "maj6" -> "6"
        "sus4(b7)" -> "7sus4"
        else -> qual   // maj, maj7, maj9, 7, 9, 11, 13, dim, dim7, aug, sus2, sus4
    }
    val bass = bassSemis(bassIv)?.let { iv ->
        val n = (rootSemis(rootRaw) + iv) % 12
        "/" + (if (rootRaw.contains('#')) NOTE_SHARP[n] else NOTE_FLAT[n])
    } ?: ""
    return root + q + bass
}

private fun mmss(sec: Double): String {
    val s = sec.toInt().coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

/**
 * Tool "Chord Finder" di panel Tools HUD. Daftar file + hasilnya disimpan di sini (bukan di HudService)
 * supaya ChordPickActivity bisa menambah file dan HUD cukup membaca [items].
 * File diproses satu per satu oleh [work], yang dijalankan HudService.
 */
internal object ChordTool {
    sealed interface St {
        object Waiting : St
        class Working(val label: String, val p: Float) : St
        /** [segs] = akor per waktu mulai (detik), berurutan; [timeline] = daftar lengkap "waktu  akor" untuk disalin; [dur] = durasi audio (detik). */
        class Done(val segs: List<Seg>, val timeline: String, val dur: Double) : St
        class Fail(val msg: String) : St
    }

    class Seg(val start: Double, val name: String)

    class Item(val id: Long, val uri: Uri, val name: String, val st: St)

    val items = MutableStateFlow<List<Item>>(emptyList())

    /** Naik tiap pemilih file selesai (dipilih atau dibatalkan): HUD membuka lagi panel Chord Finder. */
    val pickDone = MutableStateFlow(0)

    /** true = mesin CNN+BiLSTM ChordMini (assets/cnn.lkm, 3 model); false = mesin transformer lama (assets/net.lkm). */
    private const val USE_CNN_ENGINE = true

    @Volatile private var gen = 0       // naik tiap daftar dibersihkan -> pekerjaan yang sedang jalan berhenti
    private var nextId = 0L

    fun enqueue(ctx: Context, uris: List<Uri>) {
        val add = uris.map { Item(++nextId, it, displayName(ctx, it), St.Waiting) }
        items.update { it + add }
    }

    fun clear() {
        gen++
        items.value = emptyList()
    }

    /** Membuang satu file dari daftar. Kalau sedang dianalisis, pekerjaannya dibatalkan dan antrean lanjut ke file berikutnya. */
    fun remove(id: Long) {
        val cur = items.value.firstOrNull { x -> x.id == id } ?: return
        if (cur.st is St.Working) gen++
        items.update { l -> l.filter { x -> x.id != id } }
    }

    /** HUD baru menyala: file yang tadinya sedang dikerjakan (HUD keburu ditutup) diantrekan lagi. */
    fun resetStuck() {
        items.update { l -> l.map { if (it.st is St.Working) Item(it.id, it.uri, it.name, St.Waiting) else it } }
    }

    private fun set(id: Long, st: St) {
        items.update { l -> l.map { if (it.id == id) Item(it.id, it.uri, it.name, st) else it } }
    }

    private fun displayName(ctx: Context, uri: Uri): String {
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0)?.takeIf { it.isNotBlank() }?.let { return it }
            }
        } catch (_: Exception) { /* pakai nama dari path */ }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "Audio"
    }

    /** Mengerjakan semua file berstatus Waiting, satu per satu. Selesai saat tidak ada lagi yang menunggu. */
    suspend fun work(ctx: Context) {
        val app = ctx.applicationContext
        var engine: ChordEngine? = null
        var cnnEngine: CnnChordEngine? = null
        while (true) {
            val item = items.value.firstOrNull { it.st is St.Waiting } ?: return
            val my = gen
            set(item.id, St.Working("Membaca audio", 0f))
            val result: St = try {
                withContext(Dispatchers.Default) {
                    val job = currentCoroutineContext()[Job]
                    val cancelled = { gen != my || job?.isActive == false }
                    var lastP = -1f
                    fun report(label: String, p: Float) {
                        if (p - lastP >= 0.01f || p >= 1f) { lastP = p; set(item.id, St.Working(label, p)) }
                    }
                    val pcm = AudioDecoder.decodeMono(app, item.uri, cancelled) { report("Membaca audio", it * 0.2f) }
                    report("Memuat model", 0.2f)
                    val onP = { p: Float ->
                        if (cancelled()) throw CancellationException("dibatalkan")
                        report("Mencari akor", 0.2f + 0.8f * p)
                    }
                    val res: ChordAnalysis = if (USE_CNN_ENGINE) {
                        val eng = cnnEngine ?: app.assets.open("cnn.lkm").use { CnnChordEngine.load(it) }.also { cnnEngine = it }
                        eng.analyze(pcm.samples, pcm.sampleRate, onProgress = onP)
                    } else {
                        val eng = engine ?: app.assets.open("net.lkm").use { ChordEngine.load(it) }.also { engine = it }
                        eng.analyze(pcm.samples, pcm.sampleRate, onProgress = onP)
                    }
                    val segs = res.segments.map { Seg(it.start, chordName(it.label)) }
                    val timeline = segs.joinToString("\n") { mmss(it.start) + "  " + it.name }
                    St.Done(segs, timeline, pcm.samples.size.toDouble() / pcm.sampleRate.coerceAtLeast(1))
                }
            } catch (e: CancellationException) {
                currentCoroutineContext().ensureActive()   // HUD ditutup -> teruskan pembatalan
                continue                                   // hanya daftar yang dibersihkan -> lanjut ke file berikutnya
            } catch (e: OutOfMemoryError) {
                St.Fail("Memori HP tidak cukup untuk audio ini")
            } catch (e: Throwable) {
                St.Fail(e.message ?: "Gagal menganalisis audio")
            }
            set(item.id, result)
        }
    }
}
