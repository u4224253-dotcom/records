package com.laykit

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.drawable.ColorDrawable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

/** Gradient khas LayKit (biru tua ke biru ke cyan), diambil dari warna logo. Dipakai header, tombol, progress, dan aksen. */
object LayKitGradient {
    val Deep = Color(0xFF0A2FF0)
    val Mid = Color(0xFF0560FF)
    val Light = Color(0xFF00A8FF)
    val colors = listOf(Deep, Mid, Light)
    val horizontal: Brush get() = Brush.horizontalGradient(colors)
    val diagonal: Brush get() = Brush.linearGradient(colors)
}

enum class ThemeMode { SYSTEM, LIGHT, DARK }

object ThemePrefs {
    private const val FILE = "ui"
    private const val KEY = "theme"

    fun load(ctx: Context): ThemeMode {
        val v = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getInt(KEY, 0)
        return ThemeMode.values().getOrElse(v) { ThemeMode.SYSTEM }
    }

    fun save(ctx: Context, mode: ThemeMode) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putInt(KEY, mode.ordinal).apply()
    }
}

private val LightColors = lightColorScheme(
    primary = Color(0xFF0A4DF0),
    onPrimary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFDDDDE3),
    onSecondaryContainer = Color(0xFF111114),
    tertiary = Color(0xFFF5A524),
    background = Color(0xFFFAFAFA),
    onBackground = Color(0xFF111114),
    surface = Color(0xFFFAFAFA),
    onSurface = Color(0xFF111114),
    surfaceVariant = Color(0xFFECECEF),
    onSurfaceVariant = Color(0xFF6B6B73),
    surfaceContainerLow = Color(0xFFF4F4F6),
    surfaceContainer = Color(0xFFEFEFF2),
    surfaceContainerHighest = Color(0xFFE4E4E8),
    outline = Color(0xFFC0C0C8),
    outlineVariant = Color(0xFFE2E2E6),
    error = Color(0xFFE5484D),
    onError = Color(0xFFFFFFFF),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF6AA6FF),
    onPrimary = Color(0xFF001A4D),
    secondaryContainer = Color(0xFF2C2C33),
    onSecondaryContainer = Color(0xFFEDEDF0),
    tertiary = Color(0xFFFFB84D),
    background = Color(0xFF0E0E10),
    onBackground = Color(0xFFEDEDF0),
    surface = Color(0xFF0E0E10),
    onSurface = Color(0xFFEDEDF0),
    surfaceVariant = Color(0xFF1F1F23),
    onSurfaceVariant = Color(0xFF9A9AA3),
    surfaceContainerLow = Color(0xFF151518),
    surfaceContainer = Color(0xFF1A1A1E),
    surfaceContainerHighest = Color(0xFF2C2C33),
    outline = Color(0xFF4A4A53),
    outlineVariant = Color(0xFF2A2A30),
    error = Color(0xFFFF6369),
    onError = Color(0xFF1A0505),
)

internal fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

@Composable
fun LayKitTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val scheme = if (dark) DarkColors else LightColors
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val win = view.context.findActivity()?.window
            if (win != null) {
                win.setBackgroundDrawable(ColorDrawable(scheme.background.toArgb()))
                val c = WindowCompat.getInsetsController(win, view)
                c.isAppearanceLightStatusBars = !dark
                c.isAppearanceLightNavigationBars = !dark
            }
        }
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
