package com.laykit

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Satu project tersimpan: video sumber + seluruh keadaan edit ([snap]: zoom, potong, background, bingkai, rasio, kursor, efek). */
internal data class Project(
    val id: String,
    val name: String,
    val videoUri: Uri,
    val durationMs: Long,
    val updatedAt: Long,
    val snap: EditSnap,
)

/** Ringkasan project untuk daftar di layar utama. [videoOk] = video sumbernya masih ada di galeri. */
internal data class ProjectItem(
    val id: String,
    val name: String,
    val videoUri: Uri,
    val durationMs: Long,
    val updatedAt: Long,
    val zoomCount: Int,
    val videoOk: Boolean,
)

/**
 * Penyimpanan project: satu file JSON per project di filesDir/projects/<id>.json. Video TIDAK disalin (tetap di Movies/LayKit),
 * hanya Uri-nya. Gambar background pilihan pengguna disalin ke filesDir/projects/<id>_bg supaya tetap terbaca setelah app
 * dibuka ulang (izin Uri dari pemilih foto tidak bertahan).
 */
internal object ProjectStore {
    private const val VERSION = 1

    private fun dir(ctx: Context) = File(ctx.filesDir, "projects").apply { mkdirs() }
    private fun file(ctx: Context, id: String) = File(dir(ctx), "$id.json")
    private fun bgFile(ctx: Context, id: String) = File(dir(ctx), "${id}_bg")

    fun newId(): String = System.currentTimeMillis().toString(36) + (Math.random() * 1295).toInt().toString(36)

    /** Simpan (buat baru atau timpa) project [id]. Dipanggil di thread background. Mengembalikan true kalau berhasil. */
    fun save(ctx: Context, id: String, name: String, video: Uri, durationMs: Long, snap: EditSnap): Boolean = try {
        val img = persistImage(ctx, id, snap.imageUri)
        val o = JSONObject()
            .put("v", VERSION)
            .put("id", id)
            .put("name", name)
            .put("video", video.toString())
            .put("durationMs", durationMs)
            .put("updatedAt", System.currentTimeMillis())
            .put("snap", snapToJson(snap, img))
        // tulis ke file sementara lalu ganti, supaya project lama tidak rusak kalau proses terhenti di tengah
        val tmp = File(dir(ctx), "$id.tmp")
        tmp.writeText(o.toString())
        val dst = file(ctx, id)
        if (!tmp.renameTo(dst)) { dst.delete(); tmp.renameTo(dst) }
        true
    } catch (_: Exception) {
        false
    }

    fun load(ctx: Context, id: String): Project? = try {
        parse(JSONObject(file(ctx, id).readText()))
    } catch (_: Exception) {
        null
    }

    /** Semua project, terbaru diubah dulu. Berkas rusak dilewati. */
    fun list(ctx: Context): List<ProjectItem> {
        val out = mutableListOf<ProjectItem>()
        dir(ctx).listFiles { f -> f.name.endsWith(".json") }?.forEach { f ->
            try {
                val p = parse(JSONObject(f.readText())) ?: return@forEach
                out += ProjectItem(
                    p.id, p.name, p.videoUri, p.durationMs, p.updatedAt, p.snap.zooms.size,
                    videoOk = Library.nameOf(ctx, p.videoUri) != null,
                )
            } catch (_: Exception) {}
        }
        return out.sortedByDescending { it.updatedAt }
    }

    fun delete(ctx: Context, id: String) {
        file(ctx, id).delete()
        bgFile(ctx, id).delete()
    }

    // ---- gambar background ----

    private fun persistImage(ctx: Context, id: String, uri: Uri?): Uri? {
        if (uri == null) return null
        val dst = bgFile(ctx, id)
        if (uri.scheme == "file" && uri.path == dst.absolutePath) return uri   // sudah salinan kita
        return try {
            ctx.contentResolver.openInputStream(uri)?.use { ins -> dst.outputStream().use { ins.copyTo(it) } }
            if (dst.exists() && dst.length() > 0) Uri.fromFile(dst) else null
        } catch (_: Exception) {
            // sumber tidak terbaca lagi: pakai salinan lama kalau ada
            if (dst.exists() && dst.length() > 0) Uri.fromFile(dst) else null
        }
    }

    // ---- JSON ----

    private fun parse(o: JSONObject): Project? {
        val s = o.getJSONObject("snap")
        return Project(
            id = o.getString("id"),
            name = o.optString("name", "Project"),
            videoUri = Uri.parse(o.getString("video")),
            durationMs = o.optLong("durationMs", 0L),
            updatedAt = o.optLong("updatedAt", 0L),
            snap = snapFromJson(s),
        )
    }

    private fun snapToJson(s: EditSnap, img: Uri?): JSONObject = JSONObject()
        .put("zooms", JSONArray().also { a -> s.zooms.forEach { a.put(zoomToJson(it)) } })
        .put("startMs", s.startMs.toDouble()).put("endMs", s.endMs.toDouble())
        .put("bgUi", s.bgUi).put("preset", s.preset).put("solid", s.solid).put("wall", s.wall)
        .put("imageUri", img?.toString() ?: JSONObject.NULL)
        .put("blurAmt", s.blurAmt.toDouble())
        .put("padding", s.padding.toDouble()).put("corner", s.corner.toDouble())
        .put("shadow", s.shadow).put("shadowAmt", s.shadowAmt.toDouble())
        .put("aspectIdx", s.aspectIdx).put("cursorOn", s.cursorOn)
        .put("look", s.look).put("lookAmt", s.lookAmt.toDouble())
        .put("vignette", s.vignette.toDouble())
        .put("glow", s.glow.toDouble()).put("glowSize", s.glowSize.toDouble())
        .put("captions", JSONArray().also { a ->
            s.captions.forEach { a.put(JSONObject().put("s", it.startMs).put("e", it.endMs).put("t", it.text)) }
        })
        .put("capOn", s.capOn).put("capSize", s.capSize.toDouble())
        .put("texts", JSONArray().also { a ->
            s.texts.forEach {
                a.put(
                    JSONObject().put("id", it.id).put("t", it.text)
                        .put("x", it.xFrac.toDouble()).put("y", it.yFrac.toDouble()).put("sz", it.sizeFrac.toDouble()),
                )
            }
        })

    private fun snapFromJson(o: JSONObject): EditSnap {
        val za = o.optJSONArray("zooms") ?: JSONArray()
        val zooms = (0 until za.length()).map { zoomFromJson(za.getJSONObject(it)) }
        val img = if (o.isNull("imageUri")) null else Uri.parse(o.getString("imageUri"))
        val ca = o.optJSONArray("captions") ?: JSONArray()
        val captions = (0 until ca.length()).mapNotNull { i ->
            val c = ca.optJSONObject(i) ?: return@mapNotNull null
            val t = c.optString("t", "")
            if (t.isEmpty()) null else CaptionSeg(c.optLong("s", 0L), c.optLong("e", 0L), t)
        }
        val ta = o.optJSONArray("texts") ?: JSONArray()
        val texts = (0 until ta.length()).mapNotNull { i ->
            val t = ta.optJSONObject(i) ?: return@mapNotNull null
            val txt = t.optString("t", "")
            if (txt.isEmpty()) null else TextOverlay(
                id = t.optLong("id", System.nanoTime()), text = txt,
                xFrac = t.optDouble("x", 0.5).toFloat(), yFrac = t.optDouble("y", 0.5).toFloat(),
                sizeFrac = t.optDouble("sz", 0.3).toFloat(),
            )
        }
        return EditSnap(
            zooms = zooms,
            startMs = o.optDouble("startMs", 0.0).toFloat(),
            endMs = o.optDouble("endMs", 0.0).toFloat(),
            bgUi = o.optInt("bgUi", 0), preset = o.optInt("preset", 0), solid = o.optInt("solid", 0), wall = o.optInt("wall", 0),
            imageUri = img,
            blurAmt = o.optDouble("blurAmt", 0.04).toFloat(),
            padding = o.optDouble("padding", 0.08).toFloat(), corner = o.optDouble("corner", 0.03).toFloat(),
            shadow = o.optBoolean("shadow", true), shadowAmt = o.optDouble("shadowAmt", 0.5).toFloat(),
            aspectIdx = o.optInt("aspectIdx", 0), cursorOn = o.optBoolean("cursorOn", true),
            look = o.optInt("look", 0), lookAmt = o.optDouble("lookAmt", 1.0).toFloat(),
            vignette = o.optDouble("vignette", 0.0).toFloat(),
            glow = o.optDouble("glow", 0.0).toFloat(), glowSize = o.optDouble("glowSize", 0.5).toFloat(),
            captions = captions, capOn = o.optBoolean("capOn", true), capSize = o.optDouble("capSize", 0.5).toFloat(),
            texts = texts,
        )
    }

    private fun curveToJson(c: ZoomCurve?): Any =
        if (c == null) JSONObject.NULL else JSONArray().put(c.x1.toDouble()).put(c.y1.toDouble()).put(c.x2.toDouble()).put(c.y2.toDouble())

    private fun curveFromJson(o: JSONObject, k: String): ZoomCurve? {
        val a = o.optJSONArray(k) ?: return null
        if (a.length() < 4) return null
        return ZoomCurve(a.getDouble(0).toFloat(), a.getDouble(1).toFloat(), a.getDouble(2).toFloat(), a.getDouble(3).toFloat())
    }

    private fun zoomToJson(z: ZoomRegion): JSONObject = JSONObject()
        .put("id", z.id).put("startMs", z.startMs).put("endMs", z.endMs)
        .put("scale", z.scale.toDouble()).put("fx", z.fx.toDouble()).put("fy", z.fy.toDouble())
        .put("auto", z.auto).put("cam", z.cam)
        .put("keys", JSONArray().also { a ->
            z.keys.forEach { k ->
                a.put(
                    JSONObject().put("t", k.tMs).put("s", k.scale.toDouble()).put("fx", k.fx.toDouble()).put("fy", k.fy.toDouble())
                        .put("p", k.camPitch.toDouble()).put("y", k.camYaw.toDouble()).put("r", k.camRoll.toDouble()).put("d", k.camDepth.toDouble()),
                )
            }
        })
        .put("curve", curveToJson(z.curve))
        .put("camPitch", z.camPitch.toDouble()).put("camYaw", z.camYaw.toDouble()).put("camRoll", z.camRoll.toDouble())
        .put("camDepth", z.camDepth.toDouble())
        .put("curvePitch", curveToJson(z.curvePitch)).put("curveYaw", curveToJson(z.curveYaw))
        .put("curveRoll", curveToJson(z.curveRoll)).put("curveDepth", curveToJson(z.curveDepth))

    private fun zoomFromJson(o: JSONObject): ZoomRegion {
        val d = ZoomRegion(id = 0, startMs = 0, endMs = 0)   // nilai bawaan untuk kolom yang tidak ada (project dari versi lain)
        val ka = o.optJSONArray("keys") ?: JSONArray()
        val keys = (0 until ka.length()).map { i ->
            val k = ka.getJSONObject(i)
            ZoomKey(
                k.getLong("t"), k.getDouble("s").toFloat(), k.getDouble("fx").toFloat(), k.getDouble("fy").toFloat(),
                k.getDouble("p").toFloat(), k.getDouble("y").toFloat(), k.getDouble("r").toFloat(), k.getDouble("d").toFloat(),
            )
        }
        return ZoomRegion(
            id = o.getInt("id"), startMs = o.getLong("startMs"), endMs = o.getLong("endMs"),
            scale = o.optDouble("scale", d.scale.toDouble()).toFloat(),
            fx = o.optDouble("fx", d.fx.toDouble()).toFloat(), fy = o.optDouble("fy", d.fy.toDouble()).toFloat(),
            auto = o.optBoolean("auto", false), cam = o.optInt("cam", d.cam),
            keys = keys,
            curve = curveFromJson(o, "curve"),
            camPitch = o.optDouble("camPitch", d.camPitch.toDouble()).toFloat(),
            camYaw = o.optDouble("camYaw", d.camYaw.toDouble()).toFloat(),
            camRoll = o.optDouble("camRoll", d.camRoll.toDouble()).toFloat(),
            camDepth = o.optDouble("camDepth", d.camDepth.toDouble()).toFloat(),
            curvePitch = curveFromJson(o, "curvePitch"), curveYaw = curveFromJson(o, "curveYaw"),
            curveRoll = curveFromJson(o, "curveRoll"), curveDepth = curveFromJson(o, "curveDepth"),
        )
    }
}
