package com.laykit.chord

import java.io.InputStream
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min

/** Satu segmen akor: [start, end) dalam detik. */
class ChordSegment(val start: Double, val end: Double, val label: String) {
    override fun toString() = "%.3f %.3f %s".format(start, end, label)
}

/** Hasil analisis: timeline akor + indeks kelas per frame (frame = 2048 sampel @ 22.050 Hz ~ 92,9 ms). */
class ChordAnalysis(val segments: List<ChordSegment>, val frameIndices: IntArray, val frameDuration: Double)

/**
 * Mesin chord finder: audio -> timeline akor. Kotlin murni, tanpa library eksternal.
 *
 * Alur (sama dengan setelan REKOMENDASI README ChordMini, lihat tools/ref_rec.py):
 *   CQT -> log -> normalisasi -> jendela 108 frame dengan overlap 50% -> ChordNet ->
 *   smoothing Gaussian (k=9) per jendela -> voting logit antar jendela -> majority filter (k=9).
 *
 * Tidak aman dipakai dari banyak thread sekaligus untuk instance yang sama; buat satu instance per pekerjaan.
 */
class ChordEngine(lkm: LkmFile) {
    class Params(
        val overlapRatio: Double = 0.5,
        val gaussianSmoothing: Boolean = true,
        val smoothingKernel: Int = 9,
        val majorityFilter: Boolean = true,
    )

    private val cqt = Cqt(lkm)
    private val net = ChordNet(lkm)
    private val mean: Float
    private val std: Float
    val labels: List<String> = String(lkm.blob("labels"), Charsets.UTF_8).split("\n")

    init {
        val s = lkm.tensor("norm.stats").data
        mean = s[0]
        std = s[1]
        require(labels.size == net.nClasses) { "Jumlah label ${labels.size} != kelas ${net.nClasses}" }
    }

    /** @param pcm audio mono float [-1,1] pada laju [sampleRate]; di-resample ke 22.050 Hz bila perlu. */
    fun analyze(
        pcm: FloatArray,
        sampleRate: Int,
        params: Params = Params(),
        onProgress: ((Float) -> Unit)? = null,
    ): ChordAnalysis {
        val y = if (sampleRate == SAMPLE_RATE) pcm else Resampler.resample(pcm, sampleRate, SAMPLE_RATE)
        return analyze22k(y, params, onProgress)
    }

    fun analyze22k(y: FloatArray, params: Params = Params(), onProgress: ((Float) -> Unit)? = null): ChordAnalysis {
        val (feat, frames) = cqt.logFeatures(y) { onProgress?.invoke(it * 0.3f) }
        val preds = predict(feat, frames, params) { onProgress?.invoke(0.3f + it * 0.7f) }
        return ChordAnalysis(timeline(preds), preds, FRAME_DURATION)
    }

    // ------------------------------------------------------------------ prediksi sliding-window
    /** Padanan predict_sliding_windows(vote_aggregation='logit') dari repo. */
    private fun predict(feat: FloatArray, frames: Int, p: Params, onProgress: (Float) -> Unit): IntArray {
        if (frames == 0) return IntArray(0)
        val nF = net.nFreq
        val nC = net.nClasses
        val seq = SEQ_LEN
        val k = (max(1, p.smoothingKernel)).let { if (it % 2 == 0) it + 1 else it }

        val padded = if (frames % seq == 0) frames else frames + (seq - frames % seq)
        val ratio = min(max(p.overlapRatio, 0.0), 0.99)
        val stride = if (ratio > 0) max(1, (seq * (1.0 - ratio)).toInt()) else seq
        val nInst = max(1, (padded - seq) / stride + 1)

        val acc = FloatArray(frames * nC)
        val kernel = if (p.gaussianSmoothing) gaussianKernel(k) else null
        val x = FloatArray(seq * nF)
        for (idx in 0 until nInst) {
            val start = stride * idx
            if (start + seq > padded) continue
            val valid = min(seq, max(0, frames - start))
            if (valid <= 0) continue
            for (t in 0 until seq) {
                val src = start + t
                for (b in 0 until nF) {
                    // padding nol di ruang log mentah, lalu dinormalisasi (sama dengan referensi)
                    val v = if (src < frames) feat[src * nF + b] else 0f
                    x[t * nF + b] = (v - mean) / (std + 1e-8f)
                }
            }
            var logits = net.forward(x, seq)
            logits = if (kernel != null) smoothGaussian(logits, seq, nC, kernel) else smoothUniform(logits, seq, nC, k)
            for (t in 0 until valid) {
                val dst = (start + t) * nC
                val srcO = t * nC
                for (c in 0 until nC) acc[dst + c] += logits[srcO + c]
            }
            onProgress((idx + 1f) / nInst)
        }

        val preds = IntArray(frames)
        for (t in 0 until frames) {
            var best = 0
            for (c in 1 until nC) if (acc[t * nC + c] > acc[t * nC + best]) best = c
            preds[t] = best
        }
        return if (p.majorityFilter && frames >= k) majorityFilter(preds, k) else preds
    }

    private fun gaussianKernel(k: Int): FloatArray {
        val sigma = k / 6.0
        val w = DoubleArray(k) { val d = (it - k / 2).toDouble(); exp(-0.5 * (d / sigma) * (d / sigma)) }
        val s = w.sum()
        return FloatArray(k) { (w[it] / s).toFloat() }
    }

    /** F.conv1d dengan padding 'replicate' per kelas (sumbu waktu). */
    private fun smoothGaussian(l: FloatArray, t: Int, c: Int, w: FloatArray): FloatArray {
        val half = w.size / 2
        val out = FloatArray(l.size)
        for (i in 0 until t) for (j in 0 until c) {
            var s = 0f
            for (m in w.indices) {
                val ti = min(max(i + m - half, 0), t - 1)
                s += w[m] * l[ti * c + j]
            }
            out[i * c + j] = s
        }
        return out
    }

    /** F.avg_pool1d(padding=k/2): padding nol, penyebut tetap k (count_include_pad). */
    private fun smoothUniform(l: FloatArray, t: Int, c: Int, k: Int): FloatArray {
        val half = k / 2
        val out = FloatArray(l.size)
        for (i in 0 until t) for (j in 0 until c) {
            var s = 0f
            for (m in -half..half) {
                val ti = i + m
                if (ti in 0 until t) s += l[ti * c + j]
            }
            out[i * c + j] = s / k
        }
        return out
    }

    /** majority_filter_indices() dari repo: padding 'edge', seri -> pilih nilai tengah bila termasuk, else label terkecil. */
    private fun majorityFilter(v: IntArray, k: Int): IntArray {
        val pad = k / 2
        val out = IntArray(v.size)
        val win = IntArray(k)
        for (i in v.indices) {
            for (m in 0 until k) win[m] = v[min(max(i + m - pad, 0), v.size - 1)]
            var maxCount = 0
            for (m in 0 until k) {
                var cnt = 0
                for (q in 0 until k) if (win[q] == win[m]) cnt++
                if (cnt > maxCount) maxCount = cnt
            }
            var centerOk = false
            var smallest = Int.MAX_VALUE
            for (m in 0 until k) {
                var cnt = 0
                for (q in 0 until k) if (win[q] == win[m]) cnt++
                if (cnt == maxCount) {
                    if (win[m] == v[i]) centerOk = true
                    if (win[m] < smallest) smallest = win[m]
                }
            }
            out[i] = if (centerOk) v[i] else smallest
        }
        return out
    }

    private fun timeline(preds: IntArray): List<ChordSegment> {
        if (preds.isEmpty()) return emptyList()
        val out = ArrayList<ChordSegment>()
        var prev = preds[0]
        var start = 0.0
        for (i in 1 until preds.size) {
            if (preds[i] != prev) {
                out.add(ChordSegment(start, i * FRAME_DURATION, labels[prev]))
                start = i * FRAME_DURATION
                prev = preds[i]
            }
        }
        out.add(ChordSegment(start, preds.size * FRAME_DURATION, labels[prev]))
        return out
    }

    companion object {
        const val SAMPLE_RATE = 22050
        const val SEQ_LEN = 108
        const val FRAME_DURATION = 2048.0 / 22050.0

        fun load(input: InputStream): ChordEngine = ChordEngine(LkmFile.read(input))
    }
}
