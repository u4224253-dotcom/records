package com.laykit

import android.content.Context
import android.net.Uri
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.FileInputStream
import java.nio.ByteBuffer

/**
 * Menyimpan data ketukan DI DALAM file rekaman (.mp4), supaya tetap terbaca setelah aplikasi diperbarui, dipasang ulang, atau
 * dipasang dengan tanda tangan berbeda. Folder privat app (`filesDir/touch`) ikut terhapus saat uninstall; file video di
 * Movies/LayKit tidak.
 *
 * Format: satu box MP4 `free` ditambahkan di AKHIR file (box `free` memang dilewati semua pemutar):
 *   [ukuran 4B]["free"][CSV ketukan][MAGIC "LKTOUCH1" 8B][panjang CSV 8B]
 * Pembaca cukup membaca 16 byte terakhir: kalau diawali MAGIC, panjang CSV ada di situ, dan CSV-nya persis di depannya.
 */
object TouchEmbed {
    private val MAGIC = "LKTOUCH1".toByteArray(Charsets.US_ASCII)
    private const val FOOTER = 16
    private const val MAX_PAYLOAD = 8L * 1024 * 1024

    /** Tambahkan data ketukan ke akhir file [uri]. false kalau gagal (misalnya file bukan milik app ini lagi). */
    fun write(ctx: Context, uri: Uri, events: List<TouchEvent>): Boolean {
        if (events.isEmpty()) return false
        return try {
            val payload = TouchLog.encode(events).toByteArray(Charsets.UTF_8)
            val bos = ByteArrayOutputStream(payload.size + 24)
            DataOutputStream(bos).use { d ->
                d.writeInt(8 + payload.size + FOOTER)
                d.write("free".toByteArray(Charsets.US_ASCII))
                d.write(payload)
                d.write(MAGIC)
                d.writeLong(payload.size.toLong())
            }
            val out = ctx.contentResolver.openOutputStream(uri, "wa") ?: return false
            out.use { it.write(bos.toByteArray()) }
            true
        } catch (_: Exception) {
            false
        }
    }

    /** Panjang CSV yang tertanam di [uri] (>0), atau 0 kalau tidak ada. Mengisi [out] dengan isinya kalau diminta. */
    private fun probe(ctx: Context, uri: Uri, readPayload: Boolean, out: Array<ByteArray?>?): Long = try {
        var result = 0L
        ctx.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
            val ch = FileInputStream(pfd.fileDescriptor).channel
            val size = ch.size()
            if (size >= FOOTER) {
                val tail = ByteBuffer.allocate(FOOTER)
                var pos = size - FOOTER
                while (tail.hasRemaining()) {
                    val n = ch.read(tail, pos)
                    if (n <= 0) break
                    pos += n
                }
                if (!tail.hasRemaining()) {
                    tail.flip()
                    val m = ByteArray(8); tail.get(m)
                    val len = tail.getLong()
                    if (m.contentEquals(MAGIC) && len in 1..MAX_PAYLOAD && size - FOOTER - len >= 0) {
                        result = len
                        if (readPayload && out != null) {
                            val buf = ByteBuffer.allocate(len.toInt())
                            var p = size - FOOTER - len
                            while (buf.hasRemaining()) {
                                val n = ch.read(buf, p)
                                if (n <= 0) break
                                p += n
                            }
                            out[0] = buf.array()
                        }
                    }
                }
            }
        }
        result
    } catch (_: Exception) {
        0L
    }

    fun has(ctx: Context, uri: Uri): Boolean = probe(ctx, uri, false, null) > 0L

    /** Data ketukan yang tertanam di [uri]; kosong kalau tidak ada. */
    fun read(ctx: Context, uri: Uri): List<TouchEvent> {
        val box = arrayOfNulls<ByteArray>(1)
        if (probe(ctx, uri, true, box) <= 0L) return emptyList()
        val b = box[0] ?: return emptyList()
        return TouchLog.decode(String(b, Charsets.UTF_8))
    }
}
