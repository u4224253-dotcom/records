package com.laykit.chord

import kotlin.math.ln
import kotlin.math.sqrt

/**
 * Constant-Q Transform ala librosa.cqt (22.050 Hz, hop 2048, 144 bin, 24 bin/oktaf, fmin C1).
 *
 * Basis filter (domain frekuensi, sparse) dihitung sekali di Python dan disimpan di berkas
 * model, jadi di sini hanya perlu: resample rekursif (bagi dua), STFT kotak (tanpa jendela,
 * n_fft = 512), lalu perkalian sparse. Faktor 1/sqrt(panjang filter) sudah dilipat ke basis.
 */
internal class Cqt(lkm: LkmFile) {
    private class Octave(
        val hop: Int,
        val indptr: IntArray,
        val indices: IntArray,
        val re: FloatArray,
        val im: FloatArray,
    )

    private val earlyDownsample: Int
    private val nOctaves: Int
    private val nFft: Int
    private val perOctave: Int
    val nBins: Int
    private val octaves: List<Octave>
    private val fft: Fft

    init {
        val meta = lkm.ints("cqt.meta") // [downsample, n_oktaf, n_fft, bin/oktaf, n_bin]
        earlyDownsample = meta[0]
        nOctaves = meta[1]
        nFft = meta[2]
        perOctave = meta[3]
        nBins = meta[4]
        octaves = List(nOctaves) { i ->
            Octave(
                hop = lkm.ints("cqt.o$i.hop")[0],
                indptr = lkm.ints("cqt.o$i.indptr"),
                indices = lkm.ints("cqt.o$i.indices"),
                re = lkm.tensor("cqt.o$i.re").data,
                im = lkm.tensor("cqt.o$i.im").data,
            )
        }
        for (o in octaves) {
            require(o.indptr.size == perOctave + 1) { "Rencana CQT rusak (indptr)" }
            for (c in o.indices) require(c in 0..nFft / 2) { "Rencana CQT rusak (kolom di luar spektrum)" }
        }
        fft = Fft(nFft)
    }

    /**
     * @param y audio mono 22.050 Hz
     * @return fitur log(|CQT| + 1e-6), bentuk [frame][nBins] diratakan (frame * nBins + bin)
     */
    fun logFeatures(y: FloatArray, onProgress: ((Float) -> Unit)? = null): Pair<FloatArray, Int> {
        val base = if (earlyDownsample > 1) Resampler.resample(y, earlyDownsample, 1, energyScale = true) else y

        // magnitudo per oktaf: [frame][perOctave]
        val mags = ArrayList<FloatArray>(nOctaves)
        val counts = IntArray(nOctaves)
        var cur = base
        for (i in 0 until nOctaves) {
            val o = octaves[i]
            val nFrames = 1 + cur.size / o.hop
            counts[i] = nFrames
            mags.add(octaveMagnitudes(cur, o, nFrames))
            onProgress?.invoke((i + 1f) / nOctaves)
            if (i + 1 < nOctaves) cur = Resampler.halve(cur)
        }

        val frames = counts.min()
        val out = FloatArray(frames * nBins)
        for (i in 0 until nOctaves) {
            val firstBin = nBins - (i + 1) * perOctave
            val m = mags[i]
            for (t in 0 until frames) {
                for (b in 0 until perOctave) {
                    out[t * nBins + firstBin + b] = ln(m[t * perOctave + b] + 1e-6f)
                }
            }
        }
        return out to frames
    }

    /**
     * STFT kotak (center=True, padding nol) lalu proyeksi ke basis sparse; keluaran |respon|.
     * Frame t memakai sampel [t*hop - n_fft/2, t*hop + n_fft/2).
     */
    private fun octaveMagnitudes(sig: FloatArray, o: Octave, nFrames: Int): FloatArray {
        val half = nFft / 2
        val out = FloatArray(nFrames * perOctave)
        val re = FloatArray(nFft)
        val im = FloatArray(nFft)
        val n = sig.size
        for (t in 0 until nFrames) {
            val start = t * o.hop - half
            for (i in 0 until nFft) {
                val idx = start + i
                re[i] = if (idx in 0 until n) sig[idx] else 0f
                im[i] = 0f
            }
            fft.transform(re, im)
            for (r in 0 until perOctave) {
                var ar = 0f
                var ai = 0f
                for (k in o.indptr[r] until o.indptr[r + 1]) {
                    val c = o.indices[k]
                    ar += o.re[k] * re[c] - o.im[k] * im[c]
                    ai += o.re[k] * im[c] + o.im[k] * re[c]
                }
                out[t * perOctave + r] = sqrt(ar * ar + ai * ai)
            }
        }
        return out
    }
}
