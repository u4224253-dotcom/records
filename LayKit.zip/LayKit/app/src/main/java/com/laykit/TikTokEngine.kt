package com.laykit

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.coroutines.coroutineContext

/** Gagal di mesin TikTok; [message] sudah berupa kalimat yang layak ditampilkan ke pengguna. */
class TikTokException(message: String) : Exception(message)

/** Hasil baca link: info video + alamat file video (tanpa watermark) dan audio (musik) bila tersedia. */
data class TikTokInfo(
    val title: String,
    val author: String,
    val durationSec: Int,
    val videoUrl: String?,
    val audioUrl: String?,
    /** header yang harus ikut saat mengunduh (Referer/Cookie untuk jalur langsung ke TikTok). */
    val headers: Map<String, String> = emptyMap(),
)

/**
 * Mesin TikTok Converter. Urutan jalur (lanjut ke berikutnya kalau gagal):
 *  1. tikwm.com (POST), 2. tikwm.com (GET), 3. langsung dari halaman TikTok (JSON di dalam HTML).
 * Hasil diunduh ke MediaStore: Movies/LayKit/TikTok (MP4) dan Music/LayKit/TikTok (MP3),
 * jadi otomatis muncul di perpustakaan LayKit. Tanpa dependensi baru.
 */
object TikTokEngine {

    private const val UA = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    private val URL_RE = Regex("""https?://[^\s]+""")

    /** Ambil link pertama dari teks tempelan (teks "Bagikan" TikTok biasanya berisi caption + link). */
    fun extractUrl(text: String): String? =
        URL_RE.find(text)?.value?.trimEnd('.', ',', ')', '"', '\'', '!')

    fun isTikTokUrl(url: String): Boolean {
        val host = try { URL(url).host.lowercase() } catch (_: Exception) { return false }
        return host == "tiktok.com" || host.endsWith(".tiktok.com")
    }

    suspend fun resolve(input: String): TikTokInfo = withContext(Dispatchers.IO) {
        val url = extractUrl(input) ?: throw TikTokException("Link tidak ditemukan. Tempel link video TikTok.")
        if (!isTikTokUrl(url)) throw TikTokException("Ini bukan link TikTok.")

        val chain: List<Pair<String, () -> TikTokInfo>> = listOf(
            "tikwm" to { viaTikwm(url, post = true) },
            "tikwm2" to { viaTikwm(url, post = false) },
            "langsung" to { viaPage(url) },
        )
        val errors = mutableListOf<String>()
        for ((name, run) in chain) {
            coroutineContext.ensureActive()
            try {
                return@withContext run()
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                errors += "$name: ${(e.message ?: e.javaClass.simpleName).take(70)}"
            }
        }
        throw TikTokException("Gagal membaca video.\n" + errors.joinToString("\n"))
    }

    // ---------- jalur 1 & 2: tikwm.com ----------

    private fun viaTikwm(url: String, post: Boolean): TikTokInfo {
        var json: JSONObject? = null
        var msg = ""
        for (attempt in 0 until 2) {
            val c = if (post) {
                URL("https://www.tikwm.com/api/").openConnection() as HttpURLConnection
            } else {
                URL("https://www.tikwm.com/api/?hd=1&url=" + URLEncoder.encode(url, "UTF-8")).openConnection() as HttpURLConnection
            }
            try {
                c.connectTimeout = 15000; c.readTimeout = 20000
                c.setRequestProperty("User-Agent", UA)
                c.setRequestProperty("Accept", "application/json, text/javascript, */*; q=0.01")
                c.setRequestProperty("Accept-Language", "en-US,en;q=0.9,id;q=0.8")
                c.setRequestProperty("Origin", "https://www.tikwm.com")
                c.setRequestProperty("Referer", "https://www.tikwm.com/")
                c.setRequestProperty("X-Requested-With", "XMLHttpRequest")
                if (post) {
                    c.requestMethod = "POST"; c.doOutput = true
                    c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
                    c.outputStream.use { it.write("url=${URLEncoder.encode(url, "UTF-8")}&count=12&cursor=0&web=1&hd=1".toByteArray()) }
                }
                if (c.responseCode !in 200..299) throw TikTokException("HTTP ${c.responseCode}")
                val j = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                if (j.optInt("code", -1) == 0) { json = j; break }
                msg = j.optString("msg", "gagal")
            } finally {
                c.disconnect()
            }
            if (msg.contains("limit", true) && attempt == 0) Thread.sleep(1300) else break   // batas 1 permintaan/detik
        }
        val data = json?.optJSONObject("data") ?: throw TikTokException(msg.ifBlank { "respons kosong" })

        val video = data.optString("hdplay").ifBlank { data.optString("play") }
        val music = data.optString("music")
        val info = TikTokInfo(
            title = data.optString("title").ifBlank { "Video TikTok" },
            author = data.optJSONObject("author")?.let { it.optString("nickname").ifBlank { it.optString("unique_id") } } ?: "",
            durationSec = data.optInt("duration", 0),
            videoUrl = tikwmUrl(video),
            audioUrl = tikwmUrl(music),
        )
        if (info.videoUrl == null && info.audioUrl == null) throw TikTokException("tidak ada video/audio (slideshow foto?)")
        return info
    }

    private fun tikwmUrl(u: String?): String? = when {
        u.isNullOrBlank() -> null
        u.startsWith("//") -> "https:$u"
        u.startsWith("/") -> "https://www.tikwm.com$u"
        else -> u
    }

    // ---------- jalur 3: langsung dari halaman TikTok ----------

    private fun viaPage(startUrl: String): TikTokInfo {
        val cookies = LinkedHashMap<String, String>()
        var cur = startUrl
        var html = ""
        for (hop in 0 until 6) {
            val c = URL(cur).openConnection() as HttpURLConnection
            try {
                c.instanceFollowRedirects = false
                c.connectTimeout = 15000; c.readTimeout = 20000
                c.setRequestProperty("User-Agent", UA)
                c.setRequestProperty("Accept", "text/html,application/xhtml+xml,*/*;q=0.8")
                c.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
                if (cookies.isNotEmpty()) c.setRequestProperty("Cookie", cookies.entries.joinToString("; ") { "${it.key}=${it.value}" })
                val code = c.responseCode
                c.headerFields["Set-Cookie"]?.forEach { line ->
                    val kv = line.substringBefore(';'); val i = kv.indexOf('=')
                    if (i > 0) cookies[kv.substring(0, i).trim()] = kv.substring(i + 1).trim()
                }
                if (code in 300..399) {
                    val loc = c.getHeaderField("Location") ?: throw TikTokException("redirect tanpa tujuan")
                    cur = URL(URL(cur), loc).toString()
                    continue
                }
                if (code !in 200..299) throw TikTokException("HTTP $code")
                html = c.inputStream.bufferedReader().use { it.readText() }
                break
            } finally {
                c.disconnect()
            }
        }
        if (html.isEmpty()) throw TikTokException("halaman kosong")

        val m = Regex("""id="__UNIVERSAL_DATA_FOR_REHYDRATION__"[^>]*>(.*?)</script>""", RegexOption.DOT_MATCHES_ALL).find(html)
            ?: throw TikTokException("data video tidak ada di halaman")
        val scope = JSONObject(m.groupValues[1]).optJSONObject("__DEFAULT_SCOPE__") ?: throw TikTokException("format halaman berubah")
        val detail = scope.optJSONObject("webapp.video-detail") ?: throw TikTokException("format halaman berubah")
        val item = detail.optJSONObject("itemInfo")?.optJSONObject("itemStruct")
            ?: throw TikTokException(detail.optString("statusMsg").ifBlank { "video tidak ditemukan / privat" })

        val video = item.optJSONObject("video")
        val music = item.optJSONObject("music")
        var vUrl = video?.optString("playAddr").orEmpty()
        if (vUrl.isBlank()) {   // cadangan: daftar bitrate
            vUrl = video?.optJSONArray("bitrateInfo")?.optJSONObject(0)?.optJSONObject("PlayAddr")
                ?.optJSONArray("UrlList")?.optString(0).orEmpty()
        }
        val aUrl = music?.optString("playUrl").orEmpty()
        if (vUrl.isBlank() && aUrl.isBlank()) throw TikTokException("tidak ada video/audio (slideshow foto?)")

        val hdr = mutableMapOf("Referer" to "https://www.tiktok.com/")
        if (cookies.isNotEmpty()) hdr["Cookie"] = cookies.entries.joinToString("; ") { "${it.key}=${it.value}" }
        return TikTokInfo(
            title = item.optString("desc").ifBlank { "Video TikTok" },
            author = item.optJSONObject("author")?.let { it.optString("nickname").ifBlank { it.optString("uniqueId") } } ?: "",
            durationSec = video?.optInt("duration", 0) ?: 0,
            videoUrl = vUrl.ifBlank { null },
            audioUrl = aUrl.ifBlank { null },
            headers = hdr,
        )
    }

    // ---------- unduh ke MediaStore ----------

    /**
     * Unduh [url] ke MediaStore. [audio] = true -> MP3 di Music/LayKit/TikTok, selain itu MP4 di Movies/LayKit/TikTok.
     * [onProgress] 0..1 (tidak dipanggil kalau server tidak memberi ukuran file). Bisa dibatalkan lewat coroutine.
     */
    suspend fun save(
        ctx: Context, url: String, audio: Boolean, title: String,
        headers: Map<String, String> = emptyMap(), onProgress: (Float) -> Unit,
    ): Uri = withContext(Dispatchers.IO) {
        val resolver = ctx.contentResolver
        val base = if (audio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val clean = title.replace(Regex("[^A-Za-z0-9 _-]"), "").trim().take(40).ifBlank { System.currentTimeMillis().toString() }
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "TikTok_$clean" + if (audio) ".mp3" else ".mp4")
            put(MediaStore.MediaColumns.MIME_TYPE, if (audio) "audio/mpeg" else "video/mp4")
            put(
                MediaStore.MediaColumns.RELATIVE_PATH,
                (if (audio) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES) + "/LayKit/TikTok",
            )
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = resolver.insert(base, cv) ?: throw TikTokException("Tidak bisa membuat file di penyimpanan.")
        try {
            val c = URL(url).openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 15000; c.readTimeout = 30000
                c.setRequestProperty("User-Agent", UA)
                headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
                if (c.responseCode !in 200..299) throw TikTokException("Unduhan gagal (HTTP ${c.responseCode}).")
                val total = c.contentLengthLong
                var done = 0L
                c.inputStream.use { input ->
                    resolver.openOutputStream(uri)!!.use { out ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            coroutineContext.ensureActive()
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            if (total > 0) onProgress((done.toFloat() / total).coerceIn(0f, 1f))
                        }
                    }
                }
                if (done == 0L) throw TikTokException("File kosong dari server.")
            } finally {
                c.disconnect()
            }
            resolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            uri
        } catch (e: Throwable) {
            try { resolver.delete(uri, null, null) } catch (_: Exception) {}   // buang file setengah jadi
            if (e is TikTokException || e is kotlinx.coroutines.CancellationException) throw e
            throw TikTokException("Unduhan terputus. Coba lagi.")
        }
    }
}
