package com.laykit

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.coroutines.coroutineContext

/** Gagal di mesin TikTok; [message] sudah berupa kalimat yang layak ditampilkan ke pengguna. */
class TikTokException(message: String) : Exception(message)

/** Hasil baca link: info video + alamat file video (tanpa watermark) dan audio (musik) bila tersedia. */
data class TikTokInfo(
    val title: String,
    val author: String,
    val coverUrl: String?,
    val durationSec: Int,
    val videoUrl: String?,
    val audioUrl: String?,
    val audioTitle: String,
)

/**
 * Mesin TikTok Converter: link TikTok -> info (lewat API tikwm.com) -> unduh video MP4 / audio MP3
 * langsung ke MediaStore (Movies/LayKit/TikTok dan Music/LayKit/TikTok), jadi otomatis muncul di perpustakaan LayKit.
 * Tanpa dependensi baru: HttpURLConnection + org.json bawaan Android.
 */
object TikTokEngine {

    private const val API = "https://www.tikwm.com/api/"
    private const val UA = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
    private val URL_RE = Regex("""https?://[^\s]+""")

    /** Ambil link pertama dari teks tempelan (teks "Bagikan" TikTok biasanya berisi caption + link). */
    fun extractUrl(text: String): String? =
        URL_RE.find(text)?.value?.trimEnd('.', ',', ')', '"', '\'', '!')

    fun isTikTokUrl(url: String): Boolean {
        val host = try { URL(url).host.lowercase() } catch (_: Exception) { return false }
        return host == "tiktok.com" || host.endsWith(".tiktok.com")
    }

    /** Baca link TikTok (termasuk link pendek vm./vt.tiktok.com) dan kembalikan info + alamat unduhan. */
    suspend fun resolve(input: String): TikTokInfo = withContext(Dispatchers.IO) {
        val url = extractUrl(input) ?: throw TikTokException("Link tidak ditemukan. Tempel link video TikTok.")
        if (!isTikTokUrl(url)) throw TikTokException("Ini bukan link TikTok.")

        var json: JSONObject? = null
        var lastMsg = "Gagal membaca video"
        for (attempt in 0 until 3) {
            val j = try { post(url) } catch (e: TikTokException) { throw e } catch (e: Exception) {
                throw TikTokException("Tidak bisa terhubung. Cek koneksi internet.")
            }
            if (j.optInt("code", -1) == 0) { json = j; break }
            lastMsg = j.optString("msg", lastMsg)
            // API gratis dibatasi 1 permintaan/detik: tunggu sebentar lalu coba lagi; error lain langsung berhenti
            if (lastMsg.contains("limit", true) && attempt < 2) delay(1300) else break
        }
        val data = json?.optJSONObject("data") ?: throw TikTokException(friendly(lastMsg))

        val video = data.optString("hdplay").ifBlank { data.optString("play") }.ifBlank { null }
        val music = data.optString("music").ifBlank { null }
        if (video == null && music == null) {
            throw TikTokException("Postingan ini tidak punya video/audio yang bisa diunduh (mungkin slideshow foto).")
        }
        val mi = data.optJSONObject("music_info")
        TikTokInfo(
            title = data.optString("title").ifBlank { "Video TikTok" },
            author = data.optJSONObject("author")?.let { it.optString("nickname").ifBlank { it.optString("unique_id") } } ?: "",
            coverUrl = abs(data.optString("cover")),
            durationSec = data.optInt("duration", 0),
            videoUrl = abs(video),
            audioUrl = abs(music),
            audioTitle = mi?.optString("title").orEmpty(),
        )
    }

    private fun abs(u: String?): String? = when {
        u.isNullOrBlank() -> null
        u.startsWith("//") -> "https:$u"
        u.startsWith("/") -> "https://www.tikwm.com$u"
        else -> u
    }

    private fun friendly(msg: String): String = when {
        msg.contains("limit", true) -> "Server sedang sibuk. Coba lagi sebentar."
        msg.contains("private", true) || msg.contains("not exist", true) || msg.contains("removed", true) ->
            "Video tidak ditemukan atau bersifat privat."
        msg.contains("url", true) -> "Link tidak valid."
        else -> "Gagal membaca video: $msg"
    }

    private fun post(tiktokUrl: String): JSONObject {
        val c = URL(API).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000; c.readTimeout = 20000
            c.doOutput = true
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
            c.outputStream.use { it.write("url=${URLEncoder.encode(tiktokUrl, "UTF-8")}&hd=1".toByteArray()) }
            if (c.responseCode !in 200..299) throw TikTokException("Server TikTok converter error (${c.responseCode}).")
            return JSONObject(c.inputStream.bufferedReader().use { it.readText() })
        } finally {
            c.disconnect()
        }
    }

    /** Unduh gambar sampul untuk pratinjau; null kalau gagal (pratinjau opsional). */
    suspend fun loadCover(url: String): Bitmap? = withContext(Dispatchers.IO) {
        try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 10000; c.readTimeout = 10000
            c.setRequestProperty("User-Agent", UA)
            c.inputStream.use { BitmapFactory.decodeStream(it) }
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Unduh [url] ke MediaStore. [audio] = true -> MP3 di Music/LayKit/TikTok, selain itu MP4 di Movies/LayKit/TikTok.
     * [onProgress] 0..1 (tetap 0 kalau server tidak memberi ukuran file). Bisa dibatalkan lewat coroutine.
     */
    suspend fun save(ctx: Context, url: String, audio: Boolean, title: String, onProgress: (Float) -> Unit): Uri =
        withContext(Dispatchers.IO) {
            val resolver = ctx.contentResolver
            val base = if (audio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            val clean = title.replace(Regex("[^A-Za-z0-9 _-]"), "").trim().take(40).ifBlank { System.currentTimeMillis().toString() }
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, "TikTok_$clean" + if (audio) ".mp3" else ".mp4")
                put(MediaStore.MediaColumns.MIME_TYPE, if (audio) "audio/mpeg" else "video/mp4")
                put(
                    MediaStore.MediaColumns.RELATIVE_PATH,
                    (if (audio) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES) + "/LayKit/TikTok",
                )
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = resolver.insert(base, cv) ?: throw TikTokException("Tidak bisa membuat file di penyimpanan.")
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                try {
                    c.connectTimeout = 15000; c.readTimeout = 30000
                    c.setRequestProperty("User-Agent", UA)
                    if (c.responseCode !in 200..299) throw TikTokException("Unduhan gagal (${c.responseCode}).")
                    val total = c.contentLengthLong
                    var done = 0L
                    c.inputStream.use { input ->
                        resolver.openOutputStream(uri)!!.use { out ->
                            val buf = ByteArray(64 * 1024)
                            while (true) {
                                coroutineContext.ensureActive()
                                val n = input.read(buf)
                                if (n < 0) break
                                out.write(buf, 0, n)
                                done += n
                                if (total > 0) onProgress((done.toFloat() / total).coerceIn(0f, 1f))
                            }
                        }
                    }
                    if (done == 0L) throw TikTokException("File kosong dari server.")
                } finally {
                    c.disconnect()
                }
                resolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
                uri
            } catch (e: Throwable) {
                try { resolver.delete(uri, null, null) } catch (_: Exception) {}   // buang file setengah jadi
                if (e is TikTokException || e is kotlinx.coroutines.CancellationException) throw e
                throw TikTokException("Unduhan terputus. Coba lagi.")
            }
        }
}
