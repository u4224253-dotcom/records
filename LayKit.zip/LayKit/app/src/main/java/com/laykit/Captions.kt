package com.laykit

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Environment
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Satu baris caption. Waktu dalam milidetik pada waktu video SUMBER (sama dengan blok zoom), bukan waktu hasil potong. */
data class CaptionSeg(val startMs: Long, val endMs: Long, val text: String)

internal object Captions {
    private const val SIZE_MIN = 0.030f   // ukuran huruf = fraksi sisi terpendek kanvas, slider Ukuran 0..1
    private const val SIZE_MAX = 0.075f
    private const val BAND_FRAC = 0.36f   // tinggi pita caption di dasar kanvas, fraksi sisi terpendek

    /** Tinggi pita caption (px) untuk kanvas [canvasW] x [canvasH]. Pratinjau dan ekspor memakai angka yang sama. */
    fun bandHeight(canvasW: Int, canvasH: Int): Int = max(16, (min(canvasW, canvasH) * BAND_FRAC).roundToInt())

    /** Baris caption yang tampil pada [tMs], atau null. [list] harus terurut menurut awal dan tidak tumpang tindih. */
    fun at(list: List<CaptionSeg>, tMs: Long): CaptionSeg? {
        var lo = 0
        var hi = list.size - 1
        var found = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (list[mid].startMs <= tMs) { found = mid; lo = mid + 1 } else hi = mid - 1
        }
        if (found < 0) return null
        val s = list[found]
        return if (tMs < s.endMs) s else null
    }

    /**
     * Gambar satu baris caption ke bitmap selebar kanvas dan setinggi [bandHeight] (transparan di luar kotak teks), teks di
     * dasar pita. Datar: kotak hitam solid agak transparan + teks putih tebal, tanpa bayangan. Dipakai apa adanya oleh
     * pratinjau (digambar di atas kanvas) dan ekspor (tekstur GL), jadi keduanya identik.
     */
    fun renderBand(text: String, canvasW: Int, canvasH: Int, size: Float): Bitmap {
        val w = max(1, canvasW)
        val bandH = bandHeight(canvasW, canvasH)
        val bmp = Bitmap.createBitmap(w, bandH, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val short = min(canvasW, canvasH).toFloat()
        val textPx = short * (SIZE_MIN + (SIZE_MAX - SIZE_MIN) * size.coerceIn(0f, 1f))
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = textPx
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val padX = textPx * 0.6f
        val padY = textPx * 0.35f
        val textW = max(1, (w * 0.9f - 2f * padX).toInt())
        val layout = StaticLayout.Builder.obtain(text, 0, text.length, tp, textW)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setMaxLines(3)
            .setIncludePad(false)
            .build()
        var lineMax = 0f
        for (i in 0 until layout.lineCount) lineMax = max(lineMax, layout.getLineWidth(i))
        val boxW = lineMax + 2f * padX
        val boxH = layout.height + 2f * padY
        val left = (w - boxW) / 2f
        val top = max(0f, bandH - short * 0.05f - boxH)
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xB3000000.toInt() }
        c.drawRoundRect(RectF(left, top, left + boxW, top + boxH), textPx * 0.4f, textPx * 0.4f, bg)
        c.save()
        c.translate((w - textW) / 2f, top + padY)
        layout.draw(c)
        c.restore()
        return bmp
    }

    /**
     * Teks SRT untuk rentang [fromMs]..[toMs] waktu sumber; waktu digeser supaya mulai dari 0 (sama dengan video hasil potong).
     */
    fun srt(list: List<CaptionSeg>, fromMs: Long = 0L, toMs: Long = Long.MAX_VALUE): String {
        val sb = StringBuilder()
        var n = 0
        for (s in list) {
            if (s.endMs <= fromMs || s.startMs >= toMs) continue
            val a = max(s.startMs, fromMs) - fromMs
            val b = min(s.endMs, toMs) - fromMs
            if (b <= a) continue
            n++
            sb.append(n).append('\n')
                .append(stamp(a)).append(" --> ").append(stamp(b)).append('\n')
                .append(s.text).append("\n\n")
        }
        return sb.toString()
    }

    private fun stamp(ms: Long): String =
        String.format(Locale.US, "%02d:%02d:%02d,%03d", ms / 3_600_000, ms / 60_000 % 60, ms / 1000 % 60, ms % 1000)

    /** Simpan [text] sebagai berkas .srt di Download/LayKit. Mengembalikan true kalau berhasil. */
    fun saveSrt(ctx: Context, baseName: String, text: String): Boolean {
        return try {
            val safe = baseName.replace(Regex("[^A-Za-z0-9 _.-]"), "_").ifBlank { "caption" }
            val cv = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, "$safe.srt")
                put(MediaStore.Downloads.MIME_TYPE, "application/x-subrip")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/LayKit")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val r = ctx.contentResolver
            val uri = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: return false
            val wrote = r.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)); true } ?: false
            if (!wrote) { try { r.delete(uri, null, null) } catch (_: Exception) {}; return false }
            val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
            r.update(uri, done, null, null)
            true
        } catch (_: Exception) {
            false
        }
    }
}

/** Cache kecil bitmap caption untuk pratinjau, supaya teks yang sama tidak digambar ulang tiap frame. */
internal class CaptionBitmapCache {
    private val map = object : LinkedHashMap<String, Bitmap>(8, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Bitmap>?): Boolean = size > 6
    }

    fun get(text: String, w: Int, h: Int, size: Float): Bitmap {
        val key = "$w x $h|${(size * 1000).toInt()}|$text"
        return map.getOrPut(key) { Captions.renderBand(text, w, h, size) }
    }
}
