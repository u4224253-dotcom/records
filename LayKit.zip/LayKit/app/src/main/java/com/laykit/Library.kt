package com.laykit

import android.app.RecoverableSecurityException
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.IntentSender
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Size

data class RecItem(val uri: Uri, val name: String, val durationMs: Long, val sizeBytes: Long)

/** Hasil menghapus rekaman. [Confirm] = file bukan milik app ini (mis. setelah pasang ulang): sistem minta izin pengguna. */
sealed class DeleteOutcome {
    object Done : DeleteOutcome()
    object Failed : DeleteOutcome()
    class Confirm(val sender: IntentSender) : DeleteOutcome()
}

object Library {

    /**
     * Hapus rekaman dari MediaStore beserta data ketukannya. File yang dibuat app ini bisa langsung dihapus;
     * kalau bukan milik app ini, kembalikan [DeleteOutcome.Confirm] berisi dialog izin dari sistem.
     */
    fun delete(ctx: Context, uri: Uri): DeleteOutcome {
        val name = nameOf(ctx, uri)
        return try {
            if (ctx.contentResolver.delete(uri, null, null) > 0) {
                if (name != null) TouchLog.delete(ctx.filesDir, name)
                DeleteOutcome.Done
            } else {
                DeleteOutcome.Failed
            }
        } catch (e: SecurityException) {
            val sender = when {
                Build.VERSION.SDK_INT >= 30 -> MediaStore.createDeleteRequest(ctx.contentResolver, listOf(uri)).intentSender
                e is RecoverableSecurityException -> e.userAction.actionIntent.intentSender
                else -> null
            }
            if (sender != null) DeleteOutcome.Confirm(sender) else DeleteOutcome.Failed
        } catch (_: Exception) {
            DeleteOutcome.Failed
        }
    }

    /** Semua video di Movies/LayKit, terbaru dulu. */
    fun list(ctx: Context, limit: Int = 50): List<RecItem> {
        val out = mutableListOf<RecItem>()
        val proj = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
        )
        val sel = "${MediaStore.Video.Media.RELATIVE_PATH} LIKE ? AND ${MediaStore.Video.Media.IS_PENDING} = 0"
        try {
            ctx.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI, proj, sel,
                arrayOf("Movies/LayKit%"), "${MediaStore.Video.Media.DATE_ADDED} DESC",
            )?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val iName = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val iDur = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val iSize = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                while (c.moveToNext() && out.size < limit) {
                    out += RecItem(
                        uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, c.getLong(iId)),
                        name = c.getString(iName) ?: "video.mp4",
                        durationMs = c.getLong(iDur),
                        sizeBytes = c.getLong(iSize),
                    )
                }
            }
        } catch (_: Exception) {
            // izin belum diberikan: daftar kosong
        }
        return out
    }

    /** Nama file (DISPLAY_NAME) dari Uri MediaStore; dipakai untuk mencari data sentuhan rekaman itu. */
    fun nameOf(ctx: Context, uri: Uri): String? = try {
        ctx.contentResolver.query(uri, arrayOf(MediaStore.Video.Media.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (_: Exception) {
        null
    }

    fun thumbnail(ctx: Context, uri: Uri): Bitmap? = try {
        ctx.contentResolver.loadThumbnail(uri, Size(320, 320), null)
    } catch (_: Exception) {
        null
    }

    fun share(ctx: Context, uri: Uri) {
        val send = Intent(Intent.ACTION_SEND)
            .setType("video/mp4")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(send, "Bagikan video").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun fmtTime(ms: Long): String {
        val s = (ms / 1000).toInt()
        return "%02d:%02d".format(s / 60, s % 60)
    }
}
