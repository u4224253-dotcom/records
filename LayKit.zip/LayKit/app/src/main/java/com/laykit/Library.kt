package com.laykit

import android.app.RecoverableSecurityException
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.IntentSender
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Size

data class RecItem(
    val uri: Uri, val name: String, val durationMs: Long, val sizeBytes: Long,
    val isAudio: Boolean = false, val addedSec: Long = 0,
)

/** Hasil menghapus rekaman. [Confirm] = file bukan milik app ini (mis. setelah pasang ulang): sistem minta izin pengguna. */
sealed class DeleteOutcome {
    object Done : DeleteOutcome()
    object Failed : DeleteOutcome()
    class Confirm(val sender: IntentSender) : DeleteOutcome()
}

object Library {

    /**
     * Hapus rekaman dari MediaStore beserta data ketukannya. File yang dibuat app ini bisa langsung dihapus;
     * kalau bukan milik app ini, kembalikan [DeleteOutcome.Confirm] berisi dialog izin dari sistem.
     */
    fun delete(ctx: Context, uri: Uri): DeleteOutcome {
        val name = nameOf(ctx, uri)
        return try {
            if (ctx.contentResolver.delete(uri, null, null) > 0) {
                if (name != null) TouchLog.delete(ctx.filesDir, name)
                DeleteOutcome.Done
            } else {
                DeleteOutcome.Failed
            }
        } catch (e: SecurityException) {
            val sender = when {
                Build.VERSION.SDK_INT >= 30 -> MediaStore.createDeleteRequest(ctx.contentResolver, listOf(uri)).intentSender
                e is RecoverableSecurityException -> e.userAction.actionIntent.intentSender
                else -> null
            }
            if (sender != null) DeleteOutcome.Confirm(sender) else DeleteOutcome.Failed
        } catch (_: Exception) {
            DeleteOutcome.Failed
        }
    }

    /** Semua video di Movies/LayKit, terbaru dulu. */
    fun list(ctx: Context, limit: Int = 50): List<RecItem> =
        query(ctx, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "Movies/LayKit%", false, limit)

    /** Semua rekaman audio (.mp3) di Music/LayKit, terbaru dulu. */
    fun listAudio(ctx: Context, limit: Int = 50): List<RecItem> =
        query(ctx, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, "Music/LayKit%", true, limit)

    /** Video + audio digabung, terbaru dulu. */
    fun listAll(ctx: Context, limit: Int = 50): List<RecItem> =
        (list(ctx, limit) + listAudio(ctx, limit)).sortedByDescending { it.addedSec }.take(limit)

    private fun query(ctx: Context, base: Uri, path: String, audio: Boolean, limit: Int): List<RecItem> {
        val out = mutableListOf<RecItem>()
        val proj = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.DURATION,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_ADDED,
        )
        val sel = "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ? AND ${MediaStore.MediaColumns.IS_PENDING} = 0"
        try {
            ctx.contentResolver.query(base, proj, sel, arrayOf(path), "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val iName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val iDur = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DURATION)
                val iSize = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
                val iAdd = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                while (c.moveToNext() && out.size < limit) {
                    out += RecItem(
                        uri = ContentUris.withAppendedId(base, c.getLong(iId)),
                        name = c.getString(iName) ?: if (audio) "audio.mp3" else "video.mp4",
                        durationMs = c.getLong(iDur),
                        sizeBytes = c.getLong(iSize),
                        isAudio = audio,
                        addedSec = c.getLong(iAdd),
                    )
                }
            }
        } catch (_: Exception) {
            // izin belum diberikan: daftar kosong
        }
        return out
    }

    /** Nama file (DISPLAY_NAME) dari Uri MediaStore; dipakai untuk mencari data sentuhan rekaman itu. */
    fun nameOf(ctx: Context, uri: Uri): String? = try {
        ctx.contentResolver.query(uri, arrayOf(MediaStore.Video.Media.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (_: Exception) {
        null
    }

    fun thumbnail(ctx: Context, uri: Uri): Bitmap? = try {
        ctx.contentResolver.loadThumbnail(uri, Size(320, 320), null)
    } catch (_: Exception) {
        null
    }

    fun share(ctx: Context, uri: Uri) {
        val send = Intent(Intent.ACTION_SEND)
            .setType(ctx.contentResolver.getType(uri) ?: "video/mp4")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(send, "Bagikan rekaman").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Putar rekaman audio dengan pemutar musik bawaan HP. */
    fun play(ctx: Context, uri: Uri) {
        try {
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, "audio/mpeg")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        } catch (_: Exception) {
            android.widget.Toast.makeText(ctx, "Tidak ada aplikasi pemutar audio", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    fun fmtTime(ms: Long): String {
        val s = (ms / 1000).toInt()
        return "%02d:%02d".format(s / 60, s % 60)
    }
}
