package com.laykit

import kotlin.math.max
import kotlin.math.min

/**
 * Filter warna ("Efek") dan vignette. Satu model dipakai SAMA oleh pratinjau dan ekspor:
 *
 *  - Filter = transformasi warna affine per piksel `rgb' = clamp(M * rgb + o)`, disimpan sebagai 12 angka (baris-mayor, 3 baris x [r g b o]),
 *    dalam skala 0..1 pada nilai sRGB (gamma) video. Pratinjau: [colorMatrix20] -> ColorMatrixColorFilter pada layer TextureView.
 *    Ekspor: tiga uniform vec4 di shader (uLk0..uLk2). Keduanya bekerja pada nilai gamma yang sama, jadi hasilnya identik.
 *  - Vignette = gelap radial: `rgb *= 1 - amt * VIG_MAX * smoothstep(VIG_START, 1, r)`, r = jarak dari pusat kartu / setengah diagonal kartu.
 *    Pratinjau: gradien radial di atas video ([vigAlpha]); ekspor: rumus yang sama di shader.
 *
 *  - Glow (bloom) = cahaya terang video disebar lalu ditambahkan balik dengan mode Screen:
 *    `g = blur(clamp((rgb - T) / (1 - T)))`, `rgb' = 1 - (1 - rgb) * (1 - amt * g)`. Blur = Gaussian (sigma = [glowSigmaFrac] x sisi terpendek kartu).
 *    Pratinjau (semua versi Android): gambar video kecil diambil dari TextureView, diberi filter + ambang + blur di CPU ([glowPreview]),
 *    diperbesar dan di-Screen di atas video dengan alpha = amt. Ekspor: 40 tap Gaussian di shader. Glow tetap di dalam bingkai video.
 *
 * Semua rumus di sini matematika warna standar (bobot luma Rec.709, gain per kanal, kontras di sekitar abu-abu tengah), ditulis sendiri.
 */
object Looks {
    class Preset(val name: String, val m: FloatArray)

    val ID = floatArrayOf(1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f, 0f)

    private const val LR = 0.2126f
    private const val LG = 0.7152f
    private const val LB = 0.0722f

    /** Hasil menerapkan [b] dulu, lalu [a]. */
    private fun mul(a: FloatArray, b: FloatArray): FloatArray {
        val r = FloatArray(12)
        for (i in 0 until 3) {
            for (j in 0 until 3) {
                var s = 0f
                for (k in 0 until 3) s += a[i * 4 + k] * b[k * 4 + j]
                r[i * 4 + j] = s
            }
            var o = a[i * 4 + 3]
            for (k in 0 until 3) o += a[i * 4 + k] * b[k * 4 + 3]
            r[i * 4 + 3] = o
        }
        return r
    }

    /** Terapkan berurutan: argumen pertama dulu. */
    private fun chain(vararg ms: FloatArray): FloatArray = ms.fold(ID) { acc, m -> mul(m, acc) }

    private fun sat(s: Float): FloatArray {
        val w = floatArrayOf(LR, LG, LB)
        val r = FloatArray(12)
        for (i in 0 until 3) for (j in 0 until 3) r[i * 4 + j] = w[j] * (1f - s) + (if (i == j) s else 0f)
        return r
    }

    private fun contrast(c: Float): FloatArray {
        val o = 0.5f * (1f - c)
        return floatArrayOf(c, 0f, 0f, o, 0f, c, 0f, o, 0f, 0f, c, o)
    }

    private fun gain(r: Float, g: Float, b: Float) = floatArrayOf(r, 0f, 0f, 0f, 0f, g, 0f, 0f, 0f, 0f, b, 0f)

    private fun lift(o: Float) = floatArrayOf(1f, 0f, 0f, o, 0f, 1f, 0f, o, 0f, 0f, 1f, o)

    val presets: List<Preset> = listOf(
        Preset("Asli", ID),
        Preset("Hangat", chain(gain(1.07f, 1.00f, 0.90f), sat(1.05f))),
        Preset("Dingin", chain(gain(0.91f, 0.99f, 1.08f), sat(1.03f))),
        Preset("Vivid", chain(sat(1.40f), contrast(1.10f))),
        Preset("Noir", chain(sat(0f), contrast(1.30f), lift(-0.02f))),
        Preset("Bleach", chain(sat(0.50f), contrast(1.35f))),
        Preset("Golden Hour", chain(gain(1.12f, 1.03f, 0.84f), sat(1.12f), lift(0.015f))),
        Preset("Vintage", chain(sat(0.72f), gain(1.05f, 1.00f, 0.88f), contrast(0.88f), lift(0.03f))),
    )

    /** Matriks 12 angka untuk filter [look] pada intensitas [amt] (0..1, dicampur dengan identitas). null = tanpa filter. */
    fun matrix(look: Int, amt: Float): FloatArray? {
        val a = amt.coerceIn(0f, 1f)
        if (look <= 0 || look >= presets.size || a <= 0f) return null
        val p = presets[look].m
        return FloatArray(12) { ID[it] + (p[it] - ID[it]) * a }
    }

    /** Matriks 4x5 Android ColorMatrix (baris-mayor, offset dalam skala 0..255) dari matriks 12 angka. */
    fun colorMatrix20(m: FloatArray): FloatArray = floatArrayOf(
        m[0], m[1], m[2], 0f, m[3] * 255f,
        m[4], m[5], m[6], 0f, m[7] * 255f,
        m[8], m[9], m[10], 0f, m[11] * 255f,
        0f, 0f, 0f, 1f, 0f,
    )

    const val VIG_START = 0.35f
    const val VIG_MAX = 0.8f

    private fun smooth(e0: Float, e1: Float, x: Float): Float {
        val t = min(1f, max(0f, (x - e0) / (e1 - e0)))
        return t * t * (3f - 2f * t)
    }

    /** Alpha hitam vignette pada jarak relatif [r] (0 = pusat kartu, 1 = sudut) untuk jumlah [amt]. Sama dengan shader ekspor. */
    fun vigAlpha(r: Float, amt: Float): Float = amt.coerceIn(0f, 1f) * VIG_MAX * smooth(VIG_START, 1f, r)

    /** Ambang glow: bagian video yang lebih terang dari ini yang ikut menyebar cahayanya. */
    const val GLOW_THRESHOLD = 0.5f

    /** Sigma blur glow sebagai pecahan sisi terpendek kartu video, untuk ukuran [size] 0..1. */
    fun glowSigmaFrac(size: Float): Float = 0.006f + 0.034f * size.coerceIn(0f, 1f)

    /** Matriks warna 4x5 ambang glow: `rgb' = clamp((rgb - T) / (1 - T))` per kanal. Dipakai pratinjau; shader ekspor memakai rumus yang sama. */
    fun glowThresholdMatrix(): FloatArray {
        val k = 1f / (1f - GLOW_THRESHOLD)
        val o = -GLOW_THRESHOLD * k * 255f
        return floatArrayOf(
            k, 0f, 0f, 0f, o,
            0f, k, 0f, 0f, o,
            0f, 0f, k, 0f, o,
            0f, 0f, 0f, 1f, 0f,
        )
    }

    /**
     * Glow pratinjau di semua versi Android: [px] (ARGB, [w] x [h], gambar video kecil) diberi filter warna [m] (12 angka, lihat [matrix]),
     * ambang glow, lalu blur kotak 3x3 dua kali (sigma kira-kira 1,15 piksel gambar kecil), dan ditulis kembali dengan alpha penuh.
     * Gambar kecil itu lalu diperbesar dengan filter bilinear dan di-Screen di atas video, jadi sigma akhir = 1,15 x (lebar kartu / [w]).
     */
    fun glowPreview(px: IntArray, w: Int, h: Int, m: FloatArray) {
        val n = w * h
        val k = 1f / (1f - GLOW_THRESHOLD)
        var a = FloatArray(n * 3)
        for (i in 0 until n) {
            val c = px[i]
            val r = ((c shr 16) and 0xFF) / 255f
            val g = ((c shr 8) and 0xFF) / 255f
            val b = (c and 0xFF) / 255f
            for (ch in 0 until 3) {
                val v = (m[ch * 4] * r + m[ch * 4 + 1] * g + m[ch * 4 + 2] * b + m[ch * 4 + 3]).coerceIn(0f, 1f)
                a[i * 3 + ch] = ((v - GLOW_THRESHOLD) * k).coerceIn(0f, 1f)
            }
        }
        var t = FloatArray(n * 3)
        repeat(2) {
            // horizontal: a -> t
            for (y in 0 until h) for (x in 0 until w) {
                val x0 = max(x - 1, 0); val x1 = min(x + 1, w - 1)
                for (ch in 0 until 3) t[(y * w + x) * 3 + ch] = (a[(y * w + x0) * 3 + ch] + a[(y * w + x) * 3 + ch] + a[(y * w + x1) * 3 + ch]) / 3f
            }
            // vertikal: t -> a
            for (y in 0 until h) for (x in 0 until w) {
                val y0 = max(y - 1, 0); val y1 = min(y + 1, h - 1)
                for (ch in 0 until 3) a[(y * w + x) * 3 + ch] = (t[(y0 * w + x) * 3 + ch] + t[(y * w + x) * 3 + ch] + t[(y1 * w + x) * 3 + ch]) / 3f
            }
        }
        for (i in 0 until n) {
            val r = (a[i * 3] * 255f + 0.5f).toInt().coerceIn(0, 255)
            val g = (a[i * 3 + 1] * 255f + 0.5f).toInt().coerceIn(0, 255)
            val b = (a[i * 3 + 2] * 255f + 0.5f).toInt().coerceIn(0, 255)
            px[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }
    }
}
