package com.laykit

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.net.Uri
import android.provider.MediaStore
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

/**
 * Rekam audio saja -> file .mp3 di Music/LayKit.
 * Sumber: audio internal (butuh [projection]) dan/atau mikrofon, dicampur jadi satu.
 * Pipeline: AudioRecord (PCM 16-bit stereo) -> mix -> LAME -> MediaStore.
 */
class AudioRecorder(
    private val ctx: Context,
    private val projection: MediaProjection?,
    private val internalAudio: Boolean,
    private val useMic: Boolean,
    private val micDeviceId: Int = -1,
) {
    companion object {
        private const val SR = 44100
        private const val CH = 2
        private const val KBPS = 128
    }

    var name = ""
        private set
    private var uri: Uri? = null
    val savedUri: Uri? get() = uri

    @Volatile private var running = false
    @Volatile private var paused = false
    private var sys: AudioRecord? = null
    private var mic: AudioRecord? = null
    private var enc: Mp3Encoder? = null
    private var out: OutputStream? = null
    private var worker: Thread? = null
    @Volatile private var failed = false

    private inline fun quiet(block: () -> Unit) { try { block() } catch (e: Exception) { /* abaikan */ } }

    fun start() {
        try {
            init()
        } catch (e: Exception) {
            running = false
            cleanup(keep = false)
            throw e
        }
    }

    @SuppressLint("MissingPermission")
    private fun init() {
        val fmt = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(SR)
            .setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build()
        val bufSize = maxOf(
            AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT) * 2, 16384,
        )
        if (internalAudio && projection != null) {
            sys = try {
                val pc = AudioPlaybackCaptureConfiguration.Builder(projection)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN).build()
                AudioRecord.Builder().setAudioFormat(fmt).setBufferSizeInBytes(bufSize)
                    .setAudioPlaybackCaptureConfig(pc).build()
                    .takeIf { it.state == AudioRecord.STATE_INITIALIZED }
            } catch (e: Exception) { null }
        }
        if (useMic) {
            mic = try {
                AudioRecord.Builder().setAudioSource(MediaRecorder.AudioSource.MIC)
                    .setAudioFormat(fmt).setBufferSizeInBytes(bufSize).build()
                    .takeIf { it.state == AudioRecord.STATE_INITIALIZED }
                    ?.also { ar ->
                        if (micDeviceId >= 0) {
                            ctx.getSystemService(android.media.AudioManager::class.java)
                                .getDevices(android.media.AudioManager.GET_DEVICES_INPUTS)
                                .firstOrNull { it.id == micDeviceId }
                                ?.let { ar.setPreferredDevice(it) }
                        }
                    }
            } catch (e: Exception) { null }
        }
        if (sys == null && mic == null) error("Sumber audio tidak tersedia")

        val e = Mp3Encoder(SR, CH, KBPS)
        if (!e.ok) error("Encoder MP3 gagal dibuat")
        enc = e

        name = "LayKit_Audio_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp3"
        val cv = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, name)
            put(MediaStore.Audio.Media.MIME_TYPE, "audio/mpeg")
            put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/LayKit")
            put(MediaStore.Audio.Media.IS_PENDING, 1)
        }
        val u = ctx.contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, cv) ?: error("MediaStore gagal")
        uri = u
        out = ctx.contentResolver.openOutputStream(u, "w") ?: error("File gagal dibuka")

        running = true
        worker = thread(name = "rec-audio-mp3") { loop() }
    }

    fun pause() { if (running) paused = true }
    fun resume() { if (running) paused = false }

    /** true = file tersimpan utuh */
    fun stop(): Boolean {
        if (!running) return false
        running = false
        worker?.join(8000)
        return cleanup(keep = !failed)
    }

    private fun loop() {
        val e = enc ?: return
        val o = out ?: return
        val n = 2048                               // 1024 frame stereo per putaran
        val a = ShortArray(n); val b = ShortArray(n); val mix = ShortArray(n)
        val buf = ByteArray(Mp3Encoder.outSize(n / 2))
        sys?.startRecording(); mic?.startRecording()
        try {
            while (running) {
                val ra = maxOf(sys?.read(a, 0, n) ?: 0, 0)
                val rb = maxOf(mic?.read(b, 0, n) ?: 0, 0)
                val m = maxOf(ra, rb) and 1.inv()  // genap (stereo)
                if (m <= 0) { Thread.sleep(5); continue }
                if (paused) continue               // tetap dibaca (dikuras), tidak dienkode
                for (k in 0 until m) {
                    val s = (if (k < ra) a[k].toInt() else 0) + (if (k < rb) b[k].toInt() else 0)
                    mix[k] = s.coerceIn(-32768, 32767).toShort()
                }
                val len = e.encode(mix, m / 2, buf)
                if (len < 0) { failed = true; break }
                if (len > 0) o.write(buf, 0, len)
            }
            val tail = e.flush(buf)
            if (tail > 0) o.write(buf, 0, tail)
        } catch (ex: Exception) {
            failed = true
        }
        quiet { sys?.stop() }; quiet { mic?.stop() }
    }

    private fun cleanup(keep: Boolean): Boolean {
        var ok = keep && uri != null
        try { out?.flush() } catch (e: Exception) { ok = false }
        quiet { out?.close() }
        quiet { enc?.close() }
        quiet { sys?.release() }; quiet { mic?.release() }
        uri?.let { u ->
            quiet {
                if (ok) ctx.contentResolver.update(u, ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }, null, null)
                else ctx.contentResolver.delete(u, null, null)
            }
        }
        return ok
    }
}
