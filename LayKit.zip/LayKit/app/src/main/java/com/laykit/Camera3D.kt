package com.laykit

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/**
 * Kamera 3D per blok zoom. Port LANGSUNG dari Openscreen (docs/3d-effects-v2.md, regions.rs, camera.rs), bukan tebakan.
 *
 * Satu konvensi untuk pratinjau dan ekspor, sama dengan `rotate_point` Openscreen:
 *  - sistem koordinat bidang: x ke kanan, y ke bawah, z ke arah kamera;
 *  - rotasi titik: Z (roll), lalu Y (yaw), lalu X (pitch): R = Rx(pitch) * Ry(yaw) * Rz(roll);
 *  - proyeksi perspektif: x' = P * (x + ox) / (P - z), dengan P = [PERSPECTIVE_FACTOR] x sisi terpendek bidang (sudut tetap, ox = 0)
 *    atau fokus kamera (Orbit, [CamView]), dan (ox, oy) = jatuhnya pusat layar di gambar (hanya Orbit);
 *  - sudut tetap: bidang diskala dulu oleh [contain] (supaya hasil miring tetap muat di kotaknya), BARU diputar.
 *    Orbit: kamera nyata, bukan memutar kartu di tempat: [CamView].
 */
object Cam {
    const val OFF = 0
    const val LEFT = 1     // layar menghadap kiri, dilihat dari atas
    const val RIGHT = 2    // layar menghadap kanan, dilihat dari atas
    const val ORBIT = 3    // kamera mengorbit: mata di bola, memandang titik bidik (lihat [CamView])

    /** PERSPECTIVE_FACTOR Openscreen: jarak kamera P = 1,6 x sisi terpendek kartu (~35° bidang pandang). Sebelumnya 2,6 x lebar: terlalu datar. */
    const val PERSPECTIVE_FACTOR = 1.6f

    /**
     * Satuan jarak kamera Android: `graphicsLayer.cameraDistance = d` memberi jarak NYATA 72 x d px
     * (RenderProperties::setCameraDistance -> Sk3DView::setCameraLocation: "passed in inches, set in pt", x72;
     * bawaannya 8 -> 576). Jadi untuk jarak P px, kirim P / 72.
     */
    const val ANDROID_CAMERA_UNIT = 72f

    // Preset sudut tetap Openscreen (regions::rotation3d_for), derajat [X tangage, Y lacet, Z roll]:
    //  left  = [-12, -18, -2], right = [-12, 18, 2]
    private const val FIXED_PITCH = -12f
    private const val FIXED_YAW = 18f
    private const val FIXED_ROLL = 2f

    // Orbit (camera.rs): azimut +-22° di tepi kiri/kanan, elevasi 4° saat diam + ayunan +-12° di tepi atas/bawah.
    const val ORBIT_AZIMUTH = 22f
    const val ORBIT_EL_REST = 4f
    const val ORBIT_EL_SWING = 12f

    /** Rotasi bidang dalam derajat, sama dengan `rot` Openscreen: [x] tangage, [y] lacet, [z] roll. */
    data class Rot(val x: Float, val y: Float, val z: Float) {
        operator fun times(k: Float) = Rot(x * k, y * k, z * k)
        val isFlat get() = abs(x) < 1e-4f && abs(y) < 1e-4f && abs(z) < 1e-4f
        companion object { val FLAT = Rot(0f, 0f, 0f) }
    }

    /**
     * Pose bidang untuk sudut TETAP (left/right) pada bobot [w] (0..1, kekuatan zoom). Semua sudut berbanding lurus dengan
     * bobot, jadi transisi masuk/keluar mulus tanpa lompatan. Orbit TIDAK lewat sini: ia kamera nyata, lihat [CamView].
     */
    fun pose(cam: Int, w: Float = 1f): Rot = when (cam) {
        LEFT -> Rot(FIXED_PITCH, -FIXED_YAW, -FIXED_ROLL) * w
        RIGHT -> Rot(FIXED_PITCH, FIXED_YAW, FIXED_ROLL) * w
        else -> Rot.FLAT
    }

    fun perspectivePx(w: Float, h: Float) = PERSPECTIVE_FACTOR * min(w, h)

    /** Nilai `cameraDistance` Compose supaya jarak kamera nyata = [perspectivePx] px. */
    fun composeCameraDistance(w: Float, h: Float) = perspectivePx(w, h) / ANDROID_CAMERA_UNIT

    // ------------------------------------------------------------------ matematika proyeksi (port regions.rs)

    /** Kolom-kolom R = Rx(a) Ry(b) Rz(g) (derajat), kolom-mayor 3x3: [R·x̂, R·ŷ, R·ẑ]. Sama dengan `rotate_point`. */
    fun rotationColumns(rot: Rot): FloatArray {
        val a = Math.toRadians(rot.x.toDouble()); val b = Math.toRadians(rot.y.toDouble()); val g = Math.toRadians(rot.z.toDouble())
        val ca = cos(a); val sa = sin(a); val cb = cos(b); val sb = sin(b); val cg = cos(g); val sg = sin(g)
        return floatArrayOf(
            (cg * cb).toFloat(), (sg * ca + cg * sb * sa).toFloat(), (sg * sa - cg * sb * ca).toFloat(),
            (-sg * cb).toFloat(), (cg * ca - sg * sb * sa).toFloat(), (cg * sa + sg * sb * ca).toFloat(),
            sb.toFloat(), (-cb * sa).toFloat(), (cb * ca).toFloat(),
        )
    }

    /** Titik (x0,y0,0) diputar [rot] lalu diproyeksikan; null kalau jatuh di belakang kamera. Hasil: x, y. */
    private fun project(x0: Double, y0: Double, r: FloatArray, p: Double, out: DoubleArray): Boolean {
        val px = r[0] * x0 + r[3] * y0
        val py = r[1] * x0 + r[4] * y0
        val pz = r[2] * x0 + r[5] * y0
        val den = p - pz
        if (den <= 0.0) return false
        val f = p / den
        out[0] = px * f; out[1] = py * f
        return true
    }

    /**
     * Faktor containment (contain_scale): bidang [width]x[height] diskala [fit] (<= 1) lalu diputar [rot] sehingga hasil
     * proyeksinya TIDAK keluar dari kotak aslinya. Iterasi sampai 8x pada sudut yang benar-benar terproyeksi (divisi
     * perspektifnya tidak linear, jadi sekali hitung tidak cukup). Rata (1) kalau sudut jatuh di belakang kamera.
     */
    fun contain(width: Float, height: Float, rot: Rot): Float {
        if (rot.isFlat) return 1f
        val p = perspectivePx(width, height).toDouble()
        val r = rotationColumns(rot)
        val hw = width * 0.5; val hh = height * 0.5
        val xs = doubleArrayOf(-hw, hw, hw, -hw); val ys = doubleArrayOf(-hh, -hh, hh, hh)
        val o = DoubleArray(2)
        fun extents(s: Double): DoubleArray? {
            var mx = 0.0; var my = 0.0
            for (i in 0 until 4) {
                if (!project(xs[i] * s, ys[i] * s, r, p, o)) return null
                mx = max(mx, abs(o[0])); my = max(my, abs(o[1]))
            }
            return doubleArrayOf(mx, my)
        }
        var scale = 1.0
        var e = extents(scale) ?: return 1f
        for (i in 0 until 8) {
            if (e[0] <= 0.0 || e[1] <= 0.0) break
            val fit = min(hw / e[0], hh / e[1])
            if (fit >= 0.999) break
            scale *= fit
            e = extents(scale) ?: break
        }
        return scale.toFloat()
    }

    /** Skala containment sudut tetap pada bobot [w]: skala pose-nya (konstan sepanjang blok, "skala beku"). */
    fun fit(cam: Int, w: Float, cardW: Float, cardH: Float): Float = when (cam) {
        LEFT, RIGHT -> contain(cardW, cardH, pose(cam, w))
        else -> 1f
    }

    /**
     * Padanan `graphicsLayer` untuk bidang yang dilihat kamera: titik bidang p diputar R lalu diproyeksikan
     * `P * (R p + (o, 0)).xy / (P - (R p).z)` (konvensi `TiltedQuad` Openscreen: [o] = jatuhnya pusat bidang di gambar).
     *
     * graphicsLayer hanya bisa menggeser SESUDAH pembagian perspektif, jadi offset sebelum-pembagian dibuat dengan
     * menggeser PIVOT: bidang diskala [LayerFit.sigma], diputar di sekitar pivot c (di bidang, z = 0) dengan
     * M c = -o (M = blok 2x2 kiri-atas R), lalu digeser -c. Jarak kamera TETAP [p]. Ini identik secara aljabar, bukan hampiran:
     * pada o = 0 hasilnya c = 0, sigma = 1 (sama dengan sebelum tahap 3).
     * Semua dalam satuan yang sama dengan [p] dan [ox],[oy] (px bidang, sebelum diskala containment).
     */
    class LayerFit(val sigma: Float, val cx: Float, val cy: Float)

    fun layerFit(rot: Rot, p: Float, ox: Float, oy: Float): LayerFit {
        if (ox == 0f && oy == 0f) return LayerFit(1f, 0f, 0f)
        val r = rotationColumns(rot)
        val det = r[0] * r[4] - r[3] * r[1]
        if (abs(det) < 1e-6f) return LayerFit(1f, 0f, 0f)
        val cx = -(r[4] * ox - r[3] * oy) / det
        val cy = -(-r[1] * ox + r[0] * oy) / det
        val zc = r[2] * cx + r[5] * cy
        val den = p - zc
        return if (den <= 1e-3f) LayerFit(1f, 0f, 0f) else LayerFit(p / den, cx, cy)
    }
}

/**
 * Kamera Orbit NYATA: port langsung `camera.rs` Openscreen (`View::new`, `quad`, `centring`, `frame_window`, `envelope_fit`, `reach`).
 *
 * Layar TIDAK bergerak. Mata mengorbit di bola: azimut mengikuti posisi horizontal pointer, elevasi posisi vertikalnya
 * (di sekitar elevasi istirahat), dan mata SELALU memandang titik bidiknya (lookAt, atas dunia tetap), jadi roll = 0 dari
 * konstruksinya. Hasilnya dilaporkan dalam konvensi `TiltedQuad`: rotasi (pitch, yaw), skala, fokus P, dan offset jatuhnya pusat
 * layar di gambar. Dunia = layar (kartu) berukuran kotak x zoom, asal di pusat, x ke kanan, y ke bawah, z ke mata.
 */
object CamView {
    /** Jarak mata ke titik bidik, dalam sisi terpendek kotak pada zoom 1 (objektif sudut tetap, ~35° bidang pandang). */
    const val DISTANCE = Cam.PERSPECTIVE_FACTOR
    /** Bagian zoom yang diambil lewat dolly (mendekatkan kamera) dan bukan lensa: jarak dibagi zoom^DOLLY. */
    const val DOLLY = 0.5f
    /** Mulai zoom ini bingkai "layar utuh" (containment envelope, centring) sudah digantikan bingkai "titik bidik di tengah". */
    const val FULL_VIEW_ZOOM = 2f
    /** Margin containment: envelope hanya disampel 3x3, centring menggeser kasus terburuk sedikit antar titik sampel. */
    private const val FIT_MARGIN = 0.995f

    /**
     * Masukan kamera satu frame. [weight] = kekuatan blok zoom (0..1); [aimX],[aimY] = titik bidik pada layar (0..1 dari
     * kiri-atas) dan [orbitX],[orbitY] = pointer terlicinkan (0..1), KEDUANYA sudah dibobot ([weighted]); [zoom] >= 1 zoom sekarang.
     */
    class Pose(val weight: Float, val aimX: Float, val aimY: Float, val orbitX: Float, val orbitY: Float, val zoom: Float)

    /** Titik 0..1 dibobot: pusat (0,5) pada bobot 0. */
    fun weighted(p: Float, w: Float) = 0.5f + (p - 0.5f) * w

    /** Kamera terpasang: mata, orientasi (yaw/pitch rad; + = ke kanan / ke atas), dan fokus (px keluaran). */
    class Eye(val ex: Float, val ey: Float, val ez: Float, val yaw: Float, val pitch: Float, val focal: Float) {
        private val sy = sin(yaw); private val cy = cos(yaw); private val sp = sin(pitch); private val cp = cos(pitch)
        // sumbu kamera di dunia: kanan, bawah, arah pandang (basis() Rust)
        private val rx = cy; private val rz = sy
        private val ux = sy * sp; private val uy = cp; private val uz = -cy * sp
        val fx = sy * cp; val fy = -sp; val fz = -cy * cp

        /** Titik dunia -> px relatif titik utama (pusat kotak); false kalau di belakang kamera. */
        fun project(x: Float, y: Float, z: Float, out: FloatArray): Boolean {
            val qx = x - ex; val qy = y - ey; val qz = z - ez
            val zc = fx * qx + fy * qy + fz * qz
            if (zc <= 1e-3f) return false
            out[0] = focal * (rx * qx + rz * qz) / zc
            out[1] = focal * (ux * qx + uy * qy + uz * qz) / zc
            return true
        }
    }

    /** Hasil dalam konvensi TiltedQuad: R = Rx(pitch) Ry(yaw), P = [focal], skala bidang, offset pusat layar di gambar (px). */
    class Quad(val pitchDeg: Float, val yawDeg: Float, val scale: Float, val focal: Float, val offX: Float, val offY: Float)

    /** Portee titik bidik pada zoom [zoom]: tetap di 0,5 +- reach, jangkauan fokus zoom datar (gimbal). Zoom 1: pusat. */
    fun reach(zoom: Float): Float = max(0.5f - 0.5f / max(zoom, 1f), 0f)

    /** Azimut dan elevasi (rad) pointer terbobot ([ox],[oy]) pada bobot [w]. */
    private fun azimuth(ox: Float) = Math.toRadians((Cam.ORBIT_AZIMUTH * (2f * ox - 1f)).toDouble()).toFloat()
    private fun elevation(oy: Float, w: Float) =
        Math.toRadians((Cam.ORBIT_EL_REST * w + Cam.ORBIT_EL_SWING * (1f - 2f * oy)).toDouble()).toFloat()

    /** Mata sejauh [dist] dari titik ([tx],[ty]) di layar, pada arah (az, el), memandangnya. */
    private fun orbitView(tx: Float, ty: Float, dist: Float, az: Float, el: Float, focal: Float) =
        Eye(tx + dist * sin(az) * cos(el), ty - dist * sin(el), dist * cos(az) * cos(el), -az, -el, focal)

    private val tmp = ThreadLocal.withInitial { FloatArray(2) }

    /** Kotak pembatas [x0, x1, y0, y1] layar `unit` (sisi terpendek 1) dilihat dari [DISTANCE] ke titik ([tx],[ty]), fokus [DISTANCE]. */
    private fun unitBbox(uw: Float, uh: Float, az: Float, el: Float, tx: Float, ty: Float, out: FloatArray) {
        val v = orbitView(tx, ty, DISTANCE, az, el, DISTANCE)
        val o = tmp.get()!!
        var x0 = Float.MAX_VALUE; var x1 = -Float.MAX_VALUE; var y0 = Float.MAX_VALUE; var y1 = -Float.MAX_VALUE
        for (i in 0 until 4) {
            val x = if (i == 0 || i == 3) -uw * 0.5f else uw * 0.5f     // TL, TR, BR, BL
            val y = if (i < 2) -uh * 0.5f else uh * 0.5f
            val px: Float; val py: Float
            if (v.project(x, y, 0f, o)) { px = o[0]; py = o[1] } else { px = x; py = y }
            x0 = min(x0, px); x1 = max(x1, px); y0 = min(y0, py); y1 = max(y1, py)
        }
        out[0] = x0; out[1] = x1; out[2] = y0; out[3] = y1
    }

    /**
     * Titik bidik yang membuat layar tampak TEPAT di tengah kotaknya (`centring`). Dilihat dari samping sisi dekat membesar dan sisi
     * jauh mengecil, jadi membidik pusat layar menggesernya dari tengah dan containment membayar selisih itu (0,77 bukan 0,83
     * pada 16:9). Empat putaran. Hasil: out[0], out[1] dalam satuan sisi terpendek.
     */
    private fun centring(uw: Float, uh: Float, az: Float, el: Float, out: FloatArray) {
        val b = FloatArray(4)
        var lx = 0f; var ly = 0f
        for (i in 0 until 4) {
            unitBbox(uw, uh, az, el, lx, ly, b)
            lx += 0.5f * (b[0] + b[1]); ly += 0.5f * (b[2] + b[3])
        }
        out[0] = lx; out[1] = ly
    }

    /**
     * Containment satu blok: faktor yang membuat layar yang sudah dipusatkan muat di kotaknya dari SELURUH envelope orbit pada
     * bobot [w]. Tidak bergantung pointer maupun waktu, jadi layar tidak "bernapas" saat kamera berputar.
     */
    fun envelopeFit(uw: Float, uh: Float, w: Float): Float {
        var fit = 1f
        val b = FloatArray(4); val l = FloatArray(2)
        for (gx in 0 until 3) for (gy in 0 until 3) {
            val ox = 0.5f + (gx * 0.5f - 0.5f) * w
            val oy = 0.5f + (gy * 0.5f - 0.5f) * w
            val az = azimuth(ox); val el = elevation(oy, w)
            centring(uw, uh, az, el, l)
            unitBbox(uw, uh, az, el, l[0], l[1], b)
            val mx = max(abs(b[0]), abs(b[1])); val my = max(abs(b[2]), abs(b[3]))
            fit = min(fit, min(0.5f * uw / mx, 0.5f * uh / my))
        }
        return if (fit < 1f) fit * FIT_MARGIN else 1f
    }

    /**
     * Titik bidik yang membingkai JENDELA zoom (persegi setengah-sisi [halfX],[halfY] di sekitar ([aimX],[aimY])) seperti zoom
     * datar: pada tiap sumbu [ux],[uy] menaruh bidikan di jangkauannya. Pada 0 jendela menyentuh tepi kiri (atas) layar dan TEPI
     * JENDELA itu jatuh pas di tepi gambar; pada 1 tepi kanan (bawah); di antaranya campuran linear, jendela di tengah pada
     * setengah jalan. Dilihat dari samping sisi dekat membesar: membidik pusat jendela akan mendorong sisi dekatnya keluar
     * gambar, dan sudut layar ikut. Pada zoom 1 jendela = layar utuh dan u = 0,5: sama dengan [centring]. Empat putaran.
     */
    private fun frameWindow(
        aimX: Float, aimY: Float, halfX: Float, halfY: Float, ux: Float, uy: Float,
        dist: Float, az: Float, el: Float, fit: Float, out: FloatArray,
    ) {
        val edgeX = halfX * fit; val edgeY = halfY * fit
        var tx = aimX; var ty = aimY
        val o = tmp.get()!!
        for (i in 0 until 4) {
            val v = orbitView(tx, ty, dist, az, el, dist * fit)
            // sudut TL, TR, BR, BL jendela; yang gagal diproyeksikan jatuh ke (x, y) polos, seperti unwrap_or Rust
            val cxs = floatArrayOf(-halfX, halfX, halfX, -halfX); val cys = floatArrayOf(-halfY, -halfY, halfY, halfY)
            val px = FloatArray(4); val py = FloatArray(4)
            for (k in 0 until 4) {
                if (v.project(aimX + cxs[k], aimY + cys[k], 0f, o)) { px[k] = o[0]; py[k] = o[1] } else { px[k] = cxs[k]; py[k] = cys[k] }
            }
            val left = min(px[0], px[3]); val right = max(px[1], px[2])
            val top = min(py[0], py[1]); val bottom = max(py[3], py[2])
            val errX = (left + edgeX) + ((right - edgeX) - (left + edgeX)) * ux
            val errY = (top + edgeY) + ((bottom - edgeY) - (top + edgeY)) * uy
            // menggeser bidikan sebesar d menggeser gambar sebesar d x fit: geser sebesar selisihnya
            tx += errX / fit; ty += errY / fit
        }
        out[0] = tx; out[1] = ty
    }

    /**
     * Kamera yang memfilmkan kotak layar [boxW]x[boxH] px (zoom SUDAH termasuk) di bawah [pose] (`View::new`).
     *  - Mata di orbit pointer, pada jarak DISTANCE x sisi terpendek kotak x zoom^-DOLLY dari titik bidik: zoom dibagi dua, setengah
     *    dengan mendekatkan kamera, setengah dengan lensa, jadi perspektif tidak datar saat zoom dalam dan orbit tetap terbaca.
     *  - Jendela zoom di sekitar aim dibingkai seperti zoom datar ([frameWindow]). Pada zoom 1 itu layar utuh, dan fokus dikecilkan
     *    supaya layar muat dari seluruh orbit ([envelopeFit]); memudar ke 1 sampai zoom [FULL_VIEW_ZOOM], lalu layar tepat
     *    sebesar zoom.
     */
    fun view(boxW: Float, boxH: Float, pose: Pose): Eye {
        val w = pose.weight.coerceIn(0f, 1f)
        val m = max(min(boxW, boxH), 1e-3f)
        val zoom = max(pose.zoom, 1f)
        val uw = boxW / m; val uh = boxH / m
        val fade = ((zoom - 1f) / (FULL_VIEW_ZOOM - 1f)).coerceIn(0f, 1f)
        var fit = envelopeFit(uw, uh, w)
        fit += (1f - fit) * fade
        val az = azimuth(pose.orbitX); val el = elevation(pose.orbitY, w)
        val dist = DISTANCE * m * zoom.pow(-DOLLY)
        val aimX = (pose.aimX - 0.5f) * boxW; val aimY = (pose.aimY - 0.5f) * boxH
        val r = reach(zoom)
        val ux = if (r > 1e-4f) ((pose.aimX - (0.5f - r)) / (2f * r)).coerceIn(0f, 1f) else 0.5f
        val uy = if (r > 1e-4f) ((pose.aimY - (0.5f - r)) / (2f * r)).coerceIn(0f, 1f) else 0.5f
        val t = FloatArray(2)
        frameWindow(aimX, aimY, 0.5f * boxW / zoom, 0.5f * boxH / zoom, ux, uy, dist, az, el, fit, t)
        return orbitView(t[0], t[1], dist, az, el, dist * fit)
    }

    /** [eye] dalam konvensi TiltedQuad (`View::quad`): R = Rx(pitch) Ry(yaw); skala = fokus / jarak sepanjang arah pandang ke pusat. */
    fun quad(eye: Eye): Quad {
        val depth = -(eye.fx * eye.ex + eye.fy * eye.ey + eye.fz * eye.ez)
        val o = FloatArray(2)
        if (!eye.project(0f, 0f, 0f, o)) { o[0] = 0f; o[1] = 0f }
        return Quad(
            Math.toDegrees(eye.pitch.toDouble()).toFloat(), Math.toDegrees(eye.yaw.toDouble()).toFloat(),
            eye.focal / depth, eye.focal, o[0], o[1],
        )
    }
}

/**
 * Cadreur Orbit (`camera::follow` / `camera::fixed` Openscreen).
 *
 * Fokus otomatis: pointer dari jejak kursor dilicinkan dengan respons impuls pegas kritis h(τ) = ω²·τ·e^(−ωτ), ω = 5 rad/s, atas
 * 2 detik jejak (120 cuplikan), dengan antisipasi 0,25 detik: perekaman dipasang setelah kejadian, jadi kamera berangkat sebelum
 * gerakan. Fungsi MURNI dari t (tanpa memori antar-frame), biaya tetap 120 pembacaan berapa pun panjang bloknya. Tanpa zona mati.
 *
 * Dua keluaran: [Aim.ox],[Aim.oy] = pointer terlicinkan di seluruh layar (menaruh mata di orbit), [Aim.ax],[Aim.ay] = pointer yang
 * DIJEPIT ke jangkauan zoom ([CamView.reach]) SEBELUM dilicinkan (titik bidik; kamera tidak pernah membidik keluar layar).
 * Jangkauan memakai skala PENUH blok, bukan zoom yang sedang berjalan (seperti Openscreen).
 */
object Follow {
    const val OMEGA = 5f
    const val LOOKAHEAD_S = 0.25f
    const val STEP_S = 1f / 60f
    const val TAPS = 120

    class Aim(val ax: Float, val ay: Float, val ox: Float, val oy: Float)

    /** Fokus manual (`fixed`): mata di orbit titik fokus blok, bidikan = titik yang sama dijepit ke jangkauan. Tanpa jejak, kamera diam. */
    fun fixed(fx: Float, fy: Float, scale: Float): Aim {
        val r = CamView.reach(scale)
        val ox = fx.coerceIn(0f, 1f); val oy = fy.coerceIn(0f, 1f)
        return Aim(ox.coerceIn(0.5f - r, 0.5f + r), oy.coerceIn(0.5f - r, 0.5f + r), ox, oy)
    }

    /** Fokus otomatis pada [tMs] untuk blok berskala [scale]; null kalau tidak ada jejak (pakai [fixed] dengan fokus blok). */
    fun aimed(events: List<TouchEvent>, tMs: Double, scale: Float): Aim? {
        if (events.isEmpty()) return null
        val r = CamView.reach(scale)
        val lo = 0.5f - r; val hi = 0.5f + r
        var ax = 0f; var ay = 0f; var ox = 0f; var oy = 0f; var total = 0f
        for (k in 1..TAPS) {
            val tau = k * STEP_S
            val weight = tau * exp(-OMEGA * tau)
            val at = (tMs + LOOKAHEAD_S * 1000.0 - tau * 1000.0).coerceAtLeast(0.0)
            val (px0, py0) = CursorMath.pointerAt(events, at.toLong()) ?: return null
            val px = px0.coerceIn(0f, 1f); val py = py0.coerceIn(0f, 1f)
            ox += weight * px; oy += weight * py
            ax += weight * px.coerceIn(lo, hi); ay += weight * py.coerceIn(lo, hi)
            total += weight
        }
        return Aim(ax / total, ay / total, ox / total, oy / total)
    }
}
