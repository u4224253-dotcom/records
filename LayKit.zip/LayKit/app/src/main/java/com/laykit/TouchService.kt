package com.laykit

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Display
import android.view.accessibility.AccessibilityEvent

/**
 * Layanan aksesibilitas yang HANYA mencatat posisi ketukan/ketikan (untuk auto-zoom) selama rekaman berjalan.
 * Yang dibaca dari tiap kejadian hanya kotak posisi (bounds) elemen yang diketuk; isi teks tidak dibaca atau disimpan.
 *
 * Android tidak memberi koordinat sentuhan mentah ke app biasa, jadi posisi = titik tengah elemen yang diketuk.
 * Konsekuensinya: elemen yang tidak dikenali aksesibilitas (sebagian game / kanvas custom) tidak tercatat.
 */
class TouchService : AccessibilityService() {

    companion object {
        fun isEnabled(ctx: Context): Boolean {
            val me = ComponentName(ctx, TouchService::class.java).flattenToString()
            val list = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
                ?: return false
            return list.split(':').any { it.equals(me, ignoreCase = true) }
        }

        /** Elemen yang menutupi lebih dari ini dari layar (mis. kontainer besar) dianggap tidak informatif. */
        private const val MAX_AREA_FRACTION = 0.7f
    }

    override fun onInterrupt() {}

    @Suppress("DEPRECATION")
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || !TouchLog.isActive) return
        if (e.packageName?.toString() == packageName) return   // ketukan di app ini sendiri (mis. tombol Stop) tidak dihitung

        val kind = when (e.eventType) {
            AccessibilityEvent.TYPE_VIEW_CLICKED, AccessibilityEvent.TYPE_VIEW_LONG_CLICKED -> TouchLog.TAP
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> TouchLog.TEXT
            else -> return
        }

        val node = e.source ?: return
        val r = Rect()
        try { node.getBoundsInScreen(r) } finally { try { node.recycle() } catch (_: Exception) {} }
        if (r.isEmpty) return

        val dm = DisplayMetrics()
        getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(dm)
        val sw = dm.widthPixels.toFloat()
        val sh = dm.heightPixels.toFloat()
        if (sw <= 0f || sh <= 0f) return

        val area = r.width().toFloat() * r.height().toFloat()
        if (area > MAX_AREA_FRACTION * sw * sh) return

        TouchLog.record(r.exactCenterX() / sw, r.exactCenterY() / sh, kind)
    }
}
