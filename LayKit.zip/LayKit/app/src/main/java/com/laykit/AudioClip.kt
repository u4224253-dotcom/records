package com.laykit

import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File

/**
 * Satu trek audio tambahan di atas video (musik, narasi, efek suara).
 * [startMs] = kapan audio mulai bunyi pada waktu SUMBER video (sama dengan waktu zoom/caption), jadi tetap benar
 * walau video dipotong. [durationMs] = panjang berkas audio. [volume] 0..1.
 * [uri] selalu salinan di filesDir/audio (lihat [AudioStore]) supaya tetap terbaca setelah app dibuka ulang.
 */
data class AudioClip(
    val id: Long,
    val uri: Uri,
    val name: String,
    val durationMs: Long,
    val startMs: Long = 0L,
    val volume: Float = 1f,
) {
    val endMs: Long get() = startMs + durationMs
}

/**
 * Penyimpanan berkas audio tambahan. Izin Uri dari pemilih berkas tidak bertahan, jadi audio yang dipilih langsung
 * disalin ke filesDir/audio/<id>.<ekstensi>. Berkas dihapus saat project-nya dihapus (lihat [ProjectStore.delete]).
 */
internal object AudioStore {
    private fun dir(ctx: Context) = File(ctx.filesDir, "audio").apply { mkdirs() }

    /** Pesan galat kalau [import] gagal (dibaca pemanggil untuk toast). */
    class ImportException(msg: String) : Exception(msg)

    /**
     * Salin [src] ke penyimpanan app, pastikan punya trek audio yang bisa dibaca, lalu kembalikan klip yang mulai di [startMs].
     * Dipanggil di thread background. Melempar [ImportException] kalau berkas bukan audio / rusak.
     */
    fun import(ctx: Context, src: Uri, startMs: Long): AudioClip {
        val name = displayName(ctx, src) ?: "Audio"
        val ext = name.substringAfterLast('.', "").lowercase().takeIf { it.length in 1..5 && it.all { c -> c.isLetterOrDigit() } } ?: "audio"
        val id = System.nanoTime()
        val dst = File(dir(ctx), "$id.$ext")
        try {
            val ins = ctx.contentResolver.openInputStream(src) ?: throw ImportException("Berkas audio tidak bisa dibuka")
            ins.use { i -> dst.outputStream().use { o -> i.copyTo(o) } }
            val dur = probeDurationMs(dst) ?: throw ImportException("Berkas ini tidak punya trek audio")
            return AudioClip(id = id, uri = Uri.fromFile(dst), name = name.substringBeforeLast('.'), durationMs = dur, startMs = startMs)
        } catch (e: ImportException) {
            dst.delete(); throw e
        } catch (e: Exception) {
            dst.delete(); throw ImportException("Audio gagal dibuka: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    fun delete(clip: AudioClip) {
        if (clip.uri.scheme == "file") try { File(clip.uri.path ?: return).delete() } catch (_: Exception) {}
    }

    /** Berkas salinan masih ada? (dipakai saat memuat project) */
    fun exists(clip: AudioClip): Boolean = clip.uri.scheme == "file" && (clip.uri.path?.let { File(it).length() > 0 } == true)

    private fun displayName(ctx: Context, uri: Uri): String? {
        val fromProvider: String? = try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        } catch (_: Exception) {
            null
        }
        return fromProvider ?: uri.lastPathSegment
    }

    /** Panjang audio (ms) dari trek audio pertama, atau null kalau tidak ada trek audio. */
    private fun probeDurationMs(f: File): Long? {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(f.absolutePath)
            for (i in 0 until ex.trackCount) {
                val fmt = ex.getTrackFormat(i)
                if (fmt.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                    val us = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
                    return (us / 1000L).coerceAtLeast(1L)
                }
            }
            return null
        } finally {
            ex.release()
        }
    }
}
