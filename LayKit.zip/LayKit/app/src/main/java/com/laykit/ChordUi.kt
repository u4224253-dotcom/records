package com.laykit

import android.media.MediaPlayer
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.laykit.chord.ChordAnalysis
import com.laykit.chord.ChordEngine
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.max

private sealed interface ChordState {
    class Working(val label: String, val p: Float) : ChordState
    class Done(val res: ChordAnalysis) : ChordState
    class Fail(val msg: String) : ChordState
}

/** Label model ("A:min", "Db:maj7", "N") -> nama yang dibaca musisi ("Am", "D♭maj7", "–"). */
internal fun chordName(label: String): String {
    if (label == "N" || label == "X") return "–"
    val i = label.indexOf(':')
    val root = (if (i < 0) label else label.substring(0, i)).replace("b", "♭")
    if (i < 0) return root
    val q = when (val s = label.substring(i + 1)) {
        "min" -> "m"
        "min6" -> "m6"
        "min7" -> "m7"
        "minmaj7" -> "mM7"
        "hdim7" -> "m7♭5"
        "maj6" -> "6"
        else -> s   // maj7, 7, dim, dim7, aug, sus2, sus4
    }
    return root + q
}

private fun mmss(sec: Double): String {
    val s = sec.toInt().coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

/** Layar pencari akor: decode audio -> ChordEngine di thread latar -> timeline akor yang ikut lagu saat diputar. */
@Composable
internal fun ChordScreen(uri: Uri, onBack: () -> Unit) {
    val ctx = LocalContext.current
    BackHandler(onBack = onBack)
    var state by remember(uri) { mutableStateOf<ChordState>(ChordState.Working("Membaca audio", 0f)) }

    LaunchedEffect(uri) {
        try {
            val res = withContext(Dispatchers.Default) {
                val job = currentCoroutineContext()[Job]
                val cancelled = { job?.isActive == false }
                var lastP = -1f
                fun report(label: String, p: Float) {
                    if (p - lastP >= 0.005f || p >= 1f) { lastP = p; state = ChordState.Working(label, p) }
                }
                val pcm = AudioDecoder.decodeMono(ctx, uri, cancelled) { report("Membaca audio", it * 0.2f) }
                report("Memuat model", 0.2f)
                val engine = ChordEngine.load(ctx.assets.open("net.lkm"))
                engine.analyze(pcm.samples, pcm.sampleRate, onProgress = { p ->
                    if (cancelled()) throw CancellationException("dibatalkan")
                    report("Mencari akor", 0.2f + 0.8f * p)
                })
            }
            state = ChordState.Done(res)
        } catch (e: CancellationException) {
            throw e
        } catch (e: OutOfMemoryError) {
            state = ChordState.Fail("Memori HP tidak cukup untuk audio sepanjang ini")
        } catch (e: Throwable) {
            state = ChordState.Fail(e.message ?: "Gagal menganalisis audio")
        }
    }

    val cs = MaterialTheme.colorScheme
    Column(
        Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars).padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Pill("Kembali", onClick = onBack)
            Text("Akor", style = MaterialTheme.typography.titleLarge, color = cs.onSurface)
        }
        Spacer(Modifier.height(12.dp))
        when (val s = state) {
            is ChordState.Working -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(Modifier.fillMaxWidth(0.75f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(s.label, style = MaterialTheme.typography.titleMedium, color = cs.onSurface)
                    Spacer(Modifier.height(14.dp))
                    LinearProgressIndicator(
                        progress = { s.p.coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth(),
                        color = cs.primary, trackColor = cs.surfaceVariant,
                    )
                    Spacer(Modifier.height(8.dp))
                    Text("${(s.p * 100).toInt()}%", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                }
            }
            is ChordState.Fail -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(s.msg, style = MaterialTheme.typography.bodyLarge, color = cs.error, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(14.dp))
                    Pill("Kembali", onClick = onBack)
                }
            }
            is ChordState.Done -> ChordResult(uri, s.res)
        }
    }
}

@Composable
private fun ChordResult(uri: Uri, res: ChordAnalysis) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val cs = MaterialTheme.colorScheme
    val segs = res.segments
    val total = segs.lastOrNull()?.end ?: 0.0

    var mp by remember { mutableStateOf<MediaPlayer?>(null) }
    var playing by remember { mutableStateOf(false) }
    var pos by remember { mutableStateOf(0.0) }

    LaunchedEffect(uri) {
        val p = withContext(Dispatchers.IO) {
            try { MediaPlayer().apply { setDataSource(ctx, uri); prepare() } } catch (_: Exception) { null }
        }
        if (p != null) {
            p.setOnCompletionListener { playing = false; pos = 0.0 }
            mp = p
        }
    }
    DisposableEffect(uri) { onDispose { mp?.release(); mp = null } }
    LaunchedEffect(playing, mp) {
        val p = mp ?: return@LaunchedEffect
        while (playing) { pos = p.currentPosition / 1000.0; delay(60) }
    }

    fun seek(t: Double) { pos = t; mp?.seekTo((t * 1000).toInt()) }
    fun toggle() {
        val p = mp ?: return
        if (playing) { p.pause(); playing = false } else { if (pos >= total) seek(0.0); p.start(); playing = true }
    }

    if (segs.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Tidak ada akor yang terdeteksi", color = cs.onSurfaceVariant)
        }
        return
    }

    val cur = segs.indexOfLast { it.start <= pos }.coerceAtLeast(0)
    val listState = rememberLazyListState()
    LaunchedEffect(cur, playing) { if (playing) listState.animateScrollToItem(max(0, cur - 2)) }

    Column(Modifier.fillMaxSize()) {
        // akor saat ini
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(cs.surfaceVariant).padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(chordName(segs[cur].label), fontSize = 72.sp, fontWeight = FontWeight.Bold, color = cs.primary)
            Text(
                if (cur + 1 < segs.size) "Berikutnya  ${chordName(segs[cur + 1].label)}" else " ",
                style = MaterialTheme.typography.titleMedium, color = cs.onSurfaceVariant,
            )
            Spacer(Modifier.height(14.dp))
            LinearProgressIndicator(
                progress = { if (total > 0) (pos / total).toFloat().coerceIn(0f, 1f) else 0f },
                modifier = Modifier.fillMaxWidth(), color = cs.primary, trackColor = cs.surface,
            )
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(mmss(pos), style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                Text(mmss(total), style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
            }
            Spacer(Modifier.height(10.dp))
            Box(
                Modifier.size(56.dp).clip(CircleShape)
                    .background(if (mp != null) cs.primary else cs.surface)
                    .clickable(enabled = mp != null) { toggle() },
                contentAlignment = Alignment.Center,
            ) { PlayPauseIcon(playing, if (mp != null) cs.onPrimary else cs.onSurfaceVariant, 24.dp) }
        }

        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Timeline · ${segs.size} akor", style = MaterialTheme.typography.titleSmall,
                color = cs.onSurface, modifier = Modifier.weight(1f),
            )
            Pill("Salin") {
                val text = segs.joinToString("\n") { mmss(it.start) + "  " + chordName(it.label) }
                clip.setText(AnnotatedString(text))
                Toast.makeText(ctx, "Daftar akor disalin", Toast.LENGTH_SHORT).show()
            }
        }
        Spacer(Modifier.height(6.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState) {
            itemsIndexed(segs) { i, seg ->
                val on = i == cur
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                        .background(if (on) cs.primary.copy(alpha = 0.14f) else Color.Transparent)
                        .clickable { seek(seg.start) }
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        chordName(seg.label), modifier = Modifier.width(96.dp),
                        fontSize = 20.sp, fontWeight = FontWeight.SemiBold,
                        color = if (on) cs.primary else cs.onSurface,
                    )
                    Text(
                        mmss(seg.start) + " – " + mmss(seg.end),
                        style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant,
                    )
                }
            }
        }
    }
}
