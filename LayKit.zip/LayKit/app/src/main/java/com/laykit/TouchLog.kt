package com.laykit

import java.io.File
import java.util.Locale

/**
 * Pencatat ketukan/ketikan selama merekam, plus penyimpanan "sidecar" per rekaman.
 *
 * Waktu setiap kejadian memakai jam VIDEO (milidetik sejak rekaman mulai, tanpa waktu jeda),
 * jadi cocok langsung dengan timeline editor dan [AutoZoom].
 *
 * Bagian encode/decode/file sengaja tanpa dependensi Android supaya bisa diuji di JVM biasa.
 */
object TouchLog {
    const val TAP = 0
    const val TEXT = 1

    private const val TEXT_THROTTLE_MS = 250L   // ketikan beruntun dijarangkan agar timeline tidak penuh titik

    private val lock = Any()
    private val buf = ArrayList<TouchEvent>()
    @Volatile private var clock: (() -> Long)? = null
    @Volatile private var lastTextMs = Long.MIN_VALUE / 2

    val isActive: Boolean get() = clock != null

    /** Mulai mencatat. [clockMs] mengembalikan waktu video saat ini, atau -1 kalau sedang jeda. */
    fun begin(clockMs: () -> Long) {
        synchronized(lock) { buf.clear() }
        lastTextMs = Long.MIN_VALUE / 2
        clock = clockMs
    }

    /** [x],[y] dinormalisasi 0..1 pada layar (asal kiri-atas). Diabaikan kalau tidak sedang merekam / dijeda. */
    fun record(x: Float, y: Float, kind: Int) {
        val c = clock ?: return
        val t = c()
        if (t < 0) return
        if (kind == TEXT) {
            if (t - lastTextMs < TEXT_THROTTLE_MS) return
            lastTextMs = t
        }
        synchronized(lock) { buf += TouchEvent(t, x.coerceIn(0f, 1f), y.coerceIn(0f, 1f), kind) }
    }

    /** Berhenti mencatat dan ambil semua kejadian (terurut waktu). */
    fun end(): List<TouchEvent> {
        clock = null
        synchronized(lock) {
            val out = buf.sortedBy { it.tMs }
            buf.clear()
            return out
        }
    }

    // ---------------- format file: satu baris "tMs,x,y,kind" ----------------

    fun encode(events: List<TouchEvent>): String =
        events.joinToString("\n") { e ->
            String.format(Locale.US, "%d,%.4f,%.4f,%d", e.tMs, e.x, e.y, e.kind)
        }

    fun decode(text: String): List<TouchEvent> =
        text.lineSequence().mapNotNull { line ->
            val p = line.trim().split(',')
            if (p.size < 4) return@mapNotNull null
            try {
                TouchEvent(p[0].trim().toLong(), p[1].trim().toFloat(), p[2].trim().toFloat(), p[3].trim().toInt())
            } catch (_: NumberFormatException) {
                null
            }
        }.sortedBy { it.tMs }.toList()

    // ---------------- penyimpanan (folder privat app: <dir>/touch/<nama-video>.csv) ----------------

    private fun fileFor(dir: File, videoName: String): File {
        val safe = File(videoName).name.substringBeforeLast('.').ifEmpty { "video" }   // buang path, jaga dari "../"
        return File(File(dir, "touch"), "$safe.csv")
    }

    fun save(dir: File, videoName: String, events: List<TouchEvent>) {
        if (events.isEmpty()) return
        try {
            val f = fileFor(dir, videoName)
            f.parentFile?.mkdirs()
            f.writeText(encode(events))
        } catch (_: Exception) {
            // gagal simpan: rekaman tetap utuh, hanya tanpa data sentuhan
        }
    }

    fun load(dir: File, videoName: String): List<TouchEvent> = try {
        val f = fileFor(dir, videoName)
        if (f.exists()) decode(f.readText()) else emptyList()
    } catch (_: Exception) {
        emptyList()
    }
}
