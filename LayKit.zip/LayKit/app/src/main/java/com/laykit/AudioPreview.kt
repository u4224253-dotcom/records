package com.laykit

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import kotlin.math.abs

/**
 * Memutar audio tambahan di pratinjau editor, mengikuti jam video. Satu MediaPlayer per klip.
 * Semua pemanggilan dari thread utama. [sync] dipanggil berkala (~12 Hz) dari editor dengan posisi video saat ini:
 * klip yang sedang "di dalam" jangkauannya diputar dan dikoreksi kalau melenceng lebih dari [DRIFT_MS], yang lain dijeda.
 */
internal class AudioPreview(private val ctx: Context) {
    private class Slot(val mp: MediaPlayer, val uri: Uri) {
        var ready = false
        var lastSeekNs = 0L
    }

    private val slots = HashMap<Long, Slot>()

    /** Samakan pemutar dengan daftar klip: buang yang sudah tidak ada, buka yang baru. */
    fun setClips(clips: List<AudioClip>) {
        val iter = slots.entries.iterator()
        while (iter.hasNext()) {
            val e = iter.next()
            val c = clips.firstOrNull { it.id == e.key }
            if (c == null || c.uri != e.value.uri) {
                try { e.value.mp.release() } catch (_: Exception) {}
                iter.remove()
            }
        }
        for (c in clips) if (!slots.containsKey(c.id)) open(c)
    }

    private fun open(c: AudioClip) {
        val mp = MediaPlayer()
        val slot = Slot(mp, c.uri)
        try {
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build(),
            )
            mp.setDataSource(ctx, c.uri)
            mp.setOnPreparedListener { slot.ready = true }
            mp.setOnErrorListener { _, _, _ -> slot.ready = false; true }
            mp.prepareAsync()
            slots[c.id] = slot
        } catch (_: Exception) {
            try { mp.release() } catch (_: Exception) {}
        }
    }

    /**
     * @param videoMs posisi video sekarang (waktu sumber, ms)
     * @param playing video sedang diputar
     * @param muted pratinjau di-mute (ikon speaker di baris player)
     */
    fun sync(clips: List<AudioClip>, videoMs: Float, playing: Boolean, muted: Boolean) {
        val now = System.nanoTime()
        for (c in clips) {
            val s = slots[c.id] ?: continue
            if (!s.ready) continue
            try {
                val want = (videoMs - c.startMs).toLong()
                val inside = playing && want >= 0L && want < s.mp.duration
                if (inside) {
                    val v = if (muted) 0f else c.volume.coerceIn(0f, 1f)
                    s.mp.setVolume(v, v)
                    if (!s.mp.isPlaying) {
                        s.mp.seekTo(want, MediaPlayer.SEEK_CLOSEST)
                        s.lastSeekNs = now
                        s.mp.start()
                    } else if (now - s.lastSeekNs > SEEK_COOLDOWN_NS && abs(s.mp.currentPosition - want) > DRIFT_MS) {
                        s.mp.seekTo(want, MediaPlayer.SEEK_CLOSEST)
                        s.lastSeekNs = now
                    }
                } else if (s.mp.isPlaying) {
                    s.mp.pause()
                }
            } catch (_: Exception) {
                // pemutar sedang berpindah keadaan: coba lagi di putaran berikut
            }
        }
    }

    fun pauseAll() {
        for (s in slots.values) try { if (s.mp.isPlaying) s.mp.pause() } catch (_: Exception) {}
    }

    fun release() {
        for (s in slots.values) try { s.mp.release() } catch (_: Exception) {}
        slots.clear()
    }

    private companion object {
        const val DRIFT_MS = 220L
        const val SEEK_COOLDOWN_NS = 500_000_000L   // MediaPlayer.seekTo asinkron: jangan seek lagi sebelum yang tadi selesai
    }
}
