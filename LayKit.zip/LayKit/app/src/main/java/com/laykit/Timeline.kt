package com.laykit

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt

private val H_RULER = 16.dp
private val H_VIDEO = 52.dp
private val H_TOUCH = 10.dp
private val H_ZOOM = 34.dp
private val GAP = 6.dp
private val HANDLE_W = 14.dp

/** Tinggi baris yang harus tetap terlihat saat panel tool terbuka: ruler + video. */
internal val TL_ROWS_TOP: Dp = H_RULER + GAP + H_VIDEO
/** Sama, ditambah baris zoom (untuk panel Zoom yang butuh memilih blok). */
internal val TL_ROWS_ZOOM: Dp = TL_ROWS_TOP + GAP + H_ZOOM
/** Tambahan tinggi kalau baris Sentuh tampil. */
internal val TL_ROW_TOUCH: Dp = GAP + H_TOUCH

private val STEPS_MS = longArrayOf(1000, 2000, 5000, 10_000, 15_000, 30_000, 60_000, 120_000, 300_000, 600_000)

/** Skala timeline dalam dp per detik: awal, batas atas. Batas bawah = seluruh klip muat (80% lebar). */
private const val DEFAULT_DP_PER_SEC = 48f
private const val MAX_DP_PER_SEC = 320f

private const val THUMBS = 16

private val PLAYHEAD = Color.White

/**
 * Timeline editor gaya CapCut:
 *  - **Playhead tetap di tengah**, isi timeline yang bergeser. Geser timeline = scrub; saat diputar timeline berjalan sendiri.
 *  - **Cubit dua jari** untuk memperbesar/memperkecil (tidak ada tombol + / −).
 *  - Waktu "sekarang / total" kecil di pojok kiri atas, ruler tipis tanpa garis (label + titik).
 *  - Baris: video berthumbnail dengan handle potong, (sentuhan), blok zoom (geser badan = pindah, geser tepi = ubah panjang).
 *
 * Semua gestur geser baris dipasang di kontainer baris (koordinat stabil), bukan di tiap blok,
 * karena blok ikut bergeser saat di-drag dan itu merusak pembacaan delta jari.
 */
@Composable
fun TimelineEditor(
    uri: Uri,
    durMs: Long,
    positionMs: Long,
    timeMs: () -> Float,
    playing: Boolean,
    startMs: Float,
    endMs: Float,
    zooms: List<ZoomRegion>,
    touches: List<TouchEvent>,
    selectedId: Int?,
    enabled: Boolean,
    onSeek: (Long) -> Unit,
    onScrubStart: () -> Unit,
    onTrimStart: (Float) -> Unit,
    onTrimEnd: (Float) -> Unit,
    onSelect: (Int?) -> Unit,
    onZooms: (List<ZoomRegion>) -> Unit,
    modifier: Modifier = Modifier,
    selectedKey: Long? = null,
    onSelectKey: (Int, Long?) -> Unit = { _, _ -> },
) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val density = LocalDensity.current
    val scroll = rememberScrollState()
    val showTouch = touches.isNotEmpty()
    var dpPerSec by remember(durMs) { mutableFloatStateOf(0f) }   // 0 = belum diatur (pakai awal)
    // true selama jari menyeret handle potong / blok zoom / keyframe. Timeline TIDAK boleh ikut berjalan ke posisi playhead
    // saat itu: koordinat jari dibaca relatif terhadap isi yang bergeser, jadi ikut berjalan = handle meluncur sendiri.
    var rowDrag by remember { mutableStateOf(false) }

    val thumbs by produceState<List<Bitmap?>>(List(THUMBS) { null }, uri, durMs) {
        val out = arrayOfNulls<Bitmap>(THUMBS)
        withContext(Dispatchers.IO) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, uri)
                for (i in 0 until THUMBS) {
                    val t = ((i + 0.5) / THUMBS * durMs * 1000.0).toLong()
                    val b = r.getFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    if (b != null) {
                        val h = 160
                        val w = (b.width * h / b.height.toFloat()).toInt().coerceAtLeast(1)
                        val s = Bitmap.createScaledBitmap(b, w, h, true)
                        if (s !== b) b.recycle()
                        out[i] = s
                        value = out.toList()
                    }
                }
            } catch (_: Exception) {
            } finally {
                try { r.release() } catch (_: Exception) {}
            }
        }
    }

    val seekState by rememberUpdatedState(onSeek)
    val scrubState by rememberUpdatedState(onScrubStart)
    val playingState by rememberUpdatedState(playing)
    val timeState by rememberUpdatedState(timeMs)

    BoxWithConstraints(modifier) {
        val viewW = maxWidth
        val durSec = (durMs / 1000f).coerceAtLeast(0.5f)
        val minDp = (viewW.value * 0.8f / durSec).coerceAtMost(MAX_DP_PER_SEC)
        val curDp = (if (dpPerSec <= 0f) DEFAULT_DP_PER_SEC else dpPerSec).coerceIn(minDp, MAX_DP_PER_SEC)
        val pxPerMs = with(density) { curDp.dp.toPx() } / 1000f
        val clipW = with(density) { (pxPerMs * durMs).toDp() }
        val halfView = viewW / 2
        val totalH = H_RULER + GAP + H_VIDEO + GAP + H_ZOOM + (if (showTouch) TL_ROW_TOUCH else 0.dp)

        val pxPerMsState by rememberUpdatedState(pxPerMs)
        val pinch by rememberUpdatedState({ ratio: Float ->
            val base = if (dpPerSec <= 0f) curDp else dpPerSec
            dpPerSec = (base * ratio).coerceIn(minDp, MAX_DP_PER_SEC)
        })

        // pengguna menggeser timeline -> playhead (waktu) mengikuti; kalau sedang diputar, jeda dulu
        LaunchedEffect(scroll, durMs) {
            snapshotFlow { scroll.value }.collect { v ->
                if (scroll.isScrollInProgress) {
                    if (playingState) scrubState()
                    seekState((v / pxPerMsState).toLong().coerceIn(0L, durMs))
                }
            }
        }
        // waktu berubah (seek, trim, ganti skala) saat tidak diputar -> geser timeline ke posisinya.
        // dispatchRawDelta (bukan scrollTo) supaya isScrollInProgress tetap hanya berarti "digeser jari".
        LaunchedEffect(positionMs, pxPerMs, playing, rowDrag) {
            if (!playing && !rowDrag && !scroll.isScrollInProgress) {
                withFrameNanos { }   // tunggu layout (lebar konten baru berubah kalau skala berubah)
                val d = (positionMs * pxPerMs).roundToInt() - scroll.value
                if (abs(d) > 1 && !scroll.isScrollInProgress) scroll.dispatchRawDelta(d.toFloat())
            }
        }
        // diputar -> timeline berjalan halus, ikut jam per frame pemutar
        LaunchedEffect(playing, pxPerMs) {
            if (playing) {
                while (true) {
                    withFrameNanos { }
                    if (!rowDrag && !scroll.isScrollInProgress) {
                        val d = (timeState() * pxPerMsState).roundToInt() - scroll.value
                        if (d != 0) scroll.dispatchRawDelta(d.toFloat())
                    }
                }
            }
        }

        Box(
            Modifier.fillMaxSize()
                // cubit dua jari = zoom timeline. Diproses di fase Initial dan dikonsumsi, supaya gestur baris tidak ikut jalan.
                .pointerInput(Unit) {
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                        var prev = 0f
                        do {
                            val ev = awaitPointerEvent(PointerEventPass.Initial)
                            val down = ev.changes.filter { it.pressed }
                            if (down.size >= 2) {
                                val d = (down[0].position - down[1].position).getDistance()
                                if (prev > 0f && d > 0f) pinch(d / prev)
                                prev = d
                                ev.changes.forEach { it.consume() }
                            } else prev = 0f
                        } while (ev.changes.any { it.pressed })
                    }
                },
        ) {
            Box(Modifier.fillMaxWidth().horizontalScroll(scroll)) {
                Row {
                    Spacer(Modifier.width(halfView))
                    Column(Modifier.width(clipW), verticalArrangement = Arrangement.spacedBy(GAP)) {
                        RulerRow(durMs, pxPerMs, onSeek)
                        VideoRow(thumbs, durMs, pxPerMs, startMs, endMs, enabled, onSeek, onTrimStart, onTrimEnd) { rowDrag = it }
                        ZoomRow(zooms, durMs, pxPerMs, selectedId, selectedKey, enabled, onSelect, onSelectKey, onZooms) { rowDrag = it }
                        if (showTouch) TouchRow(touches, pxPerMs)
                    }
                    Spacer(Modifier.width(halfView))
                }
            }
            // playhead: garis putih tetap di tengah, setinggi seluruh area timeline
            Box(
                Modifier.align(Alignment.TopCenter).width(2.dp).fillMaxHeight()
                    .background(PLAYHEAD, RoundedCornerShape(1.dp)),
            )
            // waktu kecil di pojok kiri atas: yang sekarang terang, total redup. Ruler yang lewat di bawahnya tertutup.
            Box(
                Modifier.align(Alignment.TopStart).height(H_RULER)
                    .background(Brush.horizontalGradient(0f to cs.background, 0.82f to cs.background, 1f to Color.Transparent))
                    .padding(start = 2.dp, end = 20.dp),
                contentAlignment = Alignment.CenterStart,
            ) {
                Text(
                    buildAnnotatedString {
                        withStyle(SpanStyle(color = cs.onBackground, fontWeight = FontWeight.Medium)) { append(Library.fmtTime(positionMs)) }
                        withStyle(SpanStyle(color = cs.onSurfaceVariant)) { append(" / ${Library.fmtTime(durMs)}") }
                    },
                    fontSize = 11.sp, maxLines = 1,
                )
            }
        }
    }
}

// ------------------------------------------------------------------------------------------------

/** Ruler tipis: hanya label waktu dan satu titik di tengah tiap selang. Ketuk = pindahkan playhead. */
@Composable
private fun RulerRow(durMs: Long, pxPerMs: Float, onSeek: (Long) -> Unit) {
    val density = LocalDensity.current
    val seek by rememberUpdatedState(onSeek)
    val minStepPx = with(density) { 64.dp.toPx() }
    val step = STEPS_MS.firstOrNull { it * pxPerMs >= minStepPx } ?: STEPS_MS.last()
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    val labelHalf = with(density) { 22.dp.roundToPx() }
    val dotHalf = with(density) { 1.5.dp.roundToPx() }

    Box(
        Modifier.fillMaxWidth().height(H_RULER)
            .pointerInput(pxPerMs, durMs) {
                detectTapGestures { off -> seek((off.x / pxPerMs).toLong().coerceIn(0L, durMs)) }
            },
    ) {
        var t = 0L
        while (t <= durMs) {
            val x = (t * pxPerMs).roundToInt()
            Box(
                Modifier.offset { IntOffset(x - labelHalf, 0) }.width(44.dp).fillMaxHeight(),
                contentAlignment = Alignment.Center,
            ) { Text(Library.fmtTime(t), fontSize = 10.sp, maxLines = 1, color = dim) }
            val mid = t + step / 2
            if (mid <= durMs) {
                Box(
                    Modifier.align(Alignment.CenterStart)
                        .offset { IntOffset((mid * pxPerMs).roundToInt() - dotHalf, 0) }
                        .size(3.dp).background(dim.copy(alpha = 0.6f), CircleShape),
                )
            }
            t += step
        }
    }
}

@Composable
private fun VideoRow(
    thumbs: List<Bitmap?>,
    durMs: Long, pxPerMs: Float, startMs: Float, endMs: Float, enabled: Boolean,
    onSeek: (Long) -> Unit, onTrimStart: (Float) -> Unit, onTrimEnd: (Float) -> Unit,
    onDragState: (Boolean) -> Unit,
) {
    val density = LocalDensity.current
    val cs = MaterialTheme.colorScheme
    val dragState by rememberUpdatedState(onDragState)
    val curStart by rememberUpdatedState(startMs)
    val curEnd by rememberUpdatedState(endMs)
    val ts by rememberUpdatedState(onTrimStart)
    val te by rememberUpdatedState(onTrimEnd)
    val seek by rememberUpdatedState(onSeek)
    val handlePx = with(density) { HANDLE_W.roundToPx() }
    val touchPx = with(density) { (HANDLE_W + 8.dp).toPx() }
    val shape = RoundedCornerShape(8.dp)
    val edge = Color.White
    val scrim = Color.Black.copy(alpha = 0.62f)

    Box(
        Modifier.fillMaxWidth().height(H_VIDEO)
            .clip(shape)
            .background(cs.surfaceContainerHighest)
            .pointerInput(pxPerMs, durMs, enabled) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val x = down.position.x
                    val sx = curStart * pxPerMs
                    val ex = curEnd * pxPerMs
                    val nearL = enabled && x >= sx - touchPx / 2 && x <= sx + touchPx
                    val nearR = enabled && x >= ex - touchPx && x <= ex + touchPx / 2
                    val left = when {
                        nearL && nearR -> abs(x - sx) <= abs(x - ex)
                        nearL -> true
                        nearR -> false
                        else -> null
                    }
                    if (left == null) {
                        // bukan handle: ketukan = pindahkan playhead; geseran dibiarkan untuk scroll timeline
                        val up = waitForUpOrCancellation()
                        if (up != null) seek((up.position.x / pxPerMs).toLong().coerceIn(0L, durMs))
                        return@awaitEachGesture
                    }
                    down.consume()
                    val baseS = curStart
                    val baseE = curEnd
                    dragState(true)
                    try {
                        drag(down.id) { ch ->
                            ch.consume()
                            val dMs = (ch.position.x - x) / pxPerMs
                            if (left) ts(baseS + dMs) else te(baseE + dMs)
                        }
                    } finally { dragState(false) }
                }
            },
    ) {
        // thumbnail: tiap potongan membentang rata di seluruh durasi
        Row(Modifier.fillMaxSize()) {
            thumbs.forEach { b ->
                Box(Modifier.weight(1f).fillMaxHeight()) {
                    if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                }
            }
        }
        // bagian yang dibuang digelapkan
        Box(
            Modifier.fillMaxHeight()
                .width(with(density) { (startMs * pxPerMs).coerceAtLeast(0f).toDp() })
                .background(scrim),
        )
        Box(
            Modifier.offset { IntOffset((endMs * pxPerMs).roundToInt(), 0) }
                .fillMaxHeight()
                .width(with(density) { ((durMs - endMs) * pxPerMs).coerceAtLeast(0f).toDp() })
                .background(scrim),
        )
        // bingkai rentang yang dipertahankan
        Box(
            Modifier.offset { IntOffset((startMs * pxPerMs).roundToInt(), 0) }
                .width(with(density) { ((endMs - startMs) * pxPerMs).coerceAtLeast(0f).toDp() })
                .fillMaxHeight()
                .border(2.dp, edge, shape),
        )
        // handle kiri / kanan: pegangan putih dengan garis grip gelap
        Box(
            Modifier.offset { IntOffset((startMs * pxPerMs).roundToInt(), 0) }
                .width(HANDLE_W).fillMaxHeight()
                .background(edge, RoundedCornerShape(topStart = 8.dp, bottomStart = 8.dp)),
            contentAlignment = Alignment.Center,
        ) { Box(Modifier.width(2.dp).height(18.dp).background(Color(0xFF0B0B0B), RoundedCornerShape(1.dp))) }
        Box(
            Modifier.offset { IntOffset((endMs * pxPerMs).roundToInt() - handlePx, 0) }
                .width(HANDLE_W).fillMaxHeight()
                .background(edge, RoundedCornerShape(topEnd = 8.dp, bottomEnd = 8.dp)),
            contentAlignment = Alignment.Center,
        ) { Box(Modifier.width(2.dp).height(18.dp).background(Color(0xFF0B0B0B), RoundedCornerShape(1.dp))) }
    }
}

@Composable
private fun TouchRow(touches: List<TouchEvent>, pxPerMs: Float) {
    val dot = MaterialTheme.colorScheme.tertiary
    Box(Modifier.fillMaxWidth().height(H_TOUCH)) {
        Canvas(Modifier.fillMaxWidth().fillMaxHeight()) {
            val r = 2.dp.toPx()
            for (e in touches) {
                drawCircle(
                    color = if (e.kind == TouchLog.TEXT) dot.copy(alpha = 0.55f) else dot,
                    radius = r,
                    center = Offset(e.tMs * pxPerMs, size.height / 2f),
                )
            }
        }
    }
}

private enum class Grab { MOVE, LEFT, RIGHT }
private class Hit(val region: ZoomRegion, val grab: Grab)

private fun hitTest(list: List<ZoomRegion>, ms: Float, edgeMs: Float): Hit? {
    for (r in list) {
        if (ms < r.startMs || ms > r.endMs) continue
        val e = min(edgeMs, (r.endMs - r.startMs) / 3f)
        return when {
            ms <= r.startMs + e -> Hit(r, Grab.LEFT)
            ms >= r.endMs - e -> Hit(r, Grab.RIGHT)
            else -> Hit(r, Grab.MOVE)
        }
    }
    return null
}

@Composable
private fun ZoomRow(
    zooms: List<ZoomRegion>, durMs: Long, pxPerMs: Float, selectedId: Int?, selectedKey: Long?, enabled: Boolean,
    onSelect: (Int?) -> Unit, onSelectKey: (Int, Long?) -> Unit, onZooms: (List<ZoomRegion>) -> Unit,
    onDragState: (Boolean) -> Unit,
) {
    val density = LocalDensity.current
    val dragState by rememberUpdatedState(onDragState)
    val zl by rememberUpdatedState(zooms)
    val select by rememberUpdatedState(onSelect)
    val selectKey by rememberUpdatedState(onSelectKey)
    val change by rememberUpdatedState(onZooms)
    val edgePx = with(density) { HANDLE_W.toPx() }
    val keyHitPx = with(density) { 16.dp.toPx() }

    Box(
        Modifier.fillMaxWidth().height(H_ZOOM)
            .pointerInput(pxPerMs, durMs, enabled) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    // 1) keyframe (diamond) didahulukan: ketuk = pilih, geser = ubah waktunya
                    var keyHit: Pair<ZoomRegion, ZoomKey>? = null
                    var keyDist = keyHitPx
                    for (r in zl) {
                        for (k in r.liveKeys()) {
                            val d = abs(k.tMs * pxPerMs - down.position.x)
                            if (d <= keyDist) { keyDist = d; keyHit = r to k }
                        }
                    }
                    if (keyHit != null) {
                        val (kr, kk) = keyHit
                        select(kr.id)
                        selectKey(kr.id, kk.tMs)
                        if (!enabled) return@awaitEachGesture
                        down.consume()
                        val x0 = down.position.x
                        var curT = kk.tMs
                        dragState(true)
                        try { drag(down.id) { ch ->
                            ch.consume()
                            val cur = zl
                            val reg = cur.firstOrNull { it.id == kr.id } ?: return@drag
                            val others = reg.liveKeys().filter { it.tMs != curT }
                            val lo = (others.filter { it.tMs < curT }.maxOfOrNull { it.tMs } ?: reg.startMs) + ZoomMath.KEY_GAP_MS
                            val hi = (others.filter { it.tMs > curT }.minOfOrNull { it.tMs } ?: reg.endMs) - ZoomMath.KEY_GAP_MS
                            if (hi < lo) return@drag
                            val newT = (kk.tMs + ((ch.position.x - x0) / pxPerMs).toLong()).coerceIn(lo, hi)
                            if (newT != curT) {
                                change(ZoomOps.moveKey(cur, kr.id, curT, newT))
                                selectKey(kr.id, newT)
                                curT = newT
                            }
                        } } finally { dragState(false) }
                        return@awaitEachGesture
                    }
                    // 2) blok zoom
                    val hit = hitTest(zl, down.position.x / pxPerMs, edgePx / pxPerMs)
                    if (hit == null) {
                        val up = waitForUpOrCancellation()
                        if (up != null) select(null)
                        return@awaitEachGesture
                    }
                    select(hit.region.id)
                    if (!enabled) return@awaitEachGesture
                    down.consume()
                    val x0 = down.position.x
                    val base = hit.region
                    dragState(true)
                    try {
                        drag(down.id) { ch ->
                            ch.consume()
                            val dMs = ((ch.position.x - x0) / pxPerMs).toLong()
                            val cur = zl
                            change(
                                when (hit.grab) {
                                    Grab.MOVE -> ZoomOps.move(cur, base.id, base.startMs + dMs, durMs)
                                    Grab.LEFT -> ZoomOps.resizeStart(cur, base.id, base.startMs + dMs)
                                    Grab.RIGHT -> ZoomOps.resizeEnd(cur, base.id, base.endMs + dMs, durMs)
                                },
                            )
                        }
                    } finally { dragState(false) }
                }
            },
    ) {
        zooms.forEach { r ->
            key(r.id) { ZoomBlock(r, pxPerMs, selected = r.id == selectedId, selectedKey = if (r.id == selectedId) selectedKey else null) }
        }
        if (zooms.isEmpty()) {
            Text(
                "Belum ada zoom", fontSize = 10.sp, maxLines = 1,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                modifier = Modifier.align(Alignment.CenterStart).padding(start = 4.dp),
            )
        }
    }
}

/**
 * Tampilan saja; semua gestur ditangani [ZoomRow].
 * Tidak dipilih: blok berwarna dengan label kecil. Dipilih: bingkai putih dengan pegangan di kedua sisi (seperti klip terpilih di CapCut).
 */
@Composable
private fun ZoomBlock(r: ZoomRegion, pxPerMs: Float, selected: Boolean, selectedKey: Long?) {
    val density = LocalDensity.current
    val cs = MaterialTheme.colorScheme
    val blockW = with(density) { ((r.endMs - r.startMs) * pxPerMs).coerceAtLeast(0f).toDp() }
    val hp = if (selected) minOf(HANDLE_W, blockW * 0.25f) else 0.dp
    val outer = RoundedCornerShape(8.dp)
    val inner = RoundedCornerShape(if (selected) 4.dp else 8.dp)
    val ink = Color(0xFF0B0B0B)
    Box(
        Modifier.offset { IntOffset((r.startMs * pxPerMs).roundToInt(), 0) }
            .width(blockW)
            .fillMaxHeight()
            .padding(vertical = 1.dp)
            .then(if (selected) Modifier.background(Color.White, outer) else Modifier),
    ) {
        Box(
            Modifier.fillMaxSize()
                .padding(horizontal = hp, vertical = if (selected) 2.dp else 0.dp)
                .background(cs.primary.copy(alpha = if (selected) 1f else 0.75f), inner)
                .clip(inner),
            contentAlignment = Alignment.CenterStart,
        ) {
            // label kecil: "Zoom 2.0×" (+ A kalau otomatis)
            Box(
                Modifier.padding(start = 6.dp)
                    .background(ink.copy(alpha = 0.18f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 5.dp, vertical = 2.dp),
            ) {
                Text(
                    "%.1f×".format(r.scale) + if (r.auto) " · Auto" else "",
                    fontSize = 10.sp, maxLines = 1, softWrap = false, color = cs.onPrimary,
                )
            }
        }
        if (selected) {
            // garis grip gelap di tengah tiap pegangan putih
            Box(Modifier.align(Alignment.CenterStart).width(hp).fillMaxHeight(), contentAlignment = Alignment.Center) {
                Box(Modifier.width(2.dp).height(14.dp).background(ink, RoundedCornerShape(1.dp)))
            }
            Box(Modifier.align(Alignment.CenterEnd).width(hp).fillMaxHeight(), contentAlignment = Alignment.Center) {
                Box(Modifier.width(2.dp).height(14.dp).background(ink, RoundedCornerShape(1.dp)))
            }
        }
        // keyframe titik sorot: diamond di waktunya masing-masing
        val half = with(density) { 5.dp.roundToPx() }
        for (k in r.liveKeys()) {
            val on = k.tMs == selectedKey
            Box(
                Modifier.align(Alignment.CenterStart)
                    .offset { IntOffset(((k.tMs - r.startMs) * pxPerMs).roundToInt() - half, 0) }
                    .size(10.dp).rotate(45f)
                    .background(if (on) Color.White else Color.White.copy(alpha = 0.85f))
                    .border(if (on) 2.dp else 1.dp, if (on) LayKitGradient.Deep else ink.copy(alpha = 0.5f)),
            )
        }
    }
}
