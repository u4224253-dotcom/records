@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)

package com.laykit

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontVariation
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/*
 * Halaman Pengaturan, mengikuti desain "LayKit · Layar utama" (sheet pengaturan):
 * tile pilihan bergaya kartu, kartu toggle dengan lencana ikon, pil "Aktifkan", catatan kunci saat merekam.
 * Font: Plus Jakarta Sans (SIL OFL 1.1).
 */

internal val Jakarta = FontFamily(
    listOf(200, 400, 500, 600, 700).map { w ->
        Font(R.font.plus_jakarta_sans, FontWeight(w), variationSettings = FontVariation.Settings(FontVariation.weight(w)))
    },
)

/** Warna desain (token --bg, --surf, --raise, --hi, --line, --text, --mute, --pri, ...). */
internal class DC(dark: Boolean) {
    val bg = if (dark) Color(0xFF09090B) else Color(0xFFF2F3F6)
    val surf = if (dark) Color(0xFF121215) else Color(0xFFFFFFFF)
    val raise = if (dark) Color(0xFF1A1A1F) else Color(0xFFEAECF0)
    val hi = if (dark) Color(0xFF26262D) else Color(0xFFDADDE3)
    val line = if (dark) Color.White.copy(alpha = .07f) else Color(0xFF0A0C14).copy(alpha = .08f)
    val text = if (dark) Color(0xFFF4F4F6) else Color(0xFF0E1014)
    val mute = if (dark) Color(0xFF8C8C97) else Color(0xFF6A6F7A)
    val pri = if (dark) Color(0xFF6AA6FF) else Color(0xFF0A4DF0)
    val priSoft = pri.copy(alpha = if (dark) .14f else .10f)
    val priInk = if (dark) Color(0xFF001A4D) else Color.White
    val err = if (dark) Color(0xFFFF6369) else Color(0xFFE5484D)
}

// ---------- ikon (data dari desain, viewBox 24x24, garis 1.7 bulat) ----------

internal sealed class Pr
internal class PPath(val d: String) : Pr()
internal class PRect(val x: Float, val y: Float, val w: Float, val h: Float, val r: Float) : Pr()
internal class PCircle(val cx: Float, val cy: Float, val r: Float) : Pr()

private object Ic {
    val ORI_AUTO = listOf(PPath("M20 12a8 8 0 0 1-14 5.3M4 12a8 8 0 0 1 14-5.3"), PPath("M18 3v4h-4M6 21v-4h4"))
    val ORI_P = listOf(PRect(7f, 3f, 10f, 18f, 2.5f))
    val ORI_L = listOf(PRect(3f, 7f, 18f, 10f, 2.5f))
    val SPK = listOf(PPath("M4 9.5v5h3.5L12 18.5v-13L7.5 9.5H4Z"), PPath("M15.5 9a4.5 4.5 0 0 1 0 6M18 6.5a8 8 0 0 1 0 11"))
    val MIC = listOf(PRect(9f, 3f, 6f, 11f, 3f), PPath("M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21"))
    val TMR = listOf(PCircle(12f, 13f, 7.5f), PPath("M12 9v4l2.5 1.5M9.5 2.8h5"))
    val TCH = listOf(
        PPath("M9 11V5.5a1.5 1.5 0 0 1 3 0V11"),
        PPath("M12 10V9a1.5 1.5 0 0 1 3 0v1.5a1.5 1.5 0 0 1 3 0V15a6 6 0 0 1-6 6h-.5a6 6 0 0 1-5-2.7L4.5 14a1.5 1.5 0 0 1 2.5-1.7L9 14.5V11"),
    )
    val LOCK = listOf(PRect(5f, 11f, 14f, 9f, 2.5f), PPath("M8 11V8a4 4 0 0 1 8 0v3"))
    val CLOSE = listOf(PPath("m6 6 12 12M18 6 6 18"))
    val CHK = listOf(PPath("m5 12.5 4.5 4.5L19 7.5"))
    val TICK = listOf(PPath("m6 12.5 4 4 8-9"))
    val VIDEO = listOf(PRect(3f, 6f, 13f, 12f, 3f), PPath("m16 10.5 5-3v9l-5-3"))
    val NOTE = listOf(PPath("M9 18V6l10-2v12"), PCircle(6f, 18f, 3f), PCircle(16f, 16f, 3f))
}

@Composable
internal fun DIcon(prims: List<Pr>, color: Color, size: Dp = 20.dp, stroke: Float = 1.7f) {
    val paths = remember(prims) { prims.map { if (it is PPath) PathParser().parsePathString(it.d).toPath() else null } }
    Canvas(Modifier.size(size)) {
        val st = Stroke(width = stroke, cap = StrokeCap.Round, join = StrokeJoin.Round)
        scale(this.size.width / 24f, pivot = Offset.Zero) {
            prims.forEachIndexed { i, p ->
                when (p) {
                    is PPath -> drawPath(paths[i]!!, color, style = st)
                    is PRect -> drawRoundRect(color, Offset(p.x, p.y), Size(p.w, p.h), CornerRadius(p.r), style = st)
                    is PCircle -> drawCircle(color, p.r, Offset(p.cx, p.cy), style = st)
                }
            }
        }
    }
}

@Composable
internal fun T(
    text: String, size: Float, weight: Int, color: Color, modifier: Modifier = Modifier,
    spacing: Float = 0f, lineHeight: Float? = null, align: TextAlign? = null,
) {
    Text(
        text, modifier,
        style = TextStyle(
            fontFamily = Jakarta, fontSize = size.sp, fontWeight = FontWeight(weight), color = color,
            letterSpacing = spacing.sp, lineHeight = (lineHeight ?: (size * 1.4f)).sp, textAlign = align ?: TextAlign.Unspecified,
        ),
    )
}

// ---------- komponen ----------

@Composable
private fun SectionLabel(c: DC, title: String, right: String? = null) {
    Row(
        Modifier.fillMaxWidth().padding(start = 4.dp, end = 4.dp, top = 20.dp, bottom = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom,
    ) {
        T(title, 13f, 700, c.text)
        if (right != null) T(right, 12f, 500, c.mute)
    }
}

@Composable
private fun Tiles(content: @Composable (Modifier) -> Unit) {
    // semua tile satu baris sama tinggi, lebar dibagi rata, jarak 8dp
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        content(Modifier.weight(1f).fillMaxHeight())
    }
}

@Composable
private fun Tile(
    c: DC, selected: Boolean, enabled: Boolean, modifier: Modifier, minHeight: Dp = 0.dp,
    onClick: () -> Unit, content: @Composable () -> Unit,
) {
    val shape = RoundedCornerShape(18.dp)
    val bg by animateColorAsState(if (selected) c.priSoft else c.surf, label = "tileBg")
    val bd by animateColorAsState(if (selected) c.pri else c.line, label = "tileBd")
    Box(
        modifier.heightIn(min = minHeight).clip(shape).background(bg).border(1.5.dp, bd, shape)
            .clickable(enabled = enabled, onClick = onClick),
    ) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 12.dp).align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp, Alignment.CenterVertically),
        ) { content() }
        if (selected) {
            Box(
                Modifier.align(Alignment.TopEnd).padding(7.dp).size(16.dp).clip(CircleShape).background(c.pri),
                contentAlignment = Alignment.Center,
            ) { DIcon(Ic.TICK, Color.White, 11.dp, 3.2f) }
        }
    }
}

@Composable
private fun TextTile(c: DC, sel: Boolean, en: Boolean, mod: Modifier, title: String, sub: String?, big: Boolean = false, onClick: () -> Unit) {
    Tile(c, sel, en, mod, if (big) 72.dp else 0.dp, onClick) {
        T(title, 15f, 700, c.text, spacing = -.2f, align = TextAlign.Center)
        if (sub != null) T(sub, 11.5f, 400, c.mute, align = TextAlign.Center)
    }
}

@Composable
private fun IconTile(c: DC, sel: Boolean, en: Boolean, mod: Modifier, icon: List<Pr>, title: String, sub: String? = null, onClick: () -> Unit) {
    Tile(c, sel, en, mod, 0.dp, onClick) {
        Box(Modifier.padding(bottom = 3.dp)) { DIcon(icon, if (sel) c.pri else c.mute, 24.dp) }
        T(title, 15f, 700, c.text, spacing = -.2f, align = TextAlign.Center)
        if (sub != null) T(sub, 11.5f, 400, c.mute, align = TextAlign.Center)
    }
}

/** Pratinjau tema: kotak mini dengan blok biru dan satu garis teks. */
@Composable
private fun ThemeTile(c: DC, sel: Boolean, mod: Modifier, kind: ThemeMode, title: String, onClick: () -> Unit) {
    val dark = Color(0xFF09090B); val light = Color(0xFFF2F3F6)
    val shape = RoundedCornerShape(11.dp)
    val bgBrush = when (kind) {
        ThemeMode.SYSTEM -> Brush.horizontalGradient(0f to dark, .5f to dark, .5f to light, 1f to light)
        ThemeMode.LIGHT -> Brush.horizontalGradient(listOf(light, light))
        ThemeMode.DARK -> Brush.horizontalGradient(listOf(dark, dark))
    }
    val bar = when (kind) {
        ThemeMode.SYSTEM -> Color(0x807F7F87)
        ThemeMode.LIGHT -> Color(0xFF0A0C14).copy(alpha = .18f)
        ThemeMode.DARK -> Color.White.copy(alpha = .16f)
    }
    Tile(c, sel, true, mod, 0.dp, onClick) {
        Column(
            Modifier.fillMaxWidth().height(58.dp).clip(shape).background(bgBrush).border(1.dp, Color(0x4D7F7F87), shape).padding(7.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Box(
                Modifier.fillMaxWidth().height(20.dp).clip(RoundedCornerShape(5.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF0762FF), Color(0xFF0A39F2)))),
            )
            Box(Modifier.fillMaxWidth(.7f).height(6.dp).clip(RoundedCornerShape(3.dp)).background(bar))
        }
        Spacer(Modifier.height(3.dp))
        T(title, 15f, 700, c.text, spacing = -.2f)
    }
}

@Composable
private fun Card(c: DC, content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(c.surf)
            .border(1.dp, c.line, RoundedCornerShape(20.dp)).padding(horizontal = 14.dp),
    ) { content() }
}

@Composable
private fun Item(
    c: DC, icon: List<Pr>, on: Boolean, title: String, sub: String, first: Boolean, locked: Boolean = false,
    trailing: @Composable () -> Unit,
) {
    val line = c.line
    Row(
        Modifier.fillMaxWidth().heightIn(min = 66.dp).alpha(if (locked) .4f else 1f)
            .drawBehind { if (!first) drawLine(line, Offset(50.dp.toPx(), 0f), Offset(size.width, 0f), 1.dp.toPx()) },
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(if (on) c.priSoft else c.raise),
            contentAlignment = Alignment.Center,
        ) { DIcon(icon, if (on) c.pri else c.mute, 20.dp) }
        Column(Modifier.weight(1f)) {
            T(title, 14f, 600, c.text)
            T(sub, 12f, 400, c.mute, lineHeight = 15.6f)
        }
        trailing()
    }
}

@Composable
private fun Toggle(c: DC, on: Boolean, enabled: Boolean, label: String, onChange: (Boolean) -> Unit) {
    val track by animateColorAsState(if (on) c.pri else c.hi, label = "tg")
    val x by animateDpAsState(if (on) 20.dp else 0.dp, label = "tgx")
    Box(
        Modifier.size(48.dp, 28.dp).clip(CircleShape).background(track)
            .toggleable(value = on, enabled = enabled, role = Role.Switch, onValueChange = onChange)
            .padding(3.dp),
    ) {
        Box(Modifier.offset(x = x).size(22.dp).shadow(2.dp, CircleShape).background(Color.White, CircleShape))
    }
}

@Composable
private fun Permit(c: DC, ok: Boolean, onAsk: () -> Unit) {
    if (ok) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            DIcon(Ic.CHK, c.pri, 20.dp)
            T("Aktif", 13f, 600, c.pri)
        }
    } else {
        Box(
            Modifier.height(32.dp).clip(CircleShape).background(c.pri).clickable(onClick = onAsk).padding(horizontal = 15.dp),
            contentAlignment = Alignment.Center,
        ) { T("Aktifkan", 13f, 700, c.priInk) }
    }
}

// ---------- sheet ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun SettingsSheet(
    onClose: () -> Unit,
    themeMode: ThemeMode, onTheme: (ThemeMode) -> Unit,
    res: Int, onRes: (Int) -> Unit,
    orient: Int, onOrient: (Int) -> Unit,
    fps: Int, onFps: (Int) -> Unit,
    internal: Boolean, onInternal: (Boolean) -> Unit,
    mic: Boolean, onMic: (Boolean) -> Unit,
    audioOnly: Boolean, onAudioOnly: (Boolean) -> Unit,
    enabled: Boolean,
    overlayOk: Boolean, onAskOverlay: () -> Unit,
    touchOk: Boolean, onAskTouch: () -> Unit,
) {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val c = remember(dark) { DC(dark) }
    val locked = !enabled
    val lockedAlpha = if (locked) .4f else 1f
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onClose,
        sheetState = state,
        containerColor = c.bg,
        scrimColor = Color.Black.copy(alpha = .55f),
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        dragHandle = null,
    ) {
        val line = c.line
        Column(Modifier.fillMaxWidth().drawBehind { drawLine(line, Offset(0f, 0f), Offset(size.width, 0f), 1.dp.toPx()) }) {
            // header
            Row(
                Modifier.fillMaxWidth().padding(start = 22.dp, end = 16.dp, top = 18.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    T("Pengaturan", 20f, 700, c.text, spacing = -.2f)
                    T("Perekaman dan tampilan LayKit", 12.5f, 400, c.mute)
                }
                Box(
                    Modifier.size(34.dp).clip(CircleShape).background(c.raise).clickable(onClick = onClose),
                    contentAlignment = Alignment.Center,
                ) { DIcon(Ic.CLOSE, c.mute, 20.dp) }
            }

            Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 22.dp)) {
                if (locked) {
                    Row(
                        Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 2.dp).clip(RoundedCornerShape(16.dp)).background(c.priSoft)
                            .padding(horizontal = 14.dp, vertical = 11.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        DIcon(Ic.LOCK, c.pri, 20.dp)
                        T("Pengaturan video dan audio terkunci selama merekam", 12.5f, 500, c.pri)
                    }
                }

                SectionLabel(c, "Tampilan")
                Tiles { m ->
                    ThemeTile(c, themeMode == ThemeMode.SYSTEM, m, ThemeMode.SYSTEM, "Sistem") { onTheme(ThemeMode.SYSTEM) }
                    ThemeTile(c, themeMode == ThemeMode.LIGHT, m, ThemeMode.LIGHT, "Terang") { onTheme(ThemeMode.LIGHT) }
                    ThemeTile(c, themeMode == ThemeMode.DARK, m, ThemeMode.DARK, "Gelap") { onTheme(ThemeMode.DARK) }
                }

                // mode rekam (fitur audio MP3), gaya sama dengan tile lain
                SectionLabel(c, "Mode rekam", if (audioOnly) "Audio .mp3" else "Video .mp4")
                Box(Modifier.alpha(lockedAlpha)) {
                    Tiles { m ->
                        IconTile(c, !audioOnly, enabled, m, Ic.VIDEO, "Video", "Layar jadi .mp4") { onAudioOnly(false) }
                        IconTile(c, audioOnly, enabled, m, Ic.NOTE, "Audio MP3", "Suara saja jadi .mp3") { onAudioOnly(true) }
                    }
                }

                if (!audioOnly) {
                    SectionLabel(c, "Video", (if (res > 0) "${res}p" else "Asli") + " · $fps fps")
                    Column(Modifier.alpha(lockedAlpha)) {
                        Tiles { m ->
                            TextTile(c, res == 720, enabled, m, "720p", "HD", true) { onRes(720) }
                            TextTile(c, res == 1080, enabled, m, "1080p", "Full HD", true) { onRes(1080) }
                            TextTile(c, res == 0, enabled, m, "Asli", "Layar penuh", true) { onRes(0) }
                        }
                        Spacer(Modifier.height(8.dp))
                        Tiles { m ->
                            TextTile(c, fps == 30, enabled, m, "30 fps", "Standar, hemat ruang") { onFps(30) }
                            TextTile(c, fps == 60, enabled, m, "60 fps", "Gerakan lebih mulus") { onFps(60) }
                        }
                    }

                    SectionLabel(c, "Orientasi")
                    Box(Modifier.alpha(lockedAlpha)) {
                        Tiles { m ->
                            IconTile(c, orient == 0, enabled, m, Ic.ORI_AUTO, "Auto") { onOrient(0) }
                            IconTile(c, orient == 1, enabled, m, Ic.ORI_P, "Potret") { onOrient(1) }
                            IconTile(c, orient == 2, enabled, m, Ic.ORI_L, "Lanskap") { onOrient(2) }
                        }
                    }
                }

                SectionLabel(c, "Audio")
                Card(c) {
                    Item(c, Ic.SPK, internal, "Audio internal", "Suara dari dalam HP", first = true, locked = locked) {
                        Toggle(c, internal, enabled, "Audio internal", onInternal)
                    }
                    Item(c, Ic.MIC, mic, "Mikrofon", "Suara dari sekitarmu", first = false, locked = locked) {
                        Toggle(c, mic, enabled, "Mikrofon", onMic)
                    }
                }

                SectionLabel(c, "Fitur tambahan")
                Card(c) {
                    Item(c, Ic.TMR, overlayOk, "Hitung mundur 3-2-1", "Perlu tampil di atas app lain", first = true) {
                        Permit(c, overlayOk, onAskOverlay)
                    }
                    Item(c, Ic.TCH, touchOk, "Pencatat sentuhan", "Dasar zoom otomatis di editor", first = false) {
                        Permit(c, touchOk, onAskTouch)
                    }
                }

                T(
                    "Ikon HUD: Solar Icon Set oleh 480 Design (CC BY 4.0)\nEncoder MP3: LAME (LGPL) · Font: Plus Jakarta Sans (OFL)",
                    11f, 400, c.mute, Modifier.fillMaxWidth().padding(start = 4.dp, end = 4.dp, top = 18.dp), align = TextAlign.Center,
                )
            }
        }
    }
}
