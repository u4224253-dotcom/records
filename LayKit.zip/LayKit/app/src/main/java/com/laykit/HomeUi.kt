@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)

package com.laykit

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/*
 * Halaman utama, mengikuti desain "LayKit · Layar utama":
 * kartu hero biru (header + jam + tombol rekam jadi satu), tab Rekaman | Project berbentuk kapsul,
 * daftar baris dengan thumbnail 66x44, tombol edit berlatar lembut dan menu titik tiga.
 * Token warna dan font memakai yang sama dengan SettingsSheet (DC, Jakarta).
 */

private const val STAR = "M50 4C54 32 68 46 96 50 68 54 54 68 50 96 46 68 32 54 4 50 32 46 46 32 50 4Z"

/** Warna gradasi thumbnail (dari desain), dipakai berurutan per baris. */
private val ThumbColors = listOf(
    Color(0xFF0A2FF0) to Color(0xFF00A8FF),
    Color(0xFF7C3AED) to Color(0xFFEC4899),
    Color(0xFF059669) to Color(0xFF22D3EE),
    Color(0xFFF97316) to Color(0xFFDB2777),
    Color(0xFF1E293B) to Color(0xFF64748B),
)

private object HIc {
    val SETTINGS = listOf(PPath("M4 7h9M17 7h3M4 17h3M11 17h9"), PCircle(15f, 7f, 2f), PCircle(9f, 17f, 2f))
    val EDIT = listOf(PPath("M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16v4Z"))
    val SHARE = listOf(PPath("M12 15V4M8 8l4-4 4 4"), PPath("M5 12v5a3 3 0 0 0 3 3h8a3 3 0 0 0 3-3v-5"))
    val DEL = listOf(PPath("M4 7h16M9 7V4.5h6V7M6.5 7l1 13h9l1-13"))
    val CHV = listOf(PPath("m9 6 6 6-6 6"))
    val PLAY = listOf(PPath("M8 5v14l11-7Z"))
    val NOTE = listOf(PPath("M9 18V6l10-2v12"), PCircle(6f, 18f, 3f), PCircle(16f, 16f, 3f))
}

/** Teks dengan font desain; mendukung satu baris + elipsis untuk nama file. */
@Composable
private fun Tx(
    text: String, size: Float, weight: Int, color: Color, modifier: Modifier = Modifier,
    spacing: Float = 0f, lineHeight: Float? = null, align: TextAlign? = null,
    maxLines: Int = Int.MAX_VALUE, overflow: TextOverflow = TextOverflow.Clip,
) {
    Text(
        text, modifier, maxLines = maxLines, overflow = overflow,
        style = TextStyle(
            fontFamily = Jakarta, fontSize = size.sp, fontWeight = FontWeight(weight), color = color,
            letterSpacing = spacing.sp, lineHeight = (lineHeight ?: (size * 1.4f)).sp,
            textAlign = align ?: TextAlign.Unspecified,
        ),
    )
}

/** Ikon HUD: kapsul dengan satu titik isi. */
@Composable
private fun HudGlyph(color: Color, size: Dp = 20.dp) {
    Canvas(Modifier.size(size)) {
        scale(this.size.width / 24f, pivot = Offset.Zero) {
            drawRoundRect(
                color, Offset(2.5f, 8f), Size(19f, 8f), CornerRadius(4f),
                style = Stroke(1.7f, cap = StrokeCap.Round, join = StrokeJoin.Round),
            )
            drawCircle(color, 1.5f, Offset(7.5f, 12f))
        }
    }
}

/** Ikon titik tiga horizontal. */
@Composable
private fun MoreGlyph(color: Color, size: Dp = 20.dp) {
    Canvas(Modifier.size(size)) {
        scale(this.size.width / 24f, pivot = Offset.Zero) {
            drawCircle(color, 1.3f, Offset(5f, 12f))
            drawCircle(color, 1.3f, Offset(12f, 12f))
            drawCircle(color, 1.3f, Offset(19f, 12f))
        }
    }
}

// ======================================================================================
// HERO
// ======================================================================================

@Composable
internal fun HomeHero(
    phase: Phase, seconds: Int, msg: String?, summary: String, land: Boolean,
    onToggle: () -> Unit, onHud: () -> Unit, onSettings: () -> Unit, onSummary: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val on = phase == Phase.RECORDING || phase == Phase.PAUSED
    val cd = phase == Phase.COUNTDOWN
    val label = when (phase) {
        Phase.IDLE -> "Siap"
        Phase.COUNTDOWN -> "Bersiap"
        Phase.RECORDING -> "Merekam"
        Phase.PAUSED -> "Dijeda"
        Phase.SAVING -> "Menyimpan"
    }
    val big = when (phase) {
        Phase.IDLE -> "00:00"
        Phase.COUNTDOWN -> "$seconds"
        else -> "%02d:%02d".format(seconds / 60, seconds % 60)
    }
    val star = remember { PathParser().parsePathString(STAR).toPath() }
    val overlay by animateFloatAsState(if (on) 0.55f else 0f, tween(700), label = "heroOverlay")
    val shape = RoundedCornerShape(32.dp)

    Box(
        modifier.clip(shape).drawBehind {
            val w = size.width
            val h = size.height
            // dasar: gradasi diagonal biru
            drawRect(
                Brush.linearGradient(
                    0f to Color(0xFF0762FF), 0.7f to Color(0xFF0A39F2), 1f to Color(0xFF0A39F2),
                    start = Offset(w * 0.32f, 0f), end = Offset(w * 0.68f, h),
                ),
            )
            // kilau biru tua di kiri bawah
            drawRect(
                Brush.radialGradient(
                    listOf(Color(0xF2081EE6), Color.Transparent),
                    center = Offset(0f, h), radius = maxOf(w * 0.9f, h * 0.7f) * 0.62f,
                ),
            )
            // kilau cyan di kanan atas
            drawRect(
                Brush.radialGradient(
                    listOf(Color(0x8000ECFF), Color.Transparent),
                    center = Offset(w, 0f), radius = maxOf(w * 1.1f, h * 0.75f) * 0.58f,
                ),
            )
            // bintang putih transparan di pojok kanan bawah
            val s = 300.dp.toPx()
            val tx = w - s + 70.dp.toPx()
            val ty = h - s + 60.dp.toPx()
            withTransform({
                translate(tx, ty)
                rotate(-12f, Offset(s / 2f, s / 2f))
                scale(s / 100f, s / 100f, Offset.Zero)
            }) { drawPath(star, Color.White.copy(alpha = 0.07f)) }
            // saat merekam: layar menggelap
            if (overlay > 0f) {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF050B2E), Color(0xFF0A1560))), alpha = overlay)
            }
            // garis cahaya tipis di tepi atas
            drawRoundRect(
                Brush.verticalGradient(0f to Color.White.copy(alpha = 0.28f), 0.15f to Color.Transparent, 1f to Color.Transparent),
                topLeft = Offset(0.5f, 0.5f), size = Size(w - 1f, h - 1f),
                cornerRadius = CornerRadius(32.dp.toPx()), style = Stroke(1.dp.toPx()),
            )
        },
    ) {
        Column(Modifier.fillMaxSize()) {
            // ---- header: logo, nama, HUD, pengaturan ----
            Row(
                Modifier.fillMaxWidth().padding(start = 18.dp, end = 14.dp, top = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Image(painterResource(R.drawable.logo), contentDescription = "Logo LayKit", modifier = Modifier.size(40.dp))
                Column(Modifier.weight(1f)) {
                    Tx("LayKit", 17f, 700, Color.White, spacing = -0.2f, lineHeight = 20f)
                    if (!land) Tx("Rekam, edit, zoom otomatis", 12f, 400, Color.White.copy(alpha = 0.78f), lineHeight = 16f)
                }
                Row(
                    Modifier.height(38.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.14f))
                        .border(1.dp, Color.White.copy(alpha = 0.22f), CircleShape)
                        .clickable(role = Role.Button, onClick = onHud)
                        .padding(start = 11.dp, end = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    HudGlyph(Color.White)
                    Tx("HUD", 13f, 600, Color.White)
                }
                Box(
                    Modifier.size(38.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.14f))
                        .border(1.dp, Color.White.copy(alpha = 0.22f), CircleShape)
                        .semantics { contentDescription = "Pengaturan" }
                        .clickable(role = Role.Button, onClick = onSettings),
                    contentAlignment = Alignment.Center,
                ) { DIcon(HIc.SETTINGS, Color.White, 20.dp) }
            }

            // ---- tengah: jam, status, tombol rekam, ringkasan ----
            Column(
                Modifier.weight(1f).fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                val timeSize = if (cd) (if (land) 54f else 72f) else (if (land) 46f else 64f)
                TimeText(big, timeSize, if (cd) 0f else -2f)
                Spacer(Modifier.height(if (land) 6.dp else 10.dp))
                // pil status
                Row(
                    Modifier.height(26.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.12f)).padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(7.dp),
                ) {
                    StateDot(on)
                    Tx(label, 12f, 600, Color.White)
                }
                Spacer(Modifier.height(if (land) 12.dp else 18.dp))
                RecButton(on = on, enabled = phase != Phase.SAVING, land = land, onClick = onToggle)
                Spacer(Modifier.height(if (land) 10.dp else 16.dp))
                // ringkasan pengaturan: ketuk untuk membuka Pengaturan
                Row(
                    Modifier.clip(CircleShape).clickable(role = Role.Button, onClick = onSummary).padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Tx(summary, 12.5f, 500, Color.White.copy(alpha = 0.8f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    DIcon(HIc.CHV, Color.White.copy(alpha = 0.8f), 14.dp)
                }
                msg?.let {
                    Spacer(Modifier.height(4.dp))
                    Tx(
                        it, 12f, 500, Color.White.copy(alpha = 0.9f), Modifier.padding(horizontal = 24.dp),
                        align = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
    }
}

/** Jam besar: setiap digit di slot lebar tetap supaya angka tidak bergeser saat berganti. */
@Composable
private fun TimeText(text: String, sizeSp: Float, spacing: Float) {
    val density = LocalDensity.current
    val digitW = with(density) { (sizeSp.sp * 0.62f).toDp() }
    val colonW = with(density) { (sizeSp.sp * 0.3f).toDp() }
    val rowH = with(density) { (sizeSp.sp * 1.03f).toDp() }
    Row(Modifier.height(rowH), verticalAlignment = Alignment.CenterVertically) {
        text.forEach { ch ->
            if (ch == ':') {
                Box(Modifier.width(colonW).offset(y = (-8).dp), contentAlignment = Alignment.Center) {
                    Tx(":", sizeSp, 200, Color.White.copy(alpha = 0.5f), spacing = spacing, lineHeight = sizeSp)
                }
            } else {
                Box(Modifier.width(digitW), contentAlignment = Alignment.Center) {
                    Tx(ch.toString(), sizeSp, 200, Color.White, spacing = spacing, lineHeight = sizeSp)
                }
            }
        }
    }
}

@Composable
private fun StateDot(on: Boolean) {
    if (on) PulsingDot() else Box(Modifier.size(7.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.7f)))
}

@Composable
private fun PulsingDot() {
    val p = rememberInfiniteTransition(label = "dot").animateFloat(
        0f, 1f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "pulse",
    )
    Box(
        Modifier.size(7.dp).drawBehind {
            val t = p.value
            val ring = (3.5.dp + 3.dp * t).toPx()
            drawCircle(Color(0xFFFF5A4E).copy(alpha = 0.3f * (1f - t)), ring)
            drawCircle(Color(0xFFFF5A4E), 3.5.dp.toPx())
        },
    )
}

/** Tombol rekam: lingkaran merah yang mengecil jadi kotak saat merekam, dengan riak halus. */
@Composable
private fun RecButton(on: Boolean, enabled: Boolean, land: Boolean, onClick: () -> Unit) {
    val outer = if (land) 76.dp else 92.dp
    val idleInner = if (land) 52.dp else 62.dp
    val inner by animateDpAsState(if (on) 28.dp else idleInner, tween(300), label = "recInner")
    val corner by animateDpAsState(if (on) 8.dp else idleInner / 2, tween(300), label = "recCorner")
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val press by animateFloatAsState(if (pressed && enabled) 0.96f else 1f, label = "recPress")

    Box(
        Modifier.size(outer).alpha(if (enabled) 1f else 0.4f).graphicsLayer { scaleX = press; scaleY = press },
        contentAlignment = Alignment.Center,
    ) {
        if (on) RecRipple(Modifier.matchParentSize())
        Box(
            Modifier.matchParentSize().clip(CircleShape).background(Color.White.copy(alpha = 0.14f))
                .border(1.5.dp, Color.White.copy(alpha = 0.4f), CircleShape)
                .semantics { contentDescription = if (on) "Berhenti rekam" else "Mulai rekam" }
                .clickable(interactionSource = src, indication = null, enabled = enabled, role = Role.Button, onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                Modifier.size(inner).clip(RoundedCornerShape(corner)).drawBehind {
                    drawRect(
                        Brush.radialGradient(
                            listOf(Color(0xFFFF8A7E), Color(0xFFFF453A), Color(0xFFD12A20)),
                            center = Offset(size.width * 0.3f, size.height * 0.15f),
                            radius = size.width * 1.1f,
                        ),
                    )
                },
            )
        }
    }
}

@Composable
private fun RecRipple(modifier: Modifier) {
    val t = rememberInfiniteTransition(label = "ripple").animateFloat(
        0f, 1f, infiniteRepeatable(tween(2000, easing = LinearOutSlowInEasing)), label = "rippleT",
    )
    Box(
        modifier.drawBehind {
            val p = t.value
            drawCircle(
                Color.White.copy(alpha = 0.3f * (1f - p)),
                radius = (size.width / 2f + 2.dp.toPx()) * (1f + 0.5f * p),
                style = Stroke(1.5.dp.toPx()),
            )
        },
    )
}

// ======================================================================================
// DAFTAR
// ======================================================================================

@Composable
internal fun HomeList(
    c: DC,
    recs: List<RecItem>,
    mediaOk: Boolean,
    onAllow: () -> Unit,
    onOpenRec: (Uri) -> Unit,
    onShare: (Uri) -> Unit,
    onDelete: (RecItem) -> Unit,
    tab: Int,
    onTab: (Int) -> Unit,
    projects: List<ProjectItem>,
    onOpenProject: (ProjectItem) -> Unit,
    onDeleteProject: (ProjectItem) -> Unit,
    land: Boolean,
    bottomInset: Dp,
    modifier: Modifier = Modifier,
) {
    val tabsShape = RoundedCornerShape(14.dp)
    val panel = if (land) RoundedCornerShape(22.dp) else RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)
    Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // tab Rekaman | Project
        Row(
            Modifier.fillMaxWidth().clip(tabsShape).background(c.surf).border(1.dp, c.line, tabsShape).padding(3.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            HomeTab(c, "Rekaman", recs.size, tab == 0, Modifier.weight(1f)) { onTab(0) }
            HomeTab(c, "Project", projects.size, tab == 1, Modifier.weight(1f)) { onTab(1) }
        }
        Box(Modifier.weight(1f).fillMaxWidth().clip(panel).background(c.surf).border(1.dp, c.line, panel)) {
            val pad = PaddingValues(bottom = bottomInset)
            if (tab == 1) {
                if (projects.isEmpty()) {
                    EmptyState(c, "Belum ada project", "Buka rekaman di editor lalu tekan Simpan.")
                } else {
                    LazyColumn(Modifier.fillMaxSize(), contentPadding = pad) {
                        itemsIndexed(projects, key = { _, p -> p.id }) { i, pr ->
                            val date = java.text.SimpleDateFormat("d MMM, HH:mm", java.util.Locale("id", "ID"))
                                .format(java.util.Date(pr.updatedAt))
                            HomeRow(
                                c = c, first = i == 0,
                                thumb = { HomeThumb(pr.videoUri, i + 2, pr.durationMs, false) },
                                title = pr.name,
                                sub = if (pr.videoOk) "${pr.zoomCount} zoom · $date" else "Video asli tidak ditemukan",
                                subError = !pr.videoOk,
                                editIcon = HIc.EDIT, editDesc = "Buka project", openEnabled = pr.videoOk,
                                onOpen = { onOpenProject(pr) },
                                onShare = null, deleteLabel = "Hapus project", onDelete = { onDeleteProject(pr) },
                            )
                        }
                    }
                }
            } else if (recs.isEmpty()) {
                EmptyState(c, "Belum ada rekaman", "Ketuk tombol rekam untuk mulai.", if (mediaOk) null else "Izinkan akses rekaman", onAllow)
            } else {
                LazyColumn(Modifier.fillMaxSize(), contentPadding = pad) {
                    itemsIndexed(recs, key = { _, r -> r.uri.toString() }) { i, rec ->
                        val size = if (rec.sizeBytes < 1024 * 1024) "${rec.sizeBytes / 1024} KB" else "${rec.sizeBytes / 1024 / 1024} MB"
                        HomeRow(
                            c = c, first = i == 0,
                            thumb = { HomeThumb(rec.uri, i, rec.durationMs, rec.isAudio) },
                            title = rec.name.substringBeforeLast('.'),
                            sub = (if (rec.isAudio) "MP3 · " else "") + Library.fmtTime(rec.durationMs) + " · " + size,
                            subError = false,
                            editIcon = if (rec.isAudio) HIc.PLAY else HIc.EDIT,
                            editDesc = if (rec.isAudio) "Putar" else "Edit", openEnabled = true,
                            onOpen = { onOpenRec(rec.uri) },
                            onShare = { onShare(rec.uri) }, deleteLabel = "Hapus", onDelete = { onDelete(rec) },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeTab(c: DC, label: String, count: Int, sel: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(11.dp)
    val bg by animateColorAsState(if (sel) c.raise else Color.Transparent, label = "tabBg")
    Row(
        modifier.height(34.dp).clip(shape).background(bg).clickable(role = Role.Tab, onClick = onClick),
        horizontalArrangement = Arrangement.spacedBy(7.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Tx(label, 13f, 600, if (sel) c.text else c.mute)
        Box(
            Modifier.widthIn(min = 20.dp).clip(CircleShape).background(if (sel) c.pri else c.raise).padding(horizontal = 6.dp, vertical = 1.dp),
            contentAlignment = Alignment.Center,
        ) { Tx("$count", 11f, 600, if (sel) c.priInk else c.mute, lineHeight = 15f) }
    }
}

@Composable
private fun EmptyState(c: DC, title: String, body: String, action: String? = null, onAction: () -> Unit = {}) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = 32.dp, vertical = 48.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp, Alignment.CenterVertically),
    ) {
        Tx(title, 14f, 700, c.text, align = TextAlign.Center)
        Tx(body, 14f, 400, c.mute, align = TextAlign.Center)
        if (action != null) {
            Spacer(Modifier.height(10.dp))
            Box(
                Modifier.height(30.dp).clip(CircleShape).background(c.priSoft).clickable(role = Role.Button, onClick = onAction).padding(horizontal = 14.dp),
                contentAlignment = Alignment.Center,
            ) { Tx(action, 13f, 600, c.pri) }
        }
    }
}

@Composable
private fun HomeRow(
    c: DC, first: Boolean, thumb: @Composable () -> Unit,
    title: String, sub: String, subError: Boolean,
    editIcon: List<Pr>, editDesc: String, openEnabled: Boolean, onOpen: () -> Unit,
    onShare: (() -> Unit)?, deleteLabel: String, onDelete: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth()
            .drawBehind {
                if (!first) drawLine(c.line, Offset(90.dp.toPx(), 0f), Offset(size.width - 12.dp.toPx(), 0f), 1.dp.toPx())
            }
            .clickable(enabled = openEnabled, onClick = onOpen)
            .padding(start = 12.dp, end = 10.dp, top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        thumb()
        Column(Modifier.weight(1f)) {
            Tx(title, 13.5f, 600, c.text, maxLines = 1, overflow = TextOverflow.Ellipsis, lineHeight = 19f)
            Tx(sub, 12f, 400, if (subError) c.err else c.mute, maxLines = 1, overflow = TextOverflow.Ellipsis, lineHeight = 16f)
        }
        Box(
            Modifier.size(36.dp).clip(CircleShape).background(if (openEnabled) c.priSoft else Color.Transparent)
                .semantics { contentDescription = editDesc }
                .clickable(enabled = openEnabled, role = Role.Button, onClick = onOpen),
            contentAlignment = Alignment.Center,
        ) { DIcon(editIcon, if (openEnabled) c.pri else c.mute, 20.dp) }
        MoreMenu(c, onShare, deleteLabel, onDelete)
    }
}

@Composable
private fun MoreMenu(c: DC, onShare: (() -> Unit)?, deleteLabel: String, onDelete: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        Box(
            Modifier.size(36.dp).clip(CircleShape)
                .semantics { contentDescription = "Lainnya" }
                .clickable(role = Role.Button) { open = true },
            contentAlignment = Alignment.Center,
        ) { MoreGlyph(c.mute) }
        DropdownMenu(
            expanded = open, onDismissRequest = { open = false },
            shape = RoundedCornerShape(16.dp), containerColor = c.hi,
        ) {
            Column(Modifier.widthIn(min = 164.dp).padding(5.dp)) {
                if (onShare != null) MenuItem(HIc.SHARE, "Bagikan", c.text) { open = false; onShare() }
                MenuItem(HIc.DEL, deleteLabel, c.err) { open = false; onDelete() }
            }
        }
    }
}

@Composable
private fun MenuItem(icon: List<Pr>, text: String, color: Color, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(40.dp).clip(RoundedCornerShape(11.dp)).clickable(role = Role.Button, onClick = onClick).padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        DIcon(icon, color, 20.dp)
        Tx(text, 14f, 500, color)
    }
}

/** Thumbnail 66x44: gradasi desain sebagai dasar, cuplikan video menimpa kalau sudah termuat, lencana durasi di kanan bawah. */
@Composable
private fun HomeThumb(uri: Uri, index: Int, durationMs: Long, audio: Boolean) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, uri, audio) {
        value = if (audio) null else withContext(Dispatchers.IO) { Library.thumbnail(ctx, uri) }
    }
    val (a, b) = ThumbColors[index % ThumbColors.size]
    val shape = RoundedCornerShape(10.dp)
    Box(
        Modifier.size(width = 66.dp, height = 44.dp).clip(shape)
            .background(Brush.linearGradient(listOf(a, b)))
            .border(1.dp, Color.White.copy(alpha = 0.12f), shape),
    ) {
        bmp?.let { Image(it.asImageBitmap(), null, Modifier.matchParentSize(), contentScale = ContentScale.Crop) }
        if (audio) Box(Modifier.matchParentSize(), contentAlignment = Alignment.Center) { DIcon(HIc.NOTE, Color.White.copy(alpha = 0.9f), 22.dp) }
        Box(
            Modifier.align(Alignment.BottomEnd).padding(3.dp).clip(RoundedCornerShape(5.dp))
                .background(Color.Black.copy(alpha = 0.55f)).padding(horizontal = 5.dp, vertical = 1.dp),
        ) { Tx(Library.fmtTime(durationMs), 9.5f, 600, Color.White, lineHeight = 13f) }
    }
}

// ======================================================================================
// DIALOG KONFIRMASI
// ======================================================================================

@Composable
internal fun HomeConfirmDialog(c: DC, title: String, text: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 26.dp).clip(shape).background(c.raise).border(1.dp, c.line, shape)
                .padding(start = 22.dp, end = 22.dp, top = 24.dp, bottom = 16.dp),
        ) {
            Tx(title, 17f, 700, c.text)
            Spacer(Modifier.height(6.dp))
            Tx(text, 14f, 400, c.mute, lineHeight = 20f)
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp, Alignment.End)) {
                DialogButton("Batal", c.text, onDismiss)
                DialogButton("Hapus", c.err, onConfirm)
            }
        }
    }
}

@Composable
private fun DialogButton(label: String, color: Color, onClick: () -> Unit) {
    Box(
        Modifier.height(38.dp).clip(CircleShape).clickable(role = Role.Button, onClick = onClick).padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) { Tx(label, 14f, 600, color) }
}
