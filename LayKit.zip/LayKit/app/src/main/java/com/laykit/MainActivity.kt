package com.laykit

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings as SettingsIcon
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    /** perintah dari HUD: "edit_last" = buka editor rekaman terakhir, "home" = layar utama */
    private val cmd = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        cmd.value = intent?.getStringExtra("cmd")
        setContent { Root(cmd) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        cmd.value = intent.getStringExtra("cmd")
    }
}

@Composable
private fun Root(cmd: MutableState<String?>) {
    val ctx = LocalContext.current
    var mode by remember { mutableStateOf(ThemePrefs.load(ctx)) }
    var editing by rememberSaveable { mutableStateOf<Uri?>(null) }
    var editingProj by rememberSaveable { mutableStateOf<String?>(null) }   // id project yang sedang dibuka (null = rekaman biasa)
    LaunchedEffect(cmd.value) {
        when (cmd.value) {
            "edit_last" -> {
                val u = withContext(Dispatchers.IO) { Library.list(ctx, 1).firstOrNull()?.uri }
                if (u != null) { editingProj = null; editing = u }
            }
            "home" -> { editing = null; editingProj = null }
        }
        cmd.value = null
    }
    LayKitTheme(mode) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            val e = editing
            if (e != null) {
                val pid = editingProj
                if (pid == null) {
                    EditorScreen(e) { editing = null }
                } else {
                    // muat project dulu (JSON kecil), baru buka editor dengan keadaan tersimpan
                    val loaded by produceState<Pair<Boolean, Project?>>(false to null, pid) {
                        value = true to withContext(Dispatchers.IO) { ProjectStore.load(ctx, pid) }
                    }
                    val proj = loaded.second
                    when {
                        proj != null -> EditorScreen(e, proj) { editing = null; editingProj = null }
                        loaded.first -> {
                            LaunchedEffect(Unit) {
                                Toast.makeText(ctx, "Project tidak bisa dibuka", Toast.LENGTH_SHORT).show()
                                editing = null; editingProj = null
                            }
                        }
                        else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            androidx.compose.material3.CircularProgressIndicator()
                        }
                    }
                }
            } else {
                HomeScreen(
                    themeMode = mode,
                    onTheme = { mode = it; ThemePrefs.save(ctx, it) },
                    onEdit = { editingProj = null; editing = it },
                    onOpenProject = { editingProj = it.id; editing = it.videoUri },
                )
            }
        }
    }
}

@Composable
private fun HomeScreen(themeMode: ThemeMode, onTheme: (ThemeMode) -> Unit, onEdit: (Uri) -> Unit, onOpenProject: (ProjectItem) -> Unit) {
    val ctx = LocalContext.current
    val ui by RecorderService.ui.collectAsState()

    val saved = remember { RecPrefs.load(ctx) }
    var res by remember { mutableIntStateOf(saved.res) }
    var fps by remember { mutableIntStateOf(saved.fps) }
    var orient by remember { mutableIntStateOf(saved.orient) }
    var internal by remember { mutableStateOf(saved.internal) }
    var mic by remember { mutableStateOf(saved.mic) }
    var audioOnly by remember { mutableStateOf(saved.audioOnly) }
    // HUD bisa mengubah pengaturan saat app di latar belakang: baca ulang tiap kembali ke app
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        val x = RecPrefs.load(ctx)
        res = x.res; fps = x.fps; orient = x.orient; internal = x.internal; mic = x.mic; audioOnly = x.audioOnly
    }
    LaunchedEffect(res, fps, orient, internal, mic, audioOnly) {
        RecPrefs.save(ctx, RecPrefs.load(ctx).copy(res = res, fps = fps, orient = orient, internal = internal, mic = mic, audioOnly = audioOnly))
    }
    var useInternal by remember { mutableStateOf(false) }   // hasil akhir setelah izin
    var useMic by remember { mutableStateOf(false) }
    var overlayOk by remember { mutableStateOf(Settings.canDrawOverlays(ctx)) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { overlayOk = Settings.canDrawOverlays(ctx) }
    var touchOk by remember { mutableStateOf(TouchService.isEnabled(ctx)) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { touchOk = TouchService.isEnabled(ctx) }

    val mediaPerms = if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    var recs by remember { mutableStateOf(emptyList<RecItem>()) }
    var tick by remember { mutableIntStateOf(0) }
    var mediaOk by remember { mutableStateOf(mediaPerms.all { granted(ctx, it) }) }
    val libPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { mediaOk = mediaPerms.all { p -> granted(ctx, p) }; tick++ }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { mediaOk = mediaPerms.all { granted(ctx, it) }; tick++ }
    LaunchedEffect(tick, ui.phase) {
        if (ui.phase == Phase.IDLE) recs = withContext(Dispatchers.IO) { Library.listAll(ctx) }
    }

    // ---- tab Rekaman | Project ----
    var listTab by rememberSaveable { mutableIntStateOf(0) }
    var projects by remember { mutableStateOf(emptyList<ProjectItem>()) }
    var pendingDeleteProj by remember { mutableStateOf<ProjectItem?>(null) }
    LaunchedEffect(tick) { projects = withContext(Dispatchers.IO) { ProjectStore.list(ctx) } }

    // ---- hapus rekaman: konfirmasi dulu; kalau file bukan milik app ini, sistem yang meminta izin ----
    val scope = rememberCoroutineScope()
    var pendingDelete by remember { mutableStateOf<RecItem?>(null) }
    var confirmingName by remember { mutableStateOf<String?>(null) }
    val delLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            confirmingName?.let { TouchLog.delete(ctx.filesDir, it) }
            Toast.makeText(ctx, "Rekaman dihapus", Toast.LENGTH_SHORT).show()
        }
        confirmingName = null
        tick++
    }
    fun deleteRec(item: RecItem) {
        scope.launch {
            when (val out = withContext(Dispatchers.IO) { Library.delete(ctx, item.uri) }) {
                is DeleteOutcome.Done -> {
                    recs = recs.filter { it.uri != item.uri }
                    Toast.makeText(ctx, "Rekaman dihapus", Toast.LENGTH_SHORT).show()
                }
                is DeleteOutcome.Confirm -> {
                    confirmingName = item.name
                    delLauncher.launch(IntentSenderRequest.Builder(out.sender).build())
                }
                is DeleteOutcome.Failed ->
                    Toast.makeText(ctx, "Gagal menghapus rekaman", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun launchRec(code: Int, data: Intent?) {
        ContextCompat.startForegroundService(
            ctx,
            Intent(ctx, RecorderService::class.java).setAction(RecorderService.A_START)
                .putExtra(RecorderService.X_CODE, code)
                .putExtra(RecorderService.X_DATA, data)
                .putExtra(RecorderService.X_RES, res)
                .putExtra(RecorderService.X_FPS, fps)
                .putExtra(RecorderService.X_ORIENT, orient)
                .putExtra(RecorderService.X_INTERNAL, useInternal)
                .putExtra(RecorderService.X_MIC, useMic)
                .putExtra(RecorderService.X_MIC_DEV, RecPrefs.load(ctx).micDev)
                .putExtra(RecorderService.X_AUDIO_ONLY, audioOnly),
        )
    }
    val projLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == Activity.RESULT_OK && data != null) launchRec(r.resultCode, data)
    }
    val askProjection = {
        projLauncher.launch(ctx.getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent())
    }
    // Mode audio saja: dialog rekam layar hanya perlu kalau audio internal dipakai; mikrofon saja langsung jalan.
    val proceed = {
        if (!audioOnly || useInternal) askProjection()
        else if (useMic) launchRec(0, null)
        else Toast.makeText(ctx, "Aktifkan audio internal atau mikrofon dulu", Toast.LENGTH_SHORT).show()
        Unit
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        val rec = granted(ctx, Manifest.permission.RECORD_AUDIO)
        useInternal = internal && rec
        useMic = mic && rec
        proceed()
    }

    fun start() {
        if (audioOnly && !internal && !mic) {
            Toast.makeText(ctx, "Aktifkan audio internal atau mikrofon dulu", Toast.LENGTH_SHORT).show()
            return
        }
        val need = mutableListOf<String>()
        if ((internal || mic) && !granted(ctx, Manifest.permission.RECORD_AUDIO)) need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 && !granted(ctx, Manifest.permission.POST_NOTIFICATIONS)) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isEmpty()) { useInternal = internal; useMic = mic; proceed() }
        else permLauncher.launch(need.toTypedArray())
    }

    val idle = ui.phase == Phase.IDLE
    var showSettings by remember { mutableStateOf(false) }

    val onToggle = {
        if (idle) start()
        else ctx.startService(Intent(ctx, RecorderService::class.java).setAction(RecorderService.A_STOP))
        Unit
    }

    // video -> editor; audio -> pemutar bawaan HP
    val openRec: (Uri) -> Unit = { u ->
        if (recs.firstOrNull { it.uri == u }?.isAudio == true) Library.play(ctx, u) else onEdit(u)
    }

    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val c = remember(dark) { DC(dark) }
    val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    // tombol HUD: minta izin "tampil di atas app lain" dulu, kalau sudah ada baru tampilkan HUD dan minimalkan app
    val openHud: () -> Unit = {
        if (!Settings.canDrawOverlays(ctx)) {
            ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
        } else {
            ContextCompat.startForegroundService(ctx, Intent(ctx, HudService::class.java).setAction(HudService.A_SHOW))
            (ctx as? Activity)?.moveTaskToBack(true)
        }
    }

    // ringkasan di bawah tombol rekam, ketuk untuk membuka Pengaturan
    val audioLabel = when {
        internal && mic -> "Audio internal + mikrofon"
        internal -> "Audio internal"
        mic -> "Mikrofon"
        else -> "Tanpa audio"
    }
    val summary = if (audioOnly) "Audio MP3 · $audioLabel"
        else (if (res > 0) "${res}p" else "Resolusi asli") + " · $fps fps · $audioLabel"

    BoxWithConstraints(Modifier.fillMaxSize().background(c.bg)) {
        val land = maxWidth > maxHeight
        val hero: @Composable (Modifier) -> Unit = { m ->
            HomeHero(
                phase = ui.phase, seconds = ui.seconds, msg = ui.msg, summary = summary, land = land,
                onToggle = onToggle, onHud = openHud, onSettings = { showSettings = true }, onSummary = { showSettings = true },
                modifier = m,
            )
        }
        val list: @Composable (Modifier, Dp) -> Unit = { m, bottom ->
            HomeList(
                c = c, recs = recs, mediaOk = mediaOk, onAllow = { libPerm.launch(mediaPerms) },
                onOpenRec = openRec, onShare = { Library.share(ctx, it) }, onDelete = { pendingDelete = it },
                tab = listTab, onTab = { listTab = it },
                projects = projects, onOpenProject = onOpenProject, onDeleteProject = { pendingDeleteProj = it },
                land = land, bottomInset = bottom, modifier = m,
            )
        }
        if (land) {
            Row(
                Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars).padding(10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                hero(Modifier.weight(0.44f).fillMaxHeight())
                list(Modifier.weight(0.56f).fillMaxHeight(), 0.dp)
            }
        } else {
            Column(
                Modifier.fillMaxSize()
                    .windowInsetsPadding(WindowInsets.systemBars.only(WindowInsetsSides.Top + WindowInsetsSides.Horizontal))
                    .padding(start = 10.dp, end = 10.dp, top = 10.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                hero(Modifier.weight(0.54f).fillMaxWidth())
                list(Modifier.weight(0.46f).fillMaxWidth(), navBottom)
            }
        }
    }

    pendingDelete?.let { item ->
        HomeConfirmDialog(
            c, "Hapus rekaman?",
            "\"${item.name.substringBeforeLast('.')}\" akan dihapus permanen dan tidak bisa dikembalikan.",
            onConfirm = { pendingDelete = null; deleteRec(item) },
            onDismiss = { pendingDelete = null },
        )
    }

    pendingDeleteProj?.let { item ->
        HomeConfirmDialog(
            c, "Hapus project?",
            "\"${item.name}\" akan dihapus. Video rekaman aslinya tidak ikut terhapus.",
            onConfirm = {
                pendingDeleteProj = null
                projects = projects.filter { it.id != item.id }
                scope.launch(Dispatchers.IO) { ProjectStore.delete(ctx, item.id) }
                Toast.makeText(ctx, "Project dihapus", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { pendingDeleteProj = null },
        )
    }

    if (showSettings) {
        SettingsSheet(
            onClose = { showSettings = false },
            themeMode = themeMode, onTheme = onTheme,
            res = res, onRes = { res = it },
            orient = orient, onOrient = { orient = it },
            fps = fps, onFps = { fps = it },
            internal = internal, onInternal = { internal = it },
            mic = mic, onMic = { mic = it },
            audioOnly = audioOnly, onAudioOnly = { audioOnly = it },
            enabled = idle,
            overlayOk = overlayOk,
            onAskOverlay = {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
            },
            touchOk = touchOk,
            onAskTouch = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
        )
    }
}


private fun granted(ctx: android.content.Context, p: String) =
    ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
