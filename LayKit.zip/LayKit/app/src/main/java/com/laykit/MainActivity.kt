package com.laykit

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Settings as SettingsIcon
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    /** perintah dari HUD: "edit_last" = buka editor rekaman terakhir, "home" = layar utama */
    private val cmd = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        cmd.value = intent?.getStringExtra("cmd")
        setContent { Root(cmd) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        cmd.value = intent.getStringExtra("cmd")
    }
}

@Composable
private fun Root(cmd: MutableState<String?>) {
    val ctx = LocalContext.current
    var mode by remember { mutableStateOf(ThemePrefs.load(ctx)) }
    var editing by rememberSaveable { mutableStateOf<Uri?>(null) }
    var editingProj by rememberSaveable { mutableStateOf<String?>(null) }   // id project yang sedang dibuka (null = rekaman biasa)
    LaunchedEffect(cmd.value) {
        when (cmd.value) {
            "edit_last" -> {
                val u = withContext(Dispatchers.IO) { Library.list(ctx, 1).firstOrNull()?.uri }
                if (u != null) { editingProj = null; editing = u }
            }
            "home" -> { editing = null; editingProj = null }
        }
        cmd.value = null
    }
    LayKitTheme(mode) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            val e = editing
            if (e != null) {
                val pid = editingProj
                if (pid == null) {
                    EditorScreen(e) { editing = null }
                } else {
                    // muat project dulu (JSON kecil), baru buka editor dengan keadaan tersimpan
                    val loaded by produceState<Pair<Boolean, Project?>>(false to null, pid) {
                        value = true to withContext(Dispatchers.IO) { ProjectStore.load(ctx, pid) }
                    }
                    val proj = loaded.second
                    when {
                        proj != null -> EditorScreen(e, proj) { editing = null; editingProj = null }
                        loaded.first -> {
                            LaunchedEffect(Unit) {
                                Toast.makeText(ctx, "Project tidak bisa dibuka", Toast.LENGTH_SHORT).show()
                                editing = null; editingProj = null
                            }
                        }
                        else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            androidx.compose.material3.CircularProgressIndicator()
                        }
                    }
                }
            } else {
                HomeScreen(
                    themeMode = mode,
                    onTheme = { mode = it; ThemePrefs.save(ctx, it) },
                    onEdit = { editingProj = null; editing = it },
                    onOpenProject = { editingProj = it.id; editing = it.videoUri },
                )
            }
        }
    }
}

@Composable
private fun HomeScreen(themeMode: ThemeMode, onTheme: (ThemeMode) -> Unit, onEdit: (Uri) -> Unit, onOpenProject: (ProjectItem) -> Unit) {
    val ctx = LocalContext.current
    val ui by RecorderService.ui.collectAsState()

    val saved = remember { RecPrefs.load(ctx) }
    var res by remember { mutableIntStateOf(saved.res) }
    var fps by remember { mutableIntStateOf(saved.fps) }
    var orient by remember { mutableIntStateOf(saved.orient) }
    var internal by remember { mutableStateOf(saved.internal) }
    var mic by remember { mutableStateOf(saved.mic) }
    // HUD bisa mengubah pengaturan saat app di latar belakang: baca ulang tiap kembali ke app
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        val x = RecPrefs.load(ctx)
        res = x.res; fps = x.fps; orient = x.orient; internal = x.internal; mic = x.mic
    }
    LaunchedEffect(res, fps, orient, internal, mic) {
        RecPrefs.save(ctx, RecPrefs.load(ctx).copy(res = res, fps = fps, orient = orient, internal = internal, mic = mic))
    }
    var useInternal by remember { mutableStateOf(false) }   // hasil akhir setelah izin
    var useMic by remember { mutableStateOf(false) }
    var overlayOk by remember { mutableStateOf(Settings.canDrawOverlays(ctx)) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { overlayOk = Settings.canDrawOverlays(ctx) }
    var touchOk by remember { mutableStateOf(TouchService.isEnabled(ctx)) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { touchOk = TouchService.isEnabled(ctx) }

    val mediaPerm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE
    var recs by remember { mutableStateOf(emptyList<RecItem>()) }
    var tick by remember { mutableIntStateOf(0) }
    var mediaOk by remember { mutableStateOf(granted(ctx, mediaPerm)) }
    val libPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { mediaOk = it; tick++ }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { mediaOk = granted(ctx, mediaPerm); tick++ }
    LaunchedEffect(tick, ui.phase) {
        if (ui.phase == Phase.IDLE) recs = withContext(Dispatchers.IO) { Library.list(ctx) }
    }

    // ---- tab Rekaman | Project ----
    var listTab by rememberSaveable { mutableIntStateOf(0) }
    var projects by remember { mutableStateOf(emptyList<ProjectItem>()) }
    var pendingDeleteProj by remember { mutableStateOf<ProjectItem?>(null) }
    LaunchedEffect(tick) { projects = withContext(Dispatchers.IO) { ProjectStore.list(ctx) } }

    // ---- hapus rekaman: konfirmasi dulu; kalau file bukan milik app ini, sistem yang meminta izin ----
    val scope = rememberCoroutineScope()
    var pendingDelete by remember { mutableStateOf<RecItem?>(null) }
    var confirmingName by remember { mutableStateOf<String?>(null) }
    val delLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            confirmingName?.let { TouchLog.delete(ctx.filesDir, it) }
            Toast.makeText(ctx, "Rekaman dihapus", Toast.LENGTH_SHORT).show()
        }
        confirmingName = null
        tick++
    }
    fun deleteRec(item: RecItem) {
        scope.launch {
            when (val out = withContext(Dispatchers.IO) { Library.delete(ctx, item.uri) }) {
                is DeleteOutcome.Done -> {
                    recs = recs.filter { it.uri != item.uri }
                    Toast.makeText(ctx, "Rekaman dihapus", Toast.LENGTH_SHORT).show()
                }
                is DeleteOutcome.Confirm -> {
                    confirmingName = item.name
                    delLauncher.launch(IntentSenderRequest.Builder(out.sender).build())
                }
                is DeleteOutcome.Failed ->
                    Toast.makeText(ctx, "Gagal menghapus rekaman", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val projLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == Activity.RESULT_OK && data != null) {
            ContextCompat.startForegroundService(
                ctx,
                Intent(ctx, RecorderService::class.java).setAction(RecorderService.A_START)
                    .putExtra(RecorderService.X_CODE, r.resultCode)
                    .putExtra(RecorderService.X_DATA, data)
                    .putExtra(RecorderService.X_RES, res)
                    .putExtra(RecorderService.X_FPS, fps)
                    .putExtra(RecorderService.X_ORIENT, orient)
                    .putExtra(RecorderService.X_INTERNAL, useInternal)
                    .putExtra(RecorderService.X_MIC, useMic)
                    .putExtra(RecorderService.X_MIC_DEV, RecPrefs.load(ctx).micDev),
            )
        }
    }
    val askProjection = {
        projLauncher.launch(ctx.getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent())
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        val rec = granted(ctx, Manifest.permission.RECORD_AUDIO)
        useInternal = internal && rec
        useMic = mic && rec
        askProjection()
    }

    fun start() {
        val need = mutableListOf<String>()
        if ((internal || mic) && !granted(ctx, Manifest.permission.RECORD_AUDIO)) need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 && !granted(ctx, Manifest.permission.POST_NOTIFICATIONS)) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isEmpty()) { useInternal = internal; useMic = mic; askProjection() }
        else permLauncher.launch(need.toTypedArray())
    }

    val idle = ui.phase == Phase.IDLE
    var showSettings by remember { mutableStateOf(false) }

    val onToggle = {
        if (idle) start()
        else ctx.startService(Intent(ctx, RecorderService::class.java).setAction(RecorderService.A_STOP))
        Unit
    }

    BoxWithConstraints(Modifier.fillMaxSize().systemBarsPadding()) {
        val land = maxWidth > maxHeight
        Column(Modifier.fillMaxSize()) {
            // Kartu header bergradasi biru (warna mengikuti logo): logo + nama di kiri, aksi di kanan
            Box(
                Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 4.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(LayKitGradient.Deep, LayKitGradient.Mid, Color(0xFF0090FF)),
                            start = androidx.compose.ui.geometry.Offset(0f, 0f),
                            end = androidx.compose.ui.geometry.Offset(1100f, 500f),
                        ),
                    ),
            ) {
                // kilau cyan lembut di pojok kanan atas, seperti pada logo
                Box(
                    Modifier.matchParentSize().background(
                        Brush.radialGradient(
                            listOf(Color(0x5500F0FF), Color.Transparent),
                            center = androidx.compose.ui.geometry.Offset(Float.POSITIVE_INFINITY, 0f),
                            radius = 520f,
                        ),
                    ),
                )
                Row(
                    Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = if (land) 8.dp else 18.dp, bottom = if (land) 8.dp else 18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Image(
                        painterResource(R.drawable.logo),
                        contentDescription = "Logo LayKit",
                        modifier = Modifier.size(if (land) 40.dp else 48.dp),
                    )
                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                        Text("LayKit", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.White)
                        if (!land) Text("Rekam, edit, zoom otomatis", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.85f))
                    }
                    TextButton(onClick = {
                        if (!Settings.canDrawOverlays(ctx)) {
                            ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
                        } else {
                            ContextCompat.startForegroundService(ctx, Intent(ctx, HudService::class.java).setAction(HudService.A_SHOW))
                            (ctx as? Activity)?.moveTaskToBack(true)
                        }
                    }) { Text("HUD", color = Color.White, fontWeight = FontWeight.SemiBold) }
                    IconButton(onClick = { showSettings = true }) {
                        Icon(Icons.Default.SettingsIcon, contentDescription = "Pengaturan", tint = Color.White)
                    }
                }
            }
            if (land) {
                Row(Modifier.weight(1f).fillMaxWidth()) {
                    RecordPanel(ui.phase, ui.seconds, ui.msg, idle, onToggle, Modifier.weight(0.4f).fillMaxHeight())
                    RecList(
                        recs, mediaOk, { libPerm.launch(mediaPerm) }, onEdit, { Library.share(ctx, it) },
                        { pendingDelete = it },
                        listTab, { listTab = it }, projects, onOpenProject, { pendingDeleteProj = it },
                        Modifier.weight(0.6f).fillMaxHeight(),
                    )
                }
            } else {
                RecordPanel(ui.phase, ui.seconds, ui.msg, idle, onToggle, Modifier.weight(0.42f).fillMaxWidth())
                RecList(
                    recs, mediaOk, { libPerm.launch(mediaPerm) }, onEdit, { Library.share(ctx, it) },
                    { pendingDelete = it },
                    listTab, { listTab = it }, projects, onOpenProject, { pendingDeleteProj = it },
                    Modifier.weight(0.58f).fillMaxWidth(),
                )
            }
        }
    }

    pendingDelete?.let { item ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Hapus rekaman?") },
            text = { Text("\"${item.name.removeSuffix(".mp4")}\" akan dihapus permanen dan tidak bisa dikembalikan.") },
            confirmButton = {
                TextButton(onClick = { pendingDelete = null; deleteRec(item) }) {
                    Text("Hapus", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.SemiBold)
                }
            },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Batal") } },
        )
    }

    pendingDeleteProj?.let { item ->
        AlertDialog(
            onDismissRequest = { pendingDeleteProj = null },
            title = { Text("Hapus project?") },
            text = { Text("\"${item.name}\" akan dihapus. Video rekaman aslinya tidak ikut terhapus.") },
            confirmButton = {
                TextButton(onClick = {
                    pendingDeleteProj = null
                    projects = projects.filter { it.id != item.id }
                    scope.launch(Dispatchers.IO) { ProjectStore.delete(ctx, item.id) }
                    Toast.makeText(ctx, "Project dihapus", Toast.LENGTH_SHORT).show()
                }) { Text("Hapus", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.SemiBold) }
            },
            dismissButton = { TextButton(onClick = { pendingDeleteProj = null }) { Text("Batal") } },
        )
    }

    if (showSettings) {
        SettingsSheet(
            onClose = { showSettings = false },
            themeMode = themeMode, onTheme = onTheme,
            res = res, onRes = { res = it },
            orient = orient, onOrient = { orient = it },
            fps = fps, onFps = { fps = it },
            internal = internal, onInternal = { internal = it },
            mic = mic, onMic = { mic = it },
            enabled = idle,
            overlayOk = overlayOk,
            onAskOverlay = {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
            },
            touchOk = touchOk,
            onAskTouch = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
        )
    }
}

@Composable
private fun RecordPanel(phase: Phase, seconds: Int, msg: String?, idle: Boolean, onToggle: () -> Unit, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val mmss = "%02d:%02d".format(seconds / 60, seconds % 60)
    val big = when (phase) {
        Phase.IDLE -> "00:00"
        Phase.COUNTDOWN -> "$seconds"
        else -> mmss
    }
    val label = when (phase) {
        Phase.IDLE -> "Siap"
        Phase.COUNTDOWN -> "Bersiap"
        Phase.RECORDING -> "Merekam"
        Phase.PAUSED -> "Dijeda"
        Phase.SAVING -> "Menyimpan"
    }
    Box(
        modifier.padding(horizontal = 12.dp, vertical = 4.dp).clip(RoundedCornerShape(28.dp)).background(
            Brush.verticalGradient(listOf(LayKitGradient.Mid.copy(alpha = 0.16f), LayKitGradient.Light.copy(alpha = 0.04f))),
        ),
        contentAlignment = Alignment.Center,
    ) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(big, style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Light)
        Text(
            label,
            style = MaterialTheme.typography.labelLarge,
            color = if (phase == Phase.RECORDING) cs.error else cs.onSurfaceVariant,
        )
        Spacer(Modifier.height(24.dp))
        RecButton(idle = idle, enabled = phase != Phase.SAVING, onClick = onToggle)
        msg?.let {
            Spacer(Modifier.height(12.dp))
            Text(it, style = MaterialTheme.typography.bodySmall, color = cs.primary, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
    }
}

@Composable
private fun RecButton(idle: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val inner by animateDpAsState(if (idle) 58.dp else 28.dp, label = "inner")
    val corner by animateDpAsState(if (idle) 29.dp else 7.dp, label = "corner")
    Box(
        Modifier.size(82.dp).clip(CircleShape)
            .border(3.dp, if (enabled) LayKitGradient.diagonal else SolidColor(cs.onBackground.copy(alpha = 0.3f)), CircleShape)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.size(inner).clip(RoundedCornerShape(corner)).background(cs.error))
    }
}

@Composable
private fun RecList(
    recs: List<RecItem>,
    mediaOk: Boolean,
    onAllow: () -> Unit,
    onEdit: (Uri) -> Unit,
    onShare: (Uri) -> Unit,
    onDelete: (RecItem) -> Unit,
    tab: Int,
    onTab: (Int) -> Unit,
    projects: List<ProjectItem>,
    onOpenProject: (ProjectItem) -> Unit,
    onDeleteProject: (ProjectItem) -> Unit,
    modifier: Modifier,
) {
    val cs = MaterialTheme.colorScheme
    Column(modifier) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            ListTab("Rekaman", recs.size, tab == 0) { onTab(0) }
            ListTab("Project", projects.size, tab == 1) { onTab(1) }
        }
        if (tab == 1) {
            if (projects.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(horizontal = 32.dp), contentAlignment = Alignment.Center) {
                    Text(
                        "Belum ada project. Buka rekaman di editor lalu tekan Simpan.",
                        style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant,
                    )
                }
            } else {
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(projects, key = { it.id }) { pr ->
                        ProjectRow(pr, onOpen = { onOpenProject(pr) }, onDelete = { onDeleteProject(pr) })
                    }
                }
            }
        } else if (recs.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                if (!mediaOk) TextButton(onClick = onAllow) { Text("Izinkan akses rekaman") }
                else Text("Belum ada rekaman", style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
            }
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(recs, key = { it.uri.toString() }) { rec ->
                    RecRow(rec, onEdit = { onEdit(rec.uri) }, onShare = { onShare(rec.uri) }, onDelete = { onDelete(rec) })
                }
            }
        }
    }
}

@Composable
private fun RecRow(item: RecItem, onEdit: () -> Unit, onShare: () -> Unit, onDelete: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
            .background(Brush.horizontalGradient(listOf(LayKitGradient.Mid.copy(alpha = 0.12f), LayKitGradient.Light.copy(alpha = 0.03f))))
            .clickable(onClick = onEdit).padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Thumb(item.uri)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(item.name.removeSuffix(".mp4"), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                "${Library.fmtTime(item.durationMs)} · ${item.sizeBytes / 1024 / 1024} MB",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
            )
        }
        IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, contentDescription = "Edit", tint = cs.primary) }
        IconButton(onClick = onShare) { Icon(Icons.Default.Share, contentDescription = "Bagikan", tint = cs.primary) }
        IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = cs.error) }
    }
}

@Composable
private fun ListTab(label: String, count: Int, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onClick).padding(horizontal = 4.dp, vertical = 2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                label, style = MaterialTheme.typography.labelLarge,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                color = if (selected) cs.onBackground else cs.onSurfaceVariant,
            )
            Box(
                Modifier.padding(start = 6.dp).clip(RoundedCornerShape(50))
                    .background(if (selected) LayKitGradient.horizontal else SolidColor(cs.onBackground.copy(alpha = 0.12f)))
                    .padding(horizontal = 8.dp, vertical = 1.dp),
            ) {
                Text(
                    "$count", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold,
                    color = if (selected) Color.White else cs.onSurfaceVariant,
                )
            }
        }
        Box(
            Modifier.padding(top = 4.dp).fillMaxWidth().height(2.dp).clip(RoundedCornerShape(1.dp))
                .background(if (selected) LayKitGradient.horizontal else SolidColor(Color.Transparent)),
        )
    }
}

@Composable
private fun ProjectRow(item: ProjectItem, onOpen: () -> Unit, onDelete: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
            .background(Brush.horizontalGradient(listOf(LayKitGradient.Mid.copy(alpha = 0.12f), LayKitGradient.Light.copy(alpha = 0.03f))))
            .clickable(enabled = item.videoOk, onClick = onOpen).padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Thumb(item.videoUri)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(item.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (item.videoOk) {
                val date = java.text.SimpleDateFormat("d MMM, HH:mm", java.util.Locale("id", "ID")).format(java.util.Date(item.updatedAt))
                Text(
                    "${item.zoomCount} zoom · ${Library.fmtTime(item.durationMs)} · $date",
                    style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            } else {
                Text("Video asli tidak ditemukan", style = MaterialTheme.typography.bodySmall, color = cs.error)
            }
        }
        IconButton(onClick = onOpen, enabled = item.videoOk) { Icon(Icons.Default.Edit, contentDescription = "Buka project", tint = if (item.videoOk) cs.primary else cs.onSurfaceVariant) }
        IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = "Hapus project", tint = cs.error) }
    }
}

@Composable
private fun Thumb(uri: Uri) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, uri) { value = withContext(Dispatchers.IO) { Library.thumbnail(ctx, uri) } }
    Box(Modifier.size(56.dp).clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
        bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingsSheet(
    onClose: () -> Unit,
    themeMode: ThemeMode, onTheme: (ThemeMode) -> Unit,
    res: Int, onRes: (Int) -> Unit,
    orient: Int, onOrient: (Int) -> Unit,
    fps: Int, onFps: (Int) -> Unit,
    internal: Boolean, onInternal: (Boolean) -> Unit,
    mic: Boolean, onMic: (Boolean) -> Unit,
    enabled: Boolean,
    overlayOk: Boolean, onAskOverlay: () -> Unit,
    touchOk: Boolean, onAskTouch: () -> Unit,
) {
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onClose,
        sheetState = state,
        containerColor = MaterialTheme.colorScheme.surface,
    ) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            SetRow("Tampilan") {
                Seg(listOf("Sistem" to ThemeMode.SYSTEM, "Terang" to ThemeMode.LIGHT, "Gelap" to ThemeMode.DARK), themeMode, true, onTheme)
            }
            SetRow("Resolusi") { Seg(listOf("720p" to 720, "1080p" to 1080, "Asli" to 0), res, enabled, onRes) }
            SetRow("Orientasi") { Seg(listOf("Auto" to 0, "Potret" to 1, "Lanskap" to 2), orient, enabled, onOrient) }
            SetRow("Frame rate") { Seg(listOf("30" to 30, "60" to 60), fps, enabled, onFps) }
            SetRow("Audio internal") { Switch(checked = internal, onCheckedChange = onInternal, enabled = enabled) }
            SetRow("Mikrofon") { Switch(checked = mic, onCheckedChange = onMic, enabled = enabled) }
            if (!overlayOk) SetRow("Hitung mundur") { TextButton(onClick = onAskOverlay) { Text("Aktifkan") } }
            if (!touchOk) SetRow("Pencatat sentuhan") { TextButton(onClick = onAskTouch) { Text("Aktifkan") } }
            Text(
                "Ikon HUD: Solar Icon Set oleh 480 Design (CC BY 4.0)",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun SetRow(label: String, content: @Composable () -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 44.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, style = MaterialTheme.typography.bodyLarge)
        content()
    }
}

private fun granted(ctx: android.content.Context, p: String) =
    ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
