package com.laykit

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.IntentCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlin.concurrent.thread

/**
 * Mendengarkan AUDIO INTERNAL (suara yang diputar HP, mis. TikTok) lewat MediaProjection
 * dan mendeteksi BPM-nya. Tidak memakai mikrofon. Hasilnya ada di [bpm] (0 = belum ada ketukan).
 * Dinyalakan dari CaptureActivity (X_BPM) setelah izin rekam layar diberikan.
 */
class BpmService : Service() {

    companion object {
        val bpm = MutableStateFlow(0)
        val running = MutableStateFlow(false)
        private const val CH = "bpm"
        private const val NID = 3
        private const val SR = 44100
    }

    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    @Volatile private var gen = 0

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CH, "Deteksi BPM", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val data = intent?.let { IntentCompat.getParcelableExtra(it, RecorderService.X_DATA, Intent::class.java) }
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        if (running.value) return START_NOT_STICKY

        // Android 14+: startForeground bertipe mediaProjection HARUS dipanggil sebelum getMediaProjection
        ServiceCompat.startForeground(this, NID, notif(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        try {
            val mp = getSystemService(MediaProjectionManager::class.java)
                .getMediaProjection(intent.getIntExtra(RecorderService.X_CODE, 0), data)
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { main.post { stopSelf() } }
            }, main)
            projection = mp
            startListening(mp)
        } catch (e: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    @SuppressLint("MissingPermission")
    private fun startListening(mp: MediaProjection) {
        val my = ++gen
        running.value = true
        bpm.value = 0
        BpmWave.reset()
        thread(name = "bpm-internal") {
            var ar: AudioRecord? = null
            try {
                val fmt = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SR).setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build()
                val buf = maxOf(AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT) * 2, 16384)
                val pc = AudioPlaybackCaptureConfiguration.Builder(mp)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN).build()
                ar = AudioRecord.Builder().setAudioFormat(fmt).setBufferSizeInBytes(buf)
                    .setAudioPlaybackCaptureConfig(pc).build()
                if (ar.state != AudioRecord.STATE_INITIALIZED) return@thread
                ar.startRecording()

                // stereo 44,1 kHz -> mono 11,025 kHz (rata-rata 4 frame): cukup untuk ketukan, jauh lebih ringan
                val det = BpmDetector(SR / 4)
                val raw = ShortArray(4096)
                val mono = ShortArray(raw.size / 8 + 2)
                var sum = 0L; var cnt = 0
                val sliceLen = SR * 2 * LiveWave.SLICE_MS / 1000   // peak waveform: 1 irisan = 3 md (stereo berselang-seling)
                var lo = 0; var hi = 0; var pn = 0
                while (gen == my) {
                    val n = ar.read(raw, 0, raw.size)
                    if (n <= 0) break
                    var m = 0
                    for (k in 0 until n) {
                        val v = raw[k].toInt()
                        if (v < lo) lo = v
                        if (v > hi) hi = v
                        if (++pn >= sliceLen) { BpmWave.push(lo, hi); lo = 0; hi = 0; pn = 0 }
                        sum += raw[k]; cnt++
                        if (cnt == 8) { mono[m++] = (sum / 8).toShort(); sum = 0; cnt = 0 }
                    }
                    val r = det.feed(mono, m)
                    if (r != null) bpm.value = r
                }
            } catch (_: Exception) {
                // gagal membuka penangkap audio: berhenti
            } finally {
                try { ar?.stop() } catch (_: Exception) {}
                try { ar?.release() } catch (_: Exception) {}
                if (gen == my) main.post { stopSelf() }
            }
        }
    }

    override fun onDestroy() {
        gen++
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
        running.value = false
        bpm.value = 0
        BpmWave.reset()
        super.onDestroy()
    }

    private fun notif(): Notification =
        NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Deteksi BPM aktif")
            .setContentText("Mendengarkan audio internal")
            .setOngoing(true).setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
}
