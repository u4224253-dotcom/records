package com.laykit

import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/**
 * Pendeteksi BPM sederhana dari PCM mono 16-bit.
 *
 * Alur: energi per jendela kecil -> lonjakan energi (onset) -> autokorelasi 8 detik terakhir ->
 * lag terkuat di rentang 60..180 BPM -> median beberapa hasil terakhir supaya angkanya stabil.
 *
 * feed() mengembalikan: null = belum ada pembaruan, 0 = tidak ada ketukan terdeteksi, >0 = BPM.
 */
internal class BpmDetector(sampleRate: Int = 16000) {
    private val hop = (sampleRate / 62.5).toInt()      // ~62,5 jendela per detik berapa pun sample rate-nya
    private val fps = sampleRate.toDouble() / hop
    private val histLen = (fps * 8).toInt()
    private val minFrames = (fps * 4).toInt()          // butuh minimal 4 detik data
    private val every = (fps * 0.5).toInt()            // perkiraan baru tiap 0,5 detik
    private val lagMin = (fps * 60 / 180).toInt()
    private val lagMax = (fps * 60 / 60).toInt() + 1

    private val env = DoubleArray(histLen)
    private var filled = 0
    private var acc = 0.0
    private var accN = 0
    private var prevSample = 0.0
    private var prevE = 0.0
    private var since = 0
    private var misses = 0
    private val recent = ArrayList<Double>()

    fun feed(pcm: ShortArray, n: Int): Int? {
        var out: Int? = null
        for (i in 0 until n) {
            val x = pcm[i].toDouble()
            val y = x - 0.97 * prevSample          // pre-emphasis: tonjolkan bagian perkusif
            prevSample = x
            acc += y * y; accN++
            if (accN == hop) {
                val e = ln(1.0 + acc / hop)
                push(max(0.0, e - prevE))
                prevE = e; acc = 0.0; accN = 0
                if (++since >= every && filled >= minFrames) { since = 0; out = estimate() ?: out }
            }
        }
        return out
    }

    private fun push(v: Double) {
        System.arraycopy(env, 1, env, 0, histLen - 1)
        env[histLen - 1] = v
        if (filled < histLen) filled++
    }

    private fun estimate(): Int {
        val n = filled
        val x = DoubleArray(n) { env[histLen - n + it] }
        val mean = x.average()
        for (i in 0 until n) x[i] -= mean
        val r0 = x.sumOf { it * it }
        if (r0 / n < 0.01) return miss()           // nyaris diam

        // autokorelasi ternormalisasi sampai 3x lag terbesar (untuk kelipatan tempo)
        val maxL = min(3 * lagMax + 2, n - 2)
        val ac = DoubleArray(maxL + 2)
        ac[0] = 1.0
        for (l in 1..maxL) {
            var s = 0.0
            for (i in l until n) s += x[i] * x[i - l]
            ac[l] = s / r0
        }
        fun at(l: Double): Double {                // interpolasi linear: lag pecahan tidak jatuh di antara dua sel
            val i = l.toInt()
            if (i + 1 > maxL) return 0.0
            val f = l - i
            return ac[i] * (1 - f) + ac[i + 1] * f
        }

        // skor tiap kandidat tempo = kekuatan di 1x, 2x, 3x lag, dibobot condong ke tempo umum (cegah lompat oktaf)
        var best = -1.0; var bestScore = 0.0
        var lag = lagMin.toDouble()
        while (lag <= lagMax) {
            val bpm = 60.0 * fps / lag
            val z = ln(bpm / 130.0) / ln(2.0)
            val prior = exp(-0.5 * z * z)
            val s = (at(lag) + at(2 * lag) + (if (3 * lag < maxL) at(3 * lag) else 0.0)) / 3.0 * prior
            if (s > bestScore) { bestScore = s; best = lag }
            lag += 0.25
        }
        if (best < 0 || bestScore < 0.1) return miss()

        misses = 0
        recent.add(60.0 * fps / best)
        if (recent.size > 5) recent.removeAt(0)
        return Math.round(recent.sorted()[recent.size / 2]).toInt()
    }

    private fun miss(): Int {
        if (++misses >= 4) { recent.clear(); return 0 }
        return recent.takeIf { it.isNotEmpty() }?.sorted()?.let { Math.round(it[it.size / 2]).toInt() } ?: 0
    }
}
