package com.laykit

import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/**
 * Pendeteksi BPM sederhana dari PCM mono 16-bit.
 *
 * Alur: energi per jendela kecil -> lonjakan energi (onset) -> autokorelasi 8 detik terakhir ->
 * lag terkuat di rentang 60..180 BPM -> median beberapa hasil terakhir supaya angkanya stabil.
 *
 * feed() mengembalikan: null = belum ada pembaruan, 0 = tidak ada ketukan terdeteksi, >0 = BPM.
 */
internal class BpmDetector(sampleRate: Int = 16000) {
    private val hop = 256
    private val fps = sampleRate.toDouble() / hop
    private val histLen = (fps * 8).toInt()
    private val minFrames = (fps * 4).toInt()          // butuh minimal 4 detik data
    private val every = (fps * 0.5).toInt()            // perkiraan baru tiap 0,5 detik
    private val lagMin = (fps * 60 / 180).toInt()
    private val lagMax = (fps * 60 / 60).toInt() + 1

    private val env = DoubleArray(histLen)
    private var filled = 0
    private var acc = 0.0
    private var accN = 0
    private var prevSample = 0.0
    private var prevE = 0.0
    private var since = 0
    private var misses = 0
    private val recent = ArrayList<Double>()

    fun feed(pcm: ShortArray, n: Int): Int? {
        var out: Int? = null
        for (i in 0 until n) {
            val x = pcm[i].toDouble()
            val y = x - 0.97 * prevSample          // pre-emphasis: tonjolkan bagian perkusif
            prevSample = x
            acc += y * y; accN++
            if (accN == hop) {
                val e = ln(1.0 + acc / hop)
                push(max(0.0, e - prevE))
                prevE = e; acc = 0.0; accN = 0
                if (++since >= every && filled >= minFrames) { since = 0; out = estimate() ?: out }
            }
        }
        return out
    }

    private fun push(v: Double) {
        System.arraycopy(env, 1, env, 0, histLen - 1)
        env[histLen - 1] = v
        if (filled < histLen) filled++
    }

    private fun estimate(): Int {
        val n = filled
        val x = DoubleArray(n) { env[histLen - n + it] }
        val mean = x.average()
        for (i in 0 until n) x[i] -= mean
        val r0 = x.sumOf { it * it }
        if (r0 / n < 0.01) return miss()           // nyaris diam

        fun r(lag: Int): Double {
            var s = 0.0
            for (i in lag until n) s += x[i] * x[i - lag]
            return s / r0
        }
        val hi = min(lagMax, n / 2)
        val ac = DoubleArray(hi + 2) { if (it < lagMin) 0.0 else r(it) }
        var best = -1; var bestScore = 0.0
        for (lag in lagMin..hi) {
            val bpm = 60.0 * fps / lag
            val prior = 1.0 - 0.25 * abs(ln(bpm / 120.0) / ln(2.0))   // condong ke tempo umum, hindari lompat oktaf
            val s = (ac[lag] + 0.5 * (if (lag * 2 < n) r(lag * 2) else 0.0)) * prior
            if (s > bestScore) { bestScore = s; best = lag }
        }
        if (best < 0 || bestScore < 0.2) return miss()

        // interpolasi parabola supaya lebih halus dari sekadar bilangan bulat lag
        var lag = best.toDouble()
        if (best > lagMin && best < hi) {
            val a = ac[best - 1]; val b = ac[best]; val c = ac[best + 1]
            val d = a - 2 * b + c
            if (d != 0.0) lag += 0.5 * (a - c) / d
        }
        misses = 0
        recent.add(60.0 * fps / lag)
        if (recent.size > 5) recent.removeAt(0)
        return recent.sorted()[recent.size / 2].let { Math.round(it).toInt() }
    }

    private fun miss(): Int {
        if (++misses >= 4) { recent.clear(); return 0 }
        return recent.takeIf { it.isNotEmpty() }?.sorted()?.let { Math.round(it[it.size / 2]).toInt() } ?: 0
    }
}
