package com.laykit

import android.graphics.Bitmap
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.net.Uri
import android.view.Surface
import android.view.TextureView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicBoolean

private val PRESETS = listOf(
    0xFF1E3A8A.toInt() to 0xFF7C3AED.toInt(),   // biru-ungu
    0xFFF97316.toInt() to 0xFFDB2777.toInt(),   // sunset
    0xFF059669.toInt() to 0xFF0E7490.toInt(),   // tosca
    0xFF0F172A.toInt() to 0xFF334155.toInt(),   // malam
    0xFFF8FAFC.toInt() to 0xFFCBD5E1.toInt(),   // terang
    0xFF000000.toInt() to 0xFF000000.toInt(),   // hitam
)

private val SOLIDS = listOf(
    0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFF0F172A.toInt(), 0xFF1E293B.toInt(),
    0xFFEF4444.toInt(), 0xFFF97316.toInt(), 0xFFEAB308.toInt(), 0xFF22C55E.toInt(),
    0xFF06B6D4.toInt(), 0xFF3B82F6.toInt(), 0xFF8B5CF6.toInt(), 0xFFEC4899.toInt(),
)

// wallpaper "mesh": warna dasar, warna tengah, warna sudut bawah
private val WALLS = listOf(
    Triple(0xFF0B1026.toInt(), 0xFF22D3AE.toInt(), 0xFF7C3AED.toInt()),   // aurora
    Triple(0xFF2B1055.toInt(), 0xFFFB7185.toInt(), 0xFFFBBF24.toInt()),   // senja
    Triple(0xFF03045E.toInt(), 0xFF0096C7.toInt(), 0xFF90E0EF.toInt()),   // laut
    Triple(0xFF111827.toInt(), 0xFFF472B6.toInt(), 0xFF38BDF8.toInt()),   // neon
    Triple(0xFF052E16.toInt(), 0xFF16A34A.toInt(), 0xFFA3E635.toInt()),   // hutan
    Triple(0xFFFDE68A.toInt(), 0xFFF9A8D4.toInt(), 0xFFA5B4FC.toInt()),   // pastel
)

/** Wallpaper foto bawaan (res/raw/wallpaper1..18.jpg), diambil dari Openscreen (MIT), diperkecil ke 1600 px. */
private const val WALLPAPER_COUNT = 18

private fun wallpaperUri(ctx: android.content.Context, n: Int): Uri =
    Uri.parse("android.resource://${ctx.packageName}/raw/wallpaper$n")

@Composable
private fun WallThumb(ctx: android.content.Context, uri: Uri, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val bmp by produceState<Bitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) { Exporter.loadImage(ctx, uri, 160) }
    }
    val shape = RoundedCornerShape(10.dp)
    Box(
        Modifier.size(width = 72.dp, height = 46.dp).clip(shape)
            .background(Color.Gray.copy(alpha = 0.3f))
            .clickable(enabled = enabled, onClick = onClick),
    ) {
        bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        if (selected) Box(Modifier.matchParentSize().border(3.dp, MaterialTheme.colorScheme.primary, shape))
    }
}

/** Kotak "tambah dari galeri" di tab Foto: setinggi dua baris foto (46 + 8 + 46). */
@Composable
private fun GalleryTile(enabled: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier.size(width = 72.dp, height = 100.dp).clip(RoundedCornerShape(10.dp)).background(cs.surfaceVariant)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { ToolIcon(ICON_PLUS, cs.onBackground, 22.dp) }
}

/** Contoh warna untuk tile filter (sama dengan SAMPLE di desain). */
private val LOOK_SAMPLE = Brush.verticalGradient(
    0f to Color(0xFFFDA4AF), 0.35f to Color(0xFFFCD34D), 0.65f to Color(0xFF86EFAC), 1f to Color(0xFF7DD3FC),
)

/** Tile filter: contoh warna yang sudah diberi filter (intensitas 60%) + nama. */
@Composable
private fun LookTile(name: String, m: FloatArray?, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(10.dp)
    Column(
        Modifier.width(72.dp).alpha(if (enabled) 1f else 0.4f).clickable(enabled = enabled, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        Box(Modifier.size(width = 72.dp, height = 48.dp).clip(shape)) {
            Box(Modifier.matchParentSize().colorMatrixLayer(m?.let { Looks.colorMatrix20(it) }).background(LOOK_SAMPLE))
            if (selected) Box(Modifier.matchParentSize().border(3.dp, cs.primary, shape))
        }
        Text(name, fontSize = 11.sp, maxLines = 1, color = if (selected) cs.primary else cs.onSurfaceVariant)
    }
}

/** Kotak wallpaper "mesh" di tab Wallpaper: dua gradien radial di atas warna dasar (sama dengan desain). */
@Composable
private fun WallSwatch(w: Triple<Int, Int, Int>, selected: Boolean, enabled: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier.height(58.dp).clip(shape)
            .drawBehind {
                drawRect(Color(w.first))
                val c2x = size.width * 0.95f
                val c2y = size.height * 1.05f
                val r2 = kotlin.math.hypot(maxOf(c2x, size.width - c2x), maxOf(c2y, size.height - c2y)) * 0.55f
                drawRect(
                    Brush.radialGradient(listOf(Color(w.third), Color(w.third).copy(alpha = 0f)), center = Offset(c2x, c2y), radius = r2),
                )
                val c1x = size.width * 0.30f
                val c1y = size.height * 0.45f
                val r1 = kotlin.math.hypot(maxOf(c1x, size.width - c1x), maxOf(c1y, size.height - c1y)) * 0.60f
                drawRect(
                    Brush.radialGradient(listOf(Color(w.second), Color(w.second).copy(alpha = 0f)), center = Offset(c1x, c1y), radius = r1),
                )
            }
            .then(
                if (selected) Modifier.border(3.dp, cs.primary, shape)
                else Modifier.border(1.dp, Color.White.copy(alpha = 0.14f), shape),
            )
            .clickable(enabled = enabled, onClick = onClick),
    )
}

private val BG_TYPES = listOf("Gradient", "Warna", "Wallpaper", "Foto", "Blur")

private val ASPECTS = listOf<Pair<String, Float?>>(
    "Asli" to null, "16:9" to 16f / 9f, "9:16" to 9f / 16f, "1:1" to 1f, "4:5" to 4f / 5f,
)

private class PlayerState {
    var mp: MediaPlayer? = null
    var surface: Surface? = null
    var ready by mutableStateOf(false)
    var playing by mutableStateOf(false)
    /** Pesan kalau pemutar gagal (ditampilkan di editor), null = normal. */
    var failed by mutableStateOf<String?>(null)
    /** Play ditekan sebelum video siap: mulai otomatis begitu siap. */
    var playWhenReady = false
    /** Pemutaran sudah sampai habis (MediaPlayer ada di keadaan PlaybackCompleted). */
    var completed = false
    var positionMs by mutableLongStateOf(0L)
    /** Posisi pratinjau (ms) yang HALUS: diperbarui tiap frame layar lewat ekstrapolasi, dipakai zoom dan kursor. */
    var smoothMs by mutableFloatStateOf(0f)
    /**
     * Posisi yang DITENTUKAN pengguna saat jeda/scrub (ms), -1 = tidak ada. MediaPlayer.seekTo asinkron: selama seek berjalan,
     * currentPosition masih nilai lama, jadi playhead dan keyframe dulu ikut loncat ke nilai basi itu. Saat jeda, posisi kita
     * pegang sendiri dan TIDAK dibaca dari pemutar; dilepas (-1) begitu pemutaran dimulai.
     */
    var heldMs by mutableFloatStateOf(-1f)

    /** Jeda di posisi sekarang dan pegang posisi itu persis. */
    fun pauseHere() {
        try { mp?.pause() } catch (_: Exception) {}
        if (heldMs < 0f || playing) heldMs = smoothMs
        playing = false
    }

    /**
     * Buat MediaPlayer SEKALI per video. Sebelumnya pemutar dibuat/dibuang oleh callback TextureView, sehingga setiap kali
     * TextureView dilepas/dipasang ulang (ganti layout, mode pilih area, dsb.) pemutar ikut dibuang dan Play tidak jalan.
     * Sekarang siklus hidup pemutar terpisah dari surface: surface cukup dipasang ([attach]) atau dilepas ([detach]).
     */
    fun open(ctx: android.content.Context, uri: Uri) {
        release()
        failed = null
        val player = MediaPlayer()
        try {
            player.setDataSource(ctx, uri)
            surface?.let { player.setSurface(it) }
            player.setOnPreparedListener {
                ready = true
                try { it.seekTo(0) } catch (_: Exception) {}
                if (playWhenReady) {
                    playWhenReady = false
                    heldMs = -1f; try { it.start(); playing = true } catch (_: Exception) {}
                }
            }
            player.setOnCompletionListener { playing = false; completed = true }
            player.setOnErrorListener { _, what, extra ->
                ready = false; playing = false
                failed = "Pemutar gagal ($what/$extra)"
                true
            }
            player.prepareAsync()
            mp = player
        } catch (e: Exception) {
            failed = "Video tidak bisa dibuka"
            try { player.release() } catch (_: Exception) {}
        }
    }

    fun attach(s: Surface) {
        surface = s
        try { mp?.setSurface(s) } catch (_: Exception) {}
    }

    fun detach() {
        try { mp?.setSurface(null) } catch (_: Exception) {}
        try { surface?.release() } catch (_: Exception) {}
        surface = null
    }

    fun release() {
        ready = false
        playing = false
        playWhenReady = false
        completed = false
        try { mp?.release() } catch (_: Exception) {}
        mp = null
    }
}

private val TOOLS = listOf("Zoom", "Background", "Bingkai", "Rasio", "Efek", "Caption", "Teks", "Audio")

/** Index [TOOLS] untuk tool "Teks" (teks bebas di kanvas, beda dari Caption). */
private const val TOOL_TEXT = 6

/** Index [TOOLS] untuk tool "Audio" (musik / suara tambahan + volume suara asli video). */
private const val TOOL_AUDIO = 7

/** Tab di header panel tiap tool. Background memakai tipe background sebagai tab (lihat [BG_TYPES]). */
private val TOOL_TABS = listOf(
    listOf("Blok", "Atur", "3D", "Kurva"),
    BG_TYPES,
    listOf("Bentuk", "Bayangan", "Kursor"),
    listOf("Rasio"),
    listOf("Filter", "Vignette", "Glow"),
    listOf("Buat", "Teks", "Gaya"),
    listOf("Teks"),
    listOf("Audio", "Volume"),
)

/** Tinggi area timeline (ruler + baris + ruang kosong) dan toolbar bawah. Tetap, supaya pratinjau tidak berubah ukuran. */
private val TL_AREA = 224.dp
private val TOOLBAR_H = 72.dp   // nav bawah: padding 8 + tombol 56 + padding 8 (desain LayKit_PanelEditor)

/** Ikon caption: balon bicara dengan dua baris teks. Dideklarasikan SEBELUM [TOOL_ICONS] (urutan inisialisasi top-level). */
private val ICON_CAPTION = listOf(
    "M5 5H19a2 2 0 0 1 2 2V15a2 2 0 0 1 -2 2H12L7.5 20.5V17H5a2 2 0 0 1 -2 -2V7a2 2 0 0 1 2 -2Z",
    "M7.5 10H16.5", "M7.5 13H13",
)

/** Ikon tool "Teks": huruf T sederhana. */
private val ICON_TEXT = listOf("M6 6.5H18", "M12 6.5V18")

/** Ikon tool "Audio": not musik (dua kepala not dengan balok). Dideklarasikan SEBELUM [TOOL_ICONS]. */
private val ICON_MUSIC = listOf(
    "M9 18V6.5L19 4.5V16",
    "M4 18a2.5 2.5 0 1 0 5 0a2.5 2.5 0 1 0 -5 0Z",
    "M14 16a2.5 2.5 0 1 0 5 0a2.5 2.5 0 1 0 -5 0Z",
)

/** Ikon garis 24x24 untuk nav bawah (dari desain LayKit_PanelEditor, urutan sama dengan [TOOLS]); digambar dengan tebal garis 1,75. */
private val TOOL_ICONS = listOf(
    // Zoom: kaca pembesar dengan tanda plus
    listOf("M4 10.5a6.5 6.5 0 1 0 13 0a6.5 6.5 0 1 0 -13 0Z", "M15.5 15.5L20.5 20.5", "M10.5 7.8v5.4", "M7.8 10.5h5.4"),
    // Background: gambar dengan gunung
    listOf(
        "M7 4H17a4 4 0 0 1 4 4V16a4 4 0 0 1 -4 4H7a4 4 0 0 1 -4 -4V8a4 4 0 0 1 4 -4Z",
        "M6.9 9.5a1.6 1.6 0 1 0 3.2 0a1.6 1.6 0 1 0 -3.2 0Z",
        "M3.5 17l4.6 -4.4a1.6 1.6 0 0 1 2.2 0l2.4 2.3l2 -1.9a1.6 1.6 0 0 1 2.2 0L20.5 16",
    ),
    // Bingkai: dua persegi membulat bersarang
    listOf(
        "M8.5 3H15.5a5.5 5.5 0 0 1 5.5 5.5V15.5a5.5 5.5 0 0 1 -5.5 5.5H8.5a5.5 5.5 0 0 1 -5.5 -5.5V8.5a5.5 5.5 0 0 1 5.5 -5.5Z",
        "M10.5 8H13.5a2.5 2.5 0 0 1 2.5 2.5V13.5a2.5 2.5 0 0 1 -2.5 2.5H10.5a2.5 2.5 0 0 1 -2.5 -2.5V10.5a2.5 2.5 0 0 1 2.5 -2.5Z",
    ),
    // Rasio: persegi panjang dengan tanda sudut
    listOf(
        "M5.8 6H18.2a3 3 0 0 1 3 3V15a3 3 0 0 1 -3 3H5.8a3 3 0 0 1 -3 -3V9a3 3 0 0 1 3 -3Z",
        "M7 11V9.2a0.7 0.7 0 0 1 0.7 -0.7H9.5",
        "M17 13V14.8a0.7 0.7 0 0 1 -0.7 0.7H14.5",
    ),
    // Efek: bintang berkilau
    listOf(
        "M10 4.5c0.5 3.6 2.4 5.5 6 6c-3.6 0.5 -5.5 2.4 -6 6c-0.5 -3.6 -2.4 -5.5 -6 -6c3.6 -0.5 5.5 -2.4 6 -6Z",
        "M18.5 3V6", "M17 4.5H20", "M18 15.5V19.5", "M16 17.5H20",
    ),
    // Caption: balon bicara
    ICON_CAPTION,
    // Teks: huruf T
    ICON_TEXT,
    // Audio: not musik
    ICON_MUSIC,
)

// Ikon kartu player
private val ICON_FULLSCREEN = listOf("M4 9V4H9", "M20 9V4H15", "M4 15V20H9", "M20 15V20H15")
private val ICON_VOLUME = listOf("M4 10V14H8L13 18V6L8 10Z", "M16.5 9.5a3.5 3.5 0 0 1 0 5")
private val ICON_VOLUME_OFF = listOf("M4 10V14H8L13 18V6L8 10Z", "M17 9L21 15", "M21 9L17 15")
private val ICON_UNDO = listOf("M9 14L4 9L9 4", "M4 9H15a5 5 0 0 1 0 10H11")
private val ICON_REDO = listOf("M15 14L20 9L15 4", "M20 9H9a5 5 0 0 0 0 10H13")

/** Satu keadaan edit lengkap, dipakai untuk undo/redo. */
internal data class EditSnap(
    val zooms: List<ZoomRegion>, val startMs: Float, val endMs: Float,
    val bgUi: Int, val preset: Int, val solid: Int, val wall: Int, val imageUri: Uri?, val blurAmt: Float,
    val padding: Float, val corner: Float, val shadow: Boolean, val shadowAmt: Float, val aspectIdx: Int, val cursorOn: Boolean,
    val look: Int, val lookAmt: Float, val vignette: Float, val glow: Float, val glowSize: Float,
    val captions: List<CaptionSeg> = emptyList(), val capOn: Boolean = true, val capSize: Float = 0.5f,
    val texts: List<TextOverlay> = emptyList(),
    /** Audio tambahan (musik/narasi) dan volume suara asli video (0..1). */
    val audios: List<AudioClip> = emptyList(), val origVol: Float = 1f,
    /** Efek khusus teks (terpisah dari efek media utama): filter, intensitas, vignette, glow, ukuran glow. */
    val tLook: Int = 0, val tLookAmt: Float = 1f, val tVignette: Float = 0f, val tGlow: Float = 0f, val tGlowSize: Float = 0.5f,
)

/** Palet editor: hitam pekat, kartu abu gelap, aksen teal muda, tombol Ekspor oranye. Datar, tanpa bayangan. */
private val EditorColors = darkColorScheme(
    primary = Color(0xFFBFE0DC),
    onPrimary = Color(0xFF0B0B0B),
    secondaryContainer = Color(0xFF26262A),
    onSecondaryContainer = Color(0xFFF2F2F2),
    tertiary = Color(0xFFFF6A13),
    background = Color(0xFF0B0B0B),
    onBackground = Color(0xFFF2F2F2),
    surface = Color(0xFF0B0B0B),
    onSurface = Color(0xFFF2F2F2),
    surfaceVariant = Color(0xFF1C1C1E),
    onSurfaceVariant = Color(0xFF8E8E93),
    surfaceContainerLow = Color(0xFF131315),
    surfaceContainer = Color(0xFF161618),
    surfaceContainerHighest = Color(0xFF26262A),
    outline = Color(0xFF3A3A3E),
    outlineVariant = Color(0xFF2A2A2D),
    error = Color(0xFFFF6369),
    onError = Color(0xFF1A0505),
)

@Composable
internal fun ToolIcon(paths: List<String>, color: Color, iconSize: Dp = 22.dp, strokeW: Float = 1.6f) {
    val parsed = remember(paths) { paths.map { PathParser().parsePathString(it).toPath() } }
    Canvas(Modifier.size(iconSize)) {
        scale(this.size.width / 24f, pivot = Offset.Zero) {
            parsed.forEach { drawPath(it, color, style = Stroke(width = strokeW, cap = StrokeCap.Round, join = StrokeJoin.Round)) }
        }
    }
}

/** Ikon keyframe (belah ketupat): kosong + tanda tambah = tambah keyframe, terisi + tanda kurang = hapus keyframe di posisi ini. */
@Composable
private fun KeyframeIcon(on: Boolean, color: Color, cut: Color, iconSize: Dp = 20.dp) {
    val diamond = remember { PathParser().parsePathString("M12 3L21 12L12 21L3 12Z").toPath() }
    val plus = remember { PathParser().parsePathString("M12 8.5V15.5M8.5 12H15.5").toPath() }
    val minus = remember { PathParser().parsePathString("M8.5 12H15.5").toPath() }
    Canvas(Modifier.size(iconSize)) {
        scale(this.size.width / 24f, pivot = Offset.Zero) {
            val st = Stroke(width = 1.6f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            if (on) {
                drawPath(diamond, color)
                drawPath(minus, cut, style = Stroke(width = 1.8f, cap = StrokeCap.Round))
            } else {
                drawPath(diamond, color, style = st)
                drawPath(plus, color, style = st)
            }
        }
    }
}

@Composable
internal fun EditorScreen(uri: Uri, project: Project? = null, onBack: () -> Unit) {
    val ctx = LocalContext.current
    remember(ctx) { TextOverlays.init(ctx) }
    val scope = rememberCoroutineScope()
    val player = remember { PlayerState() }
    DisposableEffect(Unit) { onDispose { player.release(); player.detach() } }

    // Editor selalu gelap: ikon status bar dibuat terang selama editor terbuka, lalu dikembalikan.
    val view = LocalView.current
    DisposableEffect(Unit) {
        val win = view.context.findActivity()?.window
        val ctrl = win?.let { WindowCompat.getInsetsController(it, view) }
        val prevStatus = ctrl?.isAppearanceLightStatusBars
        val prevNav = ctrl?.isAppearanceLightNavigationBars
        ctrl?.isAppearanceLightStatusBars = false
        ctrl?.isAppearanceLightNavigationBars = false
        onDispose {
            if (ctrl != null && prevStatus != null) ctrl.isAppearanceLightStatusBars = prevStatus
            if (ctrl != null && prevNav != null) ctrl.isAppearanceLightNavigationBars = prevNav
        }
    }

    val info by produceState<VideoInfo?>(null, uri) {
        value = withContext(Dispatchers.IO) { Exporter.probe(ctx, uri) }
    }

    var cancel by remember { mutableStateOf<Exporter.Cancel?>(null) }
    val back = { cancel?.requested = true; onBack() }
    BackHandler { back() }

    MaterialTheme(colorScheme = EditorColors) {
        Box(Modifier.fillMaxSize().background(EditorColors.background).systemBarsPadding()) {
            val vi = info
            if (vi == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                IconButton(onClick = { back() }, modifier = Modifier.padding(4.dp)) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali", tint = EditorColors.onBackground)
                }
            } else {
                EditorContent(ctx, scope, uri, vi, project, player, { cancel = it }, cancel, back, Modifier.fillMaxSize())
            }
        }
    }
}

@Composable
private fun EditorContent(
    ctx: android.content.Context,
    scope: kotlinx.coroutines.CoroutineScope,
    uri: Uri,
    vi: VideoInfo,
    project: Project?,
    player: PlayerState,
    setCancel: (Exporter.Cancel?) -> Unit,
    cancel: Exporter.Cancel?,
    onBack: () -> Unit,
    modifier: Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val durMs = vi.durationMs.coerceAtLeast(1000L)
    DisposableEffect(uri) {
        player.open(ctx, uri)
        onDispose { player.release() }
    }
    var startMs by remember(uri) { mutableFloatStateOf(0f) }
    var endMs by remember(uri) { mutableFloatStateOf(durMs.toFloat()) }

    var tool by remember { mutableIntStateOf(-1) }   // -1 = panel tertutup

    var bgUi by remember { mutableIntStateOf(0) }       // 0 gradient, 1 warna, 2 wallpaper, 3 gambar, 4 blur
    var preset by remember { mutableIntStateOf(0) }
    var solid by remember { mutableIntStateOf(0) }
    var wall by remember { mutableIntStateOf(0) }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var blurAmt by remember { mutableFloatStateOf(0.04f) }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u ->
        if (u != null) imageUri = u
    }
    val imgBmp by produceState<Bitmap?>(null, imageUri) {
        val u = imageUri
        value = if (u == null) null else withContext(Dispatchers.IO) { Exporter.loadImage(ctx, u, 1024) }
    }
    val frameBmp by produceState<Bitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) { Exporter.firstFrame(ctx, uri) }
    }
    var padding by remember { mutableFloatStateOf(0.08f) }
    var corner by remember { mutableFloatStateOf(0.03f) }
    var shadow by remember { mutableStateOf(true) }
    var shadowAmt by remember { mutableFloatStateOf(0.5f) }
    var aspectIdx by remember { mutableIntStateOf(0) }

    // ---- zoom ----
    var zooms by remember(uri) { mutableStateOf<List<ZoomRegion>>(emptyList()) }
    var selectedZoom by remember(uri) { mutableStateOf<Int?>(null) }
    var selectedKey by remember(uri) { mutableStateOf<Long?>(null) }   // keyframe terpilih (waktu) pada blok terpilih
    var nextZoomId by remember(uri) { mutableIntStateOf(1) }
    var zoomMsg by remember(uri) { mutableStateOf<String?>(null) }
    var areaEdit by remember(uri) { mutableStateOf(false) }   // mode pilih area zoom di pratinjau
    val touches by produceState<List<TouchEvent>>(emptyList(), uri) {
        value = withContext(Dispatchers.IO) {
            val name = Library.nameOf(ctx, uri)
            val local = if (name == null) emptyList() else TouchLog.load(ctx.filesDir, name)
            if (local.isNotEmpty()) {
                // rekaman lama: tanamkan salinan ke file video supaya selamat dari update / pasang ulang
                if (!TouchEmbed.has(ctx, uri)) TouchEmbed.write(ctx, uri, local)
                local
            } else TouchEmbed.read(ctx, uri)
        }
    }

    var exporting by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var resultUri by remember { mutableStateOf<Uri?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    var cursorOn by remember { mutableStateOf(true) }

    // ---- efek: filter warna + vignette + glow (satu model, dipakai pratinjau dan ekspor lewat FrameStyle) ----
    var look by remember { mutableIntStateOf(0) }
    var lookAmt by remember { mutableFloatStateOf(1f) }
    var vignette by remember { mutableFloatStateOf(0f) }
    var glow by remember { mutableFloatStateOf(0f) }
    var glowSize by remember { mutableFloatStateOf(0.5f) }
    // efek teks terpisah + target yang sedang diedit di tool Efek (0 = Media, 1 = Teks, 2 = Semua)
    var tLook by remember { mutableIntStateOf(0) }
    var tLookAmt by remember { mutableFloatStateOf(1f) }
    var tVignette by remember { mutableFloatStateOf(0f) }
    var tGlow by remember { mutableFloatStateOf(0f) }
    var tGlowSize by remember { mutableFloatStateOf(0.5f) }
    var fxTarget by remember { mutableIntStateOf(0) }

    // ---- caption otomatis (whisper.cpp di HP): isi caption ikut project/undo; sisanya hanya keadaan layar ----
    var captions by remember { mutableStateOf<List<CaptionSeg>>(emptyList()) }
    var capOn by remember { mutableStateOf(true) }
    var capSize by remember { mutableFloatStateOf(0.5f) }
    var capModel by remember { mutableStateOf(WhisperModel.BASE) }
    var capLang by remember { mutableStateOf("auto") }
    var capBusy by remember { mutableStateOf(false) }
    var capStatus by remember { mutableStateOf("") }
    var capProg by remember { mutableFloatStateOf(0f) }
    var capEditIdx by remember { mutableStateOf<Int?>(null) }
    var capEditText by remember { mutableStateOf("") }
    val capCancel = remember { AtomicBoolean(false) }
    DisposableEffect(Unit) { onDispose { capCancel.set(true) } }   // keluar editor = hentikan pengenalan suara

    // ---- teks bebas di kanvas: posisi digeser langsung di pratinjau; isi ikut project/undo ----
    var texts by remember { mutableStateOf<List<TextOverlay>>(emptyList()) }
    var selectedText by remember { mutableStateOf<Long?>(null) }
    var textAddOpen by remember { mutableStateOf(false) }
    var textAddValue by remember { mutableStateOf("") }
    var textEditOpen by remember { mutableStateOf(false) }
    var textEditValue by remember { mutableStateOf("") }

    // ---- audio tambahan: daftar klip + volume suara asli ikut project/undo; sisanya hanya keadaan layar ----
    var audios by remember { mutableStateOf<List<AudioClip>>(emptyList()) }
    var selectedAudio by remember { mutableStateOf<Long?>(null) }
    var origVol by remember { mutableFloatStateOf(1f) }
    var audioBusy by remember { mutableStateOf(false) }

    // ---- toast kecil di atas pratinjau, mode fokus (fullscreen), mute pratinjau ----
    var toast by remember { mutableStateOf<String?>(null) }
    var toastKey by remember { mutableIntStateOf(0) }
    fun showToast(m: String) { toast = m; toastKey++ }
    LaunchedEffect(toastKey) {
        if (toast != null) { delay(2000); toast = null }
    }
    // ---- project: id (null = belum pernah disimpan), keadaan terakhir yang tersimpan, dan dialog "simpan dulu?" ----
    var projectId by remember { mutableStateOf(project?.id) }
    var baseline by remember { mutableStateOf(project?.snap) }   // keadaan yang sudah tersimpan / keadaan awal; beda dari snap = ada perubahan
    var dirty by remember { mutableStateOf(false) }
    var askSave by remember { mutableStateOf(false) }
    var savingProject by remember { mutableStateOf(false) }
    // didaftarkan SEBELUM handler fokus/panel di bawah: handler yang didaftarkan belakangan didahulukan, jadi panel/fokus tertutup dulu
    BackHandler(enabled = dirty && !savingProject) { askSave = true }
    var focus by remember { mutableStateOf(false) }
    BackHandler(enabled = focus) { focus = false }
    BackHandler(enabled = !focus && tool >= 0) { tool = -1 }   // Back menutup panel dulu sebelum keluar editor
    var muted by remember { mutableStateOf(false) }
    var bottomH by remember { mutableIntStateOf(0) }     // px, tinggi area bawah (timeline + toolbar); panel menutupi bagian bawahnya
    var toolTab by remember { mutableIntStateOf(0) }     // tab aktif di header panel (kecuali Background: pakai bgUi)
    var zParam by remember { mutableIntStateOf(0) }      // parameter zoom yang diatur slider: 0 skala, 1 X, 2 Y
    var cParam by remember { mutableIntStateOf(0) }      // parameter 3D Customize yang diatur slider: 0 angguk, 1 tengok, 2 miring, 3 jarak
    var curveCh by remember { mutableIntStateOf(CH_ZOOM) }   // channel kurva yang sedang diedit (tab Kurva)
    val lastTool = remember { intArrayOf(0) }            // tool terakhir yang dibuka: isi panel tetap ada selama animasi tutup
    fun openTool(i: Int) { tool = i; toolTab = 0 }
    LaunchedEffect(muted, origVol, player.ready) {
        val v = if (muted) 0f else origVol.coerceIn(0f, 1f)
        try { player.mp?.setVolume(v, v) } catch (_: Exception) {}
    }

    // ---- audio tambahan: pilih berkas -> salin ke penyimpanan app -> klip baru mulai di playhead ----
    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            audioBusy = true
            val at = player.positionMs.coerceIn(0L, (durMs - 500L).coerceAtLeast(0L))
            scope.launch {
                val res = withContext(Dispatchers.IO) { runCatching { AudioStore.import(ctx, u, at) } }
                audioBusy = false
                res.onSuccess { c ->
                    audios = audios + c
                    selectedAudio = c.id
                    showToast("Audio ditambahkan")
                }.onFailure { e ->
                    showToast(if (e is AudioStore.ImportException) (e.message ?: "Audio gagal") else "Audio gagal: ${e.message ?: e.javaClass.simpleName}")
                }
            }
        }
    }

    // pemutar audio tambahan di pratinjau: mengikuti jam video (lihat AudioPreview)
    val audioPrev = remember { AudioPreview(ctx) }
    DisposableEffect(Unit) { onDispose { audioPrev.release() } }
    val curAudios by rememberUpdatedState(audios)
    val curMuted by rememberUpdatedState(muted)
    LaunchedEffect(audios) { audioPrev.setClips(audios) }
    LaunchedEffect(Unit) {
        while (true) {
            audioPrev.sync(curAudios, player.smoothMs, player.playing && player.ready, curMuted)
            delay(80)
        }
    }

    // ---- undo / redo: perubahan digabung per 350 ms, lalu disimpan sebagai satu langkah ----
    val snap = EditSnap(
        zooms, startMs, endMs, bgUi, preset, solid, wall, imageUri, blurAmt,
        padding, corner, shadow, shadowAmt, aspectIdx, cursorOn,
        look, lookAmt, vignette, glow, glowSize,
        captions, capOn, capSize,
        texts,
        audios, origVol,
        tLook, tLookAmt, tVignette, tGlow, tGlowSize,
    )
    var committed by remember(uri) { mutableStateOf<EditSnap?>(null) }
    var undoStack by remember(uri) { mutableStateOf<List<EditSnap>>(emptyList()) }
    var redoStack by remember(uri) { mutableStateOf<List<EditSnap>>(emptyList()) }
    fun commitNow(s: EditSnap) {
        val c = committed
        if (c == null) { committed = s; return }
        if (s == c) return
        undoStack = (undoStack + c).takeLast(60)
        redoStack = emptyList()
        committed = s
    }
    LaunchedEffect(snap) {
        if (committed == null) { committed = snap; return@LaunchedEffect }
        delay(350)
        commitNow(snap)
    }
    fun applySnap(s: EditSnap) {
        zooms = s.zooms; startMs = s.startMs; endMs = s.endMs
        bgUi = s.bgUi; preset = s.preset; solid = s.solid; wall = s.wall; imageUri = s.imageUri; blurAmt = s.blurAmt
        padding = s.padding; corner = s.corner; shadow = s.shadow; shadowAmt = s.shadowAmt; aspectIdx = s.aspectIdx; cursorOn = s.cursorOn
        look = s.look; lookAmt = s.lookAmt; vignette = s.vignette; glow = s.glow; glowSize = s.glowSize
        tLook = s.tLook; tLookAmt = s.tLookAmt; tVignette = s.tVignette; tGlow = s.tGlow; tGlowSize = s.tGlowSize
        captions = s.captions; capOn = s.capOn; capSize = s.capSize
        texts = s.texts; selectedText = null
        audios = s.audios; origVol = s.origVol; selectedAudio = null
        selectedZoom = null; selectedKey = null; areaEdit = false
    }
    fun undo() {
        commitNow(snap)   // simpan dulu perubahan yang belum sempat tercatat
        val c = committed ?: return
        val target = undoStack.lastOrNull() ?: return
        undoStack = undoStack.dropLast(1)
        redoStack = redoStack + c
        committed = target
        applySnap(target)
        showToast("Dibatalkan")
    }
    fun redo() {
        val c = committed ?: return
        val target = redoStack.lastOrNull() ?: return
        redoStack = redoStack.dropLast(1)
        undoStack = undoStack + c
        committed = target
        applySnap(target)
        showToast("Diulangi")
    }
    val canUndo = undoStack.isNotEmpty() || (committed != null && committed != snap)
    val canRedo = redoStack.isNotEmpty()

    // ---- project: muat keadaan tersimpan sekali, lalu simpan ----
    LaunchedEffect(Unit) {
        val ps = project?.snap
        if (ps != null) {
            applySnap(ps)
            nextZoomId = (ps.zooms.maxOfOrNull { it.id } ?: 0) + 1
            committed = ps   // undo tidak boleh mundur ke keadaan kosong sebelum dimuat
        } else if (baseline == null) {
            baseline = snap
        }
    }
    LaunchedEffect(snap, baseline) { dirty = baseline != null && baseline != snap }
    val projectName by produceState("Rekaman", uri) {
        value = withContext(Dispatchers.IO) { Library.nameOf(ctx, uri)?.substringBeforeLast('.') ?: "Rekaman" }
    }
    /** Simpan project (baru atau timpa). [then] dipanggil di thread utama setelah berhasil. */
    fun saveProject(then: () -> Unit = {}) {
        if (savingProject) return
        savingProject = true
        val s = snap
        val id = projectId ?: ProjectStore.newId()
        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                val name = project?.name ?: projectName
                ProjectStore.save(ctx, id, name, uri, durMs, s)
            }
            savingProject = false
            if (ok) {
                projectId = id
                baseline = s
                showToast("Project disimpan")
                then()
            } else {
                showToast("Gagal menyimpan project")
            }
        }
    }

    // Sumber kursor: data ketukan; kalau rekaman tidak punya (layanan sentuhan mati / elemen tidak terbaca),
    // kursor memakai titik fokus tiap blok zoom, jadi saklar Kursor tetap bisa dipakai.
    val cursorTrack = remember(touches, zooms) {
        if (touches.isNotEmpty()) touches
        else zooms.map { TouchEvent(it.startMs, it.fx.coerceIn(0f, 1f), it.fy.coerceIn(0f, 1f), TouchLog.TAP) }.sortedBy { it.tMs }
    }
    val base = FrameStyle(padding = padding, corner = corner, shadow = shadow, shadowAmt = shadowAmt, aspect = ASPECTS[aspectIdx].second, cursor = cursorOn && cursorTrack.isNotEmpty(), look = look, lookAmt = lookAmt, vignette = vignette, glow = glow, glowSize = glowSize, tLook = tLook, tLookAmt = tLookAmt, tVignette = tVignette, tGlow = tGlow, tGlowSize = tGlowSize)
    val style = when (bgUi) {
        1 -> base.copy(top = SOLIDS[solid], bottom = SOLIDS[solid])
        2 -> base.copy(bgType = 1, top = WALLS[wall].first, mid = WALLS[wall].second, bottom = WALLS[wall].third)
        3 -> base.copy(bgType = 2, image = imageUri)
        4 -> base.copy(bgType = 3, blur = blurAmt)
        else -> base.copy(top = PRESETS[preset].first, bottom = PRESETS[preset].second)
    }
    val videoAspect = vi.width.toFloat() / vi.height.toFloat()

    // loop pemutaran di dalam rentang potong + jam halus untuk zoom/kursor.
    // MediaPlayer.currentPosition kasar dan bisa loncat; zoom yang dibaca darinya (dulu tiap 40 ms) patah-patah.
    // Saat memutar: waktu diekstrapolasi tiap frame layar, lalu dikoreksi pelan-pelan oleh currentPosition.
    val curStart by rememberUpdatedState(startMs)
    val curEnd by rememberUpdatedState(endMs)
    LaunchedEffect(Unit) {
        var est = 0f
        var lastFrameNs = 0L
        var lastSampleNs = 0L
        var ignoreUntilNs = 0L
        while (true) {
            val mp = player.mp
            if (mp == null || !player.ready) { delay(50); continue }
            if (!player.playing) {
                // jeda / scrub: ikuti posisi pemutar apa adanya
                try {
                    val h = player.heldMs
                    val p = if (h >= 0f) h else mp.currentPosition.toFloat()
                    est = p
                    player.smoothMs = p
                    player.positionMs = p.toLong()
                } catch (_: Exception) {}
                lastFrameNs = 0L
                delay(30)
                continue
            }
            withFrameNanos { now ->
                if (lastFrameNs == 0L) {
                    // frame pertama setelah Play: langsung selaraskan dengan pemutar (tanpa koreksi pelan)
                    lastFrameNs = now; lastSampleNs = 0L
                    try { est = mp.currentPosition.toFloat() } catch (_: Exception) {}
                }
                val dt = ((now - lastFrameNs) / 1_000_000f).coerceIn(0f, 50f)
                lastFrameNs = now
                est += dt
                if (now - lastSampleNs > 50_000_000L && now > ignoreUntilNs) {
                    lastSampleNs = now
                    try {
                        val p = mp.currentPosition.toFloat()
                        if (p >= curEnd) {
                            mp.seekTo(curStart.toLong(), MediaPlayer.SEEK_CLOSEST)
                            est = curStart
                            ignoreUntilNs = now + 200_000_000L   // abaikan pembacaan lama sampai seek selesai
                        } else {
                            val err = p - est
                            est = if (kotlin.math.abs(err) > 250f) p else est + err * 0.15f
                        }
                    } catch (_: Exception) {}
                }
                if (est > curEnd) est = curEnd
                player.smoothMs = est
                // state yang memicu recompose (timeline, teks waktu) cukup ~25 Hz
                if (kotlin.math.abs(est - player.positionMs) >= 40f) player.positionMs = est.toLong()
            }
        }
    }

    fun seek(ms: Float) {
        if (!player.playing) {
            // pegang posisi yang diminta: playhead, keyframe, zoom, dan kursor memakai angka ini, bukan currentPosition yang basi
            player.heldMs = ms
            player.smoothMs = ms
            player.positionMs = ms.toLong()
        }
        try { player.mp?.seekTo(ms.toLong(), MediaPlayer.SEEK_CLOSEST) } catch (_: Exception) {}
    }

    fun togglePlay() {
        val mp = player.mp
        if (mp == null) return
        if (!player.ready) {
            // video belum siap: ingat niatnya, mulai otomatis begitu siap
            player.playWhenReady = !player.playWhenReady
            if (player.playWhenReady) areaEdit = false
            return
        }
        try {
            if (player.playing) {
                player.pauseHere()
            } else {
                areaEdit = false
                // setelah habis (atau di luar rentang potong) mulai lagi dari awal rentang
                if (player.completed || mp.currentPosition < startMs || mp.currentPosition >= endMs) {
                    mp.seekTo(startMs.toLong(), MediaPlayer.SEEK_CLOSEST)
                }
                player.completed = false
                player.heldMs = -1f
                mp.start(); player.playing = true
            }
        } catch (e: Exception) {
            player.playing = false
            player.failed = "Tidak bisa memutar: ${e.javaClass.simpleName}"
        }
    }

    fun addZoom() {
        val added = ZoomOps.add(zooms, ZoomRegion(id = nextZoomId, startMs = 0L, endMs = 0L), player.positionMs, 5000L, durMs)
        if (added == null) {
            zoomMsg = "Tidak ada ruang kosong"
            showToast("Tidak ada ruang kosong")
        } else {
            val newId = nextZoomId
            zooms = added; selectedZoom = newId; nextZoomId++; zoomMsg = null
            showToast("Zoom ditambahkan")
            openTool(0)
            added.firstOrNull { it.id == newId }?.let { nr ->
                player.pauseHere()
                seek(nr.startMs.toFloat())
                areaEdit = true
            }
        }
    }

    /** Blok yang dimaksud tombol keyframe: yang dipilih, kalau tidak ada yang berisi playhead. */
    fun keyframeRegion(): ZoomRegion? {
        val pos = player.positionMs
        return zooms.firstOrNull { it.id == selectedZoom } ?: zooms.firstOrNull { pos >= it.startMs && pos <= it.endMs }
    }

    /** Keyframe yang sedang "aktif": yang dipilih, atau yang tepat di playhead (toleransi 150 ms). */
    fun activeKey(r: ZoomRegion): ZoomKey? {
        val pos = player.positionMs
        val ks = r.liveKeys()
        if (r.id == selectedZoom) ks.firstOrNull { it.tMs == selectedKey }?.let { return it }
        return ks.minByOrNull { kotlin.math.abs(it.tMs - pos) }?.takeIf { kotlin.math.abs(it.tMs - pos) <= 150L }
    }

    fun toggleKeyframe() {
        val r = keyframeRegion()
        if (r == null) { showToast("Pilih blok zoom atau taruh playhead di dalam blok"); return }
        val ex = activeKey(r)
        if (ex != null) {
            zooms = ZoomOps.update(zooms, r.id) { z -> z.copy(keys = z.keys.filter { it.tMs != ex.tMs }, auto = false) }
            selectedZoom = r.id; selectedKey = null
            showToast("Keyframe dihapus")
            return
        }
        val t = player.positionMs
        if (t < r.startMs + ZoomMath.KEY_GAP_MS || t > r.endMs - ZoomMath.KEY_GAP_MS) {
            showToast("Taruh playhead di dalam blok zoom")
            return
        }
        if (r.liveKeys().any { kotlin.math.abs(it.tMs - t) < ZoomMath.KEY_GAP_MS }) {
            showToast("Sudah ada keyframe di dekat sini")
            return
        }
        // keyframe baru mulai dari keadaan kamera saat itu (termasuk sudut/jarak Customize), jadi gerakannya tidak melompat
        val st = ZoomMath.stateAt(r, t.toDouble())
        val k = ZoomKey(t, st.scale, st.fx, st.fy, st.camPitch, st.camYaw, st.camRoll, st.camDepth)
        zooms = ZoomOps.update(zooms, r.id) { z -> z.copy(keys = (z.keys + k).sortedBy { x -> x.tMs }, auto = false) }
        selectedZoom = r.id; selectedKey = t
        player.pauseHere()
        areaEdit = true
        showToast("Keyframe ditambahkan")
    }

    val doExport: () -> Unit = {
        player.pauseHere()
        val c = Exporter.Cancel()
        setCancel(c)
        exporting = true; progress = 0f; resultUri = null; error = null
        val st = style
        val zl = zooms
        val tl = cursorTrack
        val capList = if (capOn) captions else emptyList<CaptionSeg>()
        val capSz = capSize
        val txtList = texts
        val audioList = audios
        val ov = origVol
        val s = (startMs * 1000f).toLong()
        val e = (endMs * 1000f).toLong()
        scope.launch(Dispatchers.Default) {
            val out = Exporter.export(ctx, uri, s, e, st, zl, tl, c, { p -> progress = p }, { m -> error = m }, capList, capSz, txtList, audioList, ov)
            withContext(Dispatchers.Main) {
                exporting = false
                resultUri = out
                if (out == null && error == null) error = "Ekspor dibatalkan"
            }
        }
    }

    // ---------------------------------------------------------------- bagian-bagian layar
    val title by produceState("Rekaman", uri) {
        value = withContext(Dispatchers.IO) { Library.nameOf(ctx, uri)?.substringBeforeLast('.') ?: "Rekaman" }
    }

    val requestBack = { if (dirty && !exporting) askSave = true else onBack() }
    val topBar: @Composable () -> Unit = {
        Row(
            Modifier.fillMaxWidth().height(52.dp).padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Box(
                Modifier.size(40.dp).clip(CircleShape).background(cs.surfaceVariant).clickable(onClick = requestBack),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali", tint = cs.onBackground, modifier = Modifier.size(20.dp))
            }
            Text(
                "$title  |  ${ASPECTS[aspectIdx].first}",
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            if (exporting) {
                Text("${(progress * 100).toInt()}%", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                Box(
                    Modifier.height(36.dp).clip(RoundedCornerShape(50)).background(cs.surfaceVariant)
                        .clickable { cancel?.requested = true }.padding(horizontal = 16.dp),
                    contentAlignment = Alignment.Center,
                ) { Text("Batal", style = MaterialTheme.typography.labelLarge, color = cs.onBackground) }
            } else {
                Box(
                    Modifier.height(36.dp).clip(RoundedCornerShape(50)).background(cs.surfaceVariant)
                        .clickable(enabled = !savingProject) { saveProject() }.padding(horizontal = 14.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        if (savingProject) "Menyimpan…" else if (dirty || projectId == null) "Simpan" else "Tersimpan",
                        style = MaterialTheme.typography.labelLarge,
                        color = if (dirty || projectId == null) cs.primary else cs.onSurfaceVariant,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
                resultUri?.let { out ->
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(cs.surfaceVariant).clickable { Library.share(ctx, out) },
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Default.Share, contentDescription = "Bagikan", tint = cs.primary, modifier = Modifier.size(20.dp)) }
                }
                Box(
                    Modifier.height(36.dp).clip(RoundedCornerShape(50)).background(LayKitGradient.horizontal)
                        .clickable(onClick = doExport).padding(horizontal = 18.dp),
                    contentAlignment = Alignment.Center,
                ) { Text("Ekspor", style = MaterialTheme.typography.labelLarge, color = Color.White, fontWeight = FontWeight.SemiBold) }
            }
        }
        Box(Modifier.fillMaxWidth().height(3.dp)) {
            if (exporting) {
                Box(Modifier.fillMaxSize().background(cs.surfaceVariant))
                Box(Modifier.fillMaxHeight().fillMaxWidth(progress.coerceIn(0f, 1f)).background(LayKitGradient.horizontal))
            }
        }
    }

    val preview: @Composable () -> Unit = {
        FramePreview(
            uri, videoAspect, style, player, imgBmp, frameBmp, zooms,
            cursorTrack, { player.smoothMs }, if (capOn) captions else emptyList<CaptionSeg>(), capSize,
            if (areaEdit) zooms.firstOrNull { it.id == selectedZoom }?.let { r ->
                val k = r.liveKeys().firstOrNull { it.tMs == selectedKey }
                if (k != null) r.copy(scale = k.scale, fx = k.fx, fy = k.fy) else r
            } else null,
            texts, selectedText, tool == TOOL_TEXT,
            onTextSelect = { id -> selectedText = id },
            onTextMove = { id, fx, fy -> texts = texts.map { if (it.id == id) it.copy(xFrac = fx, yFrac = fy) else it } },
        ) { fx, fy, sc ->
            selectedZoom?.let { id ->
                val kt = selectedKey
                val hasKey = kt != null && zooms.firstOrNull { it.id == id }?.liveKeys()?.any { it.tMs == kt } == true
                zooms = if (hasKey && kt != null) ZoomOps.updateKey(zooms, id, kt) { it.copy(fx = fx, fy = fy, scale = sc) }
                else ZoomOps.update(zooms, id) { it.copy(fx = fx, fy = fy, scale = sc, auto = false) }
            }
        }
    }

    val timeline: @Composable () -> Unit = {
        TimelineEditor(
            uri = uri,
            durMs = durMs,
            positionMs = player.positionMs,
            timeMs = { player.smoothMs },
            playing = player.playing,
            startMs = startMs,
            endMs = endMs,
            zooms = zooms,
            touches = touches,
            selectedId = selectedZoom,
            enabled = !exporting,
            onSeek = { seek(it.toFloat()) },
            // menggeser timeline saat diputar = jeda dulu, lalu scrub
            onScrubStart = { player.pauseHere() },
            onTrimStart = { v ->
                val s = v.coerceIn(0f, endMs - 500f)
                startMs = s; seek(s)
            },
            onTrimEnd = { v ->
                val e = v.coerceIn(startMs + 500f, durMs.toFloat())
                endMs = e; seek((e - 500f).coerceAtLeast(startMs))
            },
            selectedKey = selectedKey,
            onSelectKey = { id, t ->
                selectedZoom = id
                selectedKey = t
                // lompat ke waktu keyframe supaya pratinjau menampilkan keadaannya
                if (t != null) seek(t.toFloat())
            },
            onSelect = { id ->
                if (id != selectedZoom) selectedKey = null
                selectedZoom = id
                // di mode pilih area, pindah blok = lompat ke frame awal blok itu
                if (areaEdit) zooms.firstOrNull { it.id == id }?.let { seek(it.startMs.toFloat()) }
            },
            onZooms = { zooms = it },
            modifier = Modifier.fillMaxSize(),
        )
    }

    // Baris kontrol player, datar tanpa kartu: layar penuh + mute | Play | keyframe + undo + redo
    val playerCard: @Composable () -> Unit = {
        val dim = cs.onSurfaceVariant.copy(alpha = 0.35f)
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp).height(48.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.Start) {
                Box(Modifier.size(44.dp).clip(CircleShape).clickable { focus = !focus }, contentAlignment = Alignment.Center) {
                    ToolIcon(ICON_FULLSCREEN, if (focus) cs.primary else cs.onSurfaceVariant, 20.dp)
                }
                Box(Modifier.size(44.dp).clip(CircleShape).clickable { muted = !muted }, contentAlignment = Alignment.Center) {
                    ToolIcon(if (muted) ICON_VOLUME_OFF else ICON_VOLUME, if (muted) cs.primary else cs.onSurfaceVariant, 20.dp)
                }
            }
            Box(
                Modifier.size(48.dp).clip(CircleShape).clickable { togglePlay() },
                contentAlignment = Alignment.Center,
            ) { PlayPauseIcon(player.playing, cs.onBackground, 26.dp) }
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.End) {
                val kfReg = keyframeRegion()
                val kfOn = kfReg != null && activeKey(kfReg) != null
                Box(Modifier.size(44.dp).clip(CircleShape).clickable(enabled = !exporting) { toggleKeyframe() }, contentAlignment = Alignment.Center) {
                    KeyframeIcon(
                        kfOn,
                        if (kfReg == null || exporting) dim else if (kfOn) cs.primary else cs.onSurfaceVariant,
                        cs.background, 20.dp,
                    )
                }
                Box(Modifier.size(44.dp).clip(CircleShape).clickable(enabled = canUndo && !exporting) { undo() }, contentAlignment = Alignment.Center) {
                    ToolIcon(ICON_UNDO, if (canUndo) cs.onSurfaceVariant else dim, 20.dp)
                }
                Box(Modifier.size(44.dp).clip(CircleShape).clickable(enabled = canRedo && !exporting) { redo() }, contentAlignment = Alignment.Center) {
                    ToolIcon(ICON_REDO, if (canRedo) cs.onSurfaceVariant else dim, 20.dp)
                }
            }
        }
    }

    // Nav bawah (desain LayKit_NavBawah): garis tipis + 5 tombol ikon dengan indikator pil. Saat satu tool dibuka,
    // panelnya menutupi nav ini (lihat bottomSection). Ketuk tool yang sedang terbuka = tutup.
    val toolbar: @Composable () -> Unit = {
        Column(Modifier.fillMaxWidth().background(cs.background)) {
            Box(
                Modifier.fillMaxWidth().height(1.dp).background(
                    Brush.horizontalGradient(
                        0f to cs.outlineVariant.copy(alpha = 0f), 0.2f to cs.outlineVariant,
                        0.8f to cs.outlineVariant, 1f to cs.outlineVariant.copy(alpha = 0f),
                    ),
                ),
            )
            ToolNav(TOOLS, TOOL_ICONS, tool) { i -> if (tool == i) tool = -1 else openTool(i) }
        }
    }

    fun pct(v: Float, r: ClosedFloatingPointRange<Float>): String =
        (((v - r.start) / (r.endInclusive - r.start)) * 100f + 0.5f).toInt().toString()

    // ---- caption: buat (unduh model -> suara video -> whisper), simpan SRT ----
    fun clock(ms: Long): String = String.format(java.util.Locale.US, "%d:%02d", ms / 60000, ms / 1000 % 60)

    fun startCaptions() {
        if (capBusy) return
        player.pauseHere()
        capBusy = true
        capCancel.set(false)
        capStatus = "Menyiapkan"
        capProg = 0f
        val m = capModel
        val lg = capLang
        scope.launch(Dispatchers.Default) {
            val res = runCatching {
                CaptionEngine.generate(ctx, uri, m, lg, capCancel) { stage, p -> capStatus = stage.label; capProg = p }
            }
            withContext(Dispatchers.Main) {
                capBusy = false
                res.onSuccess { list ->
                    when {
                        list == null -> showToast("Dibatalkan")
                        list.isEmpty() -> showToast("Tidak ada ucapan terdeteksi")
                        else -> { captions = list; capOn = true; showToast("${list.size} baris caption dibuat") }
                    }
                }.onFailure { e ->
                    showToast(if (e is CaptionException) (e.message ?: "Caption gagal") else "Caption gagal: ${e.message ?: e.javaClass.simpleName}")
                }
            }
        }
    }

    fun exportSrt() {
        val list = captions
        if (list.isEmpty()) return
        val from = startMs.toLong()
        val to = if (endMs > startMs) endMs.toLong() else Long.MAX_VALUE
        val name = projectName
        scope.launch {
            val ok = withContext(Dispatchers.IO) { Captions.saveSrt(ctx, name, Captions.srt(list, from, to)) }
            showToast(if (ok) "SRT disimpan di Download/LayKit" else "Gagal menyimpan SRT")
        }
    }

    // Panel tool (desain LayKit_PanelEditor): header tab + Reset + centang, isi per tab. [pt] = tool yang ditampilkan.
    // Menggantikan nav (menutupinya penuh) dan bagian bawah timeline. Isi tiap baris diberi jarak 8 dp; baris yang
    // bisa digulir mendatar (preset, tile, foto) dibuat selebar panel lalu diberi jarak 16 dp DI DALAM gulirnya.
    val panel: @Composable (Dp, Int) -> Unit = { panelH, pt ->
        val tabs = TOOL_TABS[pt]
        val tabSel = if (pt == 1) bgUi else toolTab.coerceIn(0, tabs.size - 1)
        val sel = zooms.firstOrNull { it.id == selectedZoom }
        val selK = sel?.liveKeys()?.firstOrNull { it.tMs == selectedKey }   // keyframe terpilih (tab Atur dan 3D)
        val camCh = if (sel?.cam == Cam.CUSTOM) curveCh else CH_ZOOM
        val px = Modifier.padding(horizontal = 16.dp)

        // slider Customize 3D bisa di-keyframe sendiri-sendiri: ada keyframe terpilih = ubah nilainya di keyframe itu,
        // kalau tidak = ubah nilai dasar blok (sama seperti tab Atur untuk skala/posisi)
        val setCam: (Int, Float) -> Unit = { p, v ->
            if (sel != null) {
                zooms = if (selK != null) ZoomOps.updateKey(zooms, sel.id, selK.tMs) {
                    when (p) { 0 -> it.copy(camPitch = v); 1 -> it.copy(camYaw = v); 2 -> it.copy(camRoll = v); else -> it.copy(camDepth = v) }
                } else ZoomOps.update(zooms, sel.id) {
                    when (p) { 0 -> it.copy(camPitch = v); 1 -> it.copy(camYaw = v); 2 -> it.copy(camRoll = v); else -> it.copy(camDepth = v) }
                }
            }
        }
        val setCurve: (Int, ZoomCurve?) -> Unit = { ch, c ->
            selectedZoom?.let { id ->
                zooms = ZoomOps.update(zooms, id) { r ->
                    when (ch) {
                        CH_PITCH -> r.copy(curvePitch = c); CH_YAW -> r.copy(curveYaw = c)
                        CH_ROLL -> r.copy(curveRoll = c); CH_DEPTH -> r.copy(curveDepth = c)
                        else -> r.copy(curve = c)
                    }
                }
            }
        }

        // Reset ada di header panel (ikon), hanya untuk tab yang punya nilai bawaan
        val reset: PanelReset? = when {
            pt == 0 && tabSel == 2 && sel != null && sel.cam == Cam.CUSTOM -> {
                val cp = selK?.camPitch ?: sel.camPitch
                val cy = selK?.camYaw ?: sel.camYaw
                val cr = selK?.camRoll ?: sel.camRoll
                val cd = selK?.camDepth ?: sel.camDepth
                PanelReset(!exporting && (cp != 0f || cy != 0f || cr != 0f || cd != Cam.PERSPECTIVE_FACTOR)) {
                    setCam(0, 0f); setCam(1, 0f); setCam(2, 0f); setCam(3, Cam.PERSPECTIVE_FACTOR)
                }
            }
            pt == 0 && tabSel == 3 && sel != null -> PanelReset(!exporting && curveOf(sel, camCh) != null) { setCurve(camCh, null) }
            pt == 2 && tabSel == 0 -> PanelReset(!exporting && (padding != 0.08f || corner != 0.03f)) { padding = 0.08f; corner = 0.03f }
            pt == 4 && tabSel == 1 -> PanelReset(!exporting && ((fxTarget != 1 && vignette != 0f) || (fxTarget != 0 && tVignette != 0f))) {
                if (fxTarget != 1) vignette = 0f
                if (fxTarget != 0) tVignette = 0f
            }
            pt == 4 && tabSel == 2 -> PanelReset(!exporting && ((fxTarget != 1 && (glow != 0f || glowSize != 0.5f)) || (fxTarget != 0 && (tGlow != 0f || tGlowSize != 0.5f)))) {
                if (fxTarget != 1) { glow = 0f; glowSize = 0.5f }
                if (fxTarget != 0) { tGlow = 0f; tGlowSize = 0.5f }
            }
            pt == TOOL_AUDIO && tabSel == 1 -> PanelReset(!exporting && origVol != 1f) { origVol = 1f }
            else -> null
        }

        Column(
            Modifier.fillMaxWidth().height(panelH)
                .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                .background(cs.surfaceContainerHighest)
                .pointerInput(Unit) { detectTapGestures { } },   // telan ketukan supaya tidak tembus ke bawah
        ) {
            PanelTabs(tabs, tabSel, { i -> if (pt == 1) bgUi = i else toolTab = i }, { tool = -1 }, reset)
            Column(
                Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                when (pt) {
                    0 -> when (tabSel) {
                        // ---- Blok: aksi pada blok zoom (4 kartu sama lebar) ----
                        0 -> {
                            Row(px.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                ActionCard(ICON_AUTO, "Auto-zoom", enabled = !exporting && touches.isNotEmpty(), modifier = Modifier.weight(1f)) {
                                    val auto = AutoZoom.build(touches, durMs)
                                    zooms = auto
                                    nextZoomId = (auto.maxOfOrNull { it.id } ?: 0) + 1
                                    selectedZoom = null; selectedKey = null
                                    zoomMsg = if (auto.isEmpty()) "Ketukan terlalu sedikit" else null
                                    if (auto.isNotEmpty()) showToast("Auto-zoom dibuat")
                                }
                                ActionCard(ICON_PLUS, "Tambah", enabled = !exporting, modifier = Modifier.weight(1f)) { addZoom() }
                                ActionCard(ICON_TRASH, "Hapus", enabled = !exporting && selectedZoom != null, modifier = Modifier.weight(1f)) {
                                    selectedZoom?.let { zooms = ZoomOps.remove(zooms, it); selectedZoom = null; selectedKey = null; areaEdit = false; showToast("Zoom dihapus") }
                                }
                                ActionCard(
                                    ICON_AREA, if (areaEdit) "Selesai" else "Pilih area", selected = areaEdit,
                                    enabled = !exporting && selectedZoom != null, modifier = Modifier.weight(1f),
                                ) {
                                    if (areaEdit) areaEdit = false
                                    else zooms.firstOrNull { it.id == selectedZoom }?.let { sr ->
                                        // jeda dan lompat ke awal blok, supaya yang dipilih adalah frame yang akan di-zoom
                                        player.pauseHere()
                                        seek((sr.liveKeys().firstOrNull { it.tMs == selectedKey }?.tMs ?: sr.startMs).toFloat())
                                        areaEdit = true
                                    }
                                }
                            }
                            zoomMsg?.let { PanelNote(it, px) }
                        }

                        // ---- Atur: skala dan titik sorot (satu baris pilihan + satu slider) ----
                        1 -> if (sel == null) PanelHint("Pilih blok zoom di timeline untuk mengatur skala dan titik sorotnya.", px) else {
                            val sc = selK?.scale ?: sel.scale
                            val fx = selK?.fx ?: sel.fx
                            val fy = selK?.fy ?: sel.fy
                            val setParam: (Int, Float) -> Unit = { p, v ->
                                zooms = if (selK != null) ZoomOps.updateKey(zooms, sel.id, selK.tMs) {
                                    when (p) { 0 -> it.copy(scale = v); 1 -> it.copy(fx = v); else -> it.copy(fy = v) }
                                } else ZoomOps.update(zooms, sel.id) {
                                    when (p) { 0 -> it.copy(scale = v, auto = false); 1 -> it.copy(fx = v, auto = false); else -> it.copy(fy = v, auto = false) }
                                }
                            }
                            ParamRow(
                                listOf("Skala", "X", "Y"), listOf("%.1f×".format(sc), "%.2f".format(fx), "%.2f".format(fy)),
                                zParam, !exporting, px,
                            ) { zParam = it }
                            val cur = when (zParam) { 0 -> sc; 1 -> fx; else -> fy }
                            val range = when (zParam) {
                                0 -> ZoomMath.MIN_SCALE..ZoomMath.MAX_SCALE
                                else -> ZoomMath.FOCUS_MIN..ZoomMath.FOCUS_MAX
                            }
                            FlatSlider(cur, { setParam(zParam, it) }, range, !exporting, px)
                            if (selK != null) PanelNote("Keyframe di ${Library.fmtTime(selK.tMs)}", px)
                        }

                        // ---- 3D: kamera miring per blok ----
                        2 -> if (sel == null) PanelHint("Pilih blok zoom di timeline untuk mengatur kamera 3D-nya.", px) else {
                            PanelSeg(
                                listOf("3D mati" to Cam.OFF, "Kiri" to Cam.LEFT, "Kanan" to Cam.RIGHT, "Orbit" to Cam.ORBIT, "Customize" to Cam.CUSTOM),
                                sel.cam, !exporting, px,
                            ) { c ->
                                zooms = ZoomOps.update(zooms, sel.id) { z ->
                                    // pindah dari Kiri/Kanan ke Customize: mulai dari sudut preset itu, bukan dari nol
                                    if (c == Cam.CUSTOM && (z.cam == Cam.LEFT || z.cam == Cam.RIGHT)) {
                                        val pr = Cam.presetRot(z.cam)
                                        z.copy(cam = c, camPitch = pr.x, camYaw = pr.y, camRoll = pr.z)
                                    } else z.copy(cam = c)
                                }
                            }
                            if (sel.cam == Cam.CUSTOM) {
                                val cPitch = selK?.camPitch ?: sel.camPitch
                                val cYaw = selK?.camYaw ?: sel.camYaw
                                val cRoll = selK?.camRoll ?: sel.camRoll
                                val cDepth = selK?.camDepth ?: sel.camDepth
                                ParamRow(
                                    listOf("Angguk", "Tengok", "Miring", "Jarak"),
                                    listOf("%.0f°".format(cPitch), "%.0f°".format(cYaw), "%.0f°".format(cRoll), "%.1f×".format(cDepth)),
                                    cParam, !exporting, px,
                                ) { cParam = it }
                                val range = when (cParam) {
                                    0 -> -Cam.CUSTOM_PITCH_MAX..Cam.CUSTOM_PITCH_MAX
                                    1 -> -Cam.CUSTOM_YAW_MAX..Cam.CUSTOM_YAW_MAX
                                    2 -> -Cam.CUSTOM_ROLL_MAX..Cam.CUSTOM_ROLL_MAX
                                    else -> Cam.DEPTH_MIN..Cam.DEPTH_MAX
                                }
                                val curV = when (cParam) { 0 -> cPitch; 1 -> cYaw; 2 -> cRoll; else -> cDepth }
                                FlatSlider(curV, { setCam(cParam, it) }, range, !exporting, px)
                                if (selK != null) PanelNote("Keyframe di ${Library.fmtTime(selK.tMs)}", px)
                                if (player.positionMs < sel.startMs || player.positionMs > sel.endMs) {
                                    Row(px) { PanelPill("Lihat di blok ini", enabled = !exporting) { seek(((sel.startMs + sel.endMs) / 2).toFloat()) } }
                                }
                            } else {
                                PanelNote("Bingkai video dimiringkan saat zoom di blok ini.", px)
                            }
                        }

                        // ---- Kurva animasi: satu per channel (skala+posisi, dan tiap slider Customize 3D kamera) ----
                        else -> CurvePanel(
                            sel = sel,
                            channel = curveCh,
                            onChannel = { curveCh = it },
                            enabled = !exporting,
                            onCurve = setCurve,
                            onApplyAll = { ch, c ->
                                zooms = zooms.map { r ->
                                    when (ch) {
                                        CH_PITCH -> r.copy(curvePitch = c); CH_YAW -> r.copy(curveYaw = c)
                                        CH_ROLL -> r.copy(curveRoll = c); CH_DEPTH -> r.copy(curveDepth = c)
                                        else -> r.copy(curve = c)
                                    }
                                }
                            },
                        )
                    }

                    1 -> when (bgUi) {
                        // gradient: 6 bulatan satu baris; warna: 12 bulatan dua baris
                        0 -> GridRows(PRESETS.size, 6, 10.dp, px) { i, m ->
                            val (a, b) = PRESETS[i]
                            Swatch(Brush.verticalGradient(listOf(Color(a), Color(b))), i == preset, !exporting, m) { preset = i }
                        }
                        1 -> GridRows(SOLIDS.size, 6, 10.dp, px) { i, m ->
                            Swatch(Brush.verticalGradient(listOf(Color(SOLIDS[i]), Color(SOLIDS[i]))), i == solid, !exporting, m) { solid = i }
                        }
                        2 -> GridRows(WALLS.size, 3, 10.dp, px) { i, m ->
                            WallSwatch(WALLS[i], i == wall, !exporting, m) { wall = i }
                        }
                        // foto: tombol Galeri setinggi dua baris + foto bawaan 2 baris yang bisa digeser
                        3 -> Row(
                            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            GalleryTile(!exporting) {
                                pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            }
                            for (k in 0 until WALLPAPER_COUNT / 2) {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    for (j in 0..1) {
                                        val u = wallpaperUri(ctx, k * 2 + j + 1)
                                        WallThumb(ctx, u, imageUri == u, !exporting) { imageUri = u }
                                    }
                                }
                            }
                        }
                        else -> Column(px, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                buildAnnotatedString {
                                    append("Tingkat blur  ")
                                    withStyle(SpanStyle(color = cs.onBackground, fontWeight = FontWeight.SemiBold)) { append(pct(blurAmt, 0.01f..0.08f)) }
                                },
                                fontSize = 12.sp, color = cs.onSurfaceVariant,
                            )
                            FlatSlider(blurAmt, { blurAmt = it }, 0.01f..0.08f, !exporting)
                        }
                    }

                    2 -> when (tabSel) {
                        0 -> PanelGroup(px) {
                            TickSlider("Jarak", padding, 0f..0.25f, pct(padding, 0f..0.25f), !exporting) { padding = it }
                            TickSlider("Sudut", corner, 0f..0.10f, pct(corner, 0f..0.10f), !exporting, divider = true) { corner = it }
                        }
                        1 -> PanelGroup(px, 0.dp, 0.dp) {
                            ToggleRow("Bayangan", shadow, !exporting) { shadow = it }
                            TickSlider("Jumlah", shadowAmt, 0f..1f, pct(shadowAmt, 0f..1f), !exporting && shadow) { shadowAmt = it }
                        }
                        else -> PanelGroup(px, 0.dp, 6.dp) {
                            ToggleRow(
                                "Kursor sintetis", cursorOn, !exporting,
                                note = if (cursorOn && cursorTrack.isEmpty()) "Butuh data ketukan atau blok zoom." else null,
                            ) { cursorOn = it }
                        }
                    }

                    4 -> {
                    // target efek: Media (video + latar), Teks (teks bebas), atau Semua. "Semua" menampilkan nilai media dan
                    // menulis perubahan ke keduanya.
                    val showText = fxTarget == 1
                    val curLook = if (showText) tLook else look
                    val curLookAmt = if (showText) tLookAmt else lookAmt
                    val curVig = if (showText) tVignette else vignette
                    val curGlow = if (showText) tGlow else glow
                    val curGlowSize = if (showText) tGlowSize else glowSize
                    val setLook: (Int) -> Unit = { v -> if (fxTarget != 1) look = v; if (fxTarget != 0) tLook = v }
                    val setLookAmt: (Float) -> Unit = { v -> if (fxTarget != 1) lookAmt = v; if (fxTarget != 0) tLookAmt = v }
                    val setVig: (Float) -> Unit = { v -> if (fxTarget != 1) vignette = v; if (fxTarget != 0) tVignette = v }
                    val setGlow: (Float) -> Unit = { v -> if (fxTarget != 1) glow = v; if (fxTarget != 0) tGlow = v }
                    val setGlowSize: (Float) -> Unit = { v -> if (fxTarget != 1) glowSize = v; if (fxTarget != 0) tGlowSize = v }
                    PanelSeg(
                        listOf("Media" to 0, "Teks" to 1, "Semua" to 2), fxTarget, !exporting, px,
                    ) { fxTarget = it }
                    when (tabSel) {
                        // filter: tile pratinjau warna + intensitas
                        0 -> {
                            Row(
                                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Looks.presets.forEachIndexed { i, p -> LookTile(p.name, Looks.matrix(i, 0.6f), curLook == i, !exporting) { setLook(i) } }
                            }
                            PanelGroup(px) {
                                TickSlider("Intensitas", curLookAmt, 0f..1f, pct(curLookAmt, 0f..1f), !exporting && curLook != 0) { setLookAmt(it) }
                            }
                        }
                        1 -> PanelGroup(px) {
                            TickSlider("Jumlah", curVig, 0f..1f, pct(curVig, 0f..1f), !exporting) { setVig(it) }
                        }
                        else -> PanelGroup(px) {
                            TickSlider("Jumlah", curGlow, 0f..1f, pct(curGlow, 0f..1f), !exporting) { setGlow(it) }
                            TickSlider("Ukuran", curGlowSize, 0f..1f, pct(curGlowSize, 0f..1f), !exporting && curGlow > 0f, divider = true) { setGlowSize(it) }
                        }
                    }
                    }

                    // caption: Buat (model + bahasa + jalankan) / Teks (daftar baris, ubah, SRT) / Gaya (ukuran, tampil)
                    5 -> when (tabSel) {
                        0 -> {
                            Row(
                                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                WhisperModel.entries.forEach { m ->
                                    PanelPill("${m.label} · ${m.sizeMb} MB", capModel == m, !capBusy) { capModel = m }
                                }
                            }
                            PanelSeg(listOf("Otomatis" to "auto", "Indonesia" to "id", "English" to "en"), capLang, !capBusy, px) { capLang = it }
                            if (capBusy) {
                                PanelGroup(px) {
                                    Text("$capStatus ${(capProg * 100f).toInt()}%", Modifier.padding(top = 10.dp), fontSize = 13.sp, color = cs.onBackground)
                                    Spacer(Modifier.height(8.dp))
                                    LinearProgressIndicator(progress = { capProg }, modifier = Modifier.fillMaxWidth())
                                    Spacer(Modifier.height(10.dp))
                                }
                                Row(px.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                    PanelPill("Batal") { capCancel.set(true) }
                                }
                            } else {
                                Row(px.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    ActionCard(ICON_CAPTION, if (captions.isEmpty()) "Buat caption" else "Buat ulang", enabled = !exporting, modifier = Modifier.weight(1f)) { startCaptions() }
                                    ActionCard(ICON_TRASH, "Hapus", enabled = !exporting && captions.isNotEmpty(), modifier = Modifier.weight(1f)) {
                                        captions = emptyList(); showToast("Caption dihapus")
                                    }
                                }
                                val have = remember(capModel, capBusy) { WhisperModels.ready(ctx, capModel) }
                                PanelNote(
                                    (if (have) "Model sudah ada di HP, jalan offline. " else "Model ${capModel.label} belum ada: diunduh sekali (${capModel.sizeMb} MB, butuh internet). ") +
                                        "Caption dibuat dari seluruh suara video. Small paling akurat tapi butuh RAM besar.",
                                    px,
                                )
                            }
                        }
                        1 -> if (captions.isEmpty()) PanelHint("Belum ada caption. Buat dulu di tab Buat.", px) else {
                            Row(px.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                ActionCard(ICON_CAPTION, "Simpan SRT", enabled = !exporting, modifier = Modifier.weight(1f)) { exportSrt() }
                            }
                            PanelNote("Ketuk baris untuk melompat ke sana dan mengubah teksnya.", px)
                            captions.forEachIndexed { i, seg ->
                                Row(
                                    px.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(cs.surfaceVariant)
                                        .clickable { seek(seg.startMs.toFloat()); capEditIdx = i; capEditText = seg.text }
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Text(clock(seg.startMs), Modifier.width(44.dp), fontSize = 12.sp, color = cs.onSurfaceVariant)
                                    Text(seg.text, fontSize = 14.sp, color = cs.onBackground)
                                }
                            }
                        }
                        else -> {
                            PanelSeg(listOf("Tampil" to true, "Sembunyi" to false), capOn, !exporting, px) { capOn = it }
                            PanelGroup(px) {
                                TickSlider("Ukuran", capSize, 0f..1f, pct(capSize, 0f..1f), !exporting) { capSize = it }
                            }
                            PanelNote("Caption dibakar ke video saat ekspor, di bagian bawah kanvas.", px)
                        }
                    }

                    // rasio: 5 kartu persegi sama lebar
                    3 -> Row(px.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ASPECTS.forEachIndexed { i, (label, r) -> AspectCard(label, r, aspectIdx == i, !exporting, Modifier.weight(1f)) { aspectIdx = i } }
                    }

                    // teks bebas: tambah/hapus/ubah teks, geser posisinya langsung di kanvas
                    TOOL_TEXT -> {
                        Row(px.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ActionCard(ICON_TEXT, "Tambah teks", enabled = !exporting, modifier = Modifier.weight(1f)) {
                                textAddValue = ""; textAddOpen = true
                            }
                            ActionCard(ICON_TRASH, "Hapus", enabled = !exporting && selectedText != null, modifier = Modifier.weight(1f)) {
                                texts = texts.filter { it.id != selectedText }
                                selectedText = null
                            }
                        }
                        val st = texts.firstOrNull { it.id == selectedText }
                        if (texts.isEmpty()) {
                            PanelHint("Belum ada teks. Ketuk \"Tambah teks\", lalu geser langsung di kanvas untuk mengatur posisinya.", px)
                        } else if (st == null) {
                            PanelNote("Ketuk salah satu teks di kanvas untuk memilih dan mengaturnya.", px)
                        } else {
                            PanelGroup(px) {
                                TickSlider("Ukuran", st.sizeFrac, 0f..1f, pct(st.sizeFrac, 0f..1f), !exporting) { v ->
                                    texts = texts.map { if (it.id == st.id) it.copy(sizeFrac = v) else it }
                                }
                            }
                            Row(px.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                ActionCard(ICON_TEXT, "Ubah teks", enabled = !exporting, modifier = Modifier.weight(1f)) {
                                    textEditValue = st.text; textEditOpen = true
                                }
                                ActionCard(ICON_TEXT, "Font: " + TextOverlays.FONT_NAMES[st.font.coerceIn(0, TextOverlays.FONT_NAMES.lastIndex)], enabled = !exporting, modifier = Modifier.weight(1f)) {
                                    val next = (st.font + 1) % TextOverlays.FONT_NAMES.size
                                    texts = texts.map { if (it.id == st.id) it.copy(font = next) else it }
                                }
                            }
                            PanelNote("Geser teks di kanvas untuk mengatur posisi. Warnanya ikut filter & vignette di tab Efek.", px)
                        }
                    }

                    // audio tambahan: tab Audio = tambah/hapus klip + posisi + volume; tab Volume = suara asli video
                    TOOL_AUDIO -> when (tabSel) {
                        0 -> {
                            Row(px.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                ActionCard(
                                    ICON_MUSIC, if (audioBusy) "Memuat…" else "Tambah audio",
                                    enabled = !exporting && !audioBusy, modifier = Modifier.weight(1f),
                                ) { player.pauseHere(); pickAudio.launch(arrayOf("audio/*")) }
                                ActionCard(ICON_TRASH, "Hapus", enabled = !exporting && selectedAudio != null, modifier = Modifier.weight(1f)) {
                                    audios = audios.filter { it.id != selectedAudio }
                                    selectedAudio = null
                                    showToast("Audio dihapus")
                                }
                            }
                            val sa = audios.firstOrNull { it.id == selectedAudio }
                            if (audios.isEmpty()) {
                                PanelHint("Belum ada audio. Ketuk \"Tambah audio\" untuk memilih musik atau suara dari HP; audio mulai dari posisi playhead.", px)
                            } else {
                                audios.forEach { c ->
                                    val on = c.id == selectedAudio
                                    Row(
                                        px.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                                            .background(if (on) cs.primary.copy(alpha = 0.18f) else cs.surfaceVariant)
                                            .clickable { selectedAudio = c.id; seek(c.startMs.toFloat()) }
                                            .padding(horizontal = 12.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                    ) {
                                        ToolIcon(ICON_MUSIC, if (on) cs.primary else cs.onSurfaceVariant, 20.dp)
                                        Spacer(Modifier.width(10.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(c.name, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = cs.onBackground)
                                            Text("${clock(c.startMs)} – ${clock(c.endMs)}", fontSize = 12.sp, color = cs.onSurfaceVariant)
                                        }
                                    }
                                }
                                if (sa == null) {
                                    PanelNote("Ketuk salah satu audio untuk mengatur waktu mulai dan volumenya.", px)
                                } else {
                                    PanelGroup(px) {
                                        TickSlider("Mulai", sa.startMs.toFloat(), 0f..durMs.toFloat(), clock(sa.startMs), !exporting) { v ->
                                            audios = audios.map { if (it.id == sa.id) it.copy(startMs = v.toLong().coerceIn(0L, durMs)) else it }
                                        }
                                        TickSlider("Volume", sa.volume, 0f..1f, pct(sa.volume, 0f..1f), !exporting, divider = true) { v ->
                                            audios = audios.map { if (it.id == sa.id) it.copy(volume = v) else it }
                                        }
                                    }
                                    Row(px.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        ActionCard(ICON_AREA, "Mulai di playhead", enabled = !exporting, modifier = Modifier.weight(1f)) {
                                            val t = player.positionMs.coerceIn(0L, durMs)
                                            audios = audios.map { if (it.id == sa.id) it.copy(startMs = t) else it }
                                        }
                                    }
                                    PanelNote("Audio diputar sekali dari waktu mulai sampai habis, dan ikut terpotong kalau video dipotong. Pratinjau dan ekspor sama.", px)
                                }
                            }
                        }
                        else -> {
                            PanelGroup(px) {
                                TickSlider("Suara", origVol, 0f..1f, pct(origVol, 0f..1f), !exporting) { origVol = it }
                            }
                            PanelNote("Volume suara asli rekaman (0 = senyap). Audio tambahan diatur sendiri-sendiri di tab Audio.", px)
                        }
                    }

                    else -> {}
                }
            }
        }
    }

    // Area bawah: timeline (menempel di atas) + nav. Panel tool menutupi bagian bawah area ini, termasuk nav,
    // tapi ruler + baris video tetap terlihat (untuk Zoom: baris zoom juga), jadi playhead tetap bisa digeser.
    // Panel naik dari bawah (0,3 dtk) dan tingginya beranimasi (0,25 dtk) saat pindah antar tool, seperti desain.
    val bottomSection: @Composable (Modifier) -> Unit = { mod ->
        Box(mod.onSizeChanged { bottomH = it.height }) {
            Column(Modifier.fillMaxSize()) {
                Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp)) { timeline() }
                toolbar()
            }
            val open = tool in TOOLS.indices
            if (open) lastTool[0] = tool
            val shown = lastTool[0]
            val keep = if (shown == 0) TL_ROWS_ZOOM else TL_ROWS_TOP
            val target = (with(LocalDensity.current) { bottomH.toDp() } - keep).coerceAtLeast(150.dp)
            val panelH by animateDpAsState(target, tween(250), label = "panelH")
            AnimatedVisibility(
                visible = open,
                modifier = Modifier.align(Alignment.BottomCenter),
                enter = slideInVertically(tween(300, easing = PANEL_EASE)) { (it * 1.02f).toInt() },
                exit = slideOutVertically(tween(300, easing = PANEL_EASE)) { (it * 1.02f).toInt() },
            ) { panel(panelH, shown) }
        }
    }

    val toastChip: @Composable () -> Unit = {
        toast?.let { m ->
            Box(
                Modifier.clip(RoundedCornerShape(50)).background(cs.surfaceContainerHighest.copy(alpha = 0.92f))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            ) { Text(m, style = MaterialTheme.typography.labelMedium, color = cs.onBackground, maxLines = 1) }
        }
    }

    val errorChip: @Composable () -> Unit = {
        (error ?: player.failed)?.let { m ->
            Box(
                Modifier.clip(RoundedCornerShape(50)).background(cs.surfaceContainerHighest.copy(alpha = 0.92f))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            ) { Text(m, style = MaterialTheme.typography.labelMedium, color = cs.error, maxLines = 1, overflow = TextOverflow.Ellipsis) }
        }
    }

    // Kanvas dan baris player TERKUNCI: ukuran dan posisinya tidak bergantung pada panel yang dibuka.
    // Area bawah punya tinggi tetap di potret; panel tool hanya menimpa isinya (lihat bottomSection).
    if (askSave) {
        AlertDialog(
            onDismissRequest = { askSave = false },
            title = { Text("Simpan project?") },
            text = { Text("Ada perubahan yang belum disimpan.") },
            confirmButton = { TextButton(onClick = { askSave = false; saveProject { onBack() } }) { Text("Simpan") } },
            dismissButton = {
                Row {
                    TextButton(onClick = { askSave = false }) { Text("Batal") }
                    TextButton(onClick = { askSave = false; onBack() }) { Text("Buang", color = cs.error) }
                }
            },
        )
    }
    capEditIdx?.let { idx ->
        if (idx in captions.indices) {
            AlertDialog(
                onDismissRequest = { capEditIdx = null },
                title = { Text("Ubah caption") },
                text = { OutlinedTextField(value = capEditText, onValueChange = { capEditText = it }, modifier = Modifier.fillMaxWidth()) },
                confirmButton = {
                    TextButton(onClick = {
                        val t = capEditText.trim()
                        captions = if (t.isEmpty()) captions.filterIndexed { i, _ -> i != idx }
                        else captions.mapIndexed { i, s -> if (i == idx) s.copy(text = t) else s }
                        capEditIdx = null
                    }) { Text("Simpan") }
                },
                dismissButton = {
                    Row {
                        TextButton(onClick = { capEditIdx = null }) { Text("Batal") }
                        TextButton(onClick = { captions = captions.filterIndexed { i, _ -> i != idx }; capEditIdx = null }) { Text("Hapus", color = cs.error) }
                    }
                },
            )
        }
    }
    if (textAddOpen) {
        AlertDialog(
            onDismissRequest = { textAddOpen = false },
            title = { Text("Tambah teks") },
            text = { OutlinedTextField(value = textAddValue, onValueChange = { textAddValue = it }, modifier = Modifier.fillMaxWidth()) },
            confirmButton = {
                TextButton(onClick = {
                    val v = textAddValue.trim()
                    if (v.isNotEmpty()) {
                        val id = System.nanoTime()
                        texts = texts + TextOverlay(id = id, text = v)
                        selectedText = id
                    }
                    textAddOpen = false
                }) { Text("Tambah") }
            },
            dismissButton = { TextButton(onClick = { textAddOpen = false }) { Text("Batal") } },
        )
    }
    if (textEditOpen) {
        AlertDialog(
            onDismissRequest = { textEditOpen = false },
            title = { Text("Ubah teks") },
            text = { OutlinedTextField(value = textEditValue, onValueChange = { textEditValue = it }, modifier = Modifier.fillMaxWidth()) },
            confirmButton = {
                TextButton(onClick = {
                    val id = selectedText
                    val v = textEditValue.trim()
                    if (id != null) {
                        texts = if (v.isEmpty()) texts.filter { it.id != id } else texts.map { if (it.id == id) it.copy(text = v) else it }
                        if (v.isEmpty()) selectedText = null
                    }
                    textEditOpen = false
                }) { Text("Simpan") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { textEditOpen = false }) { Text("Batal") }
                    TextButton(onClick = {
                        val id = selectedText
                        if (id != null) texts = texts.filter { it.id != id }
                        selectedText = null; textEditOpen = false
                    }) { Text("Hapus", color = cs.error) }
                }
            },
        )
    }
    BoxWithConstraints(modifier) {
        val land = maxWidth > maxHeight
        Column(Modifier.fillMaxSize()) {
            topBar()
            if (land) {
                Row(Modifier.weight(1f).fillMaxWidth()) {
                    Column(Modifier.weight(if (focus) 1f else 0.42f).fillMaxHeight()) {
                        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { preview() }
                            Box(Modifier.align(Alignment.BottomStart).padding(8.dp)) { toastChip() }
                            Box(Modifier.align(Alignment.TopCenter).padding(8.dp)) { errorChip() }
                        }
                        playerCard()
                    }
                    if (!focus) bottomSection(Modifier.weight(0.58f).fillMaxHeight())
                }
            } else {
                Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp)) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { preview() }
                    Box(Modifier.align(Alignment.BottomStart).padding(8.dp)) { toastChip() }
                    Box(Modifier.align(Alignment.TopCenter).padding(8.dp)) { errorChip() }
                }
                playerCard()
                if (!focus) bottomSection(Modifier.fillMaxWidth().height(TL_AREA + TOOLBAR_H + 1.dp))
            }
        }
    }
}

/** Pratinjau: kanvas berlatar + video dengan padding/sudut/bayangan (perkiraan dari hasil ekspor). */
@Composable
private fun FramePreview(
    uri: Uri, videoAspect: Float, style: FrameStyle, player: PlayerState, img: Bitmap?, frame: Bitmap?, zooms: List<ZoomRegion>,
    cursorTrack: List<TouchEvent>, timeMs: () -> Float, captions: List<CaptionSeg>, capSize: Float,
    editRegion: ZoomRegion?,
    texts: List<TextOverlay>, selectedText: Long?, textEditable: Boolean,
    onTextSelect: (Long) -> Unit, onTextMove: (id: Long, fx: Float, fy: Float) -> Unit,
    onEdit: (fx: Float, fy: Float, scale: Float) -> Unit,
) {
    val canvasAspect = style.aspect ?: videoAspect
    val tvRef = remember { arrayOfNulls<TextureView>(1) }   // TextureView video, dibaca overlay glow
    // filter warna pratinjau: matriks 4x5 yang sama dengan uniform shader ekspor (null = tanpa filter)
    val lookFilter = remember(style.look, style.lookAmt) { Looks.matrix(style.look, style.lookAmt)?.let { Looks.colorMatrix20(it) } }
    // filter warna TEKS: terpisah dari media (lihat FrameStyle.tLook)
    val textLookFilter = remember(style.tLook, style.tLookAmt) { Looks.matrix(style.tLook, style.tLookAmt)?.let { Looks.colorMatrix20(it) } }
    BoxWithConstraints(Modifier.aspectRatio(canvasAspect).clip(RoundedCornerShape(12.dp)).clipToBounds()) {
        // filter warna berlaku juga di background (seluruh kanvas); bayangan kartu tetap hitam, sama dengan ekspor
        Box(Modifier.fillMaxSize().colorMatrixLayer(lookFilter)) { BackgroundLayer(style, img, frame, videoAspect) { tvRef[0] } }
        val short = min(maxWidth, maxHeight)
        val pad = short * style.padding
        val shape = RoundedCornerShape(short * style.corner)
        // ukuran kanvas (px): diambil di sini, karena `constraints` tidak bisa dipanggil dari lambda graphicsLayer (beda scope)
        val cw = constraints.maxWidth.toFloat()
        val ch = constraints.maxHeight.toFloat()
        // ukuran kartu video (px) untuk pemilih area: kartu muat di dalam kanvas dikurangi padding, rasio = rasio video
        val padPx = with(LocalDensity.current) { pad.toPx() }
        val availW = (cw - 2f * padPx).coerceAtLeast(1f)
        val availH = (ch - 2f * padPx).coerceAtLeast(1f)
        val cardW = if (availW / availH > videoAspect) availH * videoAspect else availW
        val cardH = cardW / videoAspect
        Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.Center) {
            Box(
                Modifier.aspectRatio(videoAspect)
                    .graphicsLayer {
                        // zoom kartu: seluruh bingkai dibesarkan dari pojok kiri-atasnya lalu digeser (rumus sama dengan ekspor)
                        // timeMs() dibaca DI SINI (fase layer): tiap frame hanya layer yang dihitung ulang, bukan seluruh UI
                        val hw = this.size.width / 2f; val hh = this.size.height / 2f
                        val cz = if (editRegion != null) CardZoom.NONE else ZoomMath.camera(zooms, timeMs().toDouble(), CardGeo(cw, ch, cw / 2f, ch / 2f, hw, hh))
                        transformOrigin = TransformOrigin(0f, 0f)
                        scaleX = cz.s
                        scaleY = cz.s
                        translationX = (cz.s - 1f) * (cw / 2f - hw) + cz.tx
                        translationY = (cz.s - 1f) * (ch / 2f - hh) + cz.ty
                    }
                    .graphicsLayer {
                        // kamera 3D: SAMA dengan shader ekspor (uRot/uPers/uOff). Titik bidang p = fit * s * (titik kartu) jatuh di
                        // P * (R p + (o, 0)).xy / (P - (R p).z), R = Rx(pitch) Ry(yaw) Rz(roll). Satuan layer ini = px kartu SEBELUM zoom,
                        // jadi P dan o dibagi s (zoom di layer luar menskala semuanya sama).
                        // graphicsLayer: rotationX/Y/Z = pitch/yaw/roll, scale lebih dulu dari rotasi, cameraDistance = P / 72 (lihat Cam).
                        // Offset kamera nyata (o) bekerja SEBELUM pembagian perspektif, sedangkan translation graphicsLayer sesudahnya:
                        // dibuat dengan menggeser PIVOT (Cam.layerFit), identik secara aljabar.
                        val hw = this.size.width / 2f; val hh = this.size.height / 2f
                        val cz = if (editRegion != null) CardZoom.NONE else ZoomMath.camera(zooms, timeMs().toDouble(), CardGeo(cw, ch, cw / 2f, ch / 2f, hw, hh), if (style.cursor) cursorTrack else emptyList())
                        if (cz.tilted) {
                            val pl = (if (cz.persp > 0f) cz.persp else Cam.perspectivePx(2f * hw * cz.s, 2f * hh * cz.s)) / cz.s
                            val lf = Cam.layerFit(cz.rot, pl, cz.ox / cz.s, cz.oy / cz.s)
                            val pvx = lf.cx / cz.fit; val pvy = lf.cy / cz.fit      // pivot, px kartu relatif pusat
                            rotationX = cz.pitchDeg
                            rotationY = cz.yawDeg
                            rotationZ = cz.rollDeg
                            scaleX = cz.fit * lf.sigma
                            scaleY = cz.fit * lf.sigma
                            transformOrigin = TransformOrigin(0.5f + pvx / this.size.width, 0.5f + pvy / this.size.height)
                            translationX = -pvx
                            translationY = -pvy
                            cameraDistance = pl / Cam.ANDROID_CAMERA_UNIT
                        }
                    }
                    .then(if (style.shadow && style.shadowAmt > 0f) Modifier.shadow(
                        short * (0.08f * style.shadowAmt), shape,
                        ambientColor = Color.Black.copy(alpha = (style.shadowAmt * 2f).coerceAtMost(1f)),
                        spotColor = Color.Black.copy(alpha = (style.shadowAmt * 2f).coerceAtMost(1f)),
                    ) else Modifier)
                    .clip(shape),
            ) {
                // Bingkai di atas sudah clip(shape) dan ikut dibesarkan bersama isinya (zoom kartu, bukan crop isi video).
                // glow (bloom): urutan efek sama dengan ekspor: filter warna -> glow -> vignette
                VideoSurface(player, Modifier.fillMaxSize(), lookFilter) { tvRef[0] = it }
                GlowOverlay(style.glow, style.glowSize, style.look, style.lookAmt, { tvRef[0] }, Modifier.fillMaxSize())
                // teks bebas ada di bawah, SETELAH vignette media: efek media tidak menyentuh teks, teks punya efek sendiri
                // vignette: gradien radial hitam di atas video (r = jarak / setengah diagonal kartu), rumus sama dengan shader ekspor
                if (style.vignette > 0f) Canvas(Modifier.fillMaxSize()) {
                    val half = kotlin.math.hypot(size.width, size.height) / 2f
                    val rs = listOf(0f, Looks.VIG_START, 0.45f, 0.55f, 0.65f, 0.75f, 0.85f, 0.93f, 1f)
                    drawRect(Brush.radialGradient(
                        colorStops = rs.map { r -> r to Color.Black.copy(alpha = Looks.vigAlpha(r, style.vignette)) }.toTypedArray(),
                        center = center, radius = half,
                    ))
                }
                // teks bebas: DI DALAM kartu (bukan di atas semua kanvas seperti caption). Filter, vignette, dan glow-nya
                // sendiri (style.tLook / tVignette / tGlow), terpisah dari media utama
                if (texts.isNotEmpty()) TextOverlaysLayer(
                    texts, selectedText, textEditable, textLookFilter, style.tVignette, style.tGlow, style.tGlowSize,
                    onTextSelect, onTextMove,
                )
                // kursor sintetis: di dalam bingkai yang sama, jadi ikut terpotong dan ikut miring (kamera 3D)
                if (style.cursor) Canvas(Modifier.fillMaxSize()) {
                    CursorMath.at(cursorTrack, timeMs().toLong())?.let { drawCursor(it) }
                }
            }
        }
        // caption: di atas seluruh kanvas (tidak ikut zoom/miring), bitmap sama dengan yang dibakar saat ekspor
        if (captions.isNotEmpty()) {
            val capCache = remember { CaptionBitmapCache() }
            Canvas(Modifier.fillMaxSize()) {
                val seg = Captions.at(captions, timeMs().toLong()) ?: return@Canvas
                val bmp = capCache.get(seg.text, size.width.toInt(), size.height.toInt(), capSize)
                drawImage(bmp.asImageBitmap(), Offset(0f, size.height - bmp.height))
            }
        }
        // pemilih area zoom: di atas SELURUH kanvas (bukan hanya kartu), kartu tampil tanpa zoom.
        // Jendela boleh keluar dari kartu ke area background.
        if (editRegion != null) ZoomAreaOverlay(editRegion, CardGeo(cw, ch, cw / 2f, ch / 2f, cardW / 2f, cardH / 2f), onEdit)
    }
}

/**
 * Lapisan teks bebas di pratinjau: tiap teks ditaruh pada ([TextOverlay.xFrac], [TextOverlay.yFrac]) relatif kartu,
 * dibungkus [colorMatrixLayer] supaya ikut filter warna (sama seperti video), dan digambar SEBELUM vignette Canvas di
 * kartu (lihat pemanggil) supaya ikut tergelapkan vignette juga — tanpa perlu hitung manual seperti di ekspor (GL).
 * Saat [editable] (tool Teks aktif), teks bisa diseret (drag) untuk mengatur posisi dan diketuk untuk dipilih.
 */
@Composable
private fun TextOverlaysLayer(
    texts: List<TextOverlay>, selectedId: Long?, editable: Boolean, lookFilter: FloatArray?,
    vignette: Float, glow: Float, glowSize: Float,
    onSelect: (Long) -> Unit, onMove: (id: Long, fx: Float, fy: Float) -> Unit,
) {
    BoxWithConstraints(Modifier.fillMaxSize().colorMatrixLayer(lookFilter)) {
        val cw = constraints.maxWidth.toFloat()
        val ch = constraints.maxHeight.toFloat()
        val short = kotlin.math.min(cw, ch)
        texts.forEach { t ->
            key(t.id) {
                var fx by remember(t.id) { mutableFloatStateOf(t.xFrac) }
                var fy by remember(t.id) { mutableFloatStateOf(t.yFrac) }
                LaunchedEffect(t.xFrac, t.yFrac) { fx = t.xFrac; fy = t.yFrac }
                var sizePx by remember { mutableStateOf(IntSize.Zero) }
                val selected = editable && t.id == selectedId
                val textPx = TextOverlays.pxSize(cw.toInt(), ch.toInt(), t.sizeFrac)
                // vignette teks: gelapkan warna menurut jarak titik tengah teks dari pusat kartu (sama dengan ekspor)
                val vr = kotlin.math.hypot((fx - 0.5f) * cw, (fy - 0.5f) * ch) / (kotlin.math.hypot(cw, ch) / 2f).coerceAtLeast(1f)
                val dark = if (vignette > 0f) 1f - Looks.vigAlpha(vr.coerceIn(0f, 1f), vignette) else 1f
                Text(
                    text = t.text,
                    color = Color(dark, dark, dark),
                    fontFamily = TextOverlays.fontRes(t.font)?.let { FontFamily(Font(it)) },
                    fontWeight = if (t.font == 0) FontWeight.Bold else FontWeight.Normal,
                    fontSize = with(LocalDensity.current) { TextOverlays.pxSize(cw.toInt(), ch.toInt(), t.sizeFrac).toSp() },
                    style = LocalTextStyle.current.copy(
                        shadow = if (glow > 0f) Shadow(
                            Color.White.copy(alpha = TextOverlays.glowAlpha(glow)), Offset.Zero,
                            blurRadius = TextOverlays.glowRadius(textPx, glow, glowSize),
                        ) else Shadow(Color.Black.copy(alpha = 0.6f), Offset(0f, short * 0.004f), blurRadius = short * 0.02f),
                    ),
                    modifier = Modifier
                        .onSizeChanged { sizePx = it }
                        .offset { IntOffset((fx * cw - sizePx.width / 2f).roundToInt(), (fy * ch - sizePx.height / 2f).roundToInt()) }
                        .then(
                            if (!editable) Modifier else Modifier
                                .border(if (selected) 1.dp else 0.dp, Color.White.copy(alpha = 0.7f), RoundedCornerShape(4.dp))
                                .clickable { onSelect(t.id) }
                                .pointerInput(t.id) {
                                    detectDragGestures(
                                        onDragStart = { onSelect(t.id) },
                                        onDrag = { change, drag ->
                                            change.consume()
                                            fx = (fx + drag.x / cw).coerceIn(0.03f, 0.97f)
                                            fy = (fy + drag.y / ch).coerceIn(0.03f, 0.97f)
                                            onMove(t.id, fx, fy)
                                        },
                                    )
                                },
                        ),
                )
            }
        }
    }
}

/**
 * Glow (bloom) pratinjau, jalan di semua versi Android. Langkah sama dengan ekspor ([Looks.glowPreview]): gambar video diambil dari [view]
 * (TextureView) tiga kali lebih besar dari tekstur glow, dirata-ratakan (prefilter), diberi filter warna + ambang, diblur Gaussian di
 * resolusi kecil, lalu diperbesar bilinear dan digambar di atas video dengan BlendMode.Screen pada alpha = [amount]
 * (sama dengan `1 - (1 - v)(1 - amount * g)` di shader ekspor). Pengolahan CPU berjalan di Dispatchers.Default, tiap dua frame.
 */
@Composable
private fun GlowOverlay(amount: Float, sizeFrac: Float, look: Int, lookAmt: Float, view: () -> TextureView?, modifier: Modifier) {
    val a = amount.coerceIn(0f, 1f)
    if (a <= 0f) return
    var bmp by remember { mutableStateOf<Bitmap?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    var box by remember { mutableStateOf(IntSize.Zero) }
    val m = remember(look, lookAmt) { Looks.matrix(look, lookAmt) ?: Looks.ID }
    LaunchedEffect(sizeFrac, m, box) {
        if (box.width <= 0 || box.height <= 0) return@LaunchedEffect
        val sigX = Looks.glowSigmaFrac(sizeFrac) * kotlin.math.min(box.width, box.height) / box.width
        val gw = (3f / sigX).coerceIn(16f, 120f).toInt()
        val gh = (gw * box.height.toFloat() / box.width).toInt().coerceAtLeast(8)
        val sigB = (sigX * gw).coerceIn(0.5f, 4f)
        val sw = gw * 3
        val sh = gh * 3
        val raw = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
        val out = Bitmap.createBitmap(gw, gh, Bitmap.Config.ARGB_8888)
        val src = IntArray(sw * sh)
        val px = IntArray(gw * gh)
        var frames = 0
        while (true) {
            withFrameNanos { }
            if (frames++ % 2 != 0) continue
            val tv = view() ?: continue
            if (!tv.isAvailable) continue
            var ok = false
            try {
                tv.getBitmap(raw)
                raw.getPixels(src, 0, sw, 0, 0, sw, sh)
                ok = true
            } catch (_: Exception) {}
            if (!ok) continue
            withContext(Dispatchers.Default) {
                Looks.glowPreview(src, sw, sh, gw, gh, sigB, m, px)
                out.setPixels(px, 0, gw, 0, 0, gw, gh)
            }
            bmp = out
            tick++
        }
    }
    Canvas(modifier.onSizeChanged { box = it }) {
        tick   // langganan: gambar ulang tiap gambar kecil baru
        bmp?.let {
            drawImage(
                it.asImageBitmap(),
                dstSize = IntSize(size.width.toInt(), size.height.toInt()),
                alpha = a, blendMode = BlendMode.Screen, filterQuality = FilterQuality.High,
            )
        }
    }
}

/** Menjalankan isi lewat filter matriks warna 4x5 (null = apa adanya). Dipakai agar background ikut berfilter seperti video. */
private fun Modifier.colorMatrixLayer(m: FloatArray?): Modifier = if (m == null) this else this.drawWithContent {
    drawIntoCanvas { canvas ->
        val paint = androidx.compose.ui.graphics.Paint().apply {
            colorFilter = androidx.compose.ui.graphics.ColorFilter.colorMatrix(androidx.compose.ui.graphics.ColorMatrix(m))
        }
        canvas.saveLayer(androidx.compose.ui.geometry.Rect(Offset.Zero, size), paint)
        drawContent()
        canvas.restore()
    }
}

/**
 * Background blur pratinjau yang BERGERAK: gambar kecil video diambil terus dari [view] (TextureView yang sama dengan video utama,
 * jadi selalu satu frame dan satu posisi dengan video: play, jeda, dan scrub ikut), digambar memenuhi kanvas (crop tengah) lalu diblur.
 * Gambar kecil dipakai supaya murah (CPU hampir nol) dan sudah halus saat diperbesar bilinear. Sebelum frame pertama tiba,
 * [placeholder] (frame pertama video) ditampilkan supaya tidak berkedip. Sama dengan ekspor, yang membaca tekstur video tiap frame.
 */
@Composable
private fun LiveBlurBackground(placeholder: Bitmap?, videoAspect: Float, view: () -> TextureView?, modifier: Modifier) {
    var bmp by remember { mutableStateOf<Bitmap?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(videoAspect) {
        val bw = 96
        val bh = (bw / videoAspect).toInt().coerceIn(16, 256)
        val buf = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        var frames = 0
        while (true) {
            withFrameNanos { }
            if (frames++ % 2 != 0) continue
            val tv = view() ?: continue
            if (!tv.isAvailable) continue
            try {
                tv.getBitmap(buf)
                bmp = buf
                tick++
            } catch (_: Exception) {}
        }
    }
    Canvas(modifier.clipToBounds().blur(24.dp)) {
        tick   // langganan: gambar ulang tiap frame baru
        val src = bmp ?: placeholder ?: return@Canvas
        val sc = kotlin.math.max(size.width / src.width, size.height / src.height)
        val dw = src.width * sc
        val dh = src.height * sc
        drawImage(
            src.asImageBitmap(),
            dstOffset = androidx.compose.ui.unit.IntOffset(((size.width - dw) / 2f).toInt(), ((size.height - dh) / 2f).toInt()),
            dstSize = IntSize(dw.toInt() + 1, dh.toInt() + 1),
            filterQuality = FilterQuality.High,
        )
    }
}

@Composable
private fun BackgroundLayer(style: FrameStyle, img: Bitmap?, frame: Bitmap?, videoAspect: Float, view: () -> TextureView?) {
    when {
        style.bgType == 2 && img != null ->
            Image(img.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        style.bgType == 3 ->
            LiveBlurBackground(frame, videoAspect, view, Modifier.fillMaxSize())
        style.bgType == 1 ->
            Box(
                Modifier.fillMaxSize().drawBehind {
                    drawRect(Color(style.top))
                    val r = size.maxDimension * 0.95f
                    drawRect(Brush.radialGradient(listOf(Color(style.mid), Color.Transparent),
                        center = Offset(size.width * 0.15f, size.height * 0.15f), radius = r))
                    drawRect(Brush.radialGradient(listOf(Color(style.bottom), Color.Transparent),
                        center = Offset(size.width * 0.85f, size.height * 0.85f), radius = r))
                },
            )
        else ->
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(style.top), Color(style.bottom)))))
    }
}

@Composable
private fun Swatch(brush: Brush, selected: Boolean, enabled: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.aspectRatio(1f).clip(CircleShape)
            .background(brush)
            .then(
                if (selected) Modifier.border(3.dp, MaterialTheme.colorScheme.primary, CircleShape)
                else Modifier.border(1.dp, Color.White.copy(alpha = 0.14f), CircleShape),
            )
            .clickable(enabled = enabled, onClick = onClick),
    )
}

@Composable
private fun VideoSurface(state: PlayerState, modifier: Modifier, colorMatrix: FloatArray? = null, onView: (TextureView) -> Unit = {}) {
    AndroidView(
        modifier = modifier,
        update = { tv ->
            tv.setLayerPaint(
                if (colorMatrix == null) null
                else android.graphics.Paint().apply { colorFilter = android.graphics.ColorMatrixColorFilter(android.graphics.ColorMatrix(colorMatrix)) },
            )
        },
        factory = { c ->
            TextureView(c).apply {
                onView(this)
                surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                        state.attach(Surface(st))
                    }

                    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}

                    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                        // pemutar TIDAK dibuang, hanya dilepas dari surface; surface baru dipasang saat tersedia lagi
                        state.detach()
                        return true
                    }

                    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
                }
            }
        },
    )
}
