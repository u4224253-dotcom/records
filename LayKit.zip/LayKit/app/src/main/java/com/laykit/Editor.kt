package com.laykit

import android.graphics.Bitmap
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.net.Uri
import android.view.Surface
import android.view.TextureView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val PRESETS = listOf(
    0xFF1E3A8A.toInt() to 0xFF7C3AED.toInt(),   // biru-ungu
    0xFFF97316.toInt() to 0xFFDB2777.toInt(),   // sunset
    0xFF059669.toInt() to 0xFF0E7490.toInt(),   // tosca
    0xFF0F172A.toInt() to 0xFF334155.toInt(),   // malam
    0xFFF8FAFC.toInt() to 0xFFCBD5E1.toInt(),   // terang
    0xFF000000.toInt() to 0xFF000000.toInt(),   // hitam
)

private val SOLIDS = listOf(
    0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFF0F172A.toInt(), 0xFF1E293B.toInt(),
    0xFFEF4444.toInt(), 0xFFF97316.toInt(), 0xFFEAB308.toInt(), 0xFF22C55E.toInt(),
    0xFF06B6D4.toInt(), 0xFF3B82F6.toInt(), 0xFF8B5CF6.toInt(), 0xFFEC4899.toInt(),
)

// wallpaper "mesh": warna dasar, warna tengah, warna sudut bawah
private val WALLS = listOf(
    Triple(0xFF0B1026.toInt(), 0xFF22D3AE.toInt(), 0xFF7C3AED.toInt()),   // aurora
    Triple(0xFF2B1055.toInt(), 0xFFFB7185.toInt(), 0xFFFBBF24.toInt()),   // senja
    Triple(0xFF03045E.toInt(), 0xFF0096C7.toInt(), 0xFF90E0EF.toInt()),   // laut
    Triple(0xFF111827.toInt(), 0xFFF472B6.toInt(), 0xFF38BDF8.toInt()),   // neon
    Triple(0xFF052E16.toInt(), 0xFF16A34A.toInt(), 0xFFA3E635.toInt()),   // hutan
    Triple(0xFFFDE68A.toInt(), 0xFFF9A8D4.toInt(), 0xFFA5B4FC.toInt()),   // pastel
)

/** Wallpaper foto bawaan (res/raw/wallpaper1..18.jpg), diambil dari Openscreen (MIT), diperkecil ke 1600 px. */
private const val WALLPAPER_COUNT = 18

private fun wallpaperUri(ctx: android.content.Context, n: Int): Uri =
    Uri.parse("android.resource://${ctx.packageName}/raw/wallpaper$n")

@Composable
private fun WallThumb(ctx: android.content.Context, uri: Uri, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val bmp by produceState<Bitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) { Exporter.loadImage(ctx, uri, 160) }
    }
    val shape = RoundedCornerShape(10.dp)
    Box(
        Modifier.size(width = 72.dp, height = 46.dp).clip(shape)
            .background(Color.Gray.copy(alpha = 0.3f))
            .clickable(enabled = enabled, onClick = onClick),
    ) {
        bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        if (selected) Box(Modifier.matchParentSize().border(3.dp, MaterialTheme.colorScheme.primary, shape))
    }
}

/** Kotak "tambah dari galeri" di tab Foto: setinggi dua baris foto (46 + 8 + 46). */
@Composable
private fun GalleryTile(enabled: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier.size(width = 72.dp, height = 100.dp).clip(RoundedCornerShape(10.dp)).background(cs.surfaceVariant)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { ToolIcon(ICON_PLUS, cs.onBackground, 22.dp) }
}

/** Contoh warna untuk tile filter (sama dengan SAMPLE di desain). */
private val LOOK_SAMPLE = Brush.verticalGradient(
    0f to Color(0xFFFDA4AF), 0.35f to Color(0xFFFCD34D), 0.65f to Color(0xFF86EFAC), 1f to Color(0xFF7DD3FC),
)

/** Tile filter: contoh warna yang sudah diberi filter (intensitas 60%) + nama. */
@Composable
private fun LookTile(name: String, m: FloatArray?, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(10.dp)
    Column(
        Modifier.width(72.dp).alpha(if (enabled) 1f else 0.4f).clickable(enabled = enabled, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        Box(Modifier.size(width = 72.dp, height = 48.dp).clip(shape)) {
            Box(Modifier.matchParentSize().colorMatrixLayer(m?.let { Looks.colorMatrix20(it) }).background(LOOK_SAMPLE))
            if (selected) Box(Modifier.matchParentSize().border(3.dp, cs.primary, shape))
        }
        Text(name, fontSize = 11.sp, maxLines = 1, color = if (selected) cs.primary else cs.onSurfaceVariant)
    }
}

/** Kotak wallpaper "mesh" di tab Wallpaper: dua gradien radial di atas warna dasar (sama dengan desain). */
@Composable
private fun WallSwatch(w: Triple<Int, Int, Int>, selected: Boolean, enabled: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier.height(58.dp).clip(shape)
            .drawBehind {
                drawRect(Color(w.first))
                val c2x = size.width * 0.95f
                val c2y = size.height * 1.05f
                val r2 = kotlin.math.hypot(maxOf(c2x, size.width - c2x), maxOf(c2y, size.height - c2y)) * 0.55f
                drawRect(
                    Brush.radialGradient(listOf(Color(w.third), Color(w.third).copy(alpha = 0f)), center = Offset(c2x, c2y), radius = r2),
                )
                val c1x = size.width * 0.30f
                val c1y = size.height * 0.45f
                val r1 = kotlin.math.hypot(maxOf(c1x, size.width - c1x), maxOf(c1y, size.height - c1y)) * 0.60f
                drawRect(
                    Brush.radialGradient(listOf(Color(w.second), Color(w.second).copy(alpha = 0f)), center = Offset(c1x, c1y), radius = r1),
                )
            }
            .then(
                if (selected) Modifier.border(3.dp, cs.primary, shape)
                else Modifier.border(1.dp, Color.White.copy(alpha = 0.14f), shape),
            )
            .clickable(enabled = enabled, onClick = onClick),
    )
}

private val BG_TYPES = listOf("Gradient", "Warna", "Wallpaper", "Foto", "Blur")

private val ASPECTS = listOf<Pair<String, Float?>>(
    "Asli" to null, "16:9" to 16f / 9f, "9:16" to 9f / 16f, "1:1" to 1f, "4:5" to 4f / 5f,
)

private class PlayerState {
    var mp: MediaPlayer? = null
    var surface: Surface? = null
    var ready by mutableStateOf(false)
    var playing by mutableStateOf(false)
    /** Pesan kalau pemutar gagal (ditampilkan di editor), null = normal. */
    var failed by mutableStateOf<String?>(null)
    /** Play ditekan sebelum video siap: mulai otomatis begitu siap. */
    var playWhenReady = false
    /** Pemutaran sudah sampai habis (MediaPlayer ada di keadaan PlaybackCompleted). */
    var completed = false
    var positionMs by mutableLongStateOf(0L)
    /** Posisi pratinjau (ms) yang HALUS: diperbarui tiap frame layar lewat ekstrapolasi, dipakai zoom dan kursor. */
    var smoothMs by mutableFloatStateOf(0f)
    /**
     * Posisi yang DITENTUKAN pengguna saat jeda/scrub (ms), -1 = tidak ada. MediaPlayer.seekTo asinkron: selama seek berjalan,
     * currentPosition masih nilai lama, jadi playhead dan keyframe dulu ikut loncat ke nilai basi itu. Saat jeda, posisi kita
     * pegang sendiri dan TIDAK dibaca dari pemutar; dilepas (-1) begitu pemutaran dimulai.
     */
    var heldMs by mutableFloatStateOf(-1f)

    /** Jeda di posisi sekarang dan pegang posisi itu persis. */
    fun pauseHere() {
        try { mp?.pause() } catch (_: Exception) {}
        if (heldMs < 0f || playing) heldMs = smoothMs
        playing = false
    }

    /**
     * Buat MediaPlayer SEKALI per video. Sebelumnya pemutar dibuat/dibuang oleh callback TextureView, sehingga setiap kali
     * TextureView dilepas/dipasang ulang (ganti layout, mode pilih area, dsb.) pemutar ikut dibuang dan Play tidak jalan.
     * Sekarang siklus hidup pemutar terpisah dari surface: surface cukup dipasang ([attach]) atau dilepas ([detach]).
     */
    fun open(ctx: android.content.Context, uri: Uri) {
        release()
        failed = null
        val player = MediaPlayer()
        try {
            player.setDataSource(ctx, uri)
            surface?.let { player.setSurface(it) }
            player.setOnPreparedListener {
                ready = true
                try { it.seekTo(0) } catch (_: Exception) {}
                if (playWhenReady) {
                    playWhenReady = false
                    heldMs = -1f; try { it.start(); playing = true } catch (_: Exception) {}
                }
            }
            player.setOnCompletionListener { playing = false; completed = true }
            player.setOnErrorListener { _, what, extra ->
                ready = false; playing = false
                failed = "Pemutar gagal ($what/$extra)"
                true
            }
            player.prepareAsync()
            mp = player
        } catch (e: Exception) {
            failed = "Video tidak bisa dibuka"
            try { player.release() } catch (_: Exception) {}
        }
    }

    fun attach(s: Surface) {
        surface = s
        try { mp?.setSurface(s) } catch (_: Exception) {}
    }

    fun detach() {
        try { mp?.setSurface(null) } catch (_: Exception) {}
        try { surface?.release() } catch (_: Exception) {}
        surface = null
    }

    fun release() {
        ready = false
        playing = false
        playWhenReady = false
        completed = false
        try { mp?.release() } catch (_: Exception) {}
        mp = null
    }
}

private val TOOLS = listOf("Zoom", "Background", "Bingkai", "Rasio", "Efek")

/** Tab di header panel tiap tool. Background memakai tipe background sebagai tab (lihat [BG_TYPES]). */
private val TOOL_TABS = listOf(
    listOf("Blok", "Atur", "3D", "Kurva"),
    BG_TYPES,
    listOf("Bentuk", "Bayangan", "Kursor"),
    listOf("Rasio"),
    listOf("Filter", "Vignette", "Glow"),
)

/** Tinggi area timeline (ruler + baris + ruang kosong) dan toolbar bawah. Tetap, supaya pratinjau tidak berubah ukuran. */
private val TL_AREA = 224.dp
private val TOOLBAR_H = 72.dp   // nav bawah: padding 8 + tombol 56 + padding 8 (desain LayKit_PanelEditor)

/** Ikon garis 24x24 untuk nav bawah (dari desain LayKit_PanelEditor, urutan sama dengan [TOOLS]); digambar dengan tebal garis 1,75. */
private val TOOL_ICONS = listOf(
    // Zoom: kaca pembesar dengan tanda plus
    listOf("M4 10.5a6.5 6.5 0 1 0 13 0a6.5 6.5 0 1 0 -13 0Z", "M15.5 15.5L20.5 20.5", "M10.5 7.8v5.4", "M7.8 10.5h5.4"),
    // Background: gambar dengan gunung
    listOf(
        "M7 4H17a4 4 0 0 1 4 4V16a4 4 0 0 1 -4 4H7a4 4 0 0 1 -4 -4V8a4 4 0 0 1 4 -4Z",
        "M6.9 9.5a1.6 1.6 0 1 0 3.2 0a1.6 1.6 0 1 0 -3.2 0Z",
        "M3.5 17l4.6 -4.4a1.6 1.6 0 0 1 2.2 0l2.4 2.3l2 -1.9a1.6 1.6 0 0 1 2.2 0L20.5 16",
    ),
    // Bingkai: dua persegi membulat bersarang
    listOf(
        "M8.5 3H15.5a5.5 5.5 0 0 1 5.5 5.5V15.5a5.5 5.5 0 0 1 -5.5 5.5H8.5a5.5 5.5 0 0 1 -5.5 -5.5V8.5a5.5 5.5 0 0 1 5.5 -5.5Z",
        "M10.5 8H13.5a2.5 2.5 0 0 1 2.5 2.5V13.5a2.5 2.5 0 0 1 -2.5 2.5H10.5a2.5 2.5 0 0 1 -2.5 -2.5V10.5a2.5 2.5 0 0 1 2.5 -2.5Z",
    ),
    // Rasio: persegi panjang dengan tanda sudut
    listOf(
        "M5.8 6H18.2a3 3 0 0 1 3 3V15a3 3 0 0 1 -3 3H5.8a3 3 0 0 1 -3 -3V9a3 3 0 0 1 3 -3Z",
        "M7 11V9.2a0.7 0.7 0 0 1 0.7 -0.7H9.5",
        "M17 13V14.8a0.7 0.7 0 0 1 -0.7 0.7H14.5",
    ),
    // Efek: bintang berkilau
    listOf(
        "M10 4.5c0.5 3.6 2.4 5.5 6 6c-3.6 0.5 -5.5 2.4 -6 6c-0.5 -3.6 -2.4 -5.5 -6 -6c3.6 -0.5 5.5 -2.4 6 -6Z",
        "M18.5 3V6", "M17 4.5H20", "M18 15.5V19.5", "M16 17.5H20",
    ),
)

// Ikon kartu player
private val ICON_FULLSCREEN = listOf("M4 9V4H9", "M20 9V4H15", "M4 15V20H9", "M20 15V20H15")
private val ICON_VOLUME = listOf("M4 10V14H8L13 18V6L8 10Z", "M16.5 9.5a3.5 3.5 0 0 1 0 5")
private val ICON_VOLUME_OFF = listOf("M4 10V14H8L13 18V6L8 10Z", "M17 9L21 15", "M21 9L17 15")
private val ICON_UNDO = listOf("M9 14L4 9L9 4", "M4 9H15a5 5 0 0 1 0 10H11")
private val ICON_REDO = listOf("M15 14L20 9L15 4", "M20 9H9a5 5 0 0 0 0 10H13")

/** Satu keadaan edit lengkap, dipakai untuk undo/redo. */
internal data class EditSnap(
    val zooms: List<ZoomRegion>, val startMs: Float, val endMs: Float,
    val bgUi: Int, val preset: Int, val solid: Int, val wall: Int, val imageUri: Uri?, val blurAmt: Float,
    val padding: Float, val corner: Float, val shadow: Boolean, val shadowAmt: Float, val aspectIdx: Int, val cursorOn: Boolean,
    val look: Int, val lookAmt: Float, val vignette: Float, val glow: Float, val glowSize: Float,
)

/** Palet editor: hitam pekat, kartu abu gelap, aksen teal muda, tombol Ekspor oranye. Datar, tanpa bayangan. */
private val EditorColors = darkColorScheme(
    primary = Color(0xFFBFE0DC),
    onPrimary = Color(0xFF0B0B0B),
    secondaryContainer = Color(0xFF26262A),
    onSecondaryContainer = Color(0xFFF2F2F2),
    tertiary = Color(0xFFFF6A13),
    background = Color(0xFF0B0B0B),
    onBackground = Color(0xFFF2F2F2),
    surface = Color(0xFF0B0B0B),
    onSurface = Color(0xFFF2F2F2),
    surfaceVariant = Color(0xFF1C1C1E),
    onSurfaceVariant = Color(0xFF8E8E93),
    surfaceContainerLow = Color(0xFF131315),
    surfaceContainer = Color(0xFF161618),
    surfaceContainerHighest = Color(0xFF26262A),
    outline = Color(0xFF3A3A3E),
    outlineVariant = Color(0xFF2A2A2D),
    error = Color(0xFFFF6369),
    onError = Color(0xFF1A0505),
)

@Composable
internal fun ToolIcon(paths: List<String>, color: Color, iconSize: Dp = 22.dp, strokeW: Float = 1.6f) {
    val parsed = remember(paths) { paths.map { PathParser().parsePathString(it).toPath() } }
    Canvas(Modifier.size(iconSize)) {
        scale(this.size.width / 24f, pivot = Offset.Zero) {
            parsed.forEach { drawPath(it, color, style = Stroke(width = strokeW, cap = StrokeCap.Round, join = StrokeJoin.Round)) }
        }
    }
}

/** Ikon keyframe (belah ketupat): kosong + tanda tambah = tambah keyframe, terisi + tanda kurang = hapus keyframe di posisi ini. */
@Composable
private fun KeyframeIcon(on: Boolean, color: Color, cut: Color, iconSize: Dp = 20.dp) {
    val diamond = remember { PathParser().parsePathString("M12 3L21 12L12 21L3 12Z").toPath() }
    val plus = remember { PathParser().parsePathString("M12 8.5V15.5M8.5 12H15.5").toPath() }
    val minus = remember { PathParser().parsePathString("M8.5 12H15.5").toPath() }
    Canvas(Modifier.size(iconSize)) {
        scale(this.size.width / 24f, pivot = Offset.Zero) {
            val st = Stroke(width = 1.6f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            if (on) {
                drawPath(diamond, color)
                drawPath(minus, cut, style = Stroke(width = 1.8f, cap = StrokeCap.Round))
            } else {
                drawPath(diamond, color, style = st)
                drawPath(plus, color, style = st)
            }
        }
    }
}

@Composable
internal fun EditorScreen(uri: Uri, project: Project? = null, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val player = remember { PlayerState() }
    DisposableEffect(Unit) { onDispose { player.release(); player.detach() } }

    // Editor selalu gelap: ikon status bar dibuat terang selama editor terbuka, lalu dikembalikan.
    val view = LocalView.current
    DisposableEffect(Unit) {
        val win = view.context.findActivity()?.window
        val ctrl = win?.let { WindowCompat.getInsetsController(it, view) }
        val prevStatus = ctrl?.isAppearanceLightStatusBars
        val prevNav = ctrl?.isAppearanceLightNavigationBars
        ctrl?.isAppearanceLightStatusBars = false
        ctrl?.isAppearanceLightNavigationBars = false
        onDispose {
            if (ctrl != null && prevStatus != null) ctrl.isAppearanceLightStatusBars = prevStatus
            if (ctrl != null && prevNav != null) ctrl.isAppearanceLightNavigationBars = prevNav
        }
    }

    val info by produceState<VideoInfo?>(null, uri) {
        value = withContext(Dispatchers.IO) { Exporter.probe(ctx, uri) }
    }

    var cancel by remember { mutableStateOf<Exporter.Cancel?>(null) }
    val back = { cancel?.requested = true; onBack() }
    BackHandler { back() }

    MaterialTheme(colorScheme = EditorColors) {
        Box(Modifier.fillMaxSize().background(EditorColors.background).systemBarsPadding()) {
            val vi = info
            if (vi == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                IconButton(onClick = { back() }, modifier = Modifier.padding(4.dp)) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali", tint = EditorColors.onBackground)
                }
            } else {
                EditorContent(ctx, scope, uri, vi, project, player, { cancel = it }, cancel, back, Modifier.fillMaxSize())
            }
        }
    }
}

@Composable
private fun EditorContent(
    ctx: android.content.Context,
    scope: kotlinx.coroutines.CoroutineScope,
    uri: Uri,
    vi: VideoInfo,
    project: Project?,
    player: PlayerState,
    setCancel: (Exporter.Cancel?) -> Unit,
    cancel: Exporter.Cancel?,
    onBack: () -> Unit,
    modifier: Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val durMs = vi.durationMs.coerceAtLeast(1000L)
    DisposableEffect(uri) {
        player.open(ctx, uri)
        onDispose { player.release() }
    }
    var startMs by remember(uri) { mutableFloatStateOf(0f) }
    var endMs by remember(uri) { mutableFloatStateOf(durMs.toFloat()) }

    var tool by remember { mutableIntStateOf(-1) }   // -1 = panel tertutup

    var bgUi by remember { mutableIntStateOf(0) }       // 0 gradient, 1 warna, 2 wallpaper, 3 gambar, 4 blur
    var preset by remember { mutableIntStateOf(0) }
    var solid by remember { mutableIntStateOf(0) }
    var wall by remember { mutableIntStateOf(0) }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var blurAmt by remember { mutableFloatStateOf(0.04f) }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u ->
        if (u != null) imageUri = u
    }
    val imgBmp by produceState<Bitmap?>(null, imageUri) {
        val u = imageUri
        value = if (u == null) null else withContext(Dispatchers.IO) { Exporter.loadImage(ctx, u, 1024) }
    }
    val frameBmp by produceState<Bitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) { Exporter.firstFrame(ctx, uri) }
    }
    var padding by remember { mutableFloatStateOf(0.08f) }
    var corner by remember { mutableFloatStateOf(0.03f) }
    var shadow by remember { mutableStateOf(true) }
    var shadowAmt by remember { mutableFloatStateOf(0.5f) }
    var aspectIdx by remember { mutableIntStateOf(0) }

    // ---- zoom ----
    var zooms by remember(uri) { mutableStateOf<List<ZoomRegion>>(emptyList()) }
    var selectedZoom by remember(uri) { mutableStateOf<Int?>(null) }
    var selectedKey by remember(uri) { mutableStateOf<Long?>(null) }   // keyframe terpilih (waktu) pada blok terpilih
    var nextZoomId by remember(uri) { mutableIntStateOf(1) }
    var zoomMsg by remember(uri) { mutableStateOf<String?>(null) }
    var areaEdit by remember(uri) { mutableStateOf(false) }   // mode pilih area zoom di pratinjau
    val touches by produceState<List<TouchEvent>>(emptyList(), uri) {
        value = withContext(Dispatchers.IO) {
            val name = Library.nameOf(ctx, uri)
            val local = if (name == null) emptyList() else TouchLog.load(ctx.filesDir, name)
            if (local.isNotEmpty()) {
                // rekaman lama: tanamkan salinan ke file video supaya selamat dari update / pasang ulang
                if (!TouchEmbed.has(ctx, uri)) TouchEmbed.write(ctx, uri, local)
                local
            } else TouchEmbed.read(ctx, uri)
        }
    }

    var exporting by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var resultUri by remember { mutableStateOf<Uri?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    var cursorOn by remember { mutableStateOf(true) }

    // ---- efek: filter warna + vignette + glow (satu model, dipakai pratinjau dan ekspor lewat FrameStyle) ----
    var look by remember { mutableIntStateOf(0) }
    var lookAmt by remember { mutableFloatStateOf(1f) }
    var vignette by remember { mutableFloatStateOf(0f) }
    var glow by remember { mutableFloatStateOf(0f) }
    var glowSize by remember { mutableFloatStateOf(0.5f) }

    // ---- toast kecil di atas pratinjau, mode fokus (fullscreen), mute pratinjau ----
    var toast by remember { mutableStateOf<String?>(null) }
    var toastKey by remember { mutableIntStateOf(0) }
    fun showToast(m: String) { toast = m; toastKey++ }
    LaunchedEffect(toastKey) {
        if (toast != null) { delay(2000); toast = null }
    }
    // ---- project: id (null = belum pernah disimpan), keadaan terakhir yang tersimpan, dan dialog "simpan dulu?" ----
    var projectId by remember { mutableStateOf(project?.id) }
    var baseline by remember { mutableStateOf(project?.snap) }   // keadaan yang sudah tersimpan / keadaan awal; beda dari snap = ada perubahan
    var dirty by remember { mutableStateOf(false) }
    var askSave by remember { mutableStateOf(false) }
    var savingProject by remember { mutableStateOf(false) }
    // didaftarkan SEBELUM handler fokus/panel di bawah: handler yang didaftarkan belakangan didahulukan, jadi panel/fokus tertutup dulu
    BackHandler(enabled = dirty && !savingProject) { askSave = true }
    var focus by remember { mutableStateOf(false) }
    BackHandler(enabled = focus) { focus = false }
    BackHandler(enabled = !focus && tool >= 0) { tool = -1 }   // Back menutup panel dulu sebelum keluar editor
    var muted by remember { mutableStateOf(false) }
    var bottomH by remember { mutableIntStateOf(0) }     // px, tinggi area bawah (timeline + toolbar); panel menutupi bagian bawahnya
    var toolTab by remember { mutableIntStateOf(0) }     // tab aktif di header panel (kecuali Background: pakai bgUi)
    var zParam by remember { mutableIntStateOf(0) }      // parameter zoom yang diatur slider: 0 skala, 1 X, 2 Y
    var cParam by remember { mutableIntStateOf(0) }      // parameter 3D Customize yang diatur slider: 0 angguk, 1 tengok, 2 miring, 3 jarak
    var curveCh by remember { mutableIntStateOf(CH_ZOOM) }   // channel kurva yang sedang diedit (tab Kurva)
    val lastTool = remember { intArrayOf(0) }            // tool terakhir yang dibuka: isi panel tetap ada selama animasi tutup
    fun openTool(i: Int) { tool = i; toolTab = 0 }
    LaunchedEffect(muted, player.ready) {
        val v = if (muted) 0f else 1f
        try { player.mp?.setVolume(v, v) } catch (_: Exception) {}
    }

    // ---- undo / redo: perubahan digabung per 350 ms, lalu disimpan sebagai satu langkah ----
    val snap = EditSnap(
        zooms, startMs, endMs, bgUi, preset, solid, wall, imageUri, blurAmt,
        padding, corner, shadow, shadowAmt, aspectIdx, cursorOn,
        look, lookAmt, vignette, glow, glowSize,
    )
    var committed by remember(uri) { mutableStateOf<EditSnap?>(null) }
    var undoStack by remember(uri) { mutableStateOf<List<EditSnap>>(emptyList()) }
    var redoStack by remember(uri) { mutableStateOf<List<EditSnap>>(emptyList()) }
    fun commitNow(s: EditSnap) {
        val c = committed
        if (c == null) { committed = s; return }
        if (s == c) return
        undoStack = (undoStack + c).takeLast(60)
        redoStack = emptyList()
        committed = s
    }
    LaunchedEffect(snap) {
        if (committed == null) { committed = snap; return@LaunchedEffect }
        delay(350)
        commitNow(snap)
    }
    fun applySnap(s: EditSnap) {
        zooms = s.zooms; startMs = s.startMs; endMs = s.endMs
        bgUi = s.bgUi; preset = s.preset; solid = s.solid; wall = s.wall; imageUri = s.imageUri; blurAmt = s.blurAmt
        padding = s.padding; corner = s.corner; shadow = s.shadow; shadowAmt = s.shadowAmt; aspectIdx = s.aspectIdx; cursorOn = s.cursorOn
        look = s.look; lookAmt = s.lookAmt; vignette = s.vignette; glow = s.glow; glowSize = s.glowSize
        selectedZoom = null; selectedKey = null; areaEdit = false
    }
    fun undo() {
        commitNow(snap)   // simpan dulu perubahan yang belum sempat tercatat
        val c = committed ?: return
        val target = undoStack.lastOrNull() ?: return
        undoStack = undoStack.dropLast(1)
        redoStack = redoStack + c
        committed = target
        applySnap(target)
        showToast("Dibatalkan")
    }
    fun redo() {
        val c = committed ?: return
        val target = redoStack.lastOrNull() ?: return
        redoStack = redoStack.dropLast(1)
        undoStack = undoStack + c
        committed = target
        applySnap(target)
        showToast("Diulangi")
    }
    val canUndo = undoStack.isNotEmpty() || (committed != null && committed != snap)
    val canRedo = redoStack.isNotEmpty()

    // ---- project: muat keadaan tersimpan sekali, lalu simpan ----
    LaunchedEffect(Unit) {
        val ps = project?.snap
        if (ps != null) {
            applySnap(ps)
            nextZoomId = (ps.zooms.maxOfOrNull { it.id } ?: 0) + 1
            committed = ps   // undo tidak boleh mundur ke keadaan kosong sebelum dimuat
        } else if (baseline == null) {
            baseline = snap
        }
    }
    LaunchedEffect(snap, baseline) { dirty = baseline != null && baseline != snap }
    val projectName by produceState("Rekaman", uri) {
        value = withContext(Dispatchers.IO) { Library.nameOf(ctx, uri)?.substringBeforeLast('.') ?: "Rekaman" }
    }
    /** Simpan project (baru atau timpa). [then] dipanggil di thread utama setelah berhasil. */
    fun saveProject(then: () -> Unit = {}) {
        if (savingProject) return
        savingProject = true
        val s = snap
        val id = projectId ?: ProjectStore.newId()
        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                val name = project?.name ?: projectName
                ProjectStore.save(ctx, id, name, uri, durMs, s)
            }
            savingProject = false
            if (ok) {
                projectId = id
                baseline = s
                showToast("Project disimpan")
                then()
            } else {
                showToast("Gagal menyimpan project")
            }
        }
    }

    // Sumber kursor: data ketukan; kalau rekaman tidak punya (layanan sentuhan mati / elemen tidak terbaca),
    // kursor memakai titik fokus tiap blok zoom, jadi saklar Kursor tetap bisa dipakai.
    val cursorTrack = remember(touches, zooms) {
        if (touches.isNotEmpty()) touches
        else zooms.map { TouchEvent(it.startMs, it.fx.coerceIn(0f, 1f), it.fy.coerceIn(0f, 1f), TouchLog.TAP) }.sortedBy { it.tMs }
    }
    val base = FrameStyle(padding = padding, corner = corner, shadow = shadow, shadowAmt = shadowAmt, aspect = ASPECTS[aspectIdx].second, cursor = cursorOn && cursorTrack.isNotEmpty(), look = look, lookAmt = lookAmt, vignette = vignette, glow = glow, glowSize = glowSize)
    val style = when (bgUi) {
        1 -> base.copy(top = SOLIDS[solid], bottom = SOLIDS[solid])
        2 -> base.copy(bgType = 1, top = WALLS[wall].first, mid = WALLS[wall].second, bottom = WALLS[wall].third)
        3 -> base.copy(bgType = 2, image = imageUri)
        4 -> base.copy(bgType = 3, blur = blurAmt)
        else -> base.copy(top = PRESETS[preset].first, bottom = PRESETS[preset].second)
    }
    val videoAspect = vi.width.toFloat() / vi.height.toFloat()

    // loop pemutaran di dalam rentang potong + jam halus untuk zoom/kursor.
    // MediaPlayer.currentPosition kasar dan bisa loncat; zoom yang dibaca darinya (dulu tiap 40 ms) patah-patah.
    // Saat memutar: waktu diekstrapolasi tiap frame layar, lalu dikoreksi pelan-pelan oleh currentPosition.
    val curStart by rememberUpdatedState(startMs)
    val curEnd by rememberUpdatedState(endMs)
    LaunchedEffect(Unit) {
        var est = 0f
        var lastFrameNs = 0L
        var lastSampleNs = 0L
        var ignoreUntilNs = 0L
        while (true) {
            val mp = player.mp
            if (mp == null || !player.ready) { delay(50); continue }
            if (!player.playing) {
                // jeda / scrub: ikuti posisi pemutar apa adanya
                try {
                    val h = player.heldMs
                    val p = if (h >= 0f) h else mp.currentPosition.toFloat()
                    est = p
                    player.smoothMs = p
                    player.positionMs = p.toLong()
                } catch (_: Exception) {}
                lastFrameNs = 0L
                delay(30)
                continue
            }
            withFrameNanos { now ->
                if (lastFrameNs == 0L) {
                    // frame pertama setelah Play: langsung selaraskan dengan pemutar (tanpa koreksi pelan)
                    lastFrameNs = now; lastSampleNs = 0L
                    try { est = mp.currentPosition.toFloat() } catch (_: Exception) {}
                }
                val dt = ((now - lastFrameNs) / 1_000_000f).coerceIn(0f, 50f)
                lastFrameNs = now
                est += dt
                if (now - lastSampleNs > 50_000_000L && now > ignoreUntilNs) {
                    lastSampleNs = now
                    try {
                        val p = mp.currentPosition.toFloat()
                        if (p >= curEnd) {
                            mp.seekTo(curStart.toLong(), MediaPlayer.SEEK_CLOSEST)
                            est = curStart
                            ignoreUntilNs = now + 200_000_000L   // abaikan pembacaan lama sampai seek selesai
                        } else {
                            val err = p - est
                            est = if (kotlin.math.abs(err) > 250f) p else est + err * 0.15f
                        }
                    } catch (_: Exception) {}
                }
                if (est > curEnd) est = curEnd
                player.smoothMs = est
                // state yang memicu recompose (timeline, teks waktu) cukup ~25 Hz
                if (kotlin.math.abs(est - player.positionMs) >= 40f) player.positionMs = est.toLong()
            }
        }
    }

    fun seek(ms: Float) {
        if (!player.playing) {
            // pegang posisi yang diminta: playhead, keyframe, zoom, dan kursor memakai angka ini, bukan currentPosition yang basi
            player.heldMs = ms
            player.smoothMs = ms
            player.positionMs = ms.toLong()
        }
        try { player.mp?.seekTo(ms.toLong(), MediaPlayer.SEEK_CLOSEST) } catch (_: Exception) {}
    }

    fun togglePlay() {
        val mp = player.mp
        if (mp == null) return
        if (!player.ready) {
            // video belum siap: ingat niatnya, mulai otomatis begitu siap
            player.playWhenReady = !player.playWhenReady
            if (player.playWhenReady) areaEdit = false
            return
        }
        try {
            if (player.playing) {
                player.pauseHere()
            } else {
                areaEdit = false
                // setelah habis (atau di luar rentang potong) mulai lagi dari awal rentang
                if (player.completed || mp.currentPosition < startMs || mp.currentPosition >= endMs) {
                    mp.seekTo(startMs.toLong(), MediaPlayer.SEEK_CLOSEST)
                }
                player.completed = false
                player.heldMs = -1f
                mp.start(); player.playing = true
            }
        } catch (e: Exception) {
            player.playing = false
            player.failed = "Tidak bisa memutar: ${e.javaClass.simpleName}"
        }
    }

    fun addZoom() {
        val added = ZoomOps.add(zooms, ZoomRegion(id = nextZoomId, startMs = 0L, endMs = 0L), player.positionMs, 5000L, durMs)
        if (added == null) {
            zoomMsg = "Tidak ada ruang kosong"
            showToast("Tidak ada ruang kosong")
        } else {
            val newId = nextZoomId
            zooms = added; selectedZoom = newId; nextZoomId++; zoomMsg = null
            showToast("Zoom ditambahkan")
            openTool(0)
            added.firstOrNull { it.id == newId }?.let { nr ->
                player.pauseHere()
                seek(nr.startMs.toFloat())
                areaEdit = true
            }
        }
    }

    /** Blok yang dimaksud tombol keyframe: yang dipilih, kalau tidak ada yang berisi playhead. */
    fun keyframeRegion(): ZoomRegion? {
        val pos = player.positionMs
        return zooms.firstOrNull { it.id == selectedZoom } ?: zooms.firstOrNull { pos >= it.startMs && pos <= it.endMs }
    }

    /** Keyframe yang sedang "aktif": yang dipilih, atau yang tepat di playhead (toleransi 150 ms). */
    fun activeKey(r: ZoomRegion): ZoomKey? {
        val pos = player.positionMs
        val ks = r.liveKeys()
        if (r.id == selectedZoom) ks.firstOrNull { it.tMs == selectedKey }?.let { return it }
        return ks.minByOrNull { kotlin.math.abs(it.tMs - pos) }?.takeIf { kotlin.math.abs(it.tMs - pos) <= 150L }
    }

    fun toggleKeyframe() {
        val r = keyframeRegion()
        if (r == null) { showToast("Pilih blok zoom atau taruh playhead di dalam blok"); return }
        val ex = activeKey(r)
        if (ex != null) {
            zooms = ZoomOps.update(zooms, r.id) { z -> z.copy(keys = z.keys.filter { it.tMs != ex.tMs }, auto = false) }
            selectedZoom = r.id; selectedKey = null
            showToast("Keyframe dihapus")
            return
        }
        val t = player.positionMs
        if (t < r.startMs + ZoomMath.KEY_GAP_MS || t > r.endMs - ZoomMath.KEY_GAP_MS) {
            showToast("Taruh playhead di dalam blok zoom")
            return
        }
        if (r.liveKeys().any { kotlin.math.abs(it.tMs - t) < ZoomMath.KEY_GAP_MS }) {
            showToast("Sudah ada keyframe di dekat sini")
            return
        }
        // keyframe baru mulai dari keadaan kamera saat itu (termasuk sudut/jarak Customize), jadi gerakannya tidak melompat
        val st = ZoomMath.stateAt(r, t.toDouble())
        val k = ZoomKey(t, st.scale, st.fx, st.fy, st.camPitch, st.camYaw, st.camRoll, st.camDepth)
        zooms = ZoomOps.update(zooms, r.id) { z -> z.copy(keys = (z.keys + k).sortedBy { x -> x.tMs }, auto = false) }
        selectedZoom = r.id; selectedKey = t
        player.pauseHere()
        areaEdit = true
        showToast("Keyframe ditambahkan")
    }

    val doExport: () -> Unit = {
        player.pauseHere()
        val c = Exporter.Cancel()
        setCancel(c)
        exporting = true; progress = 0f; resultUri = null; error = null
        val st = style
        val zl = zooms
        val tl = cursorTrack
        val s = (startMs * 1000f).toLong()
        val e = (endMs * 1000f).toLong()
        scope.launch(Dispatchers.Default) {
            val out = Exporter.export(ctx, uri, s, e, st, zl, tl, c, { p -> progress = p }, { m -> error = m })
            withContext(Dispatchers.Main) {
                exporting = false
                resultUri = out
                if (out == null && error == null) error = "Ekspor dibatalkan"
            }
        }
    }

    // ---------------------------------------------------------------- bagian-bagian layar
    val title by produceState("Rekaman", uri) {
        value = withContext(Dispatchers.IO) { Library.nameOf(ctx, uri)?.substringBeforeLast('.') ?: "Rekaman" }
    }

    val requestBack = { if (dirty && !exporting) askSave = true else onBack() }
    val topBar: @Composable () -> Unit = {
        Row(
            Modifier.fillMaxWidth().height(52.dp).padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Box(
                Modifier.size(40.dp).clip(CircleShape).background(cs.surfaceVariant).clickable(onClick = requestBack),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali", tint = cs.onBackground, modifier = Modifier.size(20.dp))
            }
            Text(
                "$title  |  ${ASPECTS[aspectIdx].first}",
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            if (exporting) {
                Text("${(progress * 100).toInt()}%", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                Box(
                    Modifier.height(36.dp).clip(RoundedCornerShape(50)).background(cs.surfaceVariant)
                        .clickable { cancel?.requested = true }.padding(horizontal = 16.dp),
                    contentAlignment = Alignment.Center,
                ) { Text("Batal", style = MaterialTheme.typography.labelLarge, color = cs.onBackground) }
            } else {
                Box(
                    Modifier.height(36.dp).clip(RoundedCornerShape(50)).background(cs.surfaceVariant)
                        .clickable(enabled = !savingProject) { saveProject() }.padding(horizontal = 14.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        if (savingProject) "Menyimpan…" else if (dirty || projectId == null) "Simpan" else "Tersimpan",
                        style = MaterialTheme.typography.labelLarge,
                        color = if (dirty || projectId == null) cs.primary else cs.onSurfaceVariant,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
                resultUri?.let { out ->
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(cs.surfaceVariant).clickable { Library.share(ctx, out) },
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Default.Share, contentDescription = "Bagikan", tint = cs.primary, modifier = Modifier.size(20.dp)) }
                }
                Box(
                    Modifier.height(36.dp).clip(RoundedCornerShape(50)).background(LayKitGradient.horizontal)
                        .clickable(onClick = doExport).padding(horizontal = 18.dp),
                    contentAlignment = Alignment.Center,
                ) { Text("Ekspor", style = MaterialTheme.typography.labelLarge, color = Color.White, fontWeight = FontWeight.SemiBold) }
            }
        }
        Box(Modifier.fillMaxWidth().height(3.dp)) {
            if (exporting) {
                Box(Modifier.fillMaxSize().background(cs.surfaceVariant))
                Box(Modifier.fillMaxHeight().fillMaxWidth(progress.coerceIn(0f, 1f)).background(LayKitGradient.horizontal))
            }
        }
    }

    val preview: @Composable () -> Unit = {
        FramePreview(
            uri, videoAspect, style, player, imgBmp, frameBmp, zooms,
            cursorTrack, { player.smoothMs },
            if (areaEdit) zooms.firstOrNull { it.id == selectedZoom }?.let { r ->
                val k = r.liveKeys().firstOrNull { it.tMs == selectedKey }
                if (k != null) r.copy(scale = k.scale, fx = k.fx, fy = k.fy) else r
            } else null,
        ) { fx, fy, sc ->
            selectedZoom?.let { id ->
                val kt = selectedKey
                val hasKey = kt != null && zooms.firstOrNull { it.id == id }?.liveKeys()?.any { it.tMs == kt } == true
                zooms = if (hasKey && kt != null) ZoomOps.updateKey(zooms, id, kt) { it.copy(fx = fx, fy = fy, scale = sc) }
                else ZoomOps.update(zooms, id) { it.copy(fx = fx, fy = fy, scale = sc, auto = false) }
            }
        }
    }

    val timeline: @Composable () -> Unit = {
        TimelineEditor(
            uri = uri,
            durMs = durMs,
            positionMs = player.positionMs,
            timeMs = { player.smoothMs },
            playing = player.playing,
            startMs = startMs,
            endMs = endMs,
            zooms = zooms,
            touches = touches,
            selectedId = selectedZoom,
            enabled = !exporting,
            onSeek = { seek(it.toFloat()) },
            // menggeser timeline saat diputar = jeda dulu, lalu scrub
            onScrubStart = { player.pauseHere() },
            onTrimStart = { v ->
                val s = v.coerceIn(0f, endMs - 500f)
                startMs = s; seek(s)
            },
            onTrimEnd = { v ->
                val e = v.coerceIn(startMs + 500f, durMs.toFloat())
                endMs = e; seek((e - 500f).coerceAtLeast(startMs))
            },
            selectedKey = selectedKey,
            onSelectKey = { id, t ->
                selectedZoom = id
                selectedKey = t
                // lompat ke waktu keyframe supaya pratinjau menampilkan keadaannya
                if (t != null) seek(t.toFloat())
            },
            onSelect = { id ->
                if (id != selectedZoom) selectedKey = null
                selectedZoom = id
                // di mode pilih area, pindah blok = lompat ke frame awal blok itu
                if (areaEdit) zooms.firstOrNull { it.id == id }?.let { seek(it.startMs.toFloat()) }
            },
            onZooms = { zooms = it },
            modifier = Modifier.fillMaxSize(),
        )
    }

    // Baris kontrol player, datar tanpa kartu: layar penuh + mute | Play | keyframe + undo + redo
    val playerCard: @Composable () -> Unit = {
        val dim = cs.onSurfaceVariant.copy(alpha = 0.35f)
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp).height(48.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.Start) {
                Box(Modifier.size(44.dp).clip(CircleShape).clickable { focus = !focus }, contentAlignment = Alignment.Center) {
                    ToolIcon(ICON_FULLSCREEN, if (focus) cs.primary else cs.onSurfaceVariant, 20.dp)
                }
                Box(Modifier.size(44.dp).clip(CircleShape).clickable { muted = !muted }, contentAlignment = Alignment.Center) {
                    ToolIcon(if (muted) ICON_VOLUME_OFF else ICON_VOLUME, if (muted) cs.primary else cs.onSurfaceVariant, 20.dp)
                }
            }
            Box(
                Modifier.size(48.dp).clip(CircleShape).clickable { togglePlay() },
                contentAlignment = Alignment.Center,
            ) { PlayPauseIcon(player.playing, cs.onBackground, 26.dp) }
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.End) {
                val kfReg = keyframeRegion()
                val kfOn = kfReg != null && activeKey(kfReg) != null
                Box(Modifier.size(44.dp).clip(CircleShape).clickable(enabled = !exporting) { toggleKeyframe() }, contentAlignment = Alignment.Center) {
                    KeyframeIcon(
                        kfOn,
                        if (kfReg == null || exporting) dim else if (kfOn) cs.primary else cs.onSurfaceVariant,
                        cs.background, 20.dp,
                    )
                }
                Box(Modifier.size(44.dp).clip(CircleShape).clickable(enabled = canUndo && !exporting) { undo() }, contentAlignment = Alignment.Center) {
                    ToolIcon(ICON_UNDO, if (canUndo) cs.onSurfaceVariant else dim, 20.dp)
                }
                Box(Modifier.size(44.dp).clip(CircleShape).clickable(enabled = canRedo && !exporting) { redo() }, contentAlignment = Alignment.Center) {
                    ToolIcon(ICON_REDO, if (canRedo) cs.onSurfaceVariant else dim, 20.dp)
                }
            }
        }
    }

    // Nav bawah (desain LayKit_NavBawah): garis tipis + 5 tombol ikon dengan indikator pil. Saat satu tool dibuka,
    // panelnya menutupi nav ini (lihat bottomSection). Ketuk tool yang sedang terbuka = tutup.
    val toolbar: @Composable () -> Unit = {
        Column(Modifier.fillMaxWidth().background(cs.background)) {
            Box(
                Modifier.fillMaxWidth().height(1.dp).background(
                    Brush.horizontalGradient(
                        0f to cs.outlineVariant.copy(alpha = 0f), 0.2f to cs.outlineVariant,
                        0.8f to cs.outlineVariant, 1f to cs.outlineVariant.copy(alpha = 0f),
                    ),
                ),
            )
            ToolNav(TOOLS, TOOL_ICONS, tool) { i -> if (tool == i) tool = -1 else openTool(i) }
        }
    }

    fun pct(v: Float, r: ClosedFloatingPointRange<Float>): String =
        (((v - r.start) / (r.endInclusive - r.start)) * 100f + 0.5f).toInt().toString()

    // Panel tool (desain LayKit_PanelEditor): header tab + Reset + centang, isi per tab. [pt] = tool yang ditampilkan.
    // Menggantikan nav (menutupinya penuh) dan bagian bawah timeline. Isi tiap baris diberi jarak 8 dp; baris yang
    // bisa digulir mendatar (preset, tile, foto) dibuat selebar panel lalu diberi jarak 16 dp DI DALAM gulirnya.
    val panel: @Composable (Dp, Int) -> Unit = { panelH, pt ->
        val tabs = TOOL_TABS[pt]
        val tabSel = if (pt == 1) bgUi else toolTab.coerceIn(0, tabs.size - 1)
        val sel = zooms.firstOrNull { it.id == selectedZoom }
        val selK = sel?.liveKeys()?.firstOrNull { it.tMs == selectedKey }   // keyframe terpilih (tab Atur dan 3D)
        val camCh = if (sel?.cam == Cam.CUSTOM) curveCh else CH_ZOOM
        val px = Modifier.padding(horizontal = 16.dp)

        // slider Customize 3D bisa di-keyframe sendiri-sendiri: ada keyframe terpilih = ubah nilainya di keyframe itu,
        // kalau tidak = ubah nilai dasar blok (sama seperti tab Atur untuk skala/posisi)
        val setCam: (Int, Float) -> Unit = { p, v ->
            if (sel != null) {
                zooms = if (selK != null) ZoomOps.updateKey(zooms, sel.id, selK.tMs) {
                    when (p) { 0 -> it.copy(camPitch = v); 1 -> it.copy(camYaw = v); 2 -> it.copy(camRoll = v); else -> it.copy(camDepth = v) }
                } else ZoomOps.update(zooms, sel.id) {
                    when (p) { 0 -> it.copy(camPitch = v); 1 -> it.copy(camYaw = v); 2 -> it.copy(camRoll = v); else -> it.copy(camDepth = v) }
                }
            }
        }
        val setCurve: (Int, ZoomCurve?) -> Unit = { ch, c ->
            selectedZoom?.let { id ->
                zooms = ZoomOps.update(zooms, id) { r ->
                    when (ch) {
                        CH_PITCH -> r.copy(curvePitch = c); CH_YAW -> r.copy(curveYaw = c)
                        CH_ROLL -> r.copy(curveRoll = c); CH_DEPTH -> r.copy(curveDepth = c)
                        else -> r.copy(curve = c)
                    }
                }
            }
        }

        // Reset ada di header panel (ikon), hanya untuk tab yang punya nilai bawaan
        val reset: PanelReset? = when {
            pt == 0 && tabSel == 2 && sel != null && sel.cam == Cam.CUSTOM -> {
                val cp = selK?.camPitch ?: sel.camPitch
                val cy = selK?.camYaw ?: sel.camYaw
                val cr = selK?.camRoll ?: sel.camRoll
                val cd = selK?.camDepth ?: sel.camDepth
                PanelReset(!exporting && (cp != 0f || cy != 0f || cr != 0f || cd != Cam.PERSPECTIVE_FACTOR)) {
                    setCam(0, 0f); setCam(1, 0f); setCam(2, 0f); setCam(3, Cam.PERSPECTIVE_FACTOR)
                }
            }
            pt == 0 && tabSel == 3 && sel != null -> PanelReset(!exporting && curveOf(sel, camCh) != null) { setCurve(camCh, null) }
            pt == 2 && tabSel == 0 -> PanelReset(!exporting && (padding != 0.08f || corner != 0.03f)) { padding = 0.08f; corner = 0.03f }
            pt == 4 && tabSel == 1 -> PanelReset(!exporting && vignette != 0f) { vignette = 0f }
            pt == 4 && tabSel == 2 -> PanelReset(!exporting && (glow != 0f || glowSize != 0.5f)) { glow = 0f; glowSize = 0.5f }
            else -> null
        }

        Column(
            Modifier.fillMaxWidth().height(panelH)
                .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                .background(cs.surfaceContainerHighest)
                .pointerInput(Unit) { detectTapGestures { } },   // telan ketukan supaya tidak tembus ke bawah
        ) {
            PanelTabs(tabs, tabSel, { i -> if (pt == 1) bgUi = i else toolTab = i }, { tool = -1 }, reset)
            Column(
                Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                when (pt) {
                    0 -> when (tabSel) {
                        // ---- Blok: aksi pada blok zoom (4 kartu sama lebar) ----
                        0 -> {
                            Row(px.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                ActionCard(ICON_AUTO, "Auto-zoom", enabled = !exporting && touches.isNotEmpty(), modifier = Modifier.weight(1f)) {
                                    val auto = AutoZoom.build(touches, durMs)
                                    zooms = auto
                                    nextZoomId = (auto.maxOfOrNull { it.id } ?: 0) + 1
                                    selectedZoom = null; selectedKey = null
                                    zoomMsg = if (auto.isEmpty()) "Ketukan terlalu sedikit" else null
                                    if (auto.isNotEmpty()) showToast("Auto-zoom dibuat")
                                }
                                ActionCard(ICON_PLUS, "Tambah", enabled = !exporting, modifier = Modifier.weight(1f)) { addZoom() }
                                ActionCard(ICON_TRASH, "Hapus", enabled = !exporting && selectedZoom != null, modifier = Modifier.weight(1f)) {
                                    selectedZoom?.let { zooms = ZoomOps.remove(zooms, it); selectedZoom = null; selectedKey = null; areaEdit = false; showToast("Zoom dihapus") }
                                }
                                ActionCard(
                                    ICON_AREA, if (areaEdit) "Selesai" else "Pilih area", selected = areaEdit,
                                    enabled = !exporting && selectedZoom != null, modifier = Modifier.weight(1f),
                                ) {
                                    if (areaEdit) areaEdit = false
                                    else zooms.firstOrNull { it.id == selectedZoom }?.let { sr ->
                                        // jeda dan lompat ke awal blok, supaya yang dipilih adalah frame yang akan di-zoom
                                        player.pauseHere()
                                        seek((sr.liveKeys().firstOrNull { it.tMs == selectedKey }?.tMs ?: sr.startMs).toFloat())
                                        areaEdit = true
                                    }
                                }
                            }
                            zoomMsg?.let { PanelNote(it, px) }
                        }

                        // ---- Atur: skala dan titik sorot (satu baris pilihan + satu slider) ----
                        1 -> if (sel == null) PanelHint("Pilih blok zoom di timeline untuk mengatur skala dan titik sorotnya.", px) else {
                            val sc = selK?.scale ?: sel.scale
                            val fx = selK?.fx ?: sel.fx
                            val fy = selK?.fy ?: sel.fy
                            val setParam: (Int, Float) -> Unit = { p, v ->
                                zooms = if (selK != null) ZoomOps.updateKey(zooms, sel.id, selK.tMs) {
                                    when (p) { 0 -> it.copy(scale = v); 1 -> it.copy(fx = v); else -> it.copy(fy = v) }
                                } else ZoomOps.update(zooms, sel.id) {
                                    when (p) { 0 -> it.copy(scale = v, auto = false); 1 -> it.copy(fx = v, auto = false); else -> it.copy(fy = v, auto = false) }
                                }
                            }
                            ParamRow(
                                listOf("Skala", "X", "Y"), listOf("%.1f×".format(sc), "%.2f".format(fx), "%.2f".format(fy)),
                                zParam, !exporting, px,
                            ) { zParam = it }
                            val cur = when (zParam) { 0 -> sc; 1 -> fx; else -> fy }
                            val range = when (zParam) {
                                0 -> ZoomMath.MIN_SCALE..ZoomMath.MAX_SCALE
                                else -> ZoomMath.FOCUS_MIN..ZoomMath.FOCUS_MAX
                            }
                            FlatSlider(cur, { setParam(zParam, it) }, range, !exporting, px)
                            if (selK != null) PanelNote("Keyframe di ${Library.fmtTime(selK.tMs)}", px)
                        }

                        // ---- 3D: kamera miring per blok ----
                        2 -> if (sel == null) PanelHint("Pilih blok zoom di timeline untuk mengatur kamera 3D-nya.", px) else {
                            PanelSeg(
                                listOf("3D mati" to Cam.OFF, "Kiri" to Cam.LEFT, "Kanan" to Cam.RIGHT, "Orbit" to Cam.ORBIT, "Customize" to Cam.CUSTOM),
                                sel.cam, !exporting, px,
                            ) { c ->
                                zooms = ZoomOps.update(zooms, sel.id) { z ->
                                    // pindah dari Kiri/Kanan ke Customize: mulai dari sudut preset itu, bukan dari nol
                                    if (c == Cam.CUSTOM && (z.cam == Cam.LEFT || z.cam == Cam.RIGHT)) {
                                        val pr = Cam.presetRot(z.cam)
                                        z.copy(cam = c, camPitch = pr.x, camYaw = pr.y, camRoll = pr.z)
                                    } else z.copy(cam = c)
                                }
                            }
                            if (sel.cam == Cam.CUSTOM) {
                                val cPitch = selK?.camPitch ?: sel.camPitch
                                val cYaw = selK?.camYaw ?: sel.camYaw
                                val cRoll = selK?.camRoll ?: sel.camRoll
                                val cDepth = selK?.camDepth ?: sel.camDepth
                                ParamRow(
                                    listOf("Angguk", "Tengok", "Miring", "Jarak"),
                                    listOf("%.0f°".format(cPitch), "%.0f°".format(cYaw), "%.0f°".format(cRoll), "%.1f×".format(cDepth)),
                                    cParam, !exporting, px,
                                ) { cParam = it }
                                val range = when (cParam) {
                                    0 -> -Cam.CUSTOM_PITCH_MAX..Cam.CUSTOM_PITCH_MAX
                                    1 -> -Cam.CUSTOM_YAW_MAX..Cam.CUSTOM_YAW_MAX
                                    2 -> -Cam.CUSTOM_ROLL_MAX..Cam.CUSTOM_ROLL_MAX
                                    else -> Cam.DEPTH_MIN..Cam.DEPTH_MAX
                                }
                                val curV = when (cParam) { 0 -> cPitch; 1 -> cYaw; 2 -> cRoll; else -> cDepth }
                                FlatSlider(curV, { setCam(cParam, it) }, range, !exporting, px)
                                if (selK != null) PanelNote("Keyframe di ${Library.fmtTime(selK.tMs)}", px)
                                if (player.positionMs < sel.startMs || player.positionMs > sel.endMs) {
                                    Row(px) { PanelPill("Lihat di blok ini", enabled = !exporting) { seek(((sel.startMs + sel.endMs) / 2).toFloat()) } }
                                }
                            } else {
                                PanelNote("Bingkai video dimiringkan saat zoom di blok ini.", px)
                            }
                        }

                        // ---- Kurva animasi: satu per channel (skala+posisi, dan tiap slider Customize 3D kamera) ----
                        else -> CurvePanel(
                            sel = sel,
                            channel = curveCh,
                            onChannel = { curveCh = it },
                            enabled = !exporting,
                            onCurve = setCurve,
                            onApplyAll = { ch, c ->
                                zooms = zooms.map { r ->
                                    when (ch) {
                                        CH_PITCH -> r.copy(curvePitch = c); CH_YAW -> r.copy(curveYaw = c)
                                        CH_ROLL -> r.copy(curveRoll = c); CH_DEPTH -> r.copy(curveDepth = c)
                                        else -> r.copy(curve = c)
                                    }
                                }
                            },
                        )
                    }

                    1 -> when (bgUi) {
                        // gradient: 6 bulatan satu baris; warna: 12 bulatan dua baris
                        0 -> GridRows(PRESETS.size, 6, 10.dp, px) { i, m ->
                            val (a, b) = PRESETS[i]
                            Swatch(Brush.verticalGradient(listOf(Color(a), Color(b))), i == preset, !exporting, m) { preset = i }
                        }
                        1 -> GridRows(SOLIDS.size, 6, 10.dp, px) { i, m ->
                            Swatch(Brush.verticalGradient(listOf(Color(SOLIDS[i]), Color(SOLIDS[i]))), i == solid, !exporting, m) { solid = i }
                        }
                        2 -> GridRows(WALLS.size, 3, 10.dp, px) { i, m ->
                            WallSwatch(WALLS[i], i == wall, !exporting, m) { wall = i }
                        }
                        // foto: tombol Galeri setinggi dua baris + foto bawaan 2 baris yang bisa digeser
                        3 -> Row(
                            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            GalleryTile(!exporting) {
                                pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            }
                            for (k in 0 until WALLPAPER_COUNT / 2) {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    for (j in 0..1) {
                                        val u = wallpaperUri(ctx, k * 2 + j + 1)
                                        WallThumb(ctx, u, imageUri == u, !exporting) { imageUri = u }
                                    }
                                }
                            }
                        }
                        else -> Column(px, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                buildAnnotatedString {
                                    append("Tingkat blur  ")
                                    withStyle(SpanStyle(color = cs.onBackground, fontWeight = FontWeight.SemiBold)) { append(pct(blurAmt, 0.01f..0.08f)) }
                                },
                                fontSize = 12.sp, color = cs.onSurfaceVariant,
                            )
                            FlatSlider(blurAmt, { blurAmt = it }, 0.01f..0.08f, !exporting)
                        }
                    }

                    2 -> when (tabSel) {
                        0 -> PanelGroup(px) {
                            TickSlider("Jarak", padding, 0f..0.25f, pct(padding, 0f..0.25f), !exporting) { padding = it }
                            TickSlider("Sudut", corner, 0f..0.10f, pct(corner, 0f..0.10f), !exporting, divider = true) { corner = it }
                        }
                        1 -> PanelGroup(px, 0.dp, 0.dp) {
                            ToggleRow("Bayangan", shadow, !exporting) { shadow = it }
                            TickSlider("Jumlah", shadowAmt, 0f..1f, pct(shadowAmt, 0f..1f), !exporting && shadow) { shadowAmt = it }
                        }
                        else -> PanelGroup(px, 0.dp, 6.dp) {
                            ToggleRow(
                                "Kursor sintetis", cursorOn, !exporting,
                                note = if (cursorOn && cursorTrack.isEmpty()) "Butuh data ketukan atau blok zoom." else null,
                            ) { cursorOn = it }
                        }
                    }

                    4 -> when (tabSel) {
                        // filter: tile pratinjau warna + intensitas
                        0 -> {
                            Row(
                                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Looks.presets.forEachIndexed { i, p -> LookTile(p.name, Looks.matrix(i, 0.6f), look == i, !exporting) { look = i } }
                            }
                            PanelGroup(px) {
                                TickSlider("Intensitas", lookAmt, 0f..1f, pct(lookAmt, 0f..1f), !exporting && look != 0) { lookAmt = it }
                            }
                        }
                        1 -> PanelGroup(px) {
                            TickSlider("Jumlah", vignette, 0f..1f, pct(vignette, 0f..1f), !exporting) { vignette = it }
                        }
                        else -> PanelGroup(px) {
                            TickSlider("Jumlah", glow, 0f..1f, pct(glow, 0f..1f), !exporting) { glow = it }
                            TickSlider("Ukuran", glowSize, 0f..1f, pct(glowSize, 0f..1f), !exporting && glow > 0f, divider = true) { glowSize = it }
                        }
                    }

                    // rasio: 5 kartu persegi sama lebar
                    else -> Row(px.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ASPECTS.forEachIndexed { i, (label, r) -> AspectCard(label, r, aspectIdx == i, !exporting, Modifier.weight(1f)) { aspectIdx = i } }
                    }
                }
            }
        }
    }

    // Area bawah: timeline (menempel di atas) + nav. Panel tool menutupi bagian bawah area ini, termasuk nav,
    // tapi ruler + baris video tetap terlihat (untuk Zoom: baris zoom juga), jadi playhead tetap bisa digeser.
    // Panel naik dari bawah (0,3 dtk) dan tingginya beranimasi (0,25 dtk) saat pindah antar tool, seperti desain.
    val bottomSection: @Composable (Modifier) -> Unit = { mod ->
        Box(mod.onSizeChanged { bottomH = it.height }) {
            Column(Modifier.fillMaxSize()) {
                Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp)) { timeline() }
                toolbar()
            }
            val open = tool in TOOLS.indices
            if (open) lastTool[0] = tool
            val shown = lastTool[0]
            val keep = if (shown == 0) TL_ROWS_ZOOM else TL_ROWS_TOP
            val target = (with(LocalDensity.current) { bottomH.toDp() } - keep).coerceAtLeast(150.dp)
            val panelH by animateDpAsState(target, tween(250), label = "panelH")
            AnimatedVisibility(
                visible = open,
                modifier = Modifier.align(Alignment.BottomCenter),
                enter = slideInVertically(tween(300, easing = PANEL_EASE)) { (it * 1.02f).toInt() },
                exit = slideOutVertically(tween(300, easing = PANEL_EASE)) { (it * 1.02f).toInt() },
            ) { panel(panelH, shown) }
        }
    }

    val toastChip: @Composable () -> Unit = {
        toast?.let { m ->
            Box(
                Modifier.clip(RoundedCornerShape(50)).background(cs.surfaceContainerHighest.copy(alpha = 0.92f))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            ) { Text(m, style = MaterialTheme.typography.labelMedium, color = cs.onBackground, maxLines = 1) }
        }
    }

    val errorChip: @Composable () -> Unit = {
        (error ?: player.failed)?.let { m ->
            Box(
                Modifier.clip(RoundedCornerShape(50)).background(cs.surfaceContainerHighest.copy(alpha = 0.92f))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            ) { Text(m, style = MaterialTheme.typography.labelMedium, color = cs.error, maxLines = 1, overflow = TextOverflow.Ellipsis) }
        }
    }

    // Kanvas dan baris player TERKUNCI: ukuran dan posisinya tidak bergantung pada panel yang dibuka.
    // Area bawah punya tinggi tetap di potret; panel tool hanya menimpa isinya (lihat bottomSection).
    if (askSave) {
        AlertDialog(
            onDismissRequest = { askSave = false },
            title = { Text("Simpan project?") },
            text = { Text("Ada perubahan yang belum disimpan.") },
            confirmButton = { TextButton(onClick = { askSave = false; saveProject { onBack() } }) { Text("Simpan") } },
            dismissButton = {
                Row {
                    TextButton(onClick = { askSave = false }) { Text("Batal") }
                    TextButton(onClick = { askSave = false; onBack() }) { Text("Buang", color = cs.error) }
                }
            },
        )
    }
    BoxWithConstraints(modifier) {
        val land = maxWidth > maxHeight
        Column(Modifier.fillMaxSize()) {
            topBar()
            if (land) {
                Row(Modifier.weight(1f).fillMaxWidth()) {
                    Column(Modifier.weight(if (focus) 1f else 0.42f).fillMaxHeight()) {
                        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { preview() }
                            Box(Modifier.align(Alignment.BottomStart).padding(8.dp)) { toastChip() }
                            Box(Modifier.align(Alignment.TopCenter).padding(8.dp)) { errorChip() }
                        }
                        playerCard()
                    }
                    if (!focus) bottomSection(Modifier.weight(0.58f).fillMaxHeight())
                }
            } else {
                Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp)) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { preview() }
                    Box(Modifier.align(Alignment.BottomStart).padding(8.dp)) { toastChip() }
                    Box(Modifier.align(Alignment.TopCenter).padding(8.dp)) { errorChip() }
                }
                playerCard()
                if (!focus) bottomSection(Modifier.fillMaxWidth().height(TL_AREA + TOOLBAR_H + 1.dp))
            }
        }
    }
}

/** Pratinjau: kanvas berlatar + video dengan padding/sudut/bayangan (perkiraan dari hasil ekspor). */
@Composable
private fun FramePreview(
    uri: Uri, videoAspect: Float, style: FrameStyle, player: PlayerState, img: Bitmap?, frame: Bitmap?, zooms: List<ZoomRegion>,
    cursorTrack: List<TouchEvent>, timeMs: () -> Float,
    editRegion: ZoomRegion?, onEdit: (fx: Float, fy: Float, scale: Float) -> Unit,
) {
    val canvasAspect = style.aspect ?: videoAspect
    val tvRef = remember { arrayOfNulls<TextureView>(1) }   // TextureView video, dibaca overlay glow
    // filter warna pratinjau: matriks 4x5 yang sama dengan uniform shader ekspor (null = tanpa filter)
    val lookFilter = remember(style.look, style.lookAmt) { Looks.matrix(style.look, style.lookAmt)?.let { Looks.colorMatrix20(it) } }
    BoxWithConstraints(Modifier.aspectRatio(canvasAspect).clip(RoundedCornerShape(12.dp)).clipToBounds()) {
        // filter warna berlaku juga di background (seluruh kanvas); bayangan kartu tetap hitam, sama dengan ekspor
        Box(Modifier.fillMaxSize().colorMatrixLayer(lookFilter)) { BackgroundLayer(style, img, frame, videoAspect) { tvRef[0] } }
        val short = min(maxWidth, maxHeight)
        val pad = short * style.padding
        val shape = RoundedCornerShape(short * style.corner)
        // ukuran kanvas (px): diambil di sini, karena `constraints` tidak bisa dipanggil dari lambda graphicsLayer (beda scope)
        val cw = constraints.maxWidth.toFloat()
        val ch = constraints.maxHeight.toFloat()
        // ukuran kartu video (px) untuk pemilih area: kartu muat di dalam kanvas dikurangi padding, rasio = rasio video
        val padPx = with(LocalDensity.current) { pad.toPx() }
        val availW = (cw - 2f * padPx).coerceAtLeast(1f)
        val availH = (ch - 2f * padPx).coerceAtLeast(1f)
        val cardW = if (availW / availH > videoAspect) availH * videoAspect else availW
        val cardH = cardW / videoAspect
        Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.Center) {
            Box(
                Modifier.aspectRatio(videoAspect)
                    .graphicsLayer {
                        // zoom kartu: seluruh bingkai dibesarkan dari pojok kiri-atasnya lalu digeser (rumus sama dengan ekspor)
                        // timeMs() dibaca DI SINI (fase layer): tiap frame hanya layer yang dihitung ulang, bukan seluruh UI
                        val hw = this.size.width / 2f; val hh = this.size.height / 2f
                        val cz = if (editRegion != null) CardZoom.NONE else ZoomMath.camera(zooms, timeMs().toDouble(), CardGeo(cw, ch, cw / 2f, ch / 2f, hw, hh))
                        transformOrigin = TransformOrigin(0f, 0f)
                        scaleX = cz.s
                        scaleY = cz.s
                        translationX = (cz.s - 1f) * (cw / 2f - hw) + cz.tx
                        translationY = (cz.s - 1f) * (ch / 2f - hh) + cz.ty
                    }
                    .graphicsLayer {
                        // kamera 3D: SAMA dengan shader ekspor (uRot/uPers/uOff). Titik bidang p = fit * s * (titik kartu) jatuh di
                        // P * (R p + (o, 0)).xy / (P - (R p).z), R = Rx(pitch) Ry(yaw) Rz(roll). Satuan layer ini = px kartu SEBELUM zoom,
                        // jadi P dan o dibagi s (zoom di layer luar menskala semuanya sama).
                        // graphicsLayer: rotationX/Y/Z = pitch/yaw/roll, scale lebih dulu dari rotasi, cameraDistance = P / 72 (lihat Cam).
                        // Offset kamera nyata (o) bekerja SEBELUM pembagian perspektif, sedangkan translation graphicsLayer sesudahnya:
                        // dibuat dengan menggeser PIVOT (Cam.layerFit), identik secara aljabar.
                        val hw = this.size.width / 2f; val hh = this.size.height / 2f
                        val cz = if (editRegion != null) CardZoom.NONE else ZoomMath.camera(zooms, timeMs().toDouble(), CardGeo(cw, ch, cw / 2f, ch / 2f, hw, hh), if (style.cursor) cursorTrack else emptyList())
                        if (cz.tilted) {
                            val pl = (if (cz.persp > 0f) cz.persp else Cam.perspectivePx(2f * hw * cz.s, 2f * hh * cz.s)) / cz.s
                            val lf = Cam.layerFit(cz.rot, pl, cz.ox / cz.s, cz.oy / cz.s)
                            val pvx = lf.cx / cz.fit; val pvy = lf.cy / cz.fit      // pivot, px kartu relatif pusat
                            rotationX = cz.pitchDeg
                            rotationY = cz.yawDeg
                            rotationZ = cz.rollDeg
                            scaleX = cz.fit * lf.sigma
                            scaleY = cz.fit * lf.sigma
                            transformOrigin = TransformOrigin(0.5f + pvx / this.size.width, 0.5f + pvy / this.size.height)
                            translationX = -pvx
                            translationY = -pvy
                            cameraDistance = pl / Cam.ANDROID_CAMERA_UNIT
                        }
                    }
                    .then(if (style.shadow && style.shadowAmt > 0f) Modifier.shadow(
                        short * (0.08f * style.shadowAmt), shape,
                        ambientColor = Color.Black.copy(alpha = (style.shadowAmt * 2f).coerceAtMost(1f)),
                        spotColor = Color.Black.copy(alpha = (style.shadowAmt * 2f).coerceAtMost(1f)),
                    ) else Modifier)
                    .clip(shape),
            ) {
                // Bingkai di atas sudah clip(shape) dan ikut dibesarkan bersama isinya (zoom kartu, bukan crop isi video).
                // glow (bloom): urutan efek sama dengan ekspor: filter warna -> glow -> vignette
                VideoSurface(player, Modifier.fillMaxSize(), lookFilter) { tvRef[0] = it }
                GlowOverlay(style.glow, style.glowSize, style.look, style.lookAmt, { tvRef[0] }, Modifier.fillMaxSize())
                // vignette: gradien radial hitam di atas video (r = jarak / setengah diagonal kartu), rumus sama dengan shader ekspor
                if (style.vignette > 0f) Canvas(Modifier.fillMaxSize()) {
                    val half = kotlin.math.hypot(size.width, size.height) / 2f
                    val rs = listOf(0f, Looks.VIG_START, 0.45f, 0.55f, 0.65f, 0.75f, 0.85f, 0.93f, 1f)
                    drawRect(Brush.radialGradient(
                        colorStops = rs.map { r -> r to Color.Black.copy(alpha = Looks.vigAlpha(r, style.vignette)) }.toTypedArray(),
                        center = center, radius = half,
                    ))
                }
                // kursor sintetis: di dalam bingkai yang sama, jadi ikut terpotong dan ikut miring (kamera 3D)
                if (style.cursor) Canvas(Modifier.fillMaxSize()) {
                    CursorMath.at(cursorTrack, timeMs().toLong())?.let { drawCursor(it) }
                }
            }
        }
        // pemilih area zoom: di atas SELURUH kanvas (bukan hanya kartu), kartu tampil tanpa zoom.
        // Jendela boleh keluar dari kartu ke area background.
        if (editRegion != null) ZoomAreaOverlay(editRegion, CardGeo(cw, ch, cw / 2f, ch / 2f, cardW / 2f, cardH / 2f), onEdit)
    }
}

/**
 * Glow (bloom) pratinjau, jalan di semua versi Android. Langkah sama dengan ekspor ([Looks.glowPreview]): gambar video diambil dari [view]
 * (TextureView) tiga kali lebih besar dari tekstur glow, dirata-ratakan (prefilter), diberi filter warna + ambang, diblur Gaussian di
 * resolusi kecil, lalu diperbesar bilinear dan digambar di atas video dengan BlendMode.Screen pada alpha = [amount]
 * (sama dengan `1 - (1 - v)(1 - amount * g)` di shader ekspor). Pengolahan CPU berjalan di Dispatchers.Default, tiap dua frame.
 */
@Composable
private fun GlowOverlay(amount: Float, sizeFrac: Float, look: Int, lookAmt: Float, view: () -> TextureView?, modifier: Modifier) {
    val a = amount.coerceIn(0f, 1f)
    if (a <= 0f) return
    var bmp by remember { mutableStateOf<Bitmap?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    var box by remember { mutableStateOf(IntSize.Zero) }
    val m = remember(look, lookAmt) { Looks.matrix(look, lookAmt) ?: Looks.ID }
    LaunchedEffect(sizeFrac, m, box) {
        if (box.width <= 0 || box.height <= 0) return@LaunchedEffect
        val sigX = Looks.glowSigmaFrac(sizeFrac) * kotlin.math.min(box.width, box.height) / box.width
        val gw = (3f / sigX).coerceIn(16f, 120f).toInt()
        val gh = (gw * box.height.toFloat() / box.width).toInt().coerceAtLeast(8)
        val sigB = (sigX * gw).coerceIn(0.5f, 4f)
        val sw = gw * 3
        val sh = gh * 3
        val raw = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
        val out = Bitmap.createBitmap(gw, gh, Bitmap.Config.ARGB_8888)
        val src = IntArray(sw * sh)
        val px = IntArray(gw * gh)
        var frames = 0
        while (true) {
            withFrameNanos { }
            if (frames++ % 2 != 0) continue
            val tv = view() ?: continue
            if (!tv.isAvailable) continue
            var ok = false
            try {
                tv.getBitmap(raw)
                raw.getPixels(src, 0, sw, 0, 0, sw, sh)
                ok = true
            } catch (_: Exception) {}
            if (!ok) continue
            withContext(Dispatchers.Default) {
                Looks.glowPreview(src, sw, sh, gw, gh, sigB, m, px)
                out.setPixels(px, 0, gw, 0, 0, gw, gh)
            }
            bmp = out
            tick++
        }
    }
    Canvas(modifier.onSizeChanged { box = it }) {
        tick   // langganan: gambar ulang tiap gambar kecil baru
        bmp?.let {
            drawImage(
                it.asImageBitmap(),
                dstSize = IntSize(size.width.toInt(), size.height.toInt()),
                alpha = a, blendMode = BlendMode.Screen, filterQuality = FilterQuality.High,
            )
        }
    }
}

/** Menjalankan isi lewat filter matriks warna 4x5 (null = apa adanya). Dipakai agar background ikut berfilter seperti video. */
private fun Modifier.colorMatrixLayer(m: FloatArray?): Modifier = if (m == null) this else this.drawWithContent {
    drawIntoCanvas { canvas ->
        val paint = androidx.compose.ui.graphics.Paint().apply {
            colorFilter = androidx.compose.ui.graphics.ColorFilter.colorMatrix(androidx.compose.ui.graphics.ColorMatrix(m))
        }
        canvas.saveLayer(androidx.compose.ui.geometry.Rect(Offset.Zero, size), paint)
        drawContent()
        canvas.restore()
    }
}

/**
 * Background blur pratinjau yang BERGERAK: gambar kecil video diambil terus dari [view] (TextureView yang sama dengan video utama,
 * jadi selalu satu frame dan satu posisi dengan video: play, jeda, dan scrub ikut), digambar memenuhi kanvas (crop tengah) lalu diblur.
 * Gambar kecil dipakai supaya murah (CPU hampir nol) dan sudah halus saat diperbesar bilinear. Sebelum frame pertama tiba,
 * [placeholder] (frame pertama video) ditampilkan supaya tidak berkedip. Sama dengan ekspor, yang membaca tekstur video tiap frame.
 */
@Composable
private fun LiveBlurBackground(placeholder: Bitmap?, videoAspect: Float, view: () -> TextureView?, modifier: Modifier) {
    var bmp by remember { mutableStateOf<Bitmap?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(videoAspect) {
        val bw = 96
        val bh = (bw / videoAspect).toInt().coerceIn(16, 256)
        val buf = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        var frames = 0
        while (true) {
            withFrameNanos { }
            if (frames++ % 2 != 0) continue
            val tv = view() ?: continue
            if (!tv.isAvailable) continue
            try {
                tv.getBitmap(buf)
                bmp = buf
                tick++
            } catch (_: Exception) {}
        }
    }
    Canvas(modifier.clipToBounds().blur(24.dp)) {
        tick   // langganan: gambar ulang tiap frame baru
        val src = bmp ?: placeholder ?: return@Canvas
        val sc = kotlin.math.max(size.width / src.width, size.height / src.height)
        val dw = src.width * sc
        val dh = src.height * sc
        drawImage(
            src.asImageBitmap(),
            dstOffset = androidx.compose.ui.unit.IntOffset(((size.width - dw) / 2f).toInt(), ((size.height - dh) / 2f).toInt()),
            dstSize = IntSize(dw.toInt() + 1, dh.toInt() + 1),
            filterQuality = FilterQuality.High,
        )
    }
}

@Composable
private fun BackgroundLayer(style: FrameStyle, img: Bitmap?, frame: Bitmap?, videoAspect: Float, view: () -> TextureView?) {
    when {
        style.bgType == 2 && img != null ->
            Image(img.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        style.bgType == 3 ->
            LiveBlurBackground(frame, videoAspect, view, Modifier.fillMaxSize())
        style.bgType == 1 ->
            Box(
                Modifier.fillMaxSize().drawBehind {
                    drawRect(Color(style.top))
                    val r = size.maxDimension * 0.95f
                    drawRect(Brush.radialGradient(listOf(Color(style.mid), Color.Transparent),
                        center = Offset(size.width * 0.15f, size.height * 0.15f), radius = r))
                    drawRect(Brush.radialGradient(listOf(Color(style.bottom), Color.Transparent),
                        center = Offset(size.width * 0.85f, size.height * 0.85f), radius = r))
                },
            )
        else ->
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(style.top), Color(style.bottom)))))
    }
}

@Composable
private fun Swatch(brush: Brush, selected: Boolean, enabled: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.aspectRatio(1f).clip(CircleShape)
            .background(brush)
            .then(
                if (selected) Modifier.border(3.dp, MaterialTheme.colorScheme.primary, CircleShape)
                else Modifier.border(1.dp, Color.White.copy(alpha = 0.14f), CircleShape),
            )
            .clickable(enabled = enabled, onClick = onClick),
    )
}

@Composable
private fun VideoSurface(state: PlayerState, modifier: Modifier, colorMatrix: FloatArray? = null, onView: (TextureView) -> Unit = {}) {
    AndroidView(
        modifier = modifier,
        update = { tv ->
            tv.setLayerPaint(
                if (colorMatrix == null) null
                else android.graphics.Paint().apply { colorFilter = android.graphics.ColorMatrixColorFilter(android.graphics.ColorMatrix(colorMatrix)) },
            )
        },
        factory = { c ->
            TextureView(c).apply {
                onView(this)
                surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                        state.attach(Surface(st))
                    }

                    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}

                    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                        // pemutar TIDAK dibuang, hanya dilepas dari surface; surface baru dipasang saat tersedia lagi
                        state.detach()
                        return true
                    }

                    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
                }
            }
        },
    )
}
