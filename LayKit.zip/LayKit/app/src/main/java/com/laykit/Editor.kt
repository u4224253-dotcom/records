package com.laykit

import android.graphics.Bitmap
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.net.Uri
import android.view.Surface
import android.view.TextureView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val PRESETS = listOf(
    0xFF1E3A8A.toInt() to 0xFF7C3AED.toInt(),   // biru-ungu
    0xFFF97316.toInt() to 0xFFDB2777.toInt(),   // sunset
    0xFF059669.toInt() to 0xFF0E7490.toInt(),   // tosca
    0xFF0F172A.toInt() to 0xFF334155.toInt(),   // malam
    0xFFF8FAFC.toInt() to 0xFFCBD5E1.toInt(),   // terang
    0xFF000000.toInt() to 0xFF000000.toInt(),   // hitam
)

private val SOLIDS = listOf(
    0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFF0F172A.toInt(), 0xFF1E293B.toInt(),
    0xFFEF4444.toInt(), 0xFFF97316.toInt(), 0xFFEAB308.toInt(), 0xFF22C55E.toInt(),
    0xFF06B6D4.toInt(), 0xFF3B82F6.toInt(), 0xFF8B5CF6.toInt(), 0xFFEC4899.toInt(),
)

// wallpaper "mesh": warna dasar, warna tengah, warna sudut bawah
private val WALLS = listOf(
    Triple(0xFF0B1026.toInt(), 0xFF22D3AE.toInt(), 0xFF7C3AED.toInt()),   // aurora
    Triple(0xFF2B1055.toInt(), 0xFFFB7185.toInt(), 0xFFFBBF24.toInt()),   // senja
    Triple(0xFF03045E.toInt(), 0xFF0096C7.toInt(), 0xFF90E0EF.toInt()),   // laut
    Triple(0xFF111827.toInt(), 0xFFF472B6.toInt(), 0xFF38BDF8.toInt()),   // neon
    Triple(0xFF052E16.toInt(), 0xFF16A34A.toInt(), 0xFFA3E635.toInt()),   // hutan
    Triple(0xFFFDE68A.toInt(), 0xFFF9A8D4.toInt(), 0xFFA5B4FC.toInt()),   // pastel
)

/** Wallpaper foto bawaan (res/raw/wallpaper1..18.jpg), diambil dari Openscreen (MIT), diperkecil ke 1600 px. */
private const val WALLPAPER_COUNT = 18

private fun wallpaperUri(ctx: android.content.Context, n: Int): Uri =
    Uri.parse("android.resource://${ctx.packageName}/raw/wallpaper$n")

@Composable
private fun WallThumb(ctx: android.content.Context, uri: Uri, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val bmp by produceState<Bitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) { Exporter.loadImage(ctx, uri, 160) }
    }
    Box(
        Modifier.size(width = 72.dp, height = 46.dp).clip(RoundedCornerShape(10.dp))
            .background(Color.Gray.copy(alpha = 0.3f))
            .then(if (selected) Modifier.border(3.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(8.dp))
                  else Modifier.border(1.dp, Color.Gray.copy(alpha = 0.5f), RoundedCornerShape(8.dp)))
            .clickable(enabled = enabled, onClick = onClick),
    ) {
        bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
    }
}

private val BG_TYPES = listOf("Gradient", "Warna", "Wallpaper", "Foto", "Blur")

private val ASPECTS = listOf<Pair<String, Float?>>(
    "Asli" to null, "16:9" to 16f / 9f, "9:16" to 9f / 16f, "1:1" to 1f, "4:5" to 4f / 5f,
)

private class PlayerState {
    var mp: MediaPlayer? = null
    var surface: Surface? = null
    var ready by mutableStateOf(false)
    var playing by mutableStateOf(false)
    /** Pesan kalau pemutar gagal (ditampilkan di editor), null = normal. */
    var failed by mutableStateOf<String?>(null)
    /** Play ditekan sebelum video siap: mulai otomatis begitu siap. */
    var playWhenReady = false
    /** Pemutaran sudah sampai habis (MediaPlayer ada di keadaan PlaybackCompleted). */
    var completed = false
    var positionMs by mutableLongStateOf(0L)
    /** Posisi pratinjau (ms) yang HALUS: diperbarui tiap frame layar lewat ekstrapolasi, dipakai zoom dan kursor. */
    var smoothMs by mutableFloatStateOf(0f)

    /**
     * Buat MediaPlayer SEKALI per video. Sebelumnya pemutar dibuat/dibuang oleh callback TextureView, sehingga setiap kali
     * TextureView dilepas/dipasang ulang (ganti layout, mode pilih area, dsb.) pemutar ikut dibuang dan Play tidak jalan.
     * Sekarang siklus hidup pemutar terpisah dari surface: surface cukup dipasang ([attach]) atau dilepas ([detach]).
     */
    fun open(ctx: android.content.Context, uri: Uri) {
        release()
        failed = null
        val player = MediaPlayer()
        try {
            player.setDataSource(ctx, uri)
            surface?.let { player.setSurface(it) }
            player.setOnPreparedListener {
                ready = true
                try { it.seekTo(0) } catch (_: Exception) {}
                if (playWhenReady) {
                    playWhenReady = false
                    try { it.start(); playing = true } catch (_: Exception) {}
                }
            }
            player.setOnCompletionListener { playing = false; completed = true }
            player.setOnErrorListener { _, what, extra ->
                ready = false; playing = false
                failed = "Pemutar gagal ($what/$extra)"
                true
            }
            player.prepareAsync()
            mp = player
        } catch (e: Exception) {
            failed = "Video tidak bisa dibuka"
            try { player.release() } catch (_: Exception) {}
        }
    }

    fun attach(s: Surface) {
        surface = s
        try { mp?.setSurface(s) } catch (_: Exception) {}
    }

    fun detach() {
        try { mp?.setSurface(null) } catch (_: Exception) {}
        try { surface?.release() } catch (_: Exception) {}
        surface = null
    }

    fun release() {
        ready = false
        playing = false
        playWhenReady = false
        completed = false
        try { mp?.release() } catch (_: Exception) {}
        mp = null
    }
}

private val TOOLS = listOf("Zoom", "Background", "Bingkai", "Rasio")

/** Tab di header panel tiap tool. Background memakai tipe background sebagai tab (lihat [BG_TYPES]). */
private val TOOL_TABS = listOf(
    listOf("Blok", "Atur", "3D", "Kurva"),
    BG_TYPES,
    listOf("Bentuk", "Bayangan", "Kursor"),
    listOf("Rasio"),
)

/** Tinggi area timeline (ruler + baris + ruang kosong) dan toolbar bawah. Tetap, supaya pratinjau tidak berubah ukuran. */
private val TL_AREA = 224.dp
private val TOOLBAR_H = 52.dp

/** Ikon garis 24x24 untuk toolbar bawah (digambar sendiri, urutan sama dengan [TOOLS]). */
private val TOOL_ICONS = listOf(
    // Zoom: kaca pembesar dengan tanda plus
    listOf("M11 4.5a6.5 6.5 0 1 0 0 13a6.5 6.5 0 0 0 0 -13Z", "M16 16L20.5 20.5", "M11 8.5V13.5", "M8.5 11H13.5"),
    // Background: gambar dengan gunung
    listOf("M5 4H19a2 2 0 0 1 2 2V18a2 2 0 0 1 -2 2H5a2 2 0 0 1 -2 -2V6a2 2 0 0 1 2 -2Z", "M3 16L8 11L12 15L15 12L21 18"),
    // Bingkai: dua persegi bersarang
    listOf("M4 4H20V20H4Z", "M8 8H16V16H8Z"),
    // Rasio: persegi panjang dengan tanda sudut
    listOf("M3 7H21V17H3Z", "M7 11V9H9", "M17 13V15H15"),
)

// Ikon kartu player
private val ICON_FULLSCREEN = listOf("M4 9V4H9", "M20 9V4H15", "M4 15V20H9", "M20 15V20H15")
private val ICON_VOLUME = listOf("M4 10V14H8L13 18V6L8 10Z", "M16.5 9.5a3.5 3.5 0 0 1 0 5")
private val ICON_VOLUME_OFF = listOf("M4 10V14H8L13 18V6L8 10Z", "M17 9L21 15", "M21 9L17 15")
private val ICON_UNDO = listOf("M9 14L4 9L9 4", "M4 9H15a5 5 0 0 1 0 10H11")
private val ICON_REDO = listOf("M15 14L20 9L15 4", "M20 9H9a5 5 0 0 0 0 10H13")

/** Satu keadaan edit lengkap, dipakai untuk undo/redo. */
private data class EditSnap(
    val zooms: List<ZoomRegion>, val startMs: Float, val endMs: Float,
    val bgUi: Int, val preset: Int, val solid: Int, val wall: Int, val imageUri: Uri?, val blurAmt: Float,
    val padding: Float, val corner: Float, val shadow: Boolean, val shadowAmt: Float, val aspectIdx: Int, val cursorOn: Boolean,
)

/** Palet editor: hitam pekat, kartu abu gelap, aksen teal muda, tombol Ekspor oranye. Datar, tanpa bayangan. */
private val EditorColors = darkColorScheme(
    primary = Color(0xFFBFE0DC),
    onPrimary = Color(0xFF0B0B0B),
    secondaryContainer = Color(0xFF26262A),
    onSecondaryContainer = Color(0xFFF2F2F2),
    tertiary = Color(0xFFFF6A13),
    background = Color(0xFF0B0B0B),
    onBackground = Color(0xFFF2F2F2),
    surface = Color(0xFF0B0B0B),
    onSurface = Color(0xFFF2F2F2),
    surfaceVariant = Color(0xFF1C1C1E),
    onSurfaceVariant = Color(0xFF8E8E93),
    surfaceContainerLow = Color(0xFF131315),
    surfaceContainer = Color(0xFF161618),
    surfaceContainerHighest = Color(0xFF26262A),
    outline = Color(0xFF3A3A3E),
    outlineVariant = Color(0xFF2A2A2D),
    error = Color(0xFFFF6369),
    onError = Color(0xFF1A0505),
)

@Composable
internal fun ToolIcon(paths: List<String>, color: Color, iconSize: Dp = 22.dp) {
    val parsed = remember(paths) { paths.map { PathParser().parsePathString(it).toPath() } }
    Canvas(Modifier.size(iconSize)) {
        scale(this.size.width / 24f, pivot = Offset.Zero) {
            parsed.forEach { drawPath(it, color, style = Stroke(width = 1.6f, cap = StrokeCap.Round, join = StrokeJoin.Round)) }
        }
    }
}

/** Ikon keyframe (belah ketupat): kosong + tanda tambah = tambah keyframe, terisi + tanda kurang = hapus keyframe di posisi ini. */
@Composable
private fun KeyframeIcon(on: Boolean, color: Color, cut: Color, iconSize: Dp = 20.dp) {
    val diamond = remember { PathParser().parsePathString("M12 3L21 12L12 21L3 12Z").toPath() }
    val plus = remember { PathParser().parsePathString("M12 8.5V15.5M8.5 12H15.5").toPath() }
    val minus = remember { PathParser().parsePathString("M8.5 12H15.5").toPath() }
    Canvas(Modifier.size(iconSize)) {
        scale(this.size.width / 24f, pivot = Offset.Zero) {
            val st = Stroke(width = 1.6f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            if (on) {
                drawPath(diamond, color)
                drawPath(minus, cut, style = Stroke(width = 1.8f, cap = StrokeCap.Round))
            } else {
                drawPath(diamond, color, style = st)
                drawPath(plus, color, style = st)
            }
        }
    }
}

@Composable
fun EditorScreen(uri: Uri, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val player = remember { PlayerState() }
    DisposableEffect(Unit) { onDispose { player.release(); player.detach() } }

    // Editor selalu gelap: ikon status bar dibuat terang selama editor terbuka, lalu dikembalikan.
    val view = LocalView.current
    DisposableEffect(Unit) {
        val win = view.context.findActivity()?.window
        val ctrl = win?.let { WindowCompat.getInsetsController(it, view) }
        val prevStatus = ctrl?.isAppearanceLightStatusBars
        val prevNav = ctrl?.isAppearanceLightNavigationBars
        ctrl?.isAppearanceLightStatusBars = false
        ctrl?.isAppearanceLightNavigationBars = false
        onDispose {
            if (ctrl != null && prevStatus != null) ctrl.isAppearanceLightStatusBars = prevStatus
            if (ctrl != null && prevNav != null) ctrl.isAppearanceLightNavigationBars = prevNav
        }
    }

    val info by produceState<VideoInfo?>(null, uri) {
        value = withContext(Dispatchers.IO) { Exporter.probe(ctx, uri) }
    }

    var cancel by remember { mutableStateOf<Exporter.Cancel?>(null) }
    val back = { cancel?.requested = true; onBack() }
    BackHandler { back() }

    MaterialTheme(colorScheme = EditorColors) {
        Box(Modifier.fillMaxSize().background(EditorColors.background).systemBarsPadding()) {
            val vi = info
            if (vi == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                IconButton(onClick = { back() }, modifier = Modifier.padding(4.dp)) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali", tint = EditorColors.onBackground)
                }
            } else {
                EditorContent(ctx, scope, uri, vi, player, { cancel = it }, cancel, back, Modifier.fillMaxSize())
            }
        }
    }
}

@Composable
private fun EditorContent(
    ctx: android.content.Context,
    scope: kotlinx.coroutines.CoroutineScope,
    uri: Uri,
    vi: VideoInfo,
    player: PlayerState,
    setCancel: (Exporter.Cancel?) -> Unit,
    cancel: Exporter.Cancel?,
    onBack: () -> Unit,
    modifier: Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val durMs = vi.durationMs.coerceAtLeast(1000L)
    DisposableEffect(uri) {
        player.open(ctx, uri)
        onDispose { player.release() }
    }
    var startMs by remember(uri) { mutableFloatStateOf(0f) }
    var endMs by remember(uri) { mutableFloatStateOf(durMs.toFloat()) }

    var tool by remember { mutableIntStateOf(-1) }   // -1 = panel tertutup

    var bgUi by remember { mutableIntStateOf(0) }       // 0 gradient, 1 warna, 2 wallpaper, 3 gambar, 4 blur
    var preset by remember { mutableIntStateOf(0) }
    var solid by remember { mutableIntStateOf(0) }
    var wall by remember { mutableIntStateOf(0) }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var blurAmt by remember { mutableFloatStateOf(0.04f) }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u ->
        if (u != null) imageUri = u
    }
    val imgBmp by produceState<Bitmap?>(null, imageUri) {
        val u = imageUri
        value = if (u == null) null else withContext(Dispatchers.IO) { Exporter.loadImage(ctx, u, 1024) }
    }
    val frameBmp by produceState<Bitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) { Exporter.firstFrame(ctx, uri) }
    }
    var padding by remember { mutableFloatStateOf(0.08f) }
    var corner by remember { mutableFloatStateOf(0.03f) }
    var shadow by remember { mutableStateOf(true) }
    var shadowAmt by remember { mutableFloatStateOf(0.5f) }
    var aspectIdx by remember { mutableIntStateOf(0) }

    // ---- zoom ----
    var zooms by remember(uri) { mutableStateOf<List<ZoomRegion>>(emptyList()) }
    var selectedZoom by remember(uri) { mutableStateOf<Int?>(null) }
    var selectedKey by remember(uri) { mutableStateOf<Long?>(null) }   // keyframe terpilih (waktu) pada blok terpilih
    var nextZoomId by remember(uri) { mutableIntStateOf(1) }
    var zoomMsg by remember(uri) { mutableStateOf<String?>(null) }
    var areaEdit by remember(uri) { mutableStateOf(false) }   // mode pilih area zoom di pratinjau
    val touches by produceState<List<TouchEvent>>(emptyList(), uri) {
        value = withContext(Dispatchers.IO) {
            val name = Library.nameOf(ctx, uri)
            if (name == null) emptyList() else TouchLog.load(ctx.filesDir, name)
        }
    }

    var exporting by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var resultUri by remember { mutableStateOf<Uri?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    var cursorOn by remember { mutableStateOf(true) }

    // ---- toast kecil di atas pratinjau, mode fokus (fullscreen), mute pratinjau ----
    var toast by remember { mutableStateOf<String?>(null) }
    var toastKey by remember { mutableIntStateOf(0) }
    fun showToast(m: String) { toast = m; toastKey++ }
    LaunchedEffect(toastKey) {
        if (toast != null) { delay(2000); toast = null }
    }
    var focus by remember { mutableStateOf(false) }
    BackHandler(enabled = focus) { focus = false }
    BackHandler(enabled = !focus && tool >= 0) { tool = -1 }   // Back menutup panel dulu sebelum keluar editor
    var muted by remember { mutableStateOf(false) }
    var bottomH by remember { mutableIntStateOf(0) }     // px, tinggi area bawah (timeline + toolbar); panel menutupi bagian bawahnya
    var toolTab by remember { mutableIntStateOf(0) }     // tab aktif di header panel (kecuali Background: pakai bgUi)
    var zParam by remember { mutableIntStateOf(0) }      // parameter zoom yang diatur slider: 0 skala, 1 X, 2 Y
    fun openTool(i: Int) { tool = i; toolTab = 0 }
    LaunchedEffect(muted, player.ready) {
        val v = if (muted) 0f else 1f
        try { player.mp?.setVolume(v, v) } catch (_: Exception) {}
    }

    // ---- undo / redo: perubahan digabung per 350 ms, lalu disimpan sebagai satu langkah ----
    val snap = EditSnap(
        zooms, startMs, endMs, bgUi, preset, solid, wall, imageUri, blurAmt,
        padding, corner, shadow, shadowAmt, aspectIdx, cursorOn,
    )
    var committed by remember(uri) { mutableStateOf<EditSnap?>(null) }
    var undoStack by remember(uri) { mutableStateOf<List<EditSnap>>(emptyList()) }
    var redoStack by remember(uri) { mutableStateOf<List<EditSnap>>(emptyList()) }
    fun commitNow(s: EditSnap) {
        val c = committed
        if (c == null) { committed = s; return }
        if (s == c) return
        undoStack = (undoStack + c).takeLast(60)
        redoStack = emptyList()
        committed = s
    }
    LaunchedEffect(snap) {
        if (committed == null) { committed = snap; return@LaunchedEffect }
        delay(350)
        commitNow(snap)
    }
    fun applySnap(s: EditSnap) {
        zooms = s.zooms; startMs = s.startMs; endMs = s.endMs
        bgUi = s.bgUi; preset = s.preset; solid = s.solid; wall = s.wall; imageUri = s.imageUri; blurAmt = s.blurAmt
        padding = s.padding; corner = s.corner; shadow = s.shadow; shadowAmt = s.shadowAmt; aspectIdx = s.aspectIdx; cursorOn = s.cursorOn
        selectedZoom = null; selectedKey = null; areaEdit = false
    }
    fun undo() {
        commitNow(snap)   // simpan dulu perubahan yang belum sempat tercatat
        val c = committed ?: return
        val target = undoStack.lastOrNull() ?: return
        undoStack = undoStack.dropLast(1)
        redoStack = redoStack + c
        committed = target
        applySnap(target)
        showToast("Dibatalkan")
    }
    fun redo() {
        val c = committed ?: return
        val target = redoStack.lastOrNull() ?: return
        redoStack = redoStack.dropLast(1)
        undoStack = undoStack + c
        committed = target
        applySnap(target)
        showToast("Diulangi")
    }
    val canUndo = undoStack.isNotEmpty() || (committed != null && committed != snap)
    val canRedo = redoStack.isNotEmpty()

    // Sumber kursor: data ketukan; kalau rekaman tidak punya (layanan sentuhan mati / elemen tidak terbaca),
    // kursor memakai titik fokus tiap blok zoom, jadi saklar Kursor tetap bisa dipakai.
    val cursorTrack = remember(touches, zooms) {
        if (touches.isNotEmpty()) touches
        else zooms.map { TouchEvent(it.startMs, it.fx.coerceIn(0f, 1f), it.fy.coerceIn(0f, 1f), TouchLog.TAP) }.sortedBy { it.tMs }
    }
    val base = FrameStyle(padding = padding, corner = corner, shadow = shadow, shadowAmt = shadowAmt, aspect = ASPECTS[aspectIdx].second, cursor = cursorOn && cursorTrack.isNotEmpty())
    val style = when (bgUi) {
        1 -> base.copy(top = SOLIDS[solid], bottom = SOLIDS[solid])
        2 -> base.copy(bgType = 1, top = WALLS[wall].first, mid = WALLS[wall].second, bottom = WALLS[wall].third)
        3 -> base.copy(bgType = 2, image = imageUri)
        4 -> base.copy(bgType = 3, blur = blurAmt)
        else -> base.copy(top = PRESETS[preset].first, bottom = PRESETS[preset].second)
    }
    val videoAspect = vi.width.toFloat() / vi.height.toFloat()

    // loop pemutaran di dalam rentang potong + jam halus untuk zoom/kursor.
    // MediaPlayer.currentPosition kasar dan bisa loncat; zoom yang dibaca darinya (dulu tiap 40 ms) patah-patah.
    // Saat memutar: waktu diekstrapolasi tiap frame layar, lalu dikoreksi pelan-pelan oleh currentPosition.
    val curStart by rememberUpdatedState(startMs)
    val curEnd by rememberUpdatedState(endMs)
    LaunchedEffect(Unit) {
        var est = 0f
        var lastFrameNs = 0L
        var lastSampleNs = 0L
        var ignoreUntilNs = 0L
        while (true) {
            val mp = player.mp
            if (mp == null || !player.ready) { delay(50); continue }
            if (!player.playing) {
                // jeda / scrub: ikuti posisi pemutar apa adanya
                try {
                    val p = mp.currentPosition.toFloat()
                    est = p
                    player.smoothMs = p
                    player.positionMs = p.toLong()
                } catch (_: Exception) {}
                lastFrameNs = 0L
                delay(30)
                continue
            }
            withFrameNanos { now ->
                if (lastFrameNs == 0L) {
                    // frame pertama setelah Play: langsung selaraskan dengan pemutar (tanpa koreksi pelan)
                    lastFrameNs = now; lastSampleNs = 0L
                    try { est = mp.currentPosition.toFloat() } catch (_: Exception) {}
                }
                val dt = ((now - lastFrameNs) / 1_000_000f).coerceIn(0f, 50f)
                lastFrameNs = now
                est += dt
                if (now - lastSampleNs > 50_000_000L && now > ignoreUntilNs) {
                    lastSampleNs = now
                    try {
                        val p = mp.currentPosition.toFloat()
                        if (p >= curEnd) {
                            mp.seekTo(curStart.toLong(), MediaPlayer.SEEK_CLOSEST)
                            est = curStart
                            ignoreUntilNs = now + 200_000_000L   // abaikan pembacaan lama sampai seek selesai
                        } else {
                            val err = p - est
                            est = if (kotlin.math.abs(err) > 250f) p else est + err * 0.15f
                        }
                    } catch (_: Exception) {}
                }
                if (est > curEnd) est = curEnd
                player.smoothMs = est
                // state yang memicu recompose (timeline, teks waktu) cukup ~25 Hz
                if (kotlin.math.abs(est - player.positionMs) >= 40f) player.positionMs = est.toLong()
            }
        }
    }

    fun seek(ms: Float) {
        try { player.mp?.seekTo(ms.toLong(), MediaPlayer.SEEK_CLOSEST) } catch (_: Exception) {}
    }

    fun togglePlay() {
        val mp = player.mp
        if (mp == null) return
        if (!player.ready) {
            // video belum siap: ingat niatnya, mulai otomatis begitu siap
            player.playWhenReady = !player.playWhenReady
            if (player.playWhenReady) areaEdit = false
            return
        }
        try {
            if (player.playing) {
                mp.pause(); player.playing = false
            } else {
                areaEdit = false
                // setelah habis (atau di luar rentang potong) mulai lagi dari awal rentang
                if (player.completed || mp.currentPosition < startMs || mp.currentPosition >= endMs) {
                    mp.seekTo(startMs.toLong(), MediaPlayer.SEEK_CLOSEST)
                }
                player.completed = false
                mp.start(); player.playing = true
            }
        } catch (e: Exception) {
            player.playing = false
            player.failed = "Tidak bisa memutar: ${e.javaClass.simpleName}"
        }
    }

    fun addZoom() {
        val added = ZoomOps.add(zooms, ZoomRegion(id = nextZoomId, startMs = 0L, endMs = 0L), player.positionMs, 5000L, durMs)
        if (added == null) {
            zoomMsg = "Tidak ada ruang kosong"
            showToast("Tidak ada ruang kosong")
        } else {
            val newId = nextZoomId
            zooms = added; selectedZoom = newId; nextZoomId++; zoomMsg = null
            showToast("Zoom ditambahkan")
            openTool(0)
            added.firstOrNull { it.id == newId }?.let { nr ->
                try { player.mp?.pause(); player.playing = false } catch (_: Exception) {}
                seek(nr.startMs.toFloat())
                areaEdit = true
            }
        }
    }

    /** Blok yang dimaksud tombol keyframe: yang dipilih, kalau tidak ada yang berisi playhead. */
    fun keyframeRegion(): ZoomRegion? {
        val pos = player.positionMs
        return zooms.firstOrNull { it.id == selectedZoom } ?: zooms.firstOrNull { pos >= it.startMs && pos <= it.endMs }
    }

    /** Keyframe yang sedang "aktif": yang dipilih, atau yang tepat di playhead (toleransi 150 ms). */
    fun activeKey(r: ZoomRegion): ZoomKey? {
        val pos = player.positionMs
        val ks = r.liveKeys()
        if (r.id == selectedZoom) ks.firstOrNull { it.tMs == selectedKey }?.let { return it }
        return ks.minByOrNull { kotlin.math.abs(it.tMs - pos) }?.takeIf { kotlin.math.abs(it.tMs - pos) <= 150L }
    }

    fun toggleKeyframe() {
        val r = keyframeRegion()
        if (r == null) { showToast("Pilih blok zoom atau taruh playhead di dalam blok"); return }
        val ex = activeKey(r)
        if (ex != null) {
            zooms = ZoomOps.update(zooms, r.id) { z -> z.copy(keys = z.keys.filter { it.tMs != ex.tMs }, auto = false) }
            selectedZoom = r.id; selectedKey = null
            showToast("Keyframe dihapus")
            return
        }
        val t = player.positionMs
        if (t < r.startMs + ZoomMath.KEY_GAP_MS || t > r.endMs - ZoomMath.KEY_GAP_MS) {
            showToast("Taruh playhead di dalam blok zoom")
            return
        }
        if (r.liveKeys().any { kotlin.math.abs(it.tMs - t) < ZoomMath.KEY_GAP_MS }) {
            showToast("Sudah ada keyframe di dekat sini")
            return
        }
        // keyframe baru mulai dari keadaan kamera saat itu, jadi gerakannya tidak melompat
        val st = ZoomMath.stateAt(r, t.toDouble())
        val k = ZoomKey(t, st.scale, st.fx, st.fy)
        zooms = ZoomOps.update(zooms, r.id) { z -> z.copy(keys = (z.keys + k).sortedBy { x -> x.tMs }, auto = false) }
        selectedZoom = r.id; selectedKey = t
        try { player.mp?.pause(); player.playing = false } catch (_: Exception) {}
        areaEdit = true
        showToast("Keyframe ditambahkan")
    }

    val doExport: () -> Unit = {
        try { player.mp?.pause(); player.playing = false } catch (_: Exception) {}
        val c = Exporter.Cancel()
        setCancel(c)
        exporting = true; progress = 0f; resultUri = null; error = null
        val st = style
        val zl = zooms
        val tl = cursorTrack
        val s = (startMs * 1000f).toLong()
        val e = (endMs * 1000f).toLong()
        scope.launch(Dispatchers.Default) {
            val out = Exporter.export(ctx, uri, s, e, st, zl, tl, c, { p -> progress = p }, { m -> error = m })
            withContext(Dispatchers.Main) {
                exporting = false
                resultUri = out
                if (out == null && error == null) error = "Ekspor dibatalkan"
            }
        }
    }

    // ---------------------------------------------------------------- bagian-bagian layar
    val title by produceState("Rekaman", uri) {
        value = withContext(Dispatchers.IO) { Library.nameOf(ctx, uri)?.substringBeforeLast('.') ?: "Rekaman" }
    }

    val topBar: @Composable () -> Unit = {
        Row(
            Modifier.fillMaxWidth().height(52.dp).padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Box(
                Modifier.size(40.dp).clip(CircleShape).background(cs.surfaceVariant).clickable(onClick = onBack),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali", tint = cs.onBackground, modifier = Modifier.size(20.dp))
            }
            Text(
                "$title  |  ${ASPECTS[aspectIdx].first}",
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            if (exporting) {
                Text("${(progress * 100).toInt()}%", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                Box(
                    Modifier.height(36.dp).clip(RoundedCornerShape(50)).background(cs.surfaceVariant)
                        .clickable { cancel?.requested = true }.padding(horizontal = 16.dp),
                    contentAlignment = Alignment.Center,
                ) { Text("Batal", style = MaterialTheme.typography.labelLarge, color = cs.onBackground) }
            } else {
                resultUri?.let { out ->
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(cs.surfaceVariant).clickable { Library.share(ctx, out) },
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Default.Share, contentDescription = "Bagikan", tint = cs.primary, modifier = Modifier.size(20.dp)) }
                }
                Box(
                    Modifier.height(36.dp).clip(RoundedCornerShape(50)).background(LayKitGradient.horizontal)
                        .clickable(onClick = doExport).padding(horizontal = 18.dp),
                    contentAlignment = Alignment.Center,
                ) { Text("Ekspor", style = MaterialTheme.typography.labelLarge, color = Color.White, fontWeight = FontWeight.SemiBold) }
            }
        }
        Box(Modifier.fillMaxWidth().height(3.dp)) {
            if (exporting) {
                Box(Modifier.fillMaxSize().background(cs.surfaceVariant))
                Box(Modifier.fillMaxHeight().fillMaxWidth(progress.coerceIn(0f, 1f)).background(LayKitGradient.horizontal))
            }
        }
    }

    val preview: @Composable () -> Unit = {
        FramePreview(
            uri, videoAspect, style, player, imgBmp, frameBmp, zooms,
            cursorTrack, { player.smoothMs },
            if (areaEdit) zooms.firstOrNull { it.id == selectedZoom }?.let { r ->
                val k = r.liveKeys().firstOrNull { it.tMs == selectedKey }
                if (k != null) r.copy(scale = k.scale, fx = k.fx, fy = k.fy) else r
            } else null,
        ) { fx, fy, sc ->
            selectedZoom?.let { id ->
                val kt = selectedKey
                val hasKey = kt != null && zooms.firstOrNull { it.id == id }?.liveKeys()?.any { it.tMs == kt } == true
                zooms = if (hasKey && kt != null) ZoomOps.updateKey(zooms, id, kt) { it.copy(fx = fx, fy = fy, scale = sc) }
                else ZoomOps.update(zooms, id) { it.copy(fx = fx, fy = fy, scale = sc, auto = false) }
            }
        }
    }

    val timeline: @Composable () -> Unit = {
        TimelineEditor(
            uri = uri,
            durMs = durMs,
            positionMs = player.positionMs,
            timeMs = { player.smoothMs },
            playing = player.playing,
            startMs = startMs,
            endMs = endMs,
            zooms = zooms,
            touches = touches,
            selectedId = selectedZoom,
            enabled = !exporting,
            onSeek = { seek(it.toFloat()) },
            // menggeser timeline saat diputar = jeda dulu, lalu scrub
            onScrubStart = { try { player.mp?.pause(); player.playing = false } catch (_: Exception) {} },
            onTrimStart = { v ->
                val s = v.coerceIn(0f, endMs - 500f)
                startMs = s; seek(s)
            },
            onTrimEnd = { v ->
                val e = v.coerceIn(startMs + 500f, durMs.toFloat())
                endMs = e; seek((e - 500f).coerceAtLeast(startMs))
            },
            selectedKey = selectedKey,
            onSelectKey = { id, t ->
                selectedZoom = id
                selectedKey = t
                // lompat ke waktu keyframe supaya pratinjau menampilkan keadaannya
                if (t != null) seek(t.toFloat())
            },
            onSelect = { id ->
                if (id != selectedZoom) selectedKey = null
                selectedZoom = id
                // di mode pilih area, pindah blok = lompat ke frame awal blok itu
                if (areaEdit) zooms.firstOrNull { it.id == id }?.let { seek(it.startMs.toFloat()) }
            },
            onZooms = { zooms = it },
            modifier = Modifier.fillMaxSize(),
        )
    }

    // Baris kontrol player, datar tanpa kartu: layar penuh + mute | Play | keyframe + undo + redo
    val playerCard: @Composable () -> Unit = {
        val dim = cs.onSurfaceVariant.copy(alpha = 0.35f)
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp).height(48.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.Start) {
                Box(Modifier.size(44.dp).clip(CircleShape).clickable { focus = !focus }, contentAlignment = Alignment.Center) {
                    ToolIcon(ICON_FULLSCREEN, if (focus) cs.primary else cs.onSurfaceVariant, 20.dp)
                }
                Box(Modifier.size(44.dp).clip(CircleShape).clickable { muted = !muted }, contentAlignment = Alignment.Center) {
                    ToolIcon(if (muted) ICON_VOLUME_OFF else ICON_VOLUME, if (muted) cs.primary else cs.onSurfaceVariant, 20.dp)
                }
            }
            Box(
                Modifier.size(48.dp).clip(CircleShape).clickable { togglePlay() },
                contentAlignment = Alignment.Center,
            ) { PlayPauseIcon(player.playing, cs.onBackground, 26.dp) }
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.End) {
                val kfReg = keyframeRegion()
                val kfOn = kfReg != null && activeKey(kfReg) != null
                Box(Modifier.size(44.dp).clip(CircleShape).clickable(enabled = !exporting) { toggleKeyframe() }, contentAlignment = Alignment.Center) {
                    KeyframeIcon(
                        kfOn,
                        if (kfReg == null || exporting) dim else if (kfOn) cs.primary else cs.onSurfaceVariant,
                        cs.background, 20.dp,
                    )
                }
                Box(Modifier.size(44.dp).clip(CircleShape).clickable(enabled = canUndo && !exporting) { undo() }, contentAlignment = Alignment.Center) {
                    ToolIcon(ICON_UNDO, if (canUndo) cs.onSurfaceVariant else dim, 20.dp)
                }
                Box(Modifier.size(44.dp).clip(CircleShape).clickable(enabled = canRedo && !exporting) { redo() }, contentAlignment = Alignment.Center) {
                    ToolIcon(ICON_REDO, if (canRedo) cs.onSurfaceVariant else dim, 20.dp)
                }
            }
        }
    }

    // Toolbar bawah: ikon + label. Saat satu tool dibuka, panelnya menutupi seluruh toolbar ini (lihat bottomSection).
    val toolbar: @Composable () -> Unit = {
        Column(Modifier.fillMaxWidth().background(cs.background)) {
            HorizontalDivider(color = cs.outlineVariant)
            Row(Modifier.fillMaxWidth().height(TOOLBAR_H)) {
                TOOLS.forEachIndexed { i, t ->
                    Column(
                        Modifier.weight(1f).fillMaxHeight().clickable { openTool(i) },
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                        ToolIcon(TOOL_ICONS[i], cs.onBackground, 22.dp)
                        Spacer(Modifier.height(3.dp))
                        Text(t, fontSize = 11.sp, color = cs.onBackground, maxLines = 1)
                    }
                }
            }
        }
    }

    fun pct(v: Float, r: ClosedFloatingPointRange<Float>): String =
        (((v - r.start) / (r.endInclusive - r.start)) * 100f + 0.5f).toInt().toString()

    // Panel tool: header tab + centang, isi per tab. Menggantikan toolbar (menutupinya penuh) dan bagian bawah timeline.
    val panel: @Composable (Dp) -> Unit = { panelH ->
        val tabs = TOOL_TABS[tool]
        val tabSel = if (tool == 1) bgUi else toolTab.coerceIn(0, tabs.size - 1)
        Column(
            Modifier.fillMaxWidth().height(panelH)
                .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                .background(cs.surfaceContainerHighest)
                .pointerInput(Unit) { detectTapGestures { } },   // telan ketukan supaya tidak tembus ke bawah
        ) {
            PanelTabs(tabs, tabSel, { i -> if (tool == 1) bgUi = i else toolTab = i }, { tool = -1 })
            Column(
                Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp).padding(bottom = 8.dp),
            ) {
                val sel = zooms.firstOrNull { it.id == selectedZoom }
                when (tool) {
                    0 -> when (toolTab) {
                        // ---- Blok: aksi pada blok zoom ----
                        0 -> Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                ActionCard(ICON_AUTO, "Auto-zoom", enabled = !exporting && touches.isNotEmpty()) {
                                    val auto = AutoZoom.build(touches, durMs)
                                    zooms = auto
                                    nextZoomId = (auto.maxOfOrNull { it.id } ?: 0) + 1
                                    selectedZoom = null; selectedKey = null
                                    zoomMsg = if (auto.isEmpty()) "Ketukan terlalu sedikit" else null
                                    if (auto.isNotEmpty()) showToast("Auto-zoom dibuat")
                                }
                                ActionCard(ICON_PLUS, "Tambah", enabled = !exporting) { addZoom() }
                                ActionCard(ICON_TRASH, "Hapus", enabled = !exporting && selectedZoom != null) {
                                    selectedZoom?.let { zooms = ZoomOps.remove(zooms, it); selectedZoom = null; selectedKey = null; areaEdit = false; showToast("Zoom dihapus") }
                                }
                                ActionCard(ICON_AREA, if (areaEdit) "Selesai" else "Pilih area", selected = areaEdit, enabled = !exporting && selectedZoom != null) {
                                    if (areaEdit) areaEdit = false
                                    else zooms.firstOrNull { it.id == selectedZoom }?.let { sr ->
                                        // jeda dan lompat ke awal blok, supaya yang dipilih adalah frame yang akan di-zoom
                                        try { player.mp?.pause(); player.playing = false } catch (_: Exception) {}
                                        seek((sr.liveKeys().firstOrNull { it.tMs == selectedKey }?.tMs ?: sr.startMs).toFloat())
                                        areaEdit = true
                                    }
                                }
                            }
                            zoomMsg?.let { Text(it, fontSize = 12.sp, color = cs.onSurfaceVariant) }
                        }

                        // ---- Atur: skala dan titik sorot (satu slider, parameter dipilih lewat lingkaran) ----
                        1 -> if (sel == null) PanelHint("Pilih blok zoom di timeline untuk mengatur skala dan titik sorotnya.") else {
                            val selK = sel.liveKeys().firstOrNull { it.tMs == selectedKey }
                            val sc = selK?.scale ?: sel.scale
                            val fx = selK?.fx ?: sel.fx
                            val fy = selK?.fy ?: sel.fy
                            val setParam: (Int, Float) -> Unit = { p, v ->
                                zooms = if (selK != null) ZoomOps.updateKey(zooms, sel.id, selK.tMs) {
                                    when (p) { 0 -> it.copy(scale = v); 1 -> it.copy(fx = v); else -> it.copy(fy = v) }
                                } else ZoomOps.update(zooms, sel.id) {
                                    when (p) { 0 -> it.copy(scale = v, auto = false); 1 -> it.copy(fx = v, auto = false); else -> it.copy(fy = v, auto = false) }
                                }
                            }
                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    ParamCircle("Skala", "%.1f×".format(sc), zParam == 0) { zParam = 0 }
                                    ParamCircle("Posisi X", "%.2f".format(fx), zParam == 1) { zParam = 1 }
                                    ParamCircle("Posisi Y", "%.2f".format(fy), zParam == 2) { zParam = 2 }
                                }
                                val cur = when (zParam) { 0 -> sc; 1 -> fx; else -> fy }
                                val range = when (zParam) {
                                    0 -> ZoomMath.MIN_SCALE..ZoomMath.MAX_SCALE
                                    else -> ZoomMath.FOCUS_MIN..ZoomMath.FOCUS_MAX
                                }
                                FlatSlider(cur, { setParam(zParam, it) }, range, !exporting)
                                if (selK != null) Text("Keyframe di ${Library.fmtTime(selK.tMs)}", fontSize = 12.sp, color = cs.onSurfaceVariant)
                            }
                        }

                        // ---- 3D: kamera miring per blok ----
                        2 -> if (sel == null) PanelHint("Pilih blok zoom di timeline untuk mengatur kamera 3D-nya.") else {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Seg(
                                    listOf("3D mati" to Cam.OFF, "Kiri" to Cam.LEFT, "Kanan" to Cam.RIGHT, "Orbit" to Cam.ORBIT),
                                    sel.cam, !exporting,
                                ) { c -> zooms = ZoomOps.update(zooms, sel.id) { it.copy(cam = c) } }
                                Text("Bingkai video dimiringkan saat zoom di blok ini.", fontSize = 12.sp, color = cs.onSurfaceVariant)
                            }
                        }

                        // ---- Kurva animasi zoom ----
                        else -> CurvePanel(
                            sel = sel,
                            enabled = !exporting,
                            onCurve = { c -> selectedZoom?.let { id -> zooms = ZoomOps.update(zooms, id) { it.copy(curve = c) } } },
                            onApplyAll = { c -> zooms = zooms.map { it.copy(curve = c) } },
                        )
                    }

                    1 -> when (bgUi) {
                        0 -> Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            PRESETS.forEachIndexed { i, (a, b) ->
                                Swatch(Brush.verticalGradient(listOf(Color(a), Color(b))), i == preset, !exporting) { preset = i }
                            }
                        }
                        1 -> Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            SOLIDS.forEachIndexed { i, c ->
                                Swatch(Brush.verticalGradient(listOf(Color(c), Color(c))), i == solid, !exporting) { solid = i }
                            }
                        }
                        2 -> Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            WALLS.forEachIndexed { i, w ->
                                Swatch(Brush.linearGradient(listOf(Color(w.first), Color(w.second), Color(w.third))), i == wall, !exporting) { wall = i }
                            }
                        }
                        3 -> Row(
                            Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            ActionCard(ICON_PLUS, "Galeri", enabled = !exporting) {
                                pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            }
                            for (n in 1..WALLPAPER_COUNT) {
                                val u = wallpaperUri(ctx, n)
                                WallThumb(ctx, u, imageUri == u, !exporting) { imageUri = u }
                            }
                        }
                        else -> Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text("Tingkat blur  ${pct(blurAmt, 0.01f..0.08f)}", fontSize = 12.sp, color = cs.onSurfaceVariant)
                            FlatSlider(blurAmt, { blurAmt = it }, 0.01f..0.08f, !exporting)
                        }
                    }

                    2 -> when (toolTab) {
                        0 -> Column {
                            TickSlider("Jarak", padding, 0f..0.25f, pct(padding, 0f..0.25f), !exporting) { padding = it }
                            TickSlider("Sudut", corner, 0f..0.10f, pct(corner, 0f..0.10f), !exporting) { corner = it }
                            ResetLink(enabled = !exporting && (padding != 0.08f || corner != 0.03f)) { padding = 0.08f; corner = 0.03f }
                        }
                        1 -> Column {
                            ToggleRow("Bayangan", shadow, !exporting) { shadow = it }
                            TickSlider("Jumlah", shadowAmt, 0f..1f, pct(shadowAmt, 0f..1f), !exporting && shadow) { shadowAmt = it }
                        }
                        else -> ToggleRow(
                            "Kursor sintetis", cursorOn, !exporting,
                            note = if (cursorOn && cursorTrack.isEmpty()) "Butuh data ketukan atau blok zoom." else null,
                        ) { cursorOn = it }
                    }

                    else -> Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ASPECTS.forEachIndexed { i, (label, r) -> AspectCard(label, r, aspectIdx == i, !exporting) { aspectIdx = i } }
                    }
                }
            }
        }
    }

    // Area bawah: timeline (menempel di atas) + toolbar. Panel tool menutupi bagian bawah area ini, termasuk toolbar,
    // tapi ruler + baris video tetap terlihat (untuk Zoom: baris zoom juga), jadi playhead tetap bisa digeser.
    val bottomSection: @Composable (Modifier) -> Unit = { mod ->
        Box(mod.onSizeChanged { bottomH = it.height }) {
            Column(Modifier.fillMaxSize()) {
                Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp)) { timeline() }
                toolbar()
            }
            if (tool in TOOLS.indices) {
                val keep = if (tool == 0) TL_ROWS_ZOOM else TL_ROWS_TOP
                val h = (with(LocalDensity.current) { bottomH.toDp() } - keep).coerceAtLeast(150.dp)
                Box(Modifier.align(Alignment.BottomCenter)) { panel(h) }
            }
        }
    }

    val toastChip: @Composable () -> Unit = {
        toast?.let { m ->
            Box(
                Modifier.clip(RoundedCornerShape(50)).background(cs.surfaceContainerHighest.copy(alpha = 0.92f))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            ) { Text(m, style = MaterialTheme.typography.labelMedium, color = cs.onBackground, maxLines = 1) }
        }
    }

    val errorChip: @Composable () -> Unit = {
        (error ?: player.failed)?.let { m ->
            Box(
                Modifier.clip(RoundedCornerShape(50)).background(cs.surfaceContainerHighest.copy(alpha = 0.92f))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            ) { Text(m, style = MaterialTheme.typography.labelMedium, color = cs.error, maxLines = 1, overflow = TextOverflow.Ellipsis) }
        }
    }

    // Kanvas dan baris player TERKUNCI: ukuran dan posisinya tidak bergantung pada panel yang dibuka.
    // Area bawah punya tinggi tetap di potret; panel tool hanya menimpa isinya (lihat bottomSection).
    BoxWithConstraints(modifier) {
        val land = maxWidth > maxHeight
        Column(Modifier.fillMaxSize()) {
            topBar()
            if (land) {
                Row(Modifier.weight(1f).fillMaxWidth()) {
                    Column(Modifier.weight(if (focus) 1f else 0.42f).fillMaxHeight()) {
                        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { preview() }
                            Box(Modifier.align(Alignment.BottomStart).padding(8.dp)) { toastChip() }
                            Box(Modifier.align(Alignment.TopCenter).padding(8.dp)) { errorChip() }
                        }
                        playerCard()
                    }
                    if (!focus) bottomSection(Modifier.weight(0.58f).fillMaxHeight())
                }
            } else {
                Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp)) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { preview() }
                    Box(Modifier.align(Alignment.BottomStart).padding(8.dp)) { toastChip() }
                    Box(Modifier.align(Alignment.TopCenter).padding(8.dp)) { errorChip() }
                }
                playerCard()
                if (!focus) bottomSection(Modifier.fillMaxWidth().height(TL_AREA + TOOLBAR_H + 1.dp))
            }
        }
    }
}

/** Pratinjau: kanvas berlatar + video dengan padding/sudut/bayangan (perkiraan dari hasil ekspor). */
@Composable
private fun FramePreview(
    uri: Uri, videoAspect: Float, style: FrameStyle, player: PlayerState, img: Bitmap?, frame: Bitmap?, zooms: List<ZoomRegion>,
    cursorTrack: List<TouchEvent>, timeMs: () -> Float,
    editRegion: ZoomRegion?, onEdit: (fx: Float, fy: Float, scale: Float) -> Unit,
) {
    val canvasAspect = style.aspect ?: videoAspect
    BoxWithConstraints(Modifier.aspectRatio(canvasAspect).clip(RoundedCornerShape(12.dp)).clipToBounds()) {
        BackgroundLayer(style, img, frame)
        val short = min(maxWidth, maxHeight)
        val pad = short * style.padding
        val shape = RoundedCornerShape(short * style.corner)
        // ukuran kanvas (px): diambil di sini, karena `constraints` tidak bisa dipanggil dari lambda graphicsLayer (beda scope)
        val cw = constraints.maxWidth.toFloat()
        val ch = constraints.maxHeight.toFloat()
        // ukuran kartu video (px) untuk pemilih area: kartu muat di dalam kanvas dikurangi padding, rasio = rasio video
        val padPx = with(LocalDensity.current) { pad.toPx() }
        val availW = (cw - 2f * padPx).coerceAtLeast(1f)
        val availH = (ch - 2f * padPx).coerceAtLeast(1f)
        val cardW = if (availW / availH > videoAspect) availH * videoAspect else availW
        val cardH = cardW / videoAspect
        Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.Center) {
            Box(
                Modifier.aspectRatio(videoAspect)
                    .graphicsLayer {
                        // zoom kartu: seluruh bingkai dibesarkan dari pojok kiri-atasnya lalu digeser (rumus sama dengan ekspor)
                        // timeMs() dibaca DI SINI (fase layer): tiap frame hanya layer yang dihitung ulang, bukan seluruh UI
                        val hw = this.size.width / 2f; val hh = this.size.height / 2f
                        val cz = if (editRegion != null) CardZoom.NONE else ZoomMath.camera(zooms, timeMs().toDouble(), CardGeo(cw, ch, cw / 2f, ch / 2f, hw, hh))
                        transformOrigin = TransformOrigin(0f, 0f)
                        scaleX = cz.s
                        scaleY = cz.s
                        translationX = (cz.s - 1f) * (cw / 2f - hw) + cz.tx
                        translationY = (cz.s - 1f) * (ch / 2f - hh) + cz.ty
                    }
                    .graphicsLayer {
                        // kamera 3D: SAMA dengan shader ekspor (uRot/uPers/uOff). Titik bidang p = fit * s * (titik kartu) jatuh di
                        // P * (R p + (o, 0)).xy / (P - (R p).z), R = Rx(pitch) Ry(yaw) Rz(roll). Satuan layer ini = px kartu SEBELUM zoom,
                        // jadi P dan o dibagi s (zoom di layer luar menskala semuanya sama).
                        // graphicsLayer: rotationX/Y/Z = pitch/yaw/roll, scale lebih dulu dari rotasi, cameraDistance = P / 72 (lihat Cam).
                        // Offset kamera nyata (o) bekerja SEBELUM pembagian perspektif, sedangkan translation graphicsLayer sesudahnya:
                        // dibuat dengan menggeser PIVOT (Cam.layerFit), identik secara aljabar.
                        val hw = this.size.width / 2f; val hh = this.size.height / 2f
                        val cz = if (editRegion != null) CardZoom.NONE else ZoomMath.camera(zooms, timeMs().toDouble(), CardGeo(cw, ch, cw / 2f, ch / 2f, hw, hh), if (style.cursor) cursorTrack else emptyList())
                        if (cz.tilted) {
                            val pl = (if (cz.persp > 0f) cz.persp else Cam.perspectivePx(2f * hw * cz.s, 2f * hh * cz.s)) / cz.s
                            val lf = Cam.layerFit(cz.rot, pl, cz.ox / cz.s, cz.oy / cz.s)
                            val pvx = lf.cx / cz.fit; val pvy = lf.cy / cz.fit      // pivot, px kartu relatif pusat
                            rotationX = cz.pitchDeg
                            rotationY = cz.yawDeg
                            rotationZ = cz.rollDeg
                            scaleX = cz.fit * lf.sigma
                            scaleY = cz.fit * lf.sigma
                            transformOrigin = TransformOrigin(0.5f + pvx / this.size.width, 0.5f + pvy / this.size.height)
                            translationX = -pvx
                            translationY = -pvy
                            cameraDistance = pl / Cam.ANDROID_CAMERA_UNIT
                        }
                    }
                    .then(if (style.shadow && style.shadowAmt > 0f) Modifier.shadow(
                        short * (0.08f * style.shadowAmt), shape,
                        ambientColor = Color.Black.copy(alpha = (style.shadowAmt * 2f).coerceAtMost(1f)),
                        spotColor = Color.Black.copy(alpha = (style.shadowAmt * 2f).coerceAtMost(1f)),
                    ) else Modifier)
                    .clip(shape),
            ) {
                // Bingkai di atas sudah clip(shape) dan ikut dibesarkan bersama isinya (zoom kartu, bukan crop isi video).
                VideoSurface(player, Modifier.fillMaxSize())
                // kursor sintetis: di dalam bingkai yang sama, jadi ikut terpotong dan ikut miring (kamera 3D)
                if (style.cursor) Canvas(Modifier.fillMaxSize()) {
                    CursorMath.at(cursorTrack, timeMs().toLong())?.let { drawCursor(it) }
                }
            }
        }
        // pemilih area zoom: di atas SELURUH kanvas (bukan hanya kartu), kartu tampil tanpa zoom.
        // Jendela boleh keluar dari kartu ke area background.
        if (editRegion != null) ZoomAreaOverlay(editRegion, CardGeo(cw, ch, cw / 2f, ch / 2f, cardW / 2f, cardH / 2f), onEdit)
    }
}

@Composable
private fun BackgroundLayer(style: FrameStyle, img: Bitmap?, frame: Bitmap?) {
    when {
        style.bgType == 2 && img != null ->
            Image(img.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        style.bgType == 3 && frame != null ->
            Image(frame.asImageBitmap(), null, Modifier.fillMaxSize().blur(24.dp), contentScale = ContentScale.Crop)
        style.bgType == 1 ->
            Box(
                Modifier.fillMaxSize().drawBehind {
                    drawRect(Color(style.top))
                    val r = size.maxDimension * 0.95f
                    drawRect(Brush.radialGradient(listOf(Color(style.mid), Color.Transparent),
                        center = Offset(size.width * 0.15f, size.height * 0.15f), radius = r))
                    drawRect(Brush.radialGradient(listOf(Color(style.bottom), Color.Transparent),
                        center = Offset(size.width * 0.85f, size.height * 0.85f), radius = r))
                },
            )
        else ->
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(style.top), Color(style.bottom)))))
    }
}

@Composable
private fun Swatch(brush: Brush, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(46.dp).clip(CircleShape)
            .background(brush)
            .then(if (selected) Modifier.border(3.dp, MaterialTheme.colorScheme.primary, CircleShape)
                  else Modifier.border(1.dp, Color.Gray.copy(alpha = 0.5f), CircleShape))
            .clickable(enabled = enabled, onClick = onClick),
    )
}

@Composable
private fun VideoSurface(state: PlayerState, modifier: Modifier) {
    AndroidView(
        modifier = modifier,
        factory = { c ->
            TextureView(c).apply {
                surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                        state.attach(Surface(st))
                    }

                    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}

                    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                        // pemutar TIDAK dibuang, hanya dilepas dari surface; surface baru dipasang saat tersedia lagi
                        state.detach()
                        return true
                    }

                    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
                }
            }
        },
    )
}
