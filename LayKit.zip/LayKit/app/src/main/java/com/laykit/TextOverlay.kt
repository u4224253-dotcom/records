package com.laykit

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Satu teks bebas di atas kanvas (berbeda dari caption: posisinya bisa digeser ke mana saja, bukan pita tetap di dasar).
 * [xFrac]/[yFrac] = posisi TITIK TENGAH teks relatif kartu video (0..1, (0,0) kiri-atas). [sizeFrac] = ukuran huruf (0..1).
 */
internal data class TextOverlay(val id: Long, val text: String, val xFrac: Float = 0.5f, val yFrac: Float = 0.5f, val sizeFrac: Float = 0.3f)

/**
 * Gambar teks bebas: putih tebal dengan bayangan lembut supaya terbaca di latar apa pun, tanpa kotak latar (beda dari
 * Captions.renderBand). Bitmap dipotong pas dengan teksnya (bukan selebar kanvas), dipakai apa adanya oleh pratinjau dan
 * ekspor (tekstur GL) supaya identik.
 */
internal object TextOverlays {
    private const val SIZE_MIN = 0.02f   // ukuran huruf = fraksi sisi terpendek kanvas, pada sizeFrac 0
    private const val SIZE_MAX = 0.12f   // pada sizeFrac 1

    fun pxSize(canvasW: Int, canvasH: Int, sizeFrac: Float): Float =
        min(canvasW, canvasH) * (SIZE_MIN + (SIZE_MAX - SIZE_MIN) * sizeFrac.coerceIn(0f, 1f))

    fun render(text: String, canvasW: Int, canvasH: Int, sizeFrac: Float): Bitmap {
        val t = text.ifBlank { " " }
        val textPx = pxSize(canvasW, canvasH, sizeFrac)
        val tp = TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = textPx
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            setShadowLayer(textPx * 0.18f, 0f, textPx * 0.04f, 0x99000000.toInt())
        }
        val maxW = max(1, (canvasW * 0.92f).toInt())
        val layout = StaticLayout.Builder.obtain(t, 0, t.length, tp, maxW)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setIncludePad(false)
            .build()
        var lineMax = 0f
        for (i in 0 until layout.lineCount) lineMax = max(lineMax, layout.getLineWidth(i))
        val padX = textPx * 0.3f   // ruang ekstra supaya bayangan (shadow layer) tidak terpotong di tepi bitmap
        val padY = textPx * 0.3f
        val w = max(1, (lineMax + 2f * padX).roundToInt())
        val h = max(1, (layout.height + 2f * padY).roundToInt())
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.translate(padX, padY)
        layout.draw(c)
        return bmp
    }
}
