package com.laykit

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.content.Context
import android.graphics.Typeface
import androidx.core.content.res.ResourcesCompat
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Satu teks bebas di atas kanvas (berbeda dari caption: posisinya bisa digeser ke mana saja, bukan pita tetap di dasar).
 * [font] = indeks pilihan font ([TextOverlays.FONT_NAMES]; 0 = bawaan sistem).
 * [xFrac]/[yFrac] = posisi TITIK TENGAH teks relatif kartu video (0..1, (0,0) kiri-atas). [sizeFrac] = ukuran huruf (0..1).
 */
data class TextOverlay(val id: Long, val text: String, val xFrac: Float = 0.5f, val yFrac: Float = 0.5f, val sizeFrac: Float = 0.3f, val font: Int = 0)

/**
 * Gambar teks bebas: putih tebal dengan bayangan lembut supaya terbaca di latar apa pun, tanpa kotak latar (beda dari
 * Captions.renderBand). Bitmap dipotong pas dengan teksnya (bukan selebar kanvas), dipakai apa adanya oleh pratinjau dan
 * ekspor (tekstur GL) supaya identik.
 */
internal object TextOverlays {
    private const val SIZE_MIN = 0.02f   // ukuran huruf = fraksi sisi terpendek kanvas, pada sizeFrac 0
    private const val SIZE_MAX = 0.12f   // pada sizeFrac 1

    /** Nama pilihan font (urutan = nilai [TextOverlay.font]). Indeks 1 dan 2 memakai berkas di res/font. */
    val FONT_NAMES = listOf("Bawaan", "Eurostile Extended Black", "Microgramma Bold Extended")

    @Volatile private var appCtx: Context? = null
    private val tfCache = HashMap<Int, Typeface>()

    /** Dipanggil sekali (editor dan ekspor) supaya font dari res/font bisa dimuat tanpa Context di tiap pemanggilan. */
    fun init(ctx: Context) { appCtx = ctx.applicationContext }

    /** Font res untuk [font]; null berarti pakai font sistem. Font kustom sudah tebal, jadi tidak diberi bold lagi. */
    fun fontRes(font: Int): Int? = when (font) {
        1 -> R.font.eurostile_extended_black
        2 -> R.font.microgramma_bold_extended
        else -> null
    }

    fun typeface(font: Int): Typeface = synchronized(tfCache) {
        tfCache.getOrPut(font) {
            val res = fontRes(font)
            val c = appCtx
            (if (res != null && c != null) runCatching { ResourcesCompat.getFont(c, res) }.getOrNull() else null)
                ?: Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
    }

    fun pxSize(canvasW: Int, canvasH: Int, sizeFrac: Float): Float =
        min(canvasW, canvasH) * (SIZE_MIN + (SIZE_MAX - SIZE_MIN) * sizeFrac.coerceIn(0f, 1f))

    /** Radius glow teks (px) untuk ukuran huruf [textPx]; dipakai bitmap ekspor dan pratinjau supaya sama. */
    fun glowRadius(textPx: Float, glow: Float, glowSize: Float): Float =
        textPx * (0.15f + 0.6f * glowSize.coerceIn(0f, 1f)) * (0.5f + glow.coerceIn(0f, 1f))

    /** Alpha (0..1) warna glow putih. */
    fun glowAlpha(glow: Float): Float = 0.35f + 0.65f * glow.coerceIn(0f, 1f)

    fun render(text: String, canvasW: Int, canvasH: Int, sizeFrac: Float, font: Int = 0, glow: Float = 0f, glowSize: Float = 0.5f): Bitmap {
        val t = text.ifBlank { " " }
        val textPx = pxSize(canvasW, canvasH, sizeFrac)
        val glowOn = glow > 0f
        val gr = if (glowOn) glowRadius(textPx, glow, glowSize) else 0f
        fun paint(shadow: Boolean, asGlow: Boolean) = TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = textPx
            typeface = typeface(font)
            if (asGlow) setShadowLayer(gr, 0f, 0f, ((glowAlpha(glow) * 255).toInt() shl 24) or 0x00FFFFFF)
            else if (shadow) setShadowLayer(textPx * 0.18f, 0f, textPx * 0.04f, 0x99000000.toInt())
        }
        val maxW = max(1, (canvasW * 0.92f).toInt())
        fun layoutOf(tp: TextPaint) = StaticLayout.Builder.obtain(t, 0, t.length, tp, maxW)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setIncludePad(false)
            .build()
        val layout = layoutOf(paint(shadow = !glowOn, asGlow = false))
        var lineMax = 0f
        for (i in 0 until layout.lineCount) lineMax = max(lineMax, layout.getLineWidth(i))
        val pad = max(textPx * 0.3f, gr * 1.3f)   // ruang ekstra supaya bayangan / glow tidak terpotong di tepi bitmap
        val w = max(1, (lineMax + 2f * pad).roundToInt())
        val h = max(1, (layout.height + 2f * pad).roundToInt())
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.translate(pad, pad)
        if (glowOn) {
            val gl = layoutOf(paint(shadow = false, asGlow = true))
            gl.draw(c); gl.draw(c)   // dua kali supaya halo cukup terang
        }
        layout.draw(c)
        return bmp
    }
}
