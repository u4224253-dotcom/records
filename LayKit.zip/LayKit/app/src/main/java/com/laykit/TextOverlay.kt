package com.laykit

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Typeface
import androidx.core.content.res.ResourcesCompat
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Satu teks bebas di atas kanvas (berbeda dari caption: posisinya bisa digeser ke mana saja, bukan pita tetap di dasar).
 * [color] = warna huruf (ARGB); glow teks otomatis mengikuti warna ini.
 * [font] = indeks pilihan font ([TextOverlays.FONT_NAMES]; 0 = bawaan sistem).
 * [xFrac]/[yFrac] = posisi TITIK TENGAH teks relatif kartu video (0..1, (0,0) kiri-atas). [sizeFrac] = ukuran huruf (0..1).
 */
data class TextOverlay(val id: Long, val text: String, val xFrac: Float = 0.5f, val yFrac: Float = 0.5f, val sizeFrac: Float = 0.3f, val font: Int = 0, val color: Int = 0xFFFFFFFF.toInt())

/**
 * Gambar teks bebas: putih tebal dengan bayangan lembut supaya terbaca di latar apa pun, tanpa kotak latar (beda dari
 * Captions.renderBand). Bitmap dipotong pas dengan teksnya (bukan selebar kanvas), dipakai apa adanya oleh pratinjau dan
 * ekspor (tekstur GL) supaya identik.
 */
internal object TextOverlays {
    private const val SIZE_MIN = 0.02f   // ukuran huruf = fraksi sisi terpendek kanvas, pada sizeFrac 0
    private const val SIZE_MAX = 0.12f   // pada sizeFrac 1

    /** Nama pilihan font (urutan = nilai [TextOverlay.font]). Indeks 1 dan 2 memakai berkas di res/font. */
    val FONT_NAMES = listOf("Bawaan", "Eurostile Extended Black", "Microgramma Bold Extended")

    @Volatile private var appCtx: Context? = null
    private val tfCache = HashMap<Int, Typeface>()

    /** Dipanggil sekali (editor dan ekspor) supaya font dari res/font bisa dimuat tanpa Context di tiap pemanggilan. */
    fun init(ctx: Context) { appCtx = ctx.applicationContext }

    /** Font res untuk [font]; null berarti pakai font sistem. Font kustom sudah tebal, jadi tidak diberi bold lagi. */
    fun fontRes(font: Int): Int? = when (font) {
        1 -> R.font.eurostile_extended_black
        2 -> R.font.microgramma_bold_extended
        else -> null
    }

    fun typeface(font: Int): Typeface = synchronized(tfCache) {
        tfCache.getOrPut(font) {
            val res = fontRes(font)
            val c = appCtx
            (if (res != null && c != null) runCatching { ResourcesCompat.getFont(c, res) }.getOrNull() else null)
                ?: Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
    }

    fun pxSize(canvasW: Int, canvasH: Int, sizeFrac: Float): Float =
        min(canvasW, canvasH) * (SIZE_MIN + (SIZE_MAX - SIZE_MIN) * sizeFrac.coerceIn(0f, 1f))

    /** Radius glow teks (px) untuk ukuran huruf [textPx]; dipakai bitmap ekspor dan pratinjau supaya sama. */
    fun glowRadius(textPx: Float, glow: Float, glowSize: Float): Float =
        textPx * (0.15f + 0.6f * glowSize.coerceIn(0f, 1f)) * (0.5f + glow.coerceIn(0f, 1f))

    /** Alpha (0..1) warna glow putih. */
    fun glowAlpha(glow: Float): Float = 0.35f + 0.65f * glow.coerceIn(0f, 1f)

    /** Campur [color] ke arah putih sebanyak [t] (0..1), dipakai untuk inti huruf yang "panas" saat glow menyala. */
    private fun towardWhite(color: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        fun ch(v: Int) = (v + (255 - v) * k).toInt().coerceIn(0, 255)
        return (Color.alpha(color) shl 24) or (ch(Color.red(color)) shl 16) or (ch(Color.green(color)) shl 8) or ch(Color.blue(color))
    }

    /**
     * [glow] = terang cahaya, [glowSize] = sebaran cahaya, [glowThick] = ketebalan (garis tepi huruf ikut bercahaya, jadi cahaya
     * lebih padat di dekat huruf). Warna cahaya = [color].
     *
     * Ini glow sungguhan (bukan bayangan): cahaya adalah salinan huruf yang DIBLUR dan DIJUMLAHKAN (PorterDuff.ADD), jadi makin
     * dekat huruf makin terang dan saling menumpuk. Urutan gambar: (1) halo lebar + sedang di belakang, (2) huruf dengan inti
     * yang digeser ke putih, (3) lapisan cahaya rapat DI ATAS huruf, supaya huruf sendiri tampak menyala dari depan.
     */
    fun render(
        text: String, canvasW: Int, canvasH: Int, sizeFrac: Float, font: Int = 0, color: Int = Color.WHITE,
        glow: Float = 0f, glowSize: Float = 0.5f, glowThick: Float = 0.3f,
    ): Bitmap {
        val t = text.ifBlank { " " }
        val textPx = pxSize(canvasW, canvasH, sizeFrac)
        val glowOn = glow > 0f
        val g = glow.coerceIn(0f, 1f)
        val gr = if (glowOn) glowRadius(textPx, glow, glowSize) else 0f
        val rgb = color and 0x00FFFFFF
        val strokeW = textPx * 0.16f * glowThick.coerceIn(0f, 1f)

        fun basePaint(c: Int): TextPaint = TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            this.color = c
            textSize = textPx
            typeface = typeface(font)
        }
        // lapisan cahaya: salinan huruf diblur, digambar dengan mode ADD
        fun glowPaint(radiusPx: Float, a: Float): TextPaint = basePaint(((a.coerceIn(0f, 1f) * 255).toInt() shl 24) or rgb).apply {
            style = android.graphics.Paint.Style.FILL_AND_STROKE
            strokeWidth = strokeW
            strokeJoin = android.graphics.Paint.Join.ROUND
            maskFilter = BlurMaskFilter(max(radiusPx, 1f), BlurMaskFilter.Blur.NORMAL)
            xfermode = PorterDuffXfermode(PorterDuff.Mode.ADD)
        }
        // huruf utama: tanpa glow = putih/warna + bayangan tipis; dengan glow = inti digeser ke putih
        fun facePaint(): TextPaint = basePaint(if (glowOn) towardWhite(color, 0.25f * g) else color).apply {
            if (glowOn) {
                style = android.graphics.Paint.Style.FILL_AND_STROKE
                strokeWidth = strokeW * 0.5f
                strokeJoin = android.graphics.Paint.Join.ROUND
            } else setShadowLayer(textPx * 0.18f, 0f, textPx * 0.04f, 0x99000000.toInt())
        }

        val maxW = max(1, (canvasW * 0.92f).toInt())
        fun layoutOf(tp: TextPaint, width: Int) = StaticLayout.Builder.obtain(t, 0, t.length, tp, width)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setIncludePad(false)
            .build()
        // Ukur dulu pada lebar maksimum, lalu bangun ulang layout dengan lebar PAS teks. Kalau layout tetap selebar maxW,
        // ALIGN_CENTER menggeser teks ke tengah maxW sementara bitmap hanya selebar teks + pad, jadi sisi kanan terpotong.
        val measure = layoutOf(facePaint(), maxW)
        var lineMax = 0f
        for (i in 0 until measure.lineCount) lineMax = max(lineMax, measure.getLineWidth(i))
        val layoutW = max(1, kotlin.math.ceil(lineMax + strokeW).toInt())
        val layout = layoutOf(facePaint(), layoutW)
        val pad = max(textPx * 0.3f, gr * 1.5f + strokeW)   // ruang ekstra supaya cahaya tidak terpotong di tepi bitmap
        val w = max(1, (layoutW + 2f * pad).roundToInt())
        val h = max(1, (layout.height + 2f * pad).roundToInt())
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.translate(pad, pad)
        if (glowOn) {
            val a = glowAlpha(glow)
            // (1) halo di belakang huruf: lebar-redup dulu, lalu sedang
            for ((rf, af) in listOf(1.0f to 0.55f, 0.55f to 0.8f)) {
                layoutOf(glowPaint(gr * rf, a * af), layoutW).draw(c)
            }
            // (2) huruf
            layout.draw(c)
            // (3) cahaya rapat DI ATAS huruf: huruf ikut menyala dari depan, tepinya paling terang
            layoutOf(glowPaint(max(textPx * 0.03f, gr * 0.18f), a * 0.9f * (0.5f + 0.5f * g)), layoutW).draw(c)
        } else {
            layout.draw(c)
        }
        return bmp
    }
}
