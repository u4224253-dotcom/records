package com.laykit

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.CancellationException
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sign
import kotlin.math.tanh

/**
 * Sumber PCM streaming untuk mixer: decode trek audio pertama dari [uri] mulai dari [seekUs] (waktu berkas),
 * keluarannya selalu stereo float pada laju [outRate]. Tidak memuat seluruh audio ke memori: hanya satu-dua buffer decoder.
 * Kalau berkas tidak punya trek audio, [silent] = true dan [read] selalu mengembalikan 0.
 */
internal class PcmStream(ctx: Context, uri: Uri, private val seekUs: Long, private val outRate: Int) {
    private val ex = MediaExtractor()
    private var codec: MediaCodec? = null
    var silent = false
        private set
    private var inRate = outRate
    private var inCh = 2
    private var floatPcm = false
    private var inDone = false
    private var outDone = false
    private var dropFrames = -1L          // -1 = belum ditentukan (diputuskan pada buffer keluaran pertama)
    private val info = MediaCodec.BufferInfo()
    private var buf = FloatArray(1 shl 14)   // frame stereo pada laju asli, belum dikonsumsi
    private var bufFrames = 0
    private var srcPos = 0.0                 // posisi baca (pecahan frame) di dalam buf

    init {
        try {
            ex.setDataSource(ctx, uri, null)
            var track = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { track = i; fmt = f; break }
            }
            if (track < 0 || fmt == null) {
                silent = true
            } else {
                ex.selectTrack(track)
                if (seekUs > 0L) ex.seekTo(seekUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
                inRate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                inCh = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                val c = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
                codec = c
                c.configure(fmt, null, null, 0)
                c.start()
            }
        } catch (e: Exception) {
            close()
            throw e
        }
    }

    /** Isi [dst] (stereo interleaved) dengan sampai [frames] frame; mengembalikan jumlah frame yang terisi (kurang dari [frames] = audio habis). */
    fun read(dst: FloatArray, frames: Int): Int {
        if (silent) return 0
        val step = inRate.toDouble() / outRate
        var n = 0
        while (n < frames) {
            val i0 = srcPos.toInt()
            while (bufFrames < i0 + 2 && !outDone) decodeMore()
            if (bufFrames <= i0) break
            val i1 = if (i0 + 1 < bufFrames) i0 + 1 else i0
            val fr = (srcPos - i0).toFloat()
            val a = i0 * 2
            val b = i1 * 2
            dst[n * 2] = buf[a] + (buf[b] - buf[a]) * fr
            dst[n * 2 + 1] = buf[a + 1] + (buf[b + 1] - buf[a + 1]) * fr
            n++
            srcPos += step
        }
        val used = min(srcPos.toInt(), bufFrames)
        if (used > 0) {
            System.arraycopy(buf, used * 2, buf, 0, (bufFrames - used) * 2)
            bufFrames -= used
            srcPos -= used
        }
        return n
    }

    /** Dorong decoder sampai ada minimal satu buffer PCM baru (atau habis). */
    private fun decodeMore() {
        val c = codec
        if (c == null) { outDone = true; return }
        var idle = 0
        while (!outDone) {
            if (!inDone) {
                val i = c.dequeueInputBuffer(0)
                if (i >= 0) {
                    val ib = c.getInputBuffer(i)!!
                    val sz = ex.readSampleData(ib, 0)
                    if (sz < 0) {
                        c.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        inDone = true
                    } else {
                        c.queueInputBuffer(i, 0, sz, ex.sampleTime, 0)
                        ex.advance()
                    }
                }
            }
            val o = c.dequeueOutputBuffer(info, 10_000)
            if (o >= 0) {
                idle = 0
                val eos = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                val got = if (info.size > 0) append(c.getOutputBuffer(o)!!) else false
                c.releaseOutputBuffer(o, false)
                if (eos) outDone = true
                if (got || eos) return
            } else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                val f = c.outputFormat
                inRate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                inCh = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                floatPcm = f.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                    f.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
            } else if (++idle > 3000) {
                throw IllegalStateException("Decoder audio tidak merespons")
            }
        }
    }

    /** Tambahkan satu buffer keluaran decoder ke [buf] sebagai stereo float. Mengembalikan true kalau ada frame yang ditambahkan. */
    private fun append(ob: ByteBuffer): Boolean {
        ob.position(info.offset)
        ob.limit(info.offset + info.size)
        ob.order(ByteOrder.nativeOrder())
        val ch = max(1, inCh)
        if (dropFrames < 0L) {
            // buffer pertama setelah seek: seek berhenti di sampel sinkron SEBELUM titik yang diminta, buang selisihnya
            val p0 = info.presentationTimeUs
            dropFrames = if (seekUs > p0) (seekUs - p0) * inRate / 1_000_000L else 0L
        }
        val total = if (floatPcm) ob.asFloatBuffer().remaining() / ch else ob.asShortBuffer().remaining() / ch
        val skip = min(dropFrames, total.toLong()).toInt()
        dropFrames -= skip
        val keep = total - skip
        if (keep <= 0) return false
        if ((bufFrames + keep) * 2 > buf.size) buf = buf.copyOf(max(buf.size * 2, (bufFrames + keep) * 2))
        var o = bufFrames * 2
        if (floatPcm) {
            val f = ob.asFloatBuffer()
            for (k in 0 until total) {
                val l = f.get()
                val r = if (ch > 1) f.get() else l
                for (q in 2 until ch) f.get()
                if (k < skip) continue
                buf[o++] = l
                buf[o++] = r
            }
        } else {
            val s = ob.asShortBuffer()
            for (k in 0 until total) {
                val l = s.get() / 32768f
                val r = if (ch > 1) s.get() / 32768f else l
                for (q in 2 until ch) s.get()
                if (k < skip) continue
                buf[o++] = l
                buf[o++] = r
            }
        }
        bufFrames += keep
        return true
    }

    fun close() {
        try { codec?.stop() } catch (_: Exception) {}
        try { codec?.release() } catch (_: Exception) {}
        codec = null
        try { ex.release() } catch (_: Exception) {}
    }
}

/**
 * Mixer audio untuk ekspor: menggabungkan suara asli video (dengan volume sendiri) dan semua [AudioClip] menjadi satu trek AAC-LC
 * stereo, ditulis ke berkas .m4a sementara. Ekspor lalu menyalin sampel AAC itu ke MP4 hasil (lihat Exporter.doExport).
 *
 * Streaming: tiap sumber di-decode sedikit demi sedikit dan dijumlahkan per potongan 1024 frame, jadi memori tetap kecil
 * walau videonya panjang. Waktu keluaran dimulai dari 0 pada awal potongan (trim) video.
 */
internal object AudioMix {
    private const val CHUNK = 1024
    private val AAC_RATES = setOf(8000, 11025, 12000, 16000, 22050, 24000, 32000, 44100, 48000)

    private class Src(val stream: PcmStream, val startFrame: Long, val volume: Float)

    /** Laju sampel trek audio pertama [uri], atau null kalau tidak ada. */
    private fun probeRate(ctx: Context, uri: Uri): Int? {
        val ex = MediaExtractor()
        return try {
            ex.setDataSource(ctx, uri, null)
            var r: Int? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { r = f.getInteger(MediaFormat.KEY_SAMPLE_RATE); break }
            }
            r
        } catch (_: Exception) {
            null
        } finally {
            ex.release()
        }
    }

    private fun softClip(x: Float): Float {
        val a = abs(x)
        return if (a <= 0.8f) x else sign(x) * (0.8f + 0.2f * tanh((a - 0.8f) / 0.2f))
    }

    /**
     * Buat trek campuran untuk rentang [startUs]..[endUs] dari [video]. Mengembalikan berkas .m4a sementara (pemanggil yang menghapusnya),
     * atau null kalau tidak ada yang bisa dicampur (mis. suara asli dibisukan dan semua klip di luar rentang).
     * Melempar CancellationException kalau [cancelled] menjadi true.
     */
    fun render(
        ctx: Context,
        video: Uri,
        startUs: Long,
        endUs: Long,
        origVol: Float,
        clips: List<AudioClip>,
        cancelled: () -> Boolean,
        onProgress: (Float) -> Unit,
    ): File? {
        val probed = probeRate(ctx, video)
        val rate = if (probed != null && probed in AAC_RATES) probed else 44100
        val totalFrames = max(1L, (endUs - startUs) * rate / 1_000_000L)
        val sources = ArrayList<Src>()
        val out = File(ctx.cacheDir, "mix_${System.nanoTime()}.m4a")
        var enc: MediaCodec? = null
        var mux: MediaMuxer? = null
        var muxStarted = false
        var ok = false
        try {
            if (origVol > 0.001f) sources += Src(PcmStream(ctx, video, startUs, rate), 0L, origVol)
            for (c in clips) {
                if (c.volume <= 0.001f) continue
                val clipStartUs = c.startMs * 1000L
                if (clipStartUs >= endUs) continue                     // mulai setelah akhir potongan
                val relUs = clipStartUs - startUs                      // posisi mulai pada garis waktu keluaran
                val seek = if (relUs < 0L) -relUs else 0L              // sudah berjalan saat potongan mulai: lewati bagian awal klip
                if (seek >= c.durationMs * 1000L) continue             // klip sudah habis sebelum potongan mulai
                val startFrame = if (relUs > 0L) relUs * rate / 1_000_000L else 0L
                sources += Src(PcmStream(ctx, c.uri, seek, rate), startFrame, c.volume)
            }
            // sumber tanpa trek audio (mis. video tanpa suara) tidak menyumbang apa-apa
            sources.removeAll { src ->
                if (src.stream.silent) { src.stream.close(); true } else false
            }
            if (sources.isEmpty()) return null

            val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, rate, 2).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 32 * 1024)
            }
            val e = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            enc = e
            e.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            e.start()
            val m = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            mux = m
            var track = -1
            val info = MediaCodec.BufferInfo()

            fun drain(wait: Boolean) {
                var idle = 0
                while (true) {
                    val o = e.dequeueOutputBuffer(info, if (wait) 10_000L else 0L)
                    when {
                        o == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                            if (!wait) return
                            if (++idle > 500) error("Encoder audio tidak merespons")
                        }
                        o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            track = m.addTrack(e.outputFormat)
                            m.start()
                            muxStarted = true
                        }
                        o >= 0 -> {
                            idle = 0
                            val b = e.getOutputBuffer(o)!!
                            if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                            if (info.size > 0 && muxStarted) {
                                b.position(info.offset)
                                b.limit(info.offset + info.size)
                                m.writeSampleData(track, b, info)
                            }
                            val eos = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                            e.releaseOutputBuffer(o, false)
                            if (eos) return
                        }
                    }
                }
            }

            val mix = FloatArray(CHUNK * 2)
            val tmp = FloatArray(CHUNK * 2)
            val pcm = ByteArray(CHUNK * 4)
            var pos = 0L
            var lastP = -1f
            while (pos < totalFrames) {
                if (cancelled()) throw CancellationException("dibatalkan")
                val n = min(CHUNK.toLong(), totalFrames - pos).toInt()
                java.util.Arrays.fill(mix, 0, n * 2, 0f)
                for (s in sources) {
                    if (pos + n <= s.startFrame) continue                       // klip belum mulai pada potongan ini
                    val off = if (s.startFrame > pos) (s.startFrame - pos).toInt() else 0
                    val got = s.stream.read(tmp, n - off)
                    val base = off * 2
                    for (i in 0 until got * 2) mix[base + i] += tmp[i] * s.volume
                }
                var bi = 0
                for (i in 0 until n * 2) {
                    val v = (softClip(mix[i]) * 32767f).toInt()
                    pcm[bi++] = (v and 0xFF).toByte()
                    pcm[bi++] = ((v shr 8) and 0xFF).toByte()
                }
                // kirim ke encoder (buffer input bisa lebih kecil dari satu potongan: kirim bertahap)
                var off = 0
                while (off < bi) {
                    if (cancelled()) throw CancellationException("dibatalkan")
                    val ii = e.dequeueInputBuffer(10_000)
                    if (ii < 0) { drain(false); continue }
                    val ib = e.getInputBuffer(ii)!!
                    ib.clear()
                    val k = min(ib.remaining(), bi - off) and 3.inv()
                    ib.put(pcm, off, k)
                    e.queueInputBuffer(ii, 0, k, (pos + off / 4) * 1_000_000L / rate, 0)
                    off += k
                    drain(false)
                }
                pos += n
                val p = pos.toFloat() / totalFrames
                if (p - lastP >= 0.01f) { lastP = p; onProgress(p.coerceIn(0f, 1f)) }
            }
            // akhir aliran
            while (true) {
                val ii = e.dequeueInputBuffer(10_000)
                if (ii >= 0) {
                    e.queueInputBuffer(ii, 0, 0, pos * 1_000_000L / rate, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    break
                }
                drain(false)
            }
            drain(true)
            if (!muxStarted) error("Encoder audio tidak menghasilkan data")
            m.stop()
            muxStarted = false
            ok = true
            onProgress(1f)
            return out
        } finally {
            for (s in sources) s.stream.close()
            try { enc?.stop() } catch (_: Exception) {}
            try { enc?.release() } catch (_: Exception) {}
            try { if (muxStarted) mux?.stop() } catch (_: Exception) {}
            try { mux?.release() } catch (_: Exception) {}
            if (!ok) out.delete()
        }
    }
}
