package com.laykit

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.roundToInt

/** Galat yang pesannya aman ditampilkan langsung ke pengguna. */
internal class CaptionException(message: String) : Exception(message)

/** Tahap pembuatan caption, dipakai untuk teks status di panel. */
internal enum class CaptionStage(val label: String) {
    DOWNLOAD("Mengunduh model"),
    AUDIO("Menyiapkan audio"),
    RECOGNIZE("Mengenali suara"),
}

/** Model Whisper (ggml, multibahasa). Diunduh sekali ke folder privat app, lalu jalan offline. */
internal enum class WhisperModel(val label: String, val file: String, val sizeMb: Int) {
    TINY("Tiny", "ggml-tiny.bin", 75),
    BASE("Base", "ggml-base.bin", 142),
    SMALL("Small", "ggml-small.bin", 466);

    val url: String get() = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/$file"
}

/** Pelapor kemajuan yang dipanggil dari kode native (nama dan tanda tangan `onProgress(I)V` dibaca oleh whisper_jni.cpp). */
internal fun interface WhisperProgress {
    fun onProgress(percent: Int)
}

/** Jembatan JNI ke whisper.cpp (lihat app/src/main/cpp/whisper_jni.cpp). Hanya dipakai dari satu thread background. */
internal object WhisperNative {
    init {
        System.loadLibrary("laykit_whisper")
    }

    external fun nativeLoad(path: String): Long
    external fun nativeFree(handle: Long)
    external fun nativeCancel(on: Boolean)
    external fun nativeRun(handle: Long, samples: FloatArray, lang: String, threads: Int, cb: WhisperProgress?): Int
    external fun nativeSegStart(handle: Long, i: Int): Long
    external fun nativeSegEnd(handle: Long, i: Int): Long
    external fun nativeSegText(handle: Long, i: Int): ByteArray
}

internal object WhisperModels {
    fun dir(ctx: Context): File = File(ctx.filesDir, "whisper").apply { mkdirs() }
    fun file(ctx: Context, m: WhisperModel): File = File(dir(ctx), m.file)

    /** File model hanya diberi nama akhirnya setelah unduhan utuh (lihat [download]), jadi ada = lengkap. */
    fun ready(ctx: Context, m: WhisperModel): Boolean = file(ctx, m).let { it.exists() && it.length() > 0 }

    /** Unduh [m]. Mengembalikan false kalau dibatalkan; melempar [CaptionException] kalau gagal. */
    fun download(ctx: Context, m: WhisperModel, cancel: AtomicBoolean, onProgress: (Float) -> Unit): Boolean {
        val dst = file(ctx, m)
        val part = File(dst.path + ".part")
        var conn: HttpURLConnection? = null
        try {
            conn = (URL(m.url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15_000
                readTimeout = 30_000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "LayKit")
            }
            val code = conn.responseCode
            if (code != HttpURLConnection.HTTP_OK) throw CaptionException("Unduh model gagal (HTTP $code). Periksa koneksi internet.")
            val declared = conn.contentLengthLong
            val total = if (declared > 0) declared else m.sizeMb * 1_000_000L
            var done = 0L
            var lastPct = -1
            conn.inputStream.use { ins ->
                part.outputStream().use { outs ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        if (cancel.get()) return false
                        val n = ins.read(buf)
                        if (n < 0) break
                        outs.write(buf, 0, n)
                        done += n
                        val pct = (done * 100 / total).toInt()
                        if (pct != lastPct) {
                            lastPct = pct
                            onProgress((done.toFloat() / total).coerceIn(0f, 1f))
                        }
                    }
                }
            }
            if (declared > 0 && done != declared) throw CaptionException("Unduhan model terputus. Coba lagi.")
            if (!part.renameTo(dst)) throw CaptionException("Model tidak bisa disimpan.")
            return true
        } catch (e: CaptionException) {
            throw e
        } catch (e: IOException) {
            throw CaptionException("Unduh model gagal: ${e.message ?: "koneksi terputus"}")
        } finally {
            conn?.disconnect()
            if (part.exists()) part.delete()
        }
    }
}

/** Decode trek suara video menjadi PCM float mono 16 kHz (format yang diminta whisper.cpp). */
internal object AudioPcm {
    private class Mono16k {
        var buf = FloatArray(1 shl 18)
        var n = 0
        private var step = 1.0
        private var boxN = 1
        private var ring = FloatArray(1)
        private var ringPos = 0
        private var ringCount = 0
        private var sum = 0.0
        private var srcPos = 0.0
        private var idx = 0L
        private var last = 0f

        fun configure(sampleRate: Int) {
            step = sampleRate / 16000.0
            boxN = max(1, step.roundToInt())
            ring = FloatArray(boxN)
            ringPos = 0; ringCount = 0; sum = 0.0
            srcPos = 0.0; idx = 0L; last = 0f
        }

        private fun add(v: Float) {
            if (n == buf.size) buf = buf.copyOf(buf.size * 2)
            buf[n++] = v
        }

        /** Satu sampel mono pada laju sumber: rata-rata kotak (anti-alias kasar) lalu interpolasi linear ke 16 kHz. */
        fun push(x: Float) {
            val old = ring[ringPos]
            ring[ringPos] = x
            ringPos = (ringPos + 1) % boxN
            if (ringCount < boxN) { ringCount++; sum += x } else sum += (x - old).toDouble()
            val f = (sum / ringCount).toFloat()
            while (srcPos <= idx) {
                val frac = (srcPos - (idx - 1)).toFloat()
                add(last + (f - last) * frac)
                srcPos += step
            }
            last = f
            idx++
        }

        fun result(): FloatArray = buf.copyOf(n)
    }

    /** Mengembalikan null kalau dibatalkan; melempar [CaptionException] kalau tidak ada suara / gagal decode. */
    fun decode(ctx: Context, uri: Uri, cancel: AtomicBoolean, onProgress: (Float) -> Unit): FloatArray? {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            try {
                ex.setDataSource(ctx, uri, null)
            } catch (e: Exception) {
                throw CaptionException("Video tidak bisa dibuka untuk dibaca suaranya.")
            }
            var idx = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) { idx = i; fmt = f; break }
            }
            if (idx < 0 || fmt == null) throw CaptionException("Rekaman ini tidak punya trek suara.")
            ex.selectTrack(idx)
            val mime = fmt.getString(MediaFormat.KEY_MIME)!!
            val durUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L

            var sampleRate = if (fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
            var channels = if (fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 1
            var floatPcm = false

            val out = Mono16k().also { it.configure(sampleRate) }
            val dec = try {
                MediaCodec.createDecoderByType(mime).also { codec = it }
            } catch (e: Exception) {
                throw CaptionException("Format suara ($mime) tidak didukung di perangkat ini.")
            }
            dec.configure(fmt, null, null, 0)
            dec.start()

            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var lastPct = -1
            while (!outputDone) {
                if (cancel.get()) return null
                if (!inputDone) {
                    val ii = dec.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        val ib = dec.getInputBuffer(ii)!!
                        val n = ex.readSampleData(ib, 0)
                        if (n < 0) {
                            dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            dec.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = dec.dequeueOutputBuffer(info, 10_000)
                when {
                    oi >= 0 -> {
                        if (info.size > 0) {
                            val ob = dec.getOutputBuffer(oi)!!
                            ob.position(info.offset)
                            ob.limit(info.offset + info.size)
                            ob.order(ByteOrder.nativeOrder())
                            val ch = max(1, channels)
                            if (floatPcm) {
                                val fb = ob.asFloatBuffer()
                                var left = fb.remaining()
                                while (left >= ch) {
                                    var s = 0f
                                    for (c in 0 until ch) s += fb.get()
                                    out.push(s / ch)
                                    left -= ch
                                }
                            } else {
                                val sb = ob.asShortBuffer()
                                var left = sb.remaining()
                                while (left >= ch) {
                                    var s = 0f
                                    for (c in 0 until ch) s += sb.get() / 32768f
                                    out.push(s / ch)
                                    left -= ch
                                }
                            }
                        }
                        dec.releaseOutputBuffer(oi, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                        if (durUs > 0) {
                            val pct = (info.presentationTimeUs * 100 / durUs).toInt().coerceIn(0, 100)
                            if (pct != lastPct) { lastPct = pct; onProgress(pct / 100f) }
                        }
                    }
                    oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val nf = dec.outputFormat
                        if (nf.containsKey(MediaFormat.KEY_SAMPLE_RATE)) sampleRate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        if (nf.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        floatPcm = nf.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                            nf.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                        out.configure(sampleRate)
                    }
                }
            }
            onProgress(1f)
            return out.result()
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            try { ex.release() } catch (_: Exception) {}
        }
    }
}

/** Alur lengkap: model (unduh bila perlu) -> suara video -> whisper -> daftar [CaptionSeg]. */
internal object CaptionEngine {
    /**
     * Blocking; panggil dari thread background. Mengembalikan null kalau dibatalkan lewat [cancel];
     * melempar [CaptionException] (pesan siap tampil) kalau gagal. Waktu hasil = waktu video sumber (ms).
     */
    fun generate(
        ctx: Context,
        uri: Uri,
        model: WhisperModel,
        lang: String,
        cancel: AtomicBoolean,
        onStage: (CaptionStage, Float) -> Unit,
    ): List<CaptionSeg>? {
        val mf = WhisperModels.file(ctx, model)
        if (!WhisperModels.ready(ctx, model)) {
            onStage(CaptionStage.DOWNLOAD, 0f)
            if (!WhisperModels.download(ctx, model, cancel) { onStage(CaptionStage.DOWNLOAD, it) }) return null
        }
        if (cancel.get()) return null

        onStage(CaptionStage.AUDIO, 0f)
        val pcm = AudioPcm.decode(ctx, uri, cancel) { onStage(CaptionStage.AUDIO, it) } ?: return null
        if (pcm.size < 16000 / 2) throw CaptionException("Suara terlalu pendek untuk dikenali.")
        if (cancel.get()) return null

        val handle = try {
            WhisperNative.nativeLoad(mf.absolutePath)
        } catch (e: LinkageError) {
            throw CaptionException("Mesin caption tidak bisa dimuat di perangkat ini.")
        }
        if (handle == 0L) {
            mf.delete()   // kemungkinan rusak / tidak utuh: unduh ulang pada percobaan berikutnya
            throw CaptionException("Model gagal dimuat (memori kurang atau file rusak). Coba lagi atau pilih model lebih kecil.")
        }

        // flag batal Kotlin -> flag native; diulang tiap 100 ms karena nativeRun menyetel ulang flag saat mulai
        val watcherDone = AtomicBoolean(false)
        val watcher = Thread {
            while (!watcherDone.get()) {
                if (cancel.get()) WhisperNative.nativeCancel(true)
                try { Thread.sleep(100) } catch (_: InterruptedException) { break }
            }
        }.apply { isDaemon = true; start() }

        try {
            if (cancel.get()) return null
            onStage(CaptionStage.RECOGNIZE, 0f)
            val threads = Runtime.getRuntime().availableProcessors().coerceIn(2, 4)
            val rc = WhisperNative.nativeRun(handle, pcm, lang, threads, WhisperProgress { p -> onStage(CaptionStage.RECOGNIZE, p / 100f) })
            if (rc == -2) return null
            if (rc < 0) throw CaptionException("Pengenalan suara gagal (kode $rc).")

            val raw = ArrayList<CaptionSeg>(rc)
            for (i in 0 until rc) {
                val t0 = WhisperNative.nativeSegStart(handle, i) * 10L   // whisper memakai satuan 10 ms
                val t1 = WhisperNative.nativeSegEnd(handle, i) * 10L
                val text = String(WhisperNative.nativeSegText(handle, i), Charsets.UTF_8).trim()
                if (text.isEmpty() || isNoise(text)) continue
                raw += CaptionSeg(t0, max(t1, t0 + 300L), text)
            }
            // tanpa tumpang tindih: akhir sebuah baris dipotong di awal baris berikutnya
            for (i in 0 until raw.size - 1) {
                if (raw[i].endMs > raw[i + 1].startMs) raw[i] = raw[i].copy(endMs = raw[i + 1].startMs)
            }
            return raw.filter { it.endMs > it.startMs }
        } finally {
            watcherDone.set(true)
            WhisperNative.nativeFree(handle)
        }
    }

    /** Anotasi bunyi seperti "[BLANK_AUDIO]" atau "(musik)" bukan ucapan. */
    private fun isNoise(t: String): Boolean =
        (t.startsWith("[") && t.endsWith("]")) || (t.startsWith("(") && t.endsWith(")"))
}
