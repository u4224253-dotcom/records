package com.laykit

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp

/**
 * Panel kurva animasi zoom: preset + editor cubic-bezier (dua titik kontrol yang bisa digeser).
 * Kurva dipakai untuk animasi zoom masuk/keluar blok dan perpindahan antar keyframe. Sumbu x = waktu animasi (0..1),
 * sumbu y = seberapa jauh zoom sudah berjalan (0..1).
 */
@Composable
internal fun CurvePanel(
    sel: ZoomRegion?,
    enabled: Boolean,
    onCurve: (ZoomCurve?) -> Unit,
    onApplyAll: (ZoomCurve?) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    if (sel == null) {
        Text("Pilih blok zoom di timeline untuk mengatur kurva animasinya.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        return
    }
    val curve = sel.curve
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ZoomCurves.presets.forEach { (name, c) ->
                Pill(name, selected = curve == c, enabled = enabled) { onCurve(c) }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
            CurveEditor(curve, enabled, onCurve)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    if (curve == null) "Pegas bawaan" else "x1 %.2f  y1 %.2f\nx2 %.2f  y2 %.2f".format(curve.x1, curve.y1, curve.x2, curve.y2),
                    style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant,
                )
                Text(
                    if (curve == null) "Geser kotak kurva untuk membuat kurva sendiri." else "Geser dua titik untuk mengubah bentuk.",
                    style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("Reset", enabled = enabled && curve != null) { onCurve(null) }
                    Pill("Semua blok", enabled = enabled) { onApplyAll(curve) }
                }
            }
        }
    }
}

@Composable
private fun CurveEditor(curve: ZoomCurve?, enabled: Boolean, onCurve: (ZoomCurve?) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val curveState = rememberUpdatedState(curve)
    val changeState = rememberUpdatedState(onCurve)
    val enabledState = rememberUpdatedState(enabled)
    var dragging by remember { mutableIntStateOf(0) }   // 0 = tidak, 1 = titik kontrol 1, 2 = titik kontrol 2
    val grid = cs.outlineVariant
    val line = cs.onSurfaceVariant.copy(alpha = 0.5f)
    val accent = cs.primary
    val pts = 40

    Canvas(
        Modifier.size(104.dp).pointerInput(Unit) {
            val pad = 14.dp.toPx()
            fun toX(v: Float) = pad + v * (size.width - 2 * pad)
            fun toY(v: Float) = size.height - pad - v * (size.height - 2 * pad)
            fun fromX(px: Float) = ((px - pad) / (size.width - 2 * pad)).coerceIn(0f, 1f)
            fun fromY(py: Float) = ((size.height - pad - py) / (size.height - 2 * pad)).coerceIn(0f, 1f)
            detectDragGestures(
                onDragStart = { o ->
                    if (!enabledState.value) return@detectDragGestures
                    val c = curveState.value ?: ZoomCurves.SMOOTH
                    val d1 = (o - Offset(toX(c.x1), toY(c.y1))).getDistance()
                    val d2 = (o - Offset(toX(c.x2), toY(c.y2))).getDistance()
                    dragging = if (d1 <= d2) 1 else 2
                    if (curveState.value == null) changeState.value(c)   // mulai dari kurva Halus
                },
                onDrag = { ch, _ ->
                    if (dragging == 0 || !enabledState.value) return@detectDragGestures
                    ch.consume()
                    val c = curveState.value ?: ZoomCurves.SMOOTH
                    val x = fromX(ch.position.x); val y = fromY(ch.position.y)
                    changeState.value(if (dragging == 1) c.copy(x1 = x, y1 = y) else c.copy(x2 = x, y2 = y))
                },
                onDragEnd = { dragging = 0 },
                onDragCancel = { dragging = 0 },
            )
        },
    ) {
        val pad = 14.dp.toPx()
        fun px(v: Float) = pad + v * (size.width - 2 * pad)
        fun py(v: Float) = size.height - pad - v * (size.height - 2 * pad)
        // kotak dan garis bantu
        for (i in 0..4) {
            val v = i / 4f
            drawLine(grid, Offset(px(v), py(0f)), Offset(px(v), py(1f)), strokeWidth = 1.dp.toPx())
            drawLine(grid, Offset(px(0f), py(v)), Offset(px(1f), py(v)), strokeWidth = 1.dp.toPx())
        }
        drawLine(grid, Offset(px(0f), py(0f)), Offset(px(1f), py(1f)), strokeWidth = 1.dp.toPx())

        // kurva
        val path = Path()
        for (i in 0..pts) {
            val t = i / pts.toFloat()
            val x: Float; val y: Float
            if (curve == null) {
                x = t; y = ZoomMath.spring(t.toDouble()).toFloat()
            } else {
                val m = 1f - t
                x = 3f * m * m * t * curve.x1 + 3f * m * t * t * curve.x2 + t * t * t
                y = 3f * m * m * t * curve.y1 + 3f * m * t * t * curve.y2 + t * t * t
            }
            if (i == 0) path.moveTo(px(x), py(y)) else path.lineTo(px(x), py(y))
        }
        drawPath(path, if (curve == null) line else accent, style = Stroke(width = 2.5.dp.toPx()))

        // titik kontrol
        if (curve != null) {
            val p1 = Offset(px(curve.x1), py(curve.y1)); val p2 = Offset(px(curve.x2), py(curve.y2))
            drawLine(line, Offset(px(0f), py(0f)), p1, strokeWidth = 1.5.dp.toPx())
            drawLine(line, Offset(px(1f), py(1f)), p2, strokeWidth = 1.5.dp.toPx())
            drawCircle(accent, if (dragging == 1) 9.dp.toPx() else 7.dp.toPx(), p1)
            drawCircle(accent, if (dragging == 2) 9.dp.toPx() else 7.dp.toPx(), p2)
        }
        drawCircle(line, 3.dp.toPx(), Offset(px(0f), py(0f)))
        drawCircle(line, 3.dp.toPx(), Offset(px(1f), py(1f)))
    }
}
