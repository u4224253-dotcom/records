package com.laykit

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Channel kurva: slider mana yang kurva antar-keyframenya sedang diatur. CH_ZOOM juga mengatur transisi masuk/keluar blok. */
internal const val CH_ZOOM = 0
internal const val CH_PITCH = 1
internal const val CH_YAW = 2
internal const val CH_ROLL = 3
internal const val CH_DEPTH = 4

private val CHANNELS = listOf(CH_ZOOM to "Posisi/Zoom", CH_PITCH to "Angguk", CH_YAW to "Tengok", CH_ROLL to "Miring", CH_DEPTH to "Jarak")

internal fun curveOf(r: ZoomRegion, ch: Int): ZoomCurve? = when (ch) {
    CH_PITCH -> r.curvePitch; CH_YAW -> r.curveYaw; CH_ROLL -> r.curveRoll; CH_DEPTH -> r.curveDepth; else -> r.curve
}

/**
 * Panel kurva animasi (desain LayKit_PanelEditor): baris preset (chip), lalu editor cubic-bezier 76 dp (dua titik kontrol yang
 * bisa digeser) dengan info di sebelahnya. Satu kurva per channel ([CH_ZOOM] = skala+posisi, dipakai juga untuk transisi masuk/keluar
 * blok; [CH_PITCH]/[CH_YAW]/[CH_ROLL]/[CH_DEPTH] = slider Customize 3D kamera, masing-masing independen). Pilihan channel hanya
 * tampil kalau blok sedang mode [Cam.CUSTOM]. Tombol Reset ada di header panel (lihat Editor.kt). [channel] disimpan oleh pemanggil
 * supaya header tahu kurva mana yang di-reset; channel selain Zoom dianggap [CH_ZOOM] kalau blok bukan Customize.
 */
@Composable
internal fun CurvePanel(
    sel: ZoomRegion?,
    channel: Int,
    onChannel: (Int) -> Unit,
    enabled: Boolean,
    onCurve: (channel: Int, ZoomCurve?) -> Unit,
    onApplyAll: (channel: Int, ZoomCurve?) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    if (sel == null) {
        PanelHint("Pilih blok zoom di timeline untuk mengatur kurva animasinya.", Modifier.padding(horizontal = 16.dp))
        return
    }
    val custom = sel.cam == Cam.CUSTOM
    val ch = if (custom) channel else CH_ZOOM
    val curve = curveOf(sel, ch)
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            ZoomCurves.presets.forEach { (name, c) ->
                PanelPill(name, selected = curve == c, enabled = enabled) { onCurve(ch, c) }
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            CurveEditor(curve, enabled, zoomChannel = ch == CH_ZOOM) { c -> onCurve(ch, c) }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (custom) {
                    PanelSeg(CHANNELS.map { it.second to it.first }, ch, enabled, fontSize = 12.sp, hPad = 10.dp) { onChannel(it) }
                } else {
                    Text(
                        when {
                            curve != null -> "x1 %.2f  y1 %.2f\nx2 %.2f  y2 %.2f".format(curve.x1, curve.y1, curve.x2, curve.y2)
                            else -> "Pegas bawaan\nGeser kotak = kurva sendiri"
                        },
                        fontFamily = FontFamily.Monospace, fontSize = 11.sp, lineHeight = 15.sp, color = cs.onSurfaceVariant,
                    )
                }
                PanelPill("Semua blok", enabled = enabled, modifier = Modifier.fillMaxWidth()) { onApplyAll(ch, curve) }
            }
        }
    }
}

/**
 * Kotak kurva 76 dp. Semua ukuran mengikuti desain (kanvas 124 satuan: kotak 100 satuan dengan margin 12).
 * [zoomChannel]: hanya channel [CH_ZOOM] yang bawaannya pegas fisik ([ZoomMath.spring]); channel Customize bawaannya kurva halus ([ZoomMath.keyEase]).
 * Kurva bawaan digambar bertitik; kurva sendiri digambar penuh dengan dua titik kontrol.
 */
@Composable
private fun CurveEditor(curve: ZoomCurve?, enabled: Boolean, zoomChannel: Boolean = true, onCurve: (ZoomCurve?) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val curveState = rememberUpdatedState(curve)
    val changeState = rememberUpdatedState(onCurve)
    val enabledState = rememberUpdatedState(enabled)
    var dragging by remember { mutableIntStateOf(0) }   // 0 = tidak, 1 = titik kontrol 1, 2 = titik kontrol 2
    val grid = cs.outlineVariant
    val mute = cs.onSurfaceVariant
    val accent = cs.primary
    val pts = 40

    Canvas(
        Modifier.size(76.dp).clip(RoundedCornerShape(14.dp)).background(cs.surfaceVariant).pointerInput(Unit) {
            val u = size.width / 124f
            fun toX(v: Float) = (12f + v * 100f) * u
            fun toY(v: Float) = (112f - v * 100f) * u
            fun fromX(px: Float) = ((px / u - 12f) / 100f).coerceIn(0f, 1f)
            fun fromY(py: Float) = ((112f - py / u) / 100f).coerceIn(0f, 1f)
            detectDragGestures(
                onDragStart = { o ->
                    if (!enabledState.value) return@detectDragGestures
                    val c = curveState.value ?: ZoomCurves.SMOOTH
                    val d1 = (o - Offset(toX(c.x1), toY(c.y1))).getDistance()
                    val d2 = (o - Offset(toX(c.x2), toY(c.y2))).getDistance()
                    dragging = if (d1 <= d2) 1 else 2
                    if (curveState.value == null) changeState.value(c)   // mulai dari kurva Halus
                },
                onDrag = { ch, _ ->
                    if (dragging == 0 || !enabledState.value) return@detectDragGestures
                    ch.consume()
                    val c = curveState.value ?: ZoomCurves.SMOOTH
                    val x = fromX(ch.position.x); val y = fromY(ch.position.y)
                    changeState.value(if (dragging == 1) c.copy(x1 = x, y1 = y) else c.copy(x2 = x, y2 = y))
                },
                onDragEnd = { dragging = 0 },
                onDragCancel = { dragging = 0 },
            )
        },
    ) {
        val u = size.width / 124f
        fun px(v: Float) = (12f + v * 100f) * u
        fun py(v: Float) = (112f - v * 100f) * u
        val hair = (1f * u).coerceAtLeast(1f)

        // kotak dan diagonal putus-putus
        drawRect(grid, Offset(px(0f), py(1f)), Size(100f * u, 100f * u), style = Stroke(width = hair))
        drawLine(
            grid, Offset(px(0f), py(0f)), Offset(px(1f), py(1f)), strokeWidth = hair,
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(3f * u, 3f * u)),
        )

        // kurva
        val path = Path()
        if (curve == null) {
            for (i in 0..pts) {
                val t = i / pts.toFloat()
                val y = (if (zoomChannel) ZoomMath.spring(t.toDouble()) else ZoomMath.keyEase(t.toDouble())).toFloat()
                if (i == 0) path.moveTo(px(t), py(y)) else path.lineTo(px(t), py(y))
            }
        } else {
            path.moveTo(px(0f), py(0f))
            path.cubicTo(px(curve.x1), py(curve.y1), px(curve.x2), py(curve.y2), px(1f), py(1f))
        }
        drawPath(
            path, accent,
            style = Stroke(
                width = 3f * u, cap = StrokeCap.Round,
                pathEffect = if (curve == null) PathEffect.dashPathEffect(floatArrayOf(1f * u, 6f * u)) else null,
            ),
        )

        // titik kontrol
        if (curve != null) {
            val p1 = Offset(px(curve.x1), py(curve.y1)); val p2 = Offset(px(curve.x2), py(curve.y2))
            drawLine(mute, Offset(px(0f), py(0f)), p1, strokeWidth = 2f * u)
            drawLine(mute, Offset(px(1f), py(1f)), p2, strokeWidth = 2f * u)
            drawCircle(accent, 9f * u, p1)
            drawCircle(accent, 9f * u, p2)
        }
    }
}
