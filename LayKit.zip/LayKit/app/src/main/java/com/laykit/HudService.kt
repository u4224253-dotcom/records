package com.laykit

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.launch
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.sqrt

/**
 * HUD melayang (bar gelap membulat) untuk mulai merekam dari app mana pun.
 * Mode video: tampil hanya saat IDLE. Begitu Record ditekan HUD dilepas total dari layar,
 * jadi tidak pernah ikut terekam; muncul lagi setelah rekaman selesai disimpan.
 * Mode audio saja (MP3): tidak ada tangkapan layar, jadi HUD tetap tampil selama merekam dan
 * menampilkan waveform real-time di bawah bar. Tombol rekam berubah jadi Stop.
 * Setelah Stop, kartu waveform tidak hilang: gambarnya diam (seluruh rekaman) dengan tombol putar pratinjau di kiri
 * dan ikon buang + simpan di kanan. Rekaman baru masuk Music/LayKit kalau dipilih simpan.
 */
class HudService : Service() {

    companion object {
        const val A_SHOW = "com.laykit.HUD_SHOW"
        const val A_CLOSE = "com.laykit.HUD_CLOSE"

        /** true selama HUD hidup: RecorderService memakainya untuk memutuskan menahan rekaman audio (pratinjau) atau langsung menyimpan. */
        @Volatile var active = false

        /** true dari Record ditekan sampai rekaman benar-benar jalan (atau dibatalkan): HUD disembunyikan. */
        val launching = MutableStateFlow(false)

        /** dinaikkan CaptureActivity setelah izin mic beres, supaya HUD membaca ulang pengaturan. */
        val refresh = MutableStateFlow(0)

        private const val CH = "hud"
        private const val NID = 2

        // Palet monokrom: hitam-abu netral + putih sebagai aksen. Merah HANYA untuk rekam dan pesan galat.
        private const val BG = 0xFF141416.toInt()          // permukaan bar / panel
        private const val LINE = 0xFF2A2A2E.toInt()        // garis tipis 1dp
        private const val TRACK = 0xFF1C1C1F.toInt()       // kolom isian, kartu, jalur segmen
        private const val PRESS = 0xFF26262A.toInt()       // ditekan / terpilih
        private const val TXT = 0xFFF2F2F3.toInt()         // teks utama
        private const val GRAY = 0xFF8E8E93.toInt()        // teks sekunder
        private const val ACCENT = 0xFFFFFFFF.toInt()      // aksen = putih
        private const val ON_ACCENT = 0xFF141416.toInt()   // teks di atas aksen
        private const val DOT_OFF = 0xFF2E2E33.toInt()
        private const val RED = 0xFFE5484D.toInt()

        /** Dipanggil setelah rekaman diizinkan: kalau 8 dtk kemudian masih IDLE (gagal mulai), HUD dimunculkan lagi. */
        fun releaseLaunchLater() {
            Handler(Looper.getMainLooper()).postDelayed({
                if (RecorderService.ui.value.phase == Phase.IDLE) launching.value = false
            }, 8000)
        }

        // TYPE_BLE_HEADSET = 26 (API 31)
        private val MIC_TYPES = setOf(
            AudioDeviceInfo.TYPE_BUILTIN_MIC, AudioDeviceInfo.TYPE_WIRED_HEADSET,
            AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET,
            AudioDeviceInfo.TYPE_BLUETOOTH_SCO, 26,
        )
    }

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var root: FrameLayout? = null
    private var attached = false
    private var wanted = false
    private var menuOpen = false      // panel (menu / Tools) terbuka
    private var panelMode = 0         // isi panel: 0 = menu (titik tiga), 1 = Tools, 2 = TikTok Converter, 3 = BPM Detector, 4 = Chord Finder
    private var s = RecSettings()
    private var devs: List<AudioDeviceInfo> = emptyList()

    // posisi bar di layar (px). Jendela overlay dihitung dari bar + panel, jadi bar tidak melompat saat menu dibuka.
    private var barX = 0
    private var barY = 0
    private lateinit var bar: LinearLayout
    private lateinit var barCol: LinearLayout       // bar + waveform di bawahnya (satu blok yang digeser / dijadikan acuan panel)
    private lateinit var waveCard: LinearLayout    // kartu waveform: [putar] [waveform] [buang] [simpan]
    private lateinit var waveView: WaveView
    private lateinit var recBtn: FrameLayout
    private lateinit var icoPlay: SolarView
    private lateinit var icoDiscard: SolarView
    private lateinit var icoSave: SolarView
    private lateinit var recDot: View
    private var player: MediaPlayer? = null
    private val playTick = object : Runnable {
        override fun run() {
            val p = player ?: return
            try {
                if (waveView.seeking) { main.postDelayed(this, 33); return }
                val dur = p.duration.coerceAtLeast(1)
                waveView.progress = (p.currentPosition.toFloat() / dur).coerceIn(0f, 1f)
                waveView.posSec = p.currentPosition / 1000
                waveView.invalidate()
            } catch (_: Exception) { /* player sedang dilepas */ }
            main.postDelayed(this, 33)
        }
    }
    private var waveRunning = false
    private val waveTick = object : Runnable {
        override fun run() {
            if (!attached || !isRec()) { waveRunning = false; return }
            val u = RecorderService.ui.value
            waveView.seconds = u.seconds
            waveView.paused = u.phase == Phase.PAUSED
            waveView.invalidate()
            main.postDelayed(this, 33)
        }
    }
    private lateinit var panelBox: LinearLayout
    private lateinit var panelContent: LinearLayout
    private lateinit var panelFooter: LinearLayout
    private lateinit var panelHead: LinearLayout     // header panel: [kembali] judul + garis
    private lateinit var panelHeadRow: LinearLayout
    private lateinit var panelTitle: TextView
    private lateinit var panelBack: SolarView
    private lateinit var vidBlock: LinearLayout     // resolusi, orientasi, fps (disembunyikan di mode MP3)
    private lateinit var micWrap: LinearLayout      // bagian mikrofon di panel (muncul saat mic aktif)
    private lateinit var devList: LinearLayout
    private lateinit var dots: List<View>
    private lateinit var icoSpk: SolarView
    private lateinit var icoMic: SolarView
    private lateinit var icoMore: SolarView
    private lateinit var icoTools: SolarView
    private lateinit var secMode: LinearLayout     // isi panel menu: mode, resolusi, ...
    private lateinit var toolsWrap: LinearLayout   // isi panel Tools
    private lateinit var bpmWrap: LinearLayout     // isi panel BPM Detector
    private lateinit var chordWrap: LinearLayout   // isi panel Chord Finder
    private lateinit var chordList: LinearLayout   // satu baris per file: nama file | akor terdeteksi
    private lateinit var chordHint: TextView
    private lateinit var chordClear: TextView
    private var chordJob: Job? = null
    private lateinit var bpmValue: TextView
    private lateinit var bpmWave: WaveView
    private var bpmStopPending = false
    private val stopBpmSvc = Runnable { bpmStopPending = false; stopService(Intent(this, BpmService::class.java)) }
    private var modeChips: List<Pair<Int, TextView>> = emptyList()
    private var resChips: List<Pair<Int, TextView>> = emptyList()
    private var orientChips: List<Pair<Int, TextView>> = emptyList()   // 0 auto, 1 potret, 2 lanskap
    private var fpsChips: List<Pair<Int, TextView>> = emptyList()

    // pengukur level mic
    @Volatile private var gen = 0
    private var meterOn = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WindowManager::class.java)
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CH, "HUD perekam", NotificationManager.IMPORTANCE_MIN))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == A_CLOSE) { shutdown(); return START_NOT_STICKY }
        startFg()
        if (!Settings.canDrawOverlays(this)) { shutdown(); return START_NOT_STICKY }
        if (!wanted) {
            wanted = true
            active = true
            s = RecPrefs.load(this)
            buildUi()
            scope.launch {
                combine(RecorderService.ui, launching, RecorderService.draft) { u, l, d ->
                    (u.phase == Phase.IDLE && !l) || d != null ||
                        (u.audio && (u.phase == Phase.RECORDING || u.phase == Phase.PAUSED || u.phase == Phase.SAVING))
                }
                    .collect { if (it) showHud() else hideHud() }
            }
            scope.launch {
                // draft berubah (muncul / disimpan / dibuang / diganti): pemutar dihentikan, kartu disesuaikan
                RecorderService.draft.collect { stopPlayer(); if (attached) syncUi() }
            }
            scope.launch {
                RecorderService.ui.collect { if (it.phase != Phase.IDLE && launching.value) launching.value = false }
            }
            scope.launch {
                BpmService.bpm.collect { v -> if (::bpmValue.isInitialized) bpmValue.text = if (v > 0) v.toString() else "--" }
            }
            ChordTool.resetStuck()
            scope.launch {
                // pemilih file selesai: panel (yang ditutup selama memilih) dibuka lagi di Chord Finder
                ChordTool.pickDone.drop(1).collect {
                    if (attached && !isRec()) { panelMode = 4; menuOpen = true; syncUi() }
                }
            }
            scope.launch {
                // daftar file Chord Finder berubah (file baru dipilih / progres / hasil): gambar ulang panel + lanjutkan antrean
                ChordTool.items.collect {
                    if (attached && menuOpen && panelMode == 4) { renderChord(); fitWindow() }
                    kickChord()
                }
            }
            scope.launch {
                refresh.drop(1).collect { s = RecPrefs.load(this@HudService); syncUi() }
            }
        } else {
            showHud()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        stopService(Intent(this, BpmService::class.java))
        wanted = false
        active = false
        flushDraft()
        hideHud()
        scope.cancel()
        super.onDestroy()
    }

    private fun startFg() {
        val n = notif()
        if (Build.VERSION.SDK_INT >= 34) {
            ServiceCompat.startForeground(this, NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NID, n)
        }
    }

    private fun notif(): Notification {
        val close = PendingIntent.getService(
            this, 10, Intent(this, HudService::class.java).setAction(A_CLOSE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("HUD LayKit aktif")
            .setContentText("Ketuk Tutup untuk menyembunyikan HUD")
            .setOngoing(true).setPriority(NotificationCompat.PRIORITY_MIN)
            .addAction(0, "Tutup", close)
            .build()
    }

    private fun shutdown() {
        stopService(Intent(this, BpmService::class.java))
        wanted = false
        active = false
        flushDraft()
        hideHud()
        scope.cancel()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ---------- tampil / sembunyi ----------

    private fun showHud() {
        val r = root ?: return
        if (!wanted) return
        if (attached) { syncUi(); return }
        try { wm.addView(r, lp); attached = true } catch (e: Exception) { shutdown(); return }
        syncUi()
    }

    private fun hideHud() {
        menuOpen = false
        stopMeter()
        stopPlayer()
        main.removeCallbacks(waveTick); waveRunning = false
        main.removeCallbacks(bpmWaveTick); bpmWaveRunning = false
        val r = root
        if (r != null && attached) { try { wm.removeView(r) } catch (_: Exception) { /* sudah lepas */ } }
        attached = false
    }

    // ---------- aksi ----------

    private fun isRec(): Boolean {
        val u = RecorderService.ui.value
        return u.audio && (u.phase == Phase.RECORDING || u.phase == Phase.PAUSED)
    }

    private fun onRecord() {
        if (RecorderService.draft.value != null) return   // rekaman sebelumnya harus diputuskan dulu (simpan / buang)
        if (isRec()) {   // rekam audio sedang jalan: tombol ini jadi Stop
            startService(Intent(this, RecorderService::class.java).setAction(RecorderService.A_STOP))
            return
        }
        stopMeter()
        stopService(Intent(this, BpmService::class.java))   // satu proyeksi saja saat merekam
        menuOpen = false
        try {
            // HUD masih terpasang saat startActivity: izin overlay mengizinkan buka Activity dari latar belakang
            startActivity(Intent(this, CaptureActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            // mode audio saja tidak menangkap layar, jadi HUD tidak perlu disembunyikan
            if (s.audioOnly) { syncUi(); return }
            launching.value = true
            main.postDelayed({
                if (launching.value && !CaptureActivity.alive && RecorderService.ui.value.phase == Phase.IDLE) launching.value = false
            }, 4000)
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal membuka izin rekam", Toast.LENGTH_SHORT).show()
            syncUi()
        }
    }

    // ---------- pratinjau + simpan / buang rekaman audio ----------

    /** Pemutar pratinjau (sudah prepare, belum tentu jalan). Dibuat saat pertama dibutuhkan: putar atau geser playhead. */
    private fun ensurePlayer(): MediaPlayer? {
        player?.let { return it }
        val d = RecorderService.draft.value ?: return null
        return try {
            val np = MediaPlayer()
            np.setDataSource(d.file.absolutePath)
            np.setOnCompletionListener { stopPlayer(); if (attached) syncUi() }
            np.prepare()
            player = np
            np
        } catch (e: Exception) {
            Toast.makeText(this, "Pratinjau gagal diputar", Toast.LENGTH_SHORT).show()
            stopPlayer()
            null
        }
    }

    private fun togglePlay() {
        val p = ensurePlayer() ?: return
        try {
            if (p.isPlaying) { p.pause(); main.removeCallbacks(playTick) }
            else { p.start(); main.removeCallbacks(playTick); main.post(playTick) }
        } catch (_: Exception) { stopPlayer() }
        syncUi()
    }

    /** Playhead digeser / dipilih di waveform: lompat ke posisi itu. Kalau sedang diam, tetap diam di posisi baru. */
    private fun seekTo(f: Float, done: Boolean) {
        val p = ensurePlayer() ?: return
        try {
            val dur = p.duration.coerceAtLeast(1)
            val ms = (f.coerceIn(0f, 1f) * dur).toInt().coerceAtMost(dur - 1)
            p.seekTo(ms)
            waveView.progress = ms.toFloat() / dur
            waveView.posSec = ms / 1000
            waveView.invalidate()
            if (done && p.isPlaying) { main.removeCallbacks(playTick); main.post(playTick) }
        } catch (_: Exception) { stopPlayer() }
    }

    /** Menghentikan dan melepas pemutar, gambar kembali ke awal (belum diputar). */
    private fun stopPlayer() {
        main.removeCallbacks(playTick)
        player?.let { try { it.stop() } catch (_: Exception) {}; try { it.release() } catch (_: Exception) {} }
        player = null
        if (::waveView.isInitialized) { waveView.progress = 0f; waveView.posSec = 0; waveView.seeking = false; waveView.invalidate() }
        if (::icoPlay.isInitialized) icoPlay.icon = SolarIcons.PLAY
    }

    private fun onSaveDraft() {
        val d = RecorderService.takeDraft() ?: return
        val app = applicationContext
        Toast.makeText(this, "Menyimpan…", Toast.LENGTH_SHORT).show()
        thread(name = "hud-save") {
            val ok = d.save(app)
            main.post {
                if (ok) {
                    RecorderService.libVersion.value++
                    Toast.makeText(app, "Tersimpan: Music/LayKit/${d.name}", Toast.LENGTH_SHORT).show()
                } else {
                    RecorderService.draft.value = d   // gagal: kartu muncul lagi supaya bisa dicoba ulang
                    Toast.makeText(app, "Gagal menyimpan rekaman", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun onDiscardDraft() {
        RecorderService.takeDraft()?.discard()
        Toast.makeText(this, "Rekaman dibuang", Toast.LENGTH_SHORT).show()
    }

    /** HUD ditutup padahal masih ada rekaman yang belum diputuskan: disimpan, jangan sampai hilang. */
    private fun flushDraft() {
        stopPlayer()
        val d = RecorderService.takeDraft() ?: return
        val app = applicationContext
        thread(name = "hud-flush") {
            val ok = d.save(app)
            if (ok) RecorderService.libVersion.value++
        }
    }

    private fun onToggleMic() {
        if (isRec()) return
        if (!s.mic && !hasMicPerm()) {
            startActivity(
                Intent(this, CaptureActivity::class.java).putExtra(CaptureActivity.X_PERM_ONLY, true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
            return
        }
        s = s.copy(mic = !s.mic); RecPrefs.save(this, s)
        syncUi()
    }

    private fun onToggleInternal() {
        if (isRec()) return
        s = s.copy(internal = !s.internal); RecPrefs.save(this, s)
        syncUi()
    }

    private fun onToggleMore() {
        if (isRec()) return
        if (menuOpen && panelMode == 0) menuOpen = false else { panelMode = 0; menuOpen = true }
        syncUi()
    }

    private fun onToggleTools() {
        if (isRec()) return
        if (menuOpen && panelMode != 0) menuOpen = false else { panelMode = 1; menuOpen = true }
        syncUi()
    }

    private fun onPickMode(audio: Boolean) {
        s = s.copy(audioOnly = audio); RecPrefs.save(this, s)
        syncUi()
    }

    private fun onPickRes(v: Int) {
        s = s.copy(res = v); RecPrefs.save(this, s)
        syncUi()
    }

    private fun onPickOrient(v: Int) {
        s = s.copy(orient = v); RecPrefs.save(this, s)
        syncUi()
    }

    private fun onPickFps(v: Int) {
        s = s.copy(fps = v); RecPrefs.save(this, s)
        syncUi()
    }

    private fun openApp(cmd: String) {
        startActivity(
            Intent(this, MainActivity::class.java).putExtra("cmd", cmd)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        )
    }

    // ---------- UI: bar ringkas (rekam, audio internal, mic, menu) + panel menu yang menempatkan diri ----------
    // Gaya datar: warna solid, garis tipis 1dp, tanpa bayangan/elevation.

    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun dpf(v: Float) = (v * resources.displayMetrics.density + 0.5f).toInt().coerceAtLeast(1)

    private fun rounded(fill: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(r).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun View.tap(f: () -> Unit) { setOnClickListener { f() } }

    /** Latar tombol ikon: lingkaran abu gelap saat ditekan atau terpilih (menu terbuka), selain itu transparan. */
    private fun pressOval() = StateListDrawable().apply {
        val oval = { GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(PRESS) } }
        addState(intArrayOf(android.R.attr.state_selected), oval())
        addState(intArrayOf(android.R.attr.state_pressed), oval())
        addState(intArrayOf(), ColorDrawable(0))
    }

    /** Latar sentuh baris / tombol footer: kotak abu gelap saat ditekan. */
    private fun pressRect() = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), ColorDrawable(PRESS))
        addState(intArrayOf(), ColorDrawable(0))
    }

    private fun ico(icon: List<SolarPath>, tint: Int = TXT): SolarView =
        SolarView(this, icon).apply {
            this.tint = tint
            background = pressOval()
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
        }

    private fun hLine(): View = View(this).apply {
        setBackgroundColor(LINE)
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1))
    }

    /** Celah transparan antar anak LinearLayout (dipasang lewat dividerDrawable, otomatis dilewati untuk anak GONE). */
    private fun gap(w: Int, h: Int) = GradientDrawable().apply { setSize(w, h); setColor(0) }

    private fun LinearLayout.spaced(px: Int) {
        showDividers = LinearLayout.SHOW_DIVIDER_MIDDLE
        dividerDrawable = if (orientation == LinearLayout.VERTICAL) gap(1, px) else gap(px, 1)
    }

    private fun medium() = Typeface.create("sans-serif-medium", Typeface.NORMAL)

    /** Label kecil abu-abu di atas kontrol (Mode, Resolusi, Mikrofon, ...). */
    private fun labelText(t: String) = TextView(this).apply {
        text = t; textSize = 12f; setTextColor(GRAY); maxLines = 1
        typeface = medium()
    }

    /** Tombol teks: utama = putih solid, sekunder = kartu gelap bergaris. Lebar dibagi rata dalam satu baris. */
    private fun btn(label: String, primary: Boolean, f: () -> Unit) = TextView(this).apply {
        text = label; textSize = 13f; gravity = Gravity.CENTER; maxLines = 1
        typeface = medium()
        setTextColor(if (primary) ON_ACCENT else TXT)
        background = if (primary) rounded(ACCENT, 12) else rounded(TRACK, 12, LINE)
        layoutParams = LinearLayout.LayoutParams(0, dp(40), 1f)
        tap(f)
    }

    /** Tombol teks polos (tanpa latar), untuk aksi tambahan seperti Batal. */
    private fun ghostBtn(label: String, f: () -> Unit) = TextView(this).apply {
        text = label; textSize = 13f; gravity = Gravity.CENTER; maxLines = 1
        typeface = medium(); setTextColor(GRAY)
        background = pressRect()
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(36))
        tap(f)
    }

    private fun hRow(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        spaced(dp(8))
        v.forEach { addView(it) }
    }

    private fun styleSeg(t: TextView, selected: Boolean) {
        t.background = if (selected) rounded(ACCENT, 9) else null
        t.setTextColor(if (selected) ON_ACCENT else GRAY)
        t.typeface = if (selected) medium() else Typeface.DEFAULT
    }

    /** Kontrol segmen: jalur gelap bergaris, pilihan aktif = pil putih. Mengembalikan wadah + daftar chip. */
    private fun seg(opts: List<Pair<String, Int>>, onPick: (Int) -> Unit): Pair<LinearLayout, List<Pair<Int, TextView>>> {
        val c: Context = this
        val chips = opts.map { (label, v) ->
            v to TextView(c).apply {
                text = label; textSize = 12.5f; maxLines = 1; gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(0, dp(28), 1f)
                tap { onPick(v) }
            }
        }
        val box = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(TRACK, 12, LINE)
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        chips.forEach { box.addView(it.second) }
        return box to chips
    }

    /** Satu pengaturan: label di atas, kontrol selebar panel di bawahnya. */
    private fun settingRow(title: String, box: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        addView(labelText(title))
        addView(box, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(8) })
    }

    private fun radio(selected: Boolean): View {
        val c: Context = this
        return FrameLayout(c).apply {
            layoutParams = LinearLayout.LayoutParams(dp(14), dp(14))
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setColor(0)
                setStroke(dpf(1.5f), if (selected) ACCENT else GRAY)
            }
            if (selected) {
                addView(
                    View(c).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(ACCENT) } },
                    FrameLayout.LayoutParams(dp(6), dp(6), Gravity.CENTER),
                )
            }
        }
    }

    // ---------- Tools: Chord Finder (di dalam panel HUD) ----------

    private fun buildChordPanel(): LinearLayout {
        val c: Context = this
        val mw = LinearLayout.LayoutParams.MATCH_PARENT; val wc = LinearLayout.LayoutParams.WRAP_CONTENT
        chordList = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(mw, wc)
            spaced(dp(8))
        }
        chordHint = TextView(c).apply {
            textSize = 12f; setTextColor(GRAY)
            layoutParams = LinearLayout.LayoutParams(mw, wc)
        }
        chordClear = ghostBtn("Bersihkan daftar") { ChordTool.clear() }
        return LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            setPadding(dp(16), dp(16), dp(16), dp(16))
            spaced(dp(12))
            addView(LinearLayout(c).apply {   // satu tombol selebar panel
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(mw, wc)
                addView(btn("Pilih file", true) { openChordPicker() })
            })
            addView(chordList)
            addView(chordHint)
            addView(chordClear)
        }
    }

    /** Isi panel Chord Finder sesuai [ChordTool.items]: kiri nama file, kanan akor yang terdeteksi (satu per satu). */
    private fun renderChord() {
        val c: Context = this
        val mw = LinearLayout.LayoutParams.MATCH_PARENT; val wc = LinearLayout.LayoutParams.WRAP_CONTENT
        val list = ChordTool.items.value
        chordList.removeAllViews()
        list.forEach { item ->
            val st = item.st
            val right = TextView(c).apply {
                textSize = 15f; gravity = Gravity.END; typeface = medium()
                setLineSpacing(0f, 1.15f)
                when (st) {
                    is ChordTool.St.Waiting -> { text = "Menunggu"; textSize = 12f; setTextColor(GRAY) }
                    is ChordTool.St.Working -> { text = "${(st.p * 100).toInt()}%"; textSize = 12f; setTextColor(GRAY) }
                    is ChordTool.St.Fail -> { text = st.msg; textSize = 12f; setTextColor(RED) }
                    is ChordTool.St.Done -> {
                        if (st.chords.isEmpty()) { text = "Tidak terdeteksi"; textSize = 12f; setTextColor(GRAY) }
                        else {
                            // akor unik sesuai urutan muncul; dibatasi supaya baris tidak terlalu panjang
                            val shown = st.chords.take(16).joinToString("   ")
                            text = if (st.chords.size > 16) "$shown   …" else shown
                            setTextColor(TXT)
                        }
                    }
                }
            }
            chordList.addView(
                LinearLayout(c).apply {
                    orientation = LinearLayout.HORIZONTAL
                    background = rounded(TRACK, 12, LINE)
                    setPadding(dp(12), dp(10), dp(12), dp(10))
                    layoutParams = LinearLayout.LayoutParams(mw, wc)
                    addView(
                        TextView(c).apply {
                            text = item.name.substringBeforeLast('.')
                            textSize = 13f; setTextColor(TXT); typeface = medium()
                            maxLines = 3; ellipsize = TextUtils.TruncateAt.END
                        },
                        LinearLayout.LayoutParams(0, wc, 1f),
                    )
                    addView(right, LinearLayout.LayoutParams(0, wc, 1.25f).apply { marginStart = dp(12) })
                    if (st is ChordTool.St.Done) tap {
                        getSystemService(ClipboardManager::class.java)
                            ?.setPrimaryClip(ClipData.newPlainText("akor", st.timeline))
                        Toast.makeText(c, "Daftar akor disalin", Toast.LENGTH_SHORT).show()
                    }
                },
            )
        }
        chordHint.text = when {
            list.isEmpty() -> "Pilih file audio atau video, lalu akor yang terdeteksi tampil di sini."
            list.any { it.st is ChordTool.St.Done } -> "Ketuk baris untuk menyalin daftar akor lengkap beserta waktunya."
            else -> ""
        }
        chordHint.visibility = if (chordHint.text.isEmpty()) View.GONE else View.VISIBLE
        chordClear.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
    }

    /** Menjalankan antrean analisis kalau belum jalan dan ada file yang menunggu. */
    private fun kickChord() {
        if (chordJob?.isActive == true) return
        if (ChordTool.items.value.none { it.st is ChordTool.St.Waiting }) return
        chordJob = scope.launch { ChordTool.work(applicationContext) }
    }

    private fun openChordPicker() {
        // panel ditutup dulu: sentuhan di pemilih file dianggap "di luar HUD" dan akan menutup panel juga
        menuOpen = false; syncUi()
        try {   // pemilih file sistem hanya bisa dibuka dari Activity (transparan)
            startActivity(Intent(this, ChordPickActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal membuka pemilih file", Toast.LENGTH_SHORT).show()
            panelMode = 4; menuOpen = true; syncUi()
        }
    }

    // ---------- Tools: TikTok Converter (di dalam panel HUD) ----------

    private var ttPhase = 0   // 0 = isi link, 1 = membaca link, 2 = siap pilih, 3 = mengunduh, 4 = selesai
    private var ttInfo: TikTokInfo? = null
    private var ttMsg: String? = null
    private var ttAudio = false
    private var ttProg = 0f
    private var ttJob: Job? = null
    private lateinit var tiktokWrap: LinearLayout
    private lateinit var ttInput: EditText
    private lateinit var ttPasteBtn: TextView
    private lateinit var ttGoBtn: TextView
    private lateinit var ttStatus: TextView
    private lateinit var ttInfoBox: LinearLayout
    private lateinit var ttTitle: TextView
    private lateinit var ttSub: TextView
    private lateinit var ttBar: ProgressBar
    private lateinit var ttChoices: LinearLayout
    private lateinit var ttVideoBtn: TextView
    private lateinit var ttAudioBtn: TextView
    private lateinit var ttAux: TextView

    // ---------- Tools: BPM Detector (di dalam panel HUD) ----------

    /** Satu baris saja: teks "BPM" di kiri, angka BPM terdeteksi di kanan. */
    private fun buildBpmPanel(): LinearLayout {
        val c: Context = this
        bpmValue = TextView(c).apply {
            text = "--"; textSize = 24f; setTextColor(TXT); maxLines = 1; typeface = medium()
        }
        // waveform audio internal: WaveView yang sama dengan rekam audio, tanpa titik status + waktu
        bpmWave = WaveView(c).apply {
            showHeader = false
            liveSource = { n, lo, hi -> BpmWave.read(n, lo, hi) }
            background = rounded(TRACK, 12, LINE)
        }
        return LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            setPadding(dp(16), dp(16), dp(16), dp(16))
            spaced(dp(16))
            addView(LinearLayout(c).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                addView(TextView(c).apply { text = "BPM"; textSize = 14f; setTextColor(GRAY); typeface = medium() },
                    LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                addView(bpmValue)
            }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            addView(bpmWave, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }
    }

    /** Menggambar ulang waveform BPM ~30x/dtk selama panelnya terlihat. */
    private var bpmWaveRunning = false
    private val bpmWaveTick = object : Runnable {
        override fun run() {
            if (!attached || !menuOpen || panelMode != 3) { bpmWaveRunning = false; return }
            bpmWave.invalidate()
            main.postDelayed(this, 33)
        }
    }

    /** Service deteksi BPM dibiarkan hidup 20 dtk setelah panel ditutup, supaya buka-tutup panel tidak minta izin lagi. */
    private fun bpmSync(open: Boolean) {
        if (open) { main.removeCallbacks(stopBpmSvc); bpmStopPending = false }
        else if (!bpmStopPending && BpmService.running.value) { bpmStopPending = true; main.postDelayed(stopBpmSvc, 20000) }
    }

    private fun onOpenBpm() {
        panelMode = 3; menuOpen = true; syncUi()
        if (BpmService.running.value) return
        try {   // izin rekam layar (untuk menangkap audio internal) diminta lewat activity transparan
            startActivity(
                Intent(this, CaptureActivity::class.java).putExtra(CaptureActivity.X_BPM, true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal membuka izin audio", Toast.LENGTH_SHORT).show()
        }
    }

    private fun buildTikTokPanel(): LinearLayout {
        val c: Context = this
        val mw = LinearLayout.LayoutParams.MATCH_PARENT; val wc = LinearLayout.LayoutParams.WRAP_CONTENT

        ttInput = EditText(c).apply {
            hint = "Tempel link TikTok"; textSize = 14f
            setTextColor(TXT); setHintTextColor(GRAY)
            background = rounded(TRACK, 12, LINE)
            setPadding(dp(14), 0, dp(14), 0)
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            layoutParams = LinearLayout.LayoutParams(mw, dp(44))
            setOnEditorActionListener { _, _, _ -> ttSearch(); true }
            setOnKeyListener { _, code, ev ->
                if (code == KeyEvent.KEYCODE_BACK && ev.action == KeyEvent.ACTION_UP) { hideKeyboard(); true } else false
            }
        }
        ttPasteBtn = btn("Tempel", false) { ttPaste() }
        ttGoBtn = btn("Cari video", true) { ttSearch() }
        ttStatus = TextView(c).apply {
            textSize = 12f; setTextColor(GRAY); maxLines = 6
            layoutParams = LinearLayout.LayoutParams(mw, wc)
        }
        ttTitle = TextView(c).apply { textSize = 14f; setTextColor(TXT); maxLines = 2; ellipsize = TextUtils.TruncateAt.END; typeface = medium() }
        ttSub = TextView(c).apply { textSize = 12f; setTextColor(GRAY); maxLines = 1; setPadding(0, dp(2), 0, 0) }
        ttInfoBox = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(TRACK, 12, LINE)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            layoutParams = LinearLayout.LayoutParams(mw, wc)
            addView(ttTitle); addView(ttSub)
        }
        ttBar = ProgressBar(c, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(ACCENT)
            progressBackgroundTintList = ColorStateList.valueOf(LINE)
            indeterminateTintList = ColorStateList.valueOf(ACCENT)
            layoutParams = LinearLayout.LayoutParams(mw, dp(3))
        }
        ttVideoBtn = btn("Simpan Video", false) { ttSave(false) }
        ttAudioBtn = btn("Simpan Audio", false) { ttSave(true) }
        ttChoices = hRow(ttVideoBtn, ttAudioBtn)
        ttAux = ghostBtn("") {
            if (ttPhase == 3) { ttJob?.cancel(); ttPhase = 2; ttMsg = "Dibatalkan."; syncUi() }
            else { ttPhase = 0; ttInfo = null; ttMsg = null; ttInput.setText(""); syncUi() }
        }
        // ttAux dibungkus supaya renderTikTok() bisa menyembunyikan barisnya tanpa menyentuh panel
        val auxRow = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(mw, wc)
            addView(ttAux)
        }

        return LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            setPadding(dp(16), dp(16), dp(16), dp(16))
            spaced(dp(12))
            addView(ttInput)
            addView(hRow(ttPasteBtn, ttGoBtn))
            addView(ttStatus)
            addView(ttInfoBox)
            addView(ttBar)
            addView(ttChoices)
            addView(auxRow)
        }
    }

    /** Menyelaraskan isi panel TikTok dengan state (ttPhase, ttInfo, ttMsg). Murah: hanya mengubah view. */
    private fun renderTikTok() {
        val busy = ttPhase == 1 || ttPhase == 3
        ttInput.isEnabled = !busy
        ttPasteBtn.isEnabled = !busy; ttPasteBtn.alpha = if (busy) 0.4f else 1f
        ttGoBtn.isEnabled = !busy; ttGoBtn.alpha = if (busy) 0.4f else 1f

        val info = ttInfo
        ttInfoBox.visibility = if (info != null && ttPhase >= 2) View.VISIBLE else View.GONE
        if (info != null) {
            ttTitle.text = info.title
            ttSub.text = listOfNotNull(
                info.author.takeIf { it.isNotBlank() }?.let { "@" + it.removePrefix("@") },
                info.durationSec.takeIf { it > 0 }?.let { Library.fmtTime(it * 1000L) },
            ).joinToString(" · ")
        }
        ttBar.visibility = if (busy) View.VISIBLE else View.GONE
        ttBar.isIndeterminate = ttPhase == 1 || (ttPhase == 3 && ttProg <= 0f)
        if (!ttBar.isIndeterminate) ttBar.progress = (ttProg * 100).toInt()

        ttChoices.visibility = if (ttPhase == 2 || ttPhase == 4) View.VISIBLE else View.GONE
        val vOk = info?.videoUrl != null; val aOk = info?.audioUrl != null
        ttVideoBtn.isEnabled = vOk; ttVideoBtn.alpha = if (vOk) 1f else 0.4f
        ttAudioBtn.isEnabled = aOk; ttAudioBtn.alpha = if (aOk) 1f else 0.4f

        (ttAux.parent as View).visibility = if (ttPhase == 3 || ttPhase == 4) View.VISIBLE else View.GONE
        ttAux.text = if (ttPhase == 3) "Batal" else "Link lain"

        val err = ttPhase == 0 || ttPhase == 2
        ttStatus.setTextColor(if (ttMsg != null && err && ttMsg != "Dibatalkan.") RED else GRAY)
        ttStatus.text = when (ttPhase) {
            1 -> "Membaca link…"
            3 -> (if (ttAudio) "Mengunduh audio… " else "Mengunduh video… ") + if (ttProg > 0f) "${(ttProg * 100).toInt()}%" else ""
            4 -> if (ttAudio) "Audio tersimpan di Music/LayKit/TikTok" else "Video tersimpan di Movies/LayKit/TikTok"
            else -> ttMsg ?: if (ttPhase == 0) "Tempel link video TikTok, lalu ketuk Cari video." else "Pilih mau disimpan sebagai:"
        }
        ttStatus.visibility = if (ttStatus.text.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun hideKeyboard() {
        getSystemService(InputMethodManager::class.java)?.hideSoftInputFromWindow(ttInput.windowToken, 0)
        ttInput.clearFocus()
    }

    private fun readClip(): String? = try {
        getSystemService(ClipboardManager::class.java)?.primaryClip?.takeIf { it.itemCount > 0 }
            ?.getItemAt(0)?.coerceToText(this)?.toString()?.takeIf { it.isNotBlank() }
    } catch (_: Exception) { null }

    private fun ttPaste() {
        val t = readClip()
        if (t == null) {
            ttMsg = "Clipboard kosong atau tidak terbaca. Ketuk kolom lalu tempel manual."
            ttPhase = 0; syncUi(); return
        }
        ttInput.setText(TikTokEngine.extractUrl(t) ?: t)
        ttInput.setSelection(ttInput.text.length)
        ttMsg = null; if (ttPhase != 1 && ttPhase != 3) { ttPhase = 0; ttInfo = null }
        syncUi()
    }

    /** Panel baru dibuka: kalau kolom kosong dan clipboard berisi link TikTok, isi otomatis. Gagal diam-diam (butuh fokus jendela). */
    private fun ttAutoPaste() {
        if (!attached || !menuOpen || panelMode != 2 || ttPhase != 0 || ttInput.text.isNotEmpty()) return
        val url = readClip()?.let { TikTokEngine.extractUrl(it) } ?: return
        if (!TikTokEngine.isTikTokUrl(url)) return
        ttInput.setText(url); syncUi()
    }

    private fun ttSearch() {
        if (ttPhase == 1 || ttPhase == 3) return
        val text = ttInput.text.toString().trim()
        if (text.isEmpty()) { ttMsg = "Tempel link video TikTok dulu."; ttPhase = 0; syncUi(); return }
        hideKeyboard()
        ttMsg = null; ttInfo = null; ttPhase = 1; syncUi()
        ttJob = scope.launch {
            try {
                ttInfo = TikTokEngine.resolve(text); ttPhase = 2
            } catch (e: CancellationException) {
                throw e
            } catch (e: TikTokException) {
                ttMsg = e.message; ttPhase = 0
            } catch (e: Exception) {
                ttMsg = "Kesalahan: ${e.message}"; ttPhase = 0
            }
            syncUi()
        }
    }

    private fun ttSave(audio: Boolean) {
        val info = ttInfo ?: return
        val url = (if (audio) info.audioUrl else info.videoUrl) ?: return
        if (ttPhase == 1 || ttPhase == 3) return
        ttAudio = audio; ttProg = 0f; ttMsg = null; ttPhase = 3; syncUi()
        ttJob = scope.launch {
            try {
                TikTokEngine.save(applicationContext, url, audio, info.title, info.headers) { p ->
                    main.post {
                        if (ttPhase == 3 && attached && menuOpen && panelMode == 2) { ttProg = p; renderTikTok() }
                        else if (ttPhase == 3) ttProg = p
                    }
                }
                ttPhase = 4
                Toast.makeText(applicationContext, if (audio) "Audio tersimpan di Music/LayKit/TikTok" else "Video tersimpan di Movies/LayKit/TikTok", Toast.LENGTH_SHORT).show()
            } catch (e: CancellationException) {
                throw e
            } catch (e: TikTokException) {
                ttMsg = e.message; ttPhase = 2
            } catch (e: Exception) {
                ttMsg = "Kesalahan: ${e.message}"; ttPhase = 2
            }
            syncUi()
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildUi() {
        val c: Context = this
        val r = FrameLayout(c)
        val mw = LinearLayout.LayoutParams.MATCH_PARENT; val wc = LinearLayout.LayoutParams.WRAP_CONTENT

        // ---- bar: [rekam] | [audio internal, mikrofon] | [tools, menu] ----
        recBtn = FrameLayout(c).apply {
            background = rounded(RED, 20)
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
            recDot = View(c).apply { background = rounded(0xFFFFFFFF.toInt(), 6) }
            addView(recDot, FrameLayout.LayoutParams(dp(12), dp(12), Gravity.CENTER))
            tap { onRecord() }
        }
        icoSpk = ico(SolarIcons.VOL).also { it.tap { onToggleInternal() } }
        icoMic = ico(SolarIcons.MIC).also { it.tap { onToggleMic() } }
        icoTools = ico(SolarIcons.TOOLS).also { it.tap { onToggleTools() } }
        icoMore = ico(SolarIcons.MORE).also { it.tap { onToggleMore() } }
        fun sep() = View(c).apply {
            setBackgroundColor(LINE)
            layoutParams = LinearLayout.LayoutParams(dp(1), dp(20)).apply { setMargins(dp(6), 0, dp(6), 0) }
        }
        bar = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = rounded(BG, 24, LINE)
            setPadding(dp(4), dp(4), dp(4), dp(4))
            addView(recBtn); addView(sep())
            addView(icoSpk); addView(icoMic); addView(sep())
            addView(icoTools); addView(icoMore)
        }

        // kartu waveform (rekam audio + pratinjau setelah stop), tepat di bawah bar.
        // Rekam: hanya waveform live. Setelah stop: waveform diam + [putar] di kiri, [buang] [simpan] di kanan.
        waveView = WaveView(c).apply { layoutParams = LinearLayout.LayoutParams(0, wc, 1f) }
        fun cardIco(icon: List<SolarPath>, tint: Int, f: () -> Unit) = SolarView(c, icon, 20f).apply {
            this.tint = tint; background = pressOval(); visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(dp(36), dp(36))
            tap(f)
        }
        icoPlay = cardIco(SolarIcons.PLAY, ACCENT) { togglePlay() }
        icoDiscard = cardIco(SolarIcons.TRASH, GRAY) { onDiscardDraft() }
        icoSave = cardIco(SolarIcons.SAVE, ACCENT) { onSaveDraft() }
        waveView.onSeek = { f, done -> seekTo(f, done) }
        waveCard = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = rounded(BG, 20, LINE); visibility = View.GONE
            setPadding(dp(4), dp(2), dp(4), dp(2))
            layoutParams = LinearLayout.LayoutParams(mw, wc).apply { topMargin = dp(8) }
            addView(icoPlay); addView(waveView); addView(icoDiscard); addView(icoSave)
        }
        barCol = DragLinear(c) { dragEvent(it) }.apply {
            orientation = LinearLayout.VERTICAL
            addView(bar, LinearLayout.LayoutParams(wc, wc))
            addView(waveCard)
        }

        // ---- panel: header seragam (judul + kembali) | isi | footer ----
        // Pengaturan: label di atas, kontrol selebar panel di bawahnya.
        val (modeBox, mChips) = seg(listOf("Video" to 0, "MP3" to 1)) { onPickMode(it == 1) }
        val (resBox, rChips) = seg(listOf("720p" to 720, "1080p" to 1080, "Asli" to 0)) { onPickRes(it) }
        val (oriBox, oChips) = seg(listOf("Auto" to 0, "Potret" to 1, "Lanskap" to 2)) { onPickOrient(it) }
        val (fpsBox, fChips) = seg(listOf("30" to 30, "60" to 60)) { onPickFps(it) }
        modeChips = mChips; resChips = rChips; orientChips = oChips; fpsChips = fChips

        vidBlock = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            spaced(dp(16))
            addView(settingRow("Resolusi", resBox)); addView(settingRow("Orientasi", oriBox)); addView(settingRow("FPS", fpsBox))
        }
        secMode = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            spaced(dp(16))
            addView(settingRow("Mode", modeBox))
            addView(vidBlock)
        }

        dots = List(5) {
            View(c).apply {
                layoutParams = LinearLayout.LayoutParams(dp(12), dp(4)).apply { setMargins(dpf(1.5f), 0, dpf(1.5f), 0) }
                background = rounded(DOT_OFF, 2)
            }
        }
        val dotsRow = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            dots.forEach { addView(it) }
        }
        val micHead = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(labelText("Mikrofon"), LinearLayout.LayoutParams(0, wc, 1f))
            addView(dotsRow)
        }
        devList = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(4), 0, 0) }
        micWrap = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            addView(hLine())
            addView(LinearLayout(c).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), dp(16), dp(16), dp(8))
                addView(micHead); addView(devList)
            })
        }

        // Tools: satu baris per tool (ikon + nama). Baris baru tinggal ditambah lewat toolRow().
        fun toolRow(label: String, icon: List<SolarPath>, f: () -> Unit) = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = pressRect()
            setPadding(dp(16), 0, dp(16), 0)
            layoutParams = LinearLayout.LayoutParams(mw, dp(48))
            addView(SolarView(c, icon, 20f).apply { layoutParams = LinearLayout.LayoutParams(dp(20), dp(20)) })
            addView(TextView(c).apply { text = label; textSize = 14f; setTextColor(TXT); maxLines = 1; setPadding(dp(14), 0, 0, 0) })
            tap(f)
        }
        toolsWrap = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            setPadding(0, dp(4), 0, dp(4))
            addView(toolRow("TikTok Converter", SolarIcons.CONVERT) {
                panelMode = 2; menuOpen = true; syncUi()
                main.postDelayed({ ttAutoPaste() }, 400)   // jendela baru jadi fokus: isi otomatis kalau clipboard berisi link TikTok
            })
            addView(toolRow("BPM Detector", SolarIcons.BPM) { onOpenBpm() })
            addView(toolRow("Chord Finder", SolarIcons.CHORD) { panelMode = 4; menuOpen = true; syncUi() })
        }
        panelContent = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            tiktokWrap = buildTikTokPanel()
            bpmWrap = buildBpmPanel()
            chordWrap = buildChordPanel()
            addView(secMode); addView(micWrap); addView(toolsWrap); addView(tiktokWrap); addView(bpmWrap); addView(chordWrap)
        }

        // header: judul halaman; di sub-halaman (TikTok, BPM, Chord Finder) muncul tombol kembali ke Tools
        panelBack = SolarView(c, SolarIcons.CHEV, 20f).apply {
            rotation = 90f   // ikon chevron yang sama, diputar menghadap kiri
            background = pressOval(); visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(dp(36), dp(36))
            tap { panelMode = 1; syncUi() }
        }
        panelTitle = TextView(c).apply { textSize = 15f; setTextColor(TXT); maxLines = 1; typeface = medium() }
        panelHeadRow = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), 0, dp(16), 0)
            layoutParams = LinearLayout.LayoutParams(mw, dp(48))
            addView(panelBack)
            addView(panelTitle, LinearLayout.LayoutParams(0, wc, 1f).apply { marginStart = dp(4) })
        }
        panelHead = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            addView(panelHeadRow); addView(hLine())
        }

        fun footBtn(label: String, icon: List<SolarPath>, f: () -> Unit) = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            background = pressRect()
            layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f)
            addView(SolarView(c, icon, 18f).apply { layoutParams = LinearLayout.LayoutParams(dp(18), dp(18)) })
            addView(TextView(c).apply { text = label; textSize = 13f; setTextColor(TXT); maxLines = 1; setPadding(dp(8), 0, 0, 0) })
            tap(f)
        }
        panelFooter = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            addView(hLine())
            addView(LinearLayout(c).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(footBtn("Layar utama", SolarIcons.HOME) { menuOpen = false; syncUi(); openApp("home") })
                addView(View(c).apply { setBackgroundColor(LINE) }, LinearLayout.LayoutParams(dp(1), LinearLayout.LayoutParams.MATCH_PARENT))
                addView(footBtn("Tutup HUD", SolarIcons.CLOSE) { shutdown() })
            })
        }

        // isi panel bisa digulir kalau layar tidak cukup tinggi; header + footer tetap menempel
        val scroll = ScrollView(c).apply {
            isVerticalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER
            addView(panelContent)
        }
        panelBox = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            background = rounded(BG, 20, LINE); clipToOutline = true
            setPadding(dp(1), dp(1), dp(1), dp(1))
            addView(panelHead)
            addView(scroll, LinearLayout.LayoutParams(mw, 0, 1f))
            addView(panelFooter)
        }

        // ukuran dan posisi bar + panel diatur ulang tiap kali oleh layoutHud()
        r.addView(panelBox, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START))
        r.addView(barCol, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START))
        // sentuhan di luar HUD menutup panel (FLAG_WATCH_OUTSIDE_TOUCH)
        r.setOnTouchListener { _, e ->
            // saat mengetik di kolom link, sentuhan (mis. di keyboard) tidak boleh menutup panel
            if (e.actionMasked == MotionEvent.ACTION_OUTSIDE && menuOpen && !(panelMode == 2 && ttInput.hasFocus())) { menuOpen = false; syncUi() }
            false
        }
        root = r

        val (px, py) = RecPrefs.hudPos(this)
        barX = if (px >= 0) px else dp(12)
        barY = if (py >= 0) py else resources.displayMetrics.heightPixels / 4
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = barX; y = barY
        }
    }

    // seret: seluruh bar bisa digeser. Ketukan tetap sampai ke tombol; baru setelah jari bergeser melewati
    // batas "slop" sentuhan diambil alih. Yang digeser adalah posisi bar (barX/barY); panel mengikuti.
    private var dX = 0f; private var dY = 0f; private var dSx = 0; private var dSy = 0; private var dragging = false

    private fun dragEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { dX = e.rawX; dY = e.rawY; dSx = barX; dSy = barY; dragging = false }
            MotionEvent.ACTION_MOVE -> {
                val mx = e.rawX - dX; val my = e.rawY - dY
                val slop = ViewConfiguration.get(this).scaledTouchSlop
                if (!dragging && (abs(mx) > slop || abs(my) > slop)) dragging = true
                if (dragging) {
                    barX = (dSx + mx).toInt(); barY = (dSy + my).toInt()
                    if (attached) layoutHud()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val was = dragging
                if (was) RecPrefs.saveHudPos(this, barX, barY)
                dragging = false
                return was
            }
        }
        return dragging
    }

    /** Menyelaraskan tampilan dengan state (pengaturan, mic, menu terbuka/tutup). */
    private fun syncUi() {
        val rec = isRec()
        val draft = RecorderService.draft.value
        val review = draft != null
        if (rec) menuOpen = false
        recDot.background = rounded(0xFFFFFFFF.toInt(), if (rec) 3 else 6)   // bulat = rekam, kotak = stop
        // kartu waveform: tampil saat merekam dan saat menunggu keputusan simpan / buang
        waveCard.visibility = if (rec || review) View.VISIBLE else View.GONE
        val rv = if (review) View.VISIBLE else View.GONE
        icoPlay.visibility = rv; icoDiscard.visibility = rv; icoSave.visibility = rv
        waveView.review = review
        if (draft != null) { waveView.totalSec = draft.seconds; waveView.invalidate() }
        icoPlay.icon = if (player?.isPlaying == true) SolarIcons.PAUSE else SolarIcons.PLAY
        recBtn.alpha = if (review) 0.4f else 1f   // rekam baru baru bisa setelah rekaman ini diputuskan
        icoSpk.alpha = if (rec) 0.4f else 1f; icoMic.alpha = if (rec) 0.4f else 1f; icoMore.alpha = if (rec) 0.4f else 1f
        icoTools.alpha = if (rec) 0.4f else 1f
        if (attached && rec) { if (!waveRunning) { waveRunning = true; main.post(waveTick) } }
        icoSpk.icon = if (s.internal) SolarIcons.VOL else SolarIcons.VOL_X
        icoSpk.tint = if (s.internal) ACCENT else GRAY
        icoMic.icon = if (s.mic) SolarIcons.MIC_BOLD else SolarIcons.MIC
        icoMic.tint = if (s.mic) ACCENT else GRAY
        icoMic.slash = !s.mic
        icoMore.tint = TXT; icoMore.isSelected = menuOpen && panelMode == 0        // menu terbuka = lingkaran abu di belakang ikon
        icoTools.tint = TXT; icoTools.isSelected = menuOpen && panelMode != 0

        modeChips.forEach { (v, t) -> styleSeg(t, (v == 1) == s.audioOnly) }
        resChips.forEach { (v, t) -> styleSeg(t, v == s.res) }
        orientChips.forEach { (v, t) -> styleSeg(t, v == s.orient) }
        fpsChips.forEach { (v, t) -> styleSeg(t, v == s.fps) }
        vidBlock.visibility = if (s.audioOnly) View.GONE else View.VISIBLE   // mode MP3: opsi video disembunyikan

        secMode.visibility = if (panelMode == 0) View.VISIBLE else View.GONE
        toolsWrap.visibility = if (panelMode == 1) View.VISIBLE else View.GONE
        tiktokWrap.visibility = if (panelMode == 2) View.VISIBLE else View.GONE
        bpmWrap.visibility = if (panelMode == 3) View.VISIBLE else View.GONE
        chordWrap.visibility = if (panelMode == 4) View.VISIBLE else View.GONE
        panelTitle.text = when (panelMode) { 0 -> "Pengaturan"; 1 -> "Tools"; 2 -> "TikTok Converter"; 3 -> "BPM Detector"; else -> "Chord Finder" }
        panelBack.visibility = if (panelMode >= 2) View.VISIBLE else View.GONE
        panelHeadRow.setPadding(if (panelMode >= 2) dp(8) else dp(16), 0, dp(16), 0)
        if (panelMode == 2) renderTikTok()
        if (panelMode == 4) renderChord()
        if (!(menuOpen && panelMode == 2) && ttInput.hasFocus()) hideKeyboard()
        if (menuOpen && panelMode == 0) { devs = inputDevices(); buildDevList() }   // daftar mic hanya perlu dibangun saat menu terbuka
        micWrap.visibility = if (s.mic && panelMode == 0) View.VISIBLE else View.GONE
        panelBox.visibility = if (menuOpen) View.VISIBLE else View.GONE

        // level mic hanya terlihat di panel, jadi pengukur hanya jalan saat menu terbuka
        if (attached && menuOpen && panelMode == 0 && s.mic) startMeter() else stopMeter()
        bpmSync(attached && menuOpen && panelMode == 3)
        if (attached && menuOpen && panelMode == 3 && !bpmWaveRunning) { bpmWaveRunning = true; main.post(bpmWaveTick) }
        fitWindow()
    }

    private fun fitWindow() {
        val r = root ?: return
        if (!attached) return
        layoutHud()
        // ukur ulang sekali lagi setelah tata letak selesai (teks baru final di sini)
        r.post { if (attached) layoutHud() }
    }

    /**
     * Menghitung posisi bar + panel, lalu membuat satu jendela overlay seukuran gabungan keduanya.
     * - Bar tetap di barX/barY (tidak melompat saat menu dibuka/ditutup).
     * - Panel dipasang di bawah bar kalau muat, kalau tidak di atas, kalau tidak di sisi yang lebih lega.
     * - Panel ditengahkan terhadap bar lalu digeser agar tetap di dalam layar.
     * - Kalau tetap tidak muat, isi panel digulir; footer tetap terlihat.
     */
    private fun layoutHud() {
        val r = root ?: return
        if (!attached) return
        val dm = resources.displayMetrics
        val sw = dm.widthPixels; val sh = dm.heightPixels
        val m = dp(8); val g = dp(8)
        val unspec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)

        barCol.measure(unspec, unspec)
        val bw = barCol.measuredWidth; val bh = barCol.measuredHeight
        if (bw <= 0 || bh <= 0) return
        barX = barX.coerceIn(0, maxOf(0, sw - bw))
        barY = barY.coerceIn(0, maxOf(0, sh - bh))

        var winL = barX; var winT = barY; var winR = barX + bw; var winB = barY + bh
        var panelL = 0; var panelT = 0; var pw = 0; var ph = 0
        if (menuOpen) {
            pw = minOf(dp(272), sw - 2 * m)
            val innerW = View.MeasureSpec.makeMeasureSpec(pw - dp(2), View.MeasureSpec.EXACTLY)
            panelContent.measure(innerW, unspec)
            panelFooter.measure(innerW, unspec)
            panelHead.measure(innerW, unspec)
            val natural = panelHead.measuredHeight + panelContent.measuredHeight + panelFooter.measuredHeight + dp(2)
            val below = sh - (barY + bh) - g - m
            val above = barY - g - m
            val useBelow = when {
                natural <= below -> true
                natural <= above -> false
                else -> below >= above
            }
            ph = minOf(natural, maxOf(dp(96), if (useBelow) below else above))
            panelL = (barX + (bw - pw) / 2).coerceIn(m, maxOf(m, sw - m - pw))
            panelT = if (useBelow) barY + bh + g else barY - g - ph
            panelT = panelT.coerceIn(0, maxOf(0, sh - ph))
            winL = minOf(winL, panelL); winT = minOf(winT, panelT)
            winR = maxOf(winR, panelL + pw); winB = maxOf(winB, panelT + ph)
        }

        barCol.layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START)
            .apply { leftMargin = barX - winL; topMargin = barY - winT }
        if (menuOpen) {
            panelBox.layoutParams = FrameLayout.LayoutParams(pw, ph, Gravity.TOP or Gravity.START)
                .apply { leftMargin = panelL - winL; topMargin = panelT - winT }
        }
        // jendela HUD biasanya tidak bisa fokus (tidak mencuri fokus dari app lain); panel TikTok butuh fokus untuk keyboard + clipboard
        val needFocus = menuOpen && panelMode == 2
        lp.flags = if (needFocus) lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        else lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        lp.softInputMode = if (needFocus) WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN else WindowManager.LayoutParams.SOFT_INPUT_ADJUST_UNSPECIFIED
        lp.x = winL; lp.y = winT
        lp.width = winR - winL; lp.height = winB - winT
        try { wm.updateViewLayout(r, lp) } catch (_: Exception) { /* jendela sudah lepas */ }
    }

    private fun buildDevList() {
        val c: Context = this
        devList.removeAllViews()
        val rows = listOf(-1 to devLabel(-1)) + devs.map { it.id to devLabel(it.id) }
        rows.forEach { (id, label) ->
            val sel = id == s.micDev
            devList.addView(
                LinearLayout(c).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(40))
                    addView(radio(sel))
                    addView(
                        TextView(c).apply {
                            text = label; textSize = 14f; maxLines = 1; ellipsize = TextUtils.TruncateAt.END
                            setTextColor(if (sel) TXT else GRAY); setPadding(dp(12), 0, 0, 0)
                        },
                        LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f),
                    )
                    tap {
                        s = s.copy(micDev = id); RecPrefs.save(c, s)
                        stopMeter(); syncUi()
                    }
                },
            )
        }
    }

    private fun inputDevices(): List<AudioDeviceInfo> =
        getSystemService(AudioManager::class.java).getDevices(AudioManager.GET_DEVICES_INPUTS).filter { it.type in MIC_TYPES }

    private fun devLabel(id: Int): String {
        val d = devs.firstOrNull { it.id == id }
        if (d == null) {
            val b = devs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_MIC }
            return if (b != null) "Default - ${b.productName}" else "Default"
        }
        val kind = when (d.type) {
            AudioDeviceInfo.TYPE_BUILTIN_MIC -> "Bawaan"
            AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Kabel"
            AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET -> "USB"
            else -> "Bluetooth"
        }
        return "${d.productName} ($kind)"
    }

    // ---------- level mic ----------

    private fun hasMicPerm() = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun setLevel(l: Double) {
        val lit = (l * dots.size + 0.5).toInt()
        dots.forEachIndexed { i, v -> (v.background as? GradientDrawable)?.setColor(if (i < lit) ACCENT else DOT_OFF) }
    }

    @SuppressLint("MissingPermission")
    private fun startMeter() {
        if (meterOn || !hasMicPerm()) return
        meterOn = true
        val my = ++gen
        val dev = devs.firstOrNull { it.id == s.micDev }
        thread(name = "hud-meter") {
            var ar: AudioRecord? = null
            try {
                val sr = 16000
                val buf = maxOf(AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT), 4096)
                ar = AudioRecord.Builder().setAudioSource(MediaRecorder.AudioSource.MIC)
                    .setAudioFormat(
                        AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build(),
                    )
                    .setBufferSizeInBytes(buf).build()
                if (ar.state != AudioRecord.STATE_INITIALIZED) return@thread
                if (dev != null) ar.setPreferredDevice(dev)
                ar.startRecording()
                val sh = ShortArray(1024)
                while (gen == my) {
                    val n = ar.read(sh, 0, sh.size)
                    if (n <= 0) break
                    var sum = 0.0
                    for (k in 0 until n) { val v = sh[k].toDouble(); sum += v * v }
                    val rms = sqrt(sum / n)
                    val db = if (rms < 1.0) -90.0 else 20 * log10(rms / 32768.0)
                    val lvl = ((db + 60) / 60).coerceIn(0.0, 1.0)
                    main.post { if (gen == my) setLevel(lvl) }
                }
            } catch (_: Exception) {
                // mic dipakai app lain / gagal dibuka: level diam saja
            } finally {
                try { ar?.stop() } catch (_: Exception) {}
                try { ar?.release() } catch (_: Exception) {}
                main.post { if (gen == my) meterOn = false }
            }
        }
    }

    private fun stopMeter() {
        gen++
        meterOn = false
        if (::dots.isInitialized) setLevel(0.0)
    }
}

// ---------- tampilan ikon Solar + bar yang bisa digeser ----------

private class SolarView(c: Context, icon: List<SolarPath>, private val iconDp: Float = 20f) : View(c) {
    var icon: List<SolarPath> = icon
        set(v) { field = v; invalidate() }
    var tint: Int = 0xFFF2F2F3.toInt()
        set(v) { field = v; invalidate() }
    var slash: Boolean = false
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(cv: Canvas) {
        val px = iconDp * resources.displayMetrics.density
        val sc = px / 24f
        cv.save()
        cv.translate((width - px) / 2f, (height - px) / 2f)
        cv.scale(sc, sc)
        p.color = tint
        p.strokeWidth = 1.5f; p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        for (sp in icon) {
            p.style = if (sp.fill) Paint.Style.FILL else Paint.Style.STROKE
            cv.drawPath(sp.path, p)
        }
        if (slash) {   // mic mati: coretan diagonal
            p.style = Paint.Style.STROKE
            cv.drawLine(4f, 4f, 20f, 20f, p)
        }
        cv.restore()
    }
}

/** Bar horizontal yang mengambil alih sentuhan begitu jari bergeser (untuk menggeser HUD). */
private class DragLinear(c: Context, private val ev: (MotionEvent) -> Boolean) : LinearLayout(c) {
    override fun onInterceptTouchEvent(e: MotionEvent): Boolean = ev(e)
    override fun onTouchEvent(e: MotionEvent): Boolean { ev(e); return true }
}

/**
 * Waveform rekaman audio, cara gambarnya sama dengan drawWave di playlist-canvas.ts (akuhanya):
 * envelope min/max per kolom, SATU KOLOM = SATU PIKSEL (bukan batang bersela), tanpa antialias, jadi gelombang tampil
 * sebagai siluet padat yang mengikuti bentuk sinyal. Garis dasar tipis (alpha 0.45).
 * Mode 'top' (default akuhanya): hanya sisi atas, puncak = |max| atau |min| terbesar per kolom, tumbuh ke atas dari
 * garis dasar di dekat dasar kartu. Ubah [WAVE_TOP] ke false untuk mode simetris atas + bawah dari tengah ('normal').
 *
 * Dua tampilan:
 * - live: jendela waktu terakhir, kolom paling kanan = suara paling baru, bergeser ke kiri seiring waktu.
 * - [review]: diam, SELURUH rekaman diperkecil ke lebar kartu (tiap kolom = min/max irisan di dalamnya); bagian yang
 *   sudah diputar terang, sisanya redup, dengan garis penanda posisi. Sentuh / geser = pilih posisi putar.
 *
 * Zoom (hanya render, hasil rekaman tidak diubah): skala linear akuhanya dikali gain otomatis mengikuti puncak yang terlihat, jadi suara mic yang kecil pun
 * memenuhi kartu. Di mode live gain naik pelan dan turun seketika kalau ada suara keras.
 */
private class WaveView(c: Context) : View(c) {
    var seconds: Int = 0          // live: lama rekaman
    var paused: Boolean = false
    var review: Boolean = false
        set(v) { if (field != v) { field = v; ovKey = -1; invalidate() } }
    var totalSec: Int = 0         // review: lama rekaman
    var posSec: Int = 0           // review: posisi putar
    var progress: Float = 0f      // review: 0..1, 0 = belum diputar
    var seeking: Boolean = false  // review: jari sedang menggeser playhead
    var onSeek: ((Float, Boolean) -> Unit)? = null   // (posisi 0..1, selesai?)
    var showHeader = true         // false = tanpa titik status + waktu (dipakai BPM Detector)
    var liveSource: (Int, FloatArray, FloatArray) -> Int = { c, a, b -> LiveWave.read(c, a, b) }
    private var gx0 = 0f; private var gw = 1f        // area gambar terakhir, untuk memetakan sentuhan ke posisi

    companion object {
        private const val INK = 0xFFF2F2F3.toInt()
        private const val WAVE_TOP = false     // false = simetris atas + bawah dari tengah (normal); true = hanya sisi atas
        private const val HEADROOM = 0.65f     // puncak terbesar diskalakan sampai 65% tinggi gelombang (sisanya lega, tidak mentok)
        private const val MIN_GAIN = 1.5f      // gain render minimal (hanya tampilan, audio tidak berubah)
        private const val MAX_GAIN = 12f       // batas atas supaya desis halus tidak tampak seperti suara
        private const val SILENCE = 0.012f     // di bawah ini dianggap sunyi (tidak di-zoom naik)
    }

    private val d = resources.displayMetrics.density
    private val col = Paint().apply { color = INK; isAntiAlias = false }          // 1 kolom = 1 piksel, tepi tajam
    private val baseLine = Paint().apply { color = INK; alpha = 115 }              // 0.45
    private val head = Paint().apply { color = 0xFFE6E8EE.toInt() }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF8A8F9C.toInt(); textSize = 11f * resources.displayMetrics.scaledDensity
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private var mn = FloatArray(LiveWave.CAP)
    private var mx = FloatArray(LiveWave.CAP)
    private var gain = MIN_GAIN
    private var ovKey = -1L          // cache gambaran rekaman utuh: (jumlah kolom, jumlah irisan)

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(resolveSize(0, w), ((if (showHeader) 52 else 48) * d + 0.5f).toInt())
    }

    private fun fmt(s: Int) = "%02d:%02d".format(s / 60, s % 60)

    /** Review: sentuh = pilih posisi putar, geser = scrub. Sentuhan diambil dari bar induk supaya HUD tidak ikut bergeser. */
    @android.annotation.SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!review) return false
        val f = ((e.x - gx0) / gw).coerceIn(0f, 1f)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { parent?.requestDisallowInterceptTouchEvent(true); seeking = true; onSeek?.invoke(f, false) }
            MotionEvent.ACTION_MOVE -> onSeek?.invoke(f, false)
            MotionEvent.ACTION_UP -> { seeking = false; onSeek?.invoke(f, true) }
            MotionEvent.ACTION_CANCEL -> { seeking = false; onSeek?.invoke(f, true) }
        }
        return true
    }

    override fun onDraw(cv: Canvas) {
        val padX = (if (review) 4 else 10) * d
        val cols = (width - 2 * padX).toInt().coerceIn(1, LiveWave.CAP)           // 1 kolom = 1 piksel
        val x0 = Math.round(padX + ((width - 2 * padX) - cols) / 2f).toFloat()
        gx0 = x0; gw = cols.toFloat()

        // baris atas: waktu (live: titik status + waktu; review: posisi bila dipilih/diputar, selain itu total)
        val ty = 12 * d + txt.textSize * 0.35f
        if (!showHeader) {
            // tanpa header
        } else if (review) {
            cv.drawText(fmt(if (progress > 0f) posSec else totalSec), padX + 2 * d, ty, txt)
        } else {
            dot.color = if (paused) 0xFF8A8F9C.toInt() else 0xFFE5484D.toInt()
            cv.drawCircle(padX + 3 * d, 12 * d, 3 * d, dot)
            cv.drawText(fmt(seconds), padX + 11 * d, ty, txt)
        }

        // area gelombang di bawah baris waktu
        val bodyY = (if (showHeader) 20 else 4) * d; val bodyH = height - bodyY - 3 * d
        val mid = bodyY + bodyH / 2f
        val base = if (WAVE_TOP) bodyY + bodyH * 0.94f else mid
        val amp = if (WAVE_TOP) bodyH * 0.92f else bodyH / 2f - 0.5f

        if (review) {
            val key = cols.toLong() * 1_000_000L + LiveWave.total()
            if (key != ovKey) { LiveWave.overview(cols, mn, mx); ovKey = key }
        } else {
            liveSource(cols, mn, mx)
        }

        // zoom otomatis mengikuti puncak yang terlihat
        var peak = 0f
        for (i in 0 until cols) {
            if (mx[i] > peak) peak = mx[i]
            if (-mn[i] > peak) peak = -mn[i]
        }
        val target = if (peak < SILENCE) MIN_GAIN else (HEADROOM / peak).coerceIn(MIN_GAIN, MAX_GAIN)
        gain = when {
            review || target < gain -> target                  // review: pas; live: turun seketika
            else -> gain + (target - gain) * 0.08f             // live: naik pelan
        }

        val by = Math.round(base).toFloat()
        cv.drawRect(x0, by - 1f, x0 + cols, by, baseLine)                           // garis dasar 1 px
        val split = if (review && progress > 0f) (progress * cols).toInt() else cols
        for (i in 0 until cols) {
            val x = x0 + i
            col.alpha = if (i < split) 255 else 110                                 // belum diputar = redup
            if (WAVE_TOP) {
                val m = maxOf(mx[i], -mn[i]) * gain
                val h = m.coerceAtMost(1f) * amp
                if (h >= 0.5f) cv.drawRect(x, base - h, x + 1f, base, col)
            } else {
                val up = (mx[i] * gain).coerceAtMost(1f) * amp
                val dn = (-mn[i] * gain).coerceAtMost(1f) * amp
                if (up + dn >= 0.5f) cv.drawRect(x, base - up, x + 1f, base + dn, col)
            }
        }
        if (review && progress > 0f) {
            val px = x0 + progress * cols
            cv.drawRect(px - 0.75f * d, bodyY - 1 * d, px + 0.75f * d, height - 2 * d, head)
        }
    }
}
