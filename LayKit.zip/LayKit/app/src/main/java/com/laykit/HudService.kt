package com.laykit

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.launch
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.sqrt

/**
 * HUD melayang (bar gelap membulat) untuk mulai merekam dari app mana pun.
 * Mode video: tampil hanya saat IDLE. Begitu Record ditekan HUD dilepas total dari layar,
 * jadi tidak pernah ikut terekam; muncul lagi setelah rekaman selesai disimpan.
 * Mode audio saja (MP3): tidak ada tangkapan layar, jadi HUD tetap tampil selama merekam dan
 * menampilkan waveform real-time di bawah bar. Tombol rekam berubah jadi Stop.
 * Setelah Stop, kartu waveform tidak hilang: gambarnya diam (seluruh rekaman) dengan tombol putar pratinjau di kiri
 * dan ikon buang + simpan di kanan. Rekaman baru masuk Music/LayKit kalau dipilih simpan.
 */
class HudService : Service() {

    companion object {
        const val A_SHOW = "com.laykit.HUD_SHOW"
        const val A_CLOSE = "com.laykit.HUD_CLOSE"

        /** true selama HUD hidup: RecorderService memakainya untuk memutuskan menahan rekaman audio (pratinjau) atau langsung menyimpan. */
        @Volatile var active = false

        /** true dari Record ditekan sampai rekaman benar-benar jalan (atau dibatalkan): HUD disembunyikan. */
        val launching = MutableStateFlow(false)

        /** dinaikkan CaptureActivity setelah izin mic beres, supaya HUD membaca ulang pengaturan. */
        val refresh = MutableStateFlow(0)

        private const val CH = "hud"
        private const val NID = 2

        private const val BG = 0xFF181A20.toInt()
        private const val LINE = 0xFF2C303A.toInt()
        private const val TRACK = 0xFF101217.toInt()
        private const val PRESS = 0xFF262932.toInt()
        private const val TXT = 0xFFE6E8EE.toInt()
        private const val GRAY = 0xFF8A8F9C.toInt()
        private const val ACCENT = 0xFF4D7CFF.toInt()
        private const val DOT_OFF = 0xFF3A3D48.toInt()
        private const val RED = 0xFFE5484D.toInt()

        /** Dipanggil setelah rekaman diizinkan: kalau 8 dtk kemudian masih IDLE (gagal mulai), HUD dimunculkan lagi. */
        fun releaseLaunchLater() {
            Handler(Looper.getMainLooper()).postDelayed({
                if (RecorderService.ui.value.phase == Phase.IDLE) launching.value = false
            }, 8000)
        }

        // TYPE_BLE_HEADSET = 26 (API 31)
        private val MIC_TYPES = setOf(
            AudioDeviceInfo.TYPE_BUILTIN_MIC, AudioDeviceInfo.TYPE_WIRED_HEADSET,
            AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET,
            AudioDeviceInfo.TYPE_BLUETOOTH_SCO, 26,
        )
    }

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var root: FrameLayout? = null
    private var attached = false
    private var wanted = false
    private var menuOpen = false      // panel (menu / Tools) terbuka
    private var panelMode = 0         // isi panel: 0 = menu (titik tiga), 1 = Tools
    private var s = RecSettings()
    private var devs: List<AudioDeviceInfo> = emptyList()

    // posisi bar di layar (px). Jendela overlay dihitung dari bar + panel, jadi bar tidak melompat saat menu dibuka.
    private var barX = 0
    private var barY = 0
    private lateinit var bar: LinearLayout
    private lateinit var barCol: LinearLayout       // bar + waveform di bawahnya (satu blok yang digeser / dijadikan acuan panel)
    private lateinit var waveCard: LinearLayout    // kartu waveform: [putar] [waveform] [buang] [simpan]
    private lateinit var waveView: WaveView
    private lateinit var recBtn: FrameLayout
    private lateinit var icoPlay: SolarView
    private lateinit var icoDiscard: SolarView
    private lateinit var icoSave: SolarView
    private lateinit var recDot: View
    private var player: MediaPlayer? = null
    private val playTick = object : Runnable {
        override fun run() {
            val p = player ?: return
            try {
                if (waveView.seeking) { main.postDelayed(this, 33); return }
                val dur = p.duration.coerceAtLeast(1)
                waveView.progress = (p.currentPosition.toFloat() / dur).coerceIn(0f, 1f)
                waveView.posSec = p.currentPosition / 1000
                waveView.invalidate()
            } catch (_: Exception) { /* player sedang dilepas */ }
            main.postDelayed(this, 33)
        }
    }
    private var waveRunning = false
    private val waveTick = object : Runnable {
        override fun run() {
            if (!attached || !isRec()) { waveRunning = false; return }
            val u = RecorderService.ui.value
            waveView.seconds = u.seconds
            waveView.paused = u.phase == Phase.PAUSED
            waveView.invalidate()
            main.postDelayed(this, 33)
        }
    }
    private lateinit var panelBox: LinearLayout
    private lateinit var panelContent: LinearLayout
    private lateinit var panelFooter: LinearLayout
    private lateinit var vidBlock: LinearLayout     // resolusi, orientasi, fps (disembunyikan di mode MP3)
    private lateinit var micWrap: LinearLayout      // bagian mikrofon di panel (muncul saat mic aktif)
    private lateinit var devList: LinearLayout
    private lateinit var dots: List<View>
    private lateinit var icoSpk: SolarView
    private lateinit var icoMic: SolarView
    private lateinit var icoMore: SolarView
    private lateinit var icoTools: SolarView
    private lateinit var secMode: LinearLayout     // isi panel menu: mode, resolusi, ...
    private lateinit var toolsWrap: LinearLayout   // isi panel Tools
    private var modeChips: List<Pair<Int, TextView>> = emptyList()
    private var resChips: List<Pair<Int, TextView>> = emptyList()
    private var orientChips: List<Pair<Int, TextView>> = emptyList()   // 0 auto, 1 potret, 2 lanskap
    private var fpsChips: List<Pair<Int, TextView>> = emptyList()

    // pengukur level mic
    @Volatile private var gen = 0
    private var meterOn = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WindowManager::class.java)
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CH, "HUD perekam", NotificationManager.IMPORTANCE_MIN))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == A_CLOSE) { shutdown(); return START_NOT_STICKY }
        startFg()
        if (!Settings.canDrawOverlays(this)) { shutdown(); return START_NOT_STICKY }
        if (!wanted) {
            wanted = true
            active = true
            s = RecPrefs.load(this)
            buildUi()
            scope.launch {
                combine(RecorderService.ui, launching, RecorderService.draft) { u, l, d ->
                    (u.phase == Phase.IDLE && !l) || d != null ||
                        (u.audio && (u.phase == Phase.RECORDING || u.phase == Phase.PAUSED || u.phase == Phase.SAVING))
                }
                    .collect { if (it) showHud() else hideHud() }
            }
            scope.launch {
                // draft berubah (muncul / disimpan / dibuang / diganti): pemutar dihentikan, kartu disesuaikan
                RecorderService.draft.collect { stopPlayer(); if (attached) syncUi() }
            }
            scope.launch {
                RecorderService.ui.collect { if (it.phase != Phase.IDLE && launching.value) launching.value = false }
            }
            scope.launch {
                refresh.drop(1).collect { s = RecPrefs.load(this@HudService); syncUi() }
            }
        } else {
            showHud()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        wanted = false
        active = false
        flushDraft()
        hideHud()
        scope.cancel()
        super.onDestroy()
    }

    private fun startFg() {
        val n = notif()
        if (Build.VERSION.SDK_INT >= 34) {
            ServiceCompat.startForeground(this, NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NID, n)
        }
    }

    private fun notif(): Notification {
        val close = PendingIntent.getService(
            this, 10, Intent(this, HudService::class.java).setAction(A_CLOSE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("HUD LayKit aktif")
            .setContentText("Ketuk Tutup untuk menyembunyikan HUD")
            .setOngoing(true).setPriority(NotificationCompat.PRIORITY_MIN)
            .addAction(0, "Tutup", close)
            .build()
    }

    private fun shutdown() {
        wanted = false
        active = false
        flushDraft()
        hideHud()
        scope.cancel()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ---------- tampil / sembunyi ----------

    private fun showHud() {
        val r = root ?: return
        if (!wanted) return
        if (attached) { syncUi(); return }
        try { wm.addView(r, lp); attached = true } catch (e: Exception) { shutdown(); return }
        syncUi()
    }

    private fun hideHud() {
        menuOpen = false
        stopMeter()
        stopPlayer()
        main.removeCallbacks(waveTick); waveRunning = false
        val r = root
        if (r != null && attached) { try { wm.removeView(r) } catch (_: Exception) { /* sudah lepas */ } }
        attached = false
    }

    // ---------- aksi ----------

    private fun isRec(): Boolean {
        val u = RecorderService.ui.value
        return u.audio && (u.phase == Phase.RECORDING || u.phase == Phase.PAUSED)
    }

    private fun onRecord() {
        if (RecorderService.draft.value != null) return   // rekaman sebelumnya harus diputuskan dulu (simpan / buang)
        if (isRec()) {   // rekam audio sedang jalan: tombol ini jadi Stop
            startService(Intent(this, RecorderService::class.java).setAction(RecorderService.A_STOP))
            return
        }
        stopMeter()
        menuOpen = false
        try {
            // HUD masih terpasang saat startActivity: izin overlay mengizinkan buka Activity dari latar belakang
            startActivity(Intent(this, CaptureActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            // mode audio saja tidak menangkap layar, jadi HUD tidak perlu disembunyikan
            if (s.audioOnly) { syncUi(); return }
            launching.value = true
            main.postDelayed({
                if (launching.value && !CaptureActivity.alive && RecorderService.ui.value.phase == Phase.IDLE) launching.value = false
            }, 4000)
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal membuka izin rekam", Toast.LENGTH_SHORT).show()
            syncUi()
        }
    }

    // ---------- pratinjau + simpan / buang rekaman audio ----------

    /** Pemutar pratinjau (sudah prepare, belum tentu jalan). Dibuat saat pertama dibutuhkan: putar atau geser playhead. */
    private fun ensurePlayer(): MediaPlayer? {
        player?.let { return it }
        val d = RecorderService.draft.value ?: return null
        return try {
            val np = MediaPlayer()
            np.setDataSource(d.file.absolutePath)
            np.setOnCompletionListener { stopPlayer(); if (attached) syncUi() }
            np.prepare()
            player = np
            np
        } catch (e: Exception) {
            Toast.makeText(this, "Pratinjau gagal diputar", Toast.LENGTH_SHORT).show()
            stopPlayer()
            null
        }
    }

    private fun togglePlay() {
        val p = ensurePlayer() ?: return
        try {
            if (p.isPlaying) { p.pause(); main.removeCallbacks(playTick) }
            else { p.start(); main.removeCallbacks(playTick); main.post(playTick) }
        } catch (_: Exception) { stopPlayer() }
        syncUi()
    }

    /** Playhead digeser / dipilih di waveform: lompat ke posisi itu. Kalau sedang diam, tetap diam di posisi baru. */
    private fun seekTo(f: Float, done: Boolean) {
        val p = ensurePlayer() ?: return
        try {
            val dur = p.duration.coerceAtLeast(1)
            val ms = (f.coerceIn(0f, 1f) * dur).toInt().coerceAtMost(dur - 1)
            p.seekTo(ms)
            waveView.progress = ms.toFloat() / dur
            waveView.posSec = ms / 1000
            waveView.invalidate()
            if (done && p.isPlaying) { main.removeCallbacks(playTick); main.post(playTick) }
        } catch (_: Exception) { stopPlayer() }
    }

    /** Menghentikan dan melepas pemutar, gambar kembali ke awal (belum diputar). */
    private fun stopPlayer() {
        main.removeCallbacks(playTick)
        player?.let { try { it.stop() } catch (_: Exception) {}; try { it.release() } catch (_: Exception) {} }
        player = null
        if (::waveView.isInitialized) { waveView.progress = 0f; waveView.posSec = 0; waveView.seeking = false; waveView.invalidate() }
        if (::icoPlay.isInitialized) icoPlay.icon = SolarIcons.PLAY
    }

    private fun onSaveDraft() {
        val d = RecorderService.takeDraft() ?: return
        val app = applicationContext
        Toast.makeText(this, "Menyimpan…", Toast.LENGTH_SHORT).show()
        thread(name = "hud-save") {
            val ok = d.save(app)
            main.post {
                if (ok) {
                    RecorderService.libVersion.value++
                    Toast.makeText(app, "Tersimpan: Music/LayKit/${d.name}", Toast.LENGTH_SHORT).show()
                } else {
                    RecorderService.draft.value = d   // gagal: kartu muncul lagi supaya bisa dicoba ulang
                    Toast.makeText(app, "Gagal menyimpan rekaman", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun onDiscardDraft() {
        RecorderService.takeDraft()?.discard()
        Toast.makeText(this, "Rekaman dibuang", Toast.LENGTH_SHORT).show()
    }

    /** HUD ditutup padahal masih ada rekaman yang belum diputuskan: disimpan, jangan sampai hilang. */
    private fun flushDraft() {
        stopPlayer()
        val d = RecorderService.takeDraft() ?: return
        val app = applicationContext
        thread(name = "hud-flush") {
            val ok = d.save(app)
            if (ok) RecorderService.libVersion.value++
        }
    }

    private fun onToggleMic() {
        if (isRec()) return
        if (!s.mic && !hasMicPerm()) {
            startActivity(
                Intent(this, CaptureActivity::class.java).putExtra(CaptureActivity.X_PERM_ONLY, true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
            return
        }
        s = s.copy(mic = !s.mic); RecPrefs.save(this, s)
        syncUi()
    }

    private fun onToggleInternal() {
        if (isRec()) return
        s = s.copy(internal = !s.internal); RecPrefs.save(this, s)
        syncUi()
    }

    private fun onToggleMore() {
        if (isRec()) return
        if (menuOpen && panelMode == 0) menuOpen = false else { panelMode = 0; menuOpen = true }
        syncUi()
    }

    private fun onToggleTools() {
        if (isRec()) return
        if (menuOpen && panelMode == 1) menuOpen = false else { panelMode = 1; menuOpen = true }
        syncUi()
    }

    private fun onPickMode(audio: Boolean) {
        s = s.copy(audioOnly = audio); RecPrefs.save(this, s)
        syncUi()
    }

    private fun onPickRes(v: Int) {
        s = s.copy(res = v); RecPrefs.save(this, s)
        syncUi()
    }

    private fun onPickOrient(v: Int) {
        s = s.copy(orient = v); RecPrefs.save(this, s)
        syncUi()
    }

    private fun onPickFps(v: Int) {
        s = s.copy(fps = v); RecPrefs.save(this, s)
        syncUi()
    }

    private fun openApp(cmd: String) {
        startActivity(
            Intent(this, MainActivity::class.java).putExtra("cmd", cmd)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        )
    }

    // ---------- UI: bar ringkas (rekam, audio internal, mic, menu) + panel menu yang menempatkan diri ----------
    // Gaya datar: warna solid, garis tipis 1dp, tanpa bayangan/elevation.

    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun dpf(v: Float) = (v * resources.displayMetrics.density + 0.5f).toInt().coerceAtLeast(1)

    private fun rounded(fill: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(r).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun View.tap(f: () -> Unit) { setOnClickListener { f() } }

    /** Latar sentuh ikon: lingkaran abu gelap saat ditekan, selain itu transparan. */
    private fun pressOval() = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(PRESS) })
        addState(intArrayOf(), ColorDrawable(0))
    }

    /** Latar sentuh tombol footer panel: kotak abu gelap saat ditekan. */
    private fun pressRect() = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), ColorDrawable(PRESS))
        addState(intArrayOf(), ColorDrawable(0))
    }

    private fun ico(icon: List<SolarPath>, tint: Int = TXT): SolarView =
        SolarView(this, icon).apply {
            this.tint = tint
            background = pressOval()
            layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)).apply { setMargins(dp(1), 0, dp(1), 0) }
        }

    private fun hLine(): View = View(this).apply {
        setBackgroundColor(LINE)
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1))
    }

    /** Label kecil huruf kapital abu-abu (Mode, Resolusi, Mikrofon, ...). */
    private fun labelText(t: String) = TextView(this).apply {
        text = t; textSize = 11f; setTextColor(GRAY); maxLines = 1
        isAllCaps = true; letterSpacing = 0.05f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    private fun styleSeg(t: TextView, selected: Boolean) {
        t.background = if (selected) rounded(ACCENT, 8) else null
        t.setTextColor(if (selected) 0xFFFFFFFF.toInt() else GRAY)
        t.typeface = if (selected) Typeface.create("sans-serif-medium", Typeface.NORMAL) else Typeface.DEFAULT
    }

    /** Kontrol segmen datar: satu garis tipis, pilihan aktif berisi solid aksen. Mengembalikan wadah + daftar chip. */
    private fun seg(opts: List<Pair<String, Int>>, onPick: (Int) -> Unit): Pair<LinearLayout, List<Pair<Int, TextView>>> {
        val c: Context = this
        val chips = opts.map { (label, v) ->
            v to TextView(c).apply {
                text = label; textSize = 12f; maxLines = 1; gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(0, dp(24), 1f).apply { setMargins(dp(1), 0, dp(1), 0) }
                tap { onPick(v) }
            }
        }
        val box = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(TRACK, 10, LINE)
            setPadding(dp(2), dp(3), dp(2), dp(3))
        }
        chips.forEach { box.addView(it.second) }
        return box to chips
    }

    /** Satu baris panel: label di kiri (60dp) + kontrol segmen mengisi sisanya. */
    private fun segRow(title: String, box: View, topDp: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(topDp) }
        addView(labelText(title), LinearLayout.LayoutParams(dp(60), LinearLayout.LayoutParams.WRAP_CONTENT))
        addView(box, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
    }

    private fun radio(selected: Boolean): View {
        val c: Context = this
        return FrameLayout(c).apply {
            layoutParams = LinearLayout.LayoutParams(dp(12), dp(12))
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setColor(0)
                setStroke(dpf(1.5f), if (selected) ACCENT else GRAY)
            }
            if (selected) {
                addView(
                    View(c).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(ACCENT) } },
                    FrameLayout.LayoutParams(dp(6), dp(6), Gravity.CENTER),
                )
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildUi() {
        val c: Context = this
        val r = FrameLayout(c)

        // ---- bar: tombol rekam, audio internal, mic | menu ----
        recBtn = FrameLayout(c).apply {
            background = rounded(RED, 18)
            layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)).apply { setMargins(0, 0, dp(4), 0) }
            recDot = View(c).apply { background = rounded(0xFFFFFFFF.toInt(), 6) }
            addView(recDot, FrameLayout.LayoutParams(dp(12), dp(12), Gravity.CENTER))
            tap { onRecord() }
        }
        icoSpk = ico(SolarIcons.VOL).also { it.tap { onToggleInternal() } }
        icoMic = ico(SolarIcons.MIC).also { it.tap { onToggleMic() } }
        icoTools = ico(SolarIcons.TOOLS).also { it.tap { onToggleTools() } }
        icoMore = ico(SolarIcons.MORE).also { it.tap { onToggleMore() } }
        val sep = View(c).apply {
            setBackgroundColor(LINE)
            layoutParams = LinearLayout.LayoutParams(dp(1), dp(20)).apply { setMargins(dp(4), 0, dp(4), 0) }
        }
        bar = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = rounded(BG, 23, LINE)
            setPadding(dp(5), dp(5), dp(5), dp(5))
            addView(recBtn); addView(icoSpk); addView(icoMic); addView(icoTools); addView(sep); addView(icoMore)
        }
        // kartu waveform (rekam audio + pratinjau setelah stop), tepat di bawah bar.
        // Rekam: hanya waveform live. Setelah stop: waveform diam + [putar] di kiri, [buang] [simpan] di kanan.
        waveView = WaveView(c).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        // tombol kartu: ikon Solar yang sama dengan bar, sedikit lebih kecil supaya waveform tetap lega
        fun cardIco(icon: List<SolarPath>, tint: Int, f: () -> Unit) = SolarView(c, icon, 19f).apply {
            this.tint = tint; background = pressOval(); visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(dp(32), dp(32))
            tap(f)
        }
        icoPlay = cardIco(SolarIcons.PLAY, ACCENT) { togglePlay() }
        icoDiscard = cardIco(SolarIcons.TRASH, GRAY) { onDiscardDraft() }
        icoSave = cardIco(SolarIcons.SAVE, ACCENT) { onSaveDraft() }
        waveView.onSeek = { f, done -> seekTo(f, done) }
        waveCard = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = rounded(BG, 18, LINE); visibility = View.GONE
            setPadding(dp(3), dp(2), dp(3), dp(2))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(6) }
            addView(icoPlay); addView(waveView); addView(icoDiscard); addView(icoSave)
        }
        barCol = DragLinear(c) { dragEvent(it) }.apply {
            orientation = LinearLayout.VERTICAL
            addView(bar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            addView(waveCard)
        }

        // ---- panel menu: mode, resolusi, orientasi, fps | mikrofon | layar utama, tutup ----
        val (modeBox, mChips) = seg(listOf("Video" to 0, "MP3" to 1)) { onPickMode(it == 1) }
        val (resBox, rChips) = seg(listOf("720p" to 720, "1080p" to 1080, "Asli" to 0)) { onPickRes(it) }
        val (oriBox, oChips) = seg(listOf("Auto" to 0, "Potret" to 1, "Lanskap" to 2)) { onPickOrient(it) }
        val (fpsBox, fChips) = seg(listOf("30" to 30, "60" to 60)) { onPickFps(it) }
        modeChips = mChips; resChips = rChips; orientChips = oChips; fpsChips = fChips

        vidBlock = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            addView(segRow("Resolusi", resBox, 8))
            addView(segRow("Orientasi", oriBox, 8))
            addView(segRow("FPS", fpsBox, 8))
        }
        secMode = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            addView(segRow("Mode", modeBox, 0))
            addView(vidBlock)
        }

        dots = List(5) {
            View(c).apply {
                layoutParams = LinearLayout.LayoutParams(dp(12), dp(4)).apply { setMargins(dpf(1.5f), 0, dpf(1.5f), 0) }
                background = rounded(DOT_OFF, 2)
            }
        }
        val dotsRow = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            dots.forEach { addView(it) }
        }
        val micHead = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(labelText("Mikrofon"), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(dotsRow)
        }
        devList = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(4), 0, 0) }
        micWrap = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            addView(hLine())
            addView(LinearLayout(c).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(12), dp(12), dp(6))
                addView(micHead); addView(devList)
            })
        }
        // panel Tools: satu baris per tool (ikon + nama). Baris baru tinggal ditambah lewat toolRow().
        fun toolRow(label: String, icon: List<SolarPath>, f: () -> Unit) = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = pressRect()
            setPadding(dp(12), 0, dp(12), 0)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(44))
            addView(SolarView(c, icon, 20f).apply { layoutParams = LinearLayout.LayoutParams(dp(20), dp(20)) })
            addView(TextView(c).apply { text = label; textSize = 13f; setTextColor(TXT); maxLines = 1; setPadding(dp(12), 0, 0, 0) })
            tap(f)
        }
        toolsWrap = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            addView(
                labelText("Tools"),
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                    .apply { setMargins(dp(12), dp(12), dp(12), dp(6)) },
            )
            addView(toolRow("Tiktok Convert", SolarIcons.CONVERT) {
                menuOpen = false; syncUi()
                startActivity(Intent(this@HudService, TikTokActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            })
        }
        panelContent = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            addView(secMode); addView(micWrap); addView(toolsWrap)
        }

        fun footBtn(label: String, icon: List<SolarPath>, f: () -> Unit) = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            background = pressRect()
            layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f)
            addView(SolarView(c, icon, 16f).apply { layoutParams = LinearLayout.LayoutParams(dp(16), dp(16)) })
            addView(TextView(c).apply { text = label; textSize = 12f; setTextColor(TXT); maxLines = 1; setPadding(dp(6), 0, 0, 0) })
            tap(f)
        }
        panelFooter = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            addView(hLine())
            addView(LinearLayout(c).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(footBtn("Layar utama", SolarIcons.HOME) { menuOpen = false; syncUi(); openApp("home") })
                addView(View(c).apply { setBackgroundColor(LINE) }, LinearLayout.LayoutParams(dp(1), LinearLayout.LayoutParams.MATCH_PARENT))
                addView(footBtn("Tutup HUD", SolarIcons.CLOSE) { shutdown() })
            })
        }

        // isi panel bisa digulir kalau layar tidak cukup tinggi; footer tetap menempel di dasar panel
        val scroll = ScrollView(c).apply {
            isVerticalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER
            addView(panelContent)
        }
        panelBox = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            background = rounded(BG, 16, LINE); clipToOutline = true
            setPadding(dp(1), dp(1), dp(1), dp(1))
            addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(panelFooter)
        }

        // ukuran dan posisi bar + panel diatur ulang tiap kali oleh layoutHud()
        r.addView(panelBox, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START))
        r.addView(barCol, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START))
        // sentuhan di luar HUD menutup panel (FLAG_WATCH_OUTSIDE_TOUCH)
        r.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_OUTSIDE && menuOpen) { menuOpen = false; syncUi() }
            false
        }
        root = r

        val (px, py) = RecPrefs.hudPos(this)
        barX = if (px >= 0) px else dp(12)
        barY = if (py >= 0) py else resources.displayMetrics.heightPixels / 4
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = barX; y = barY
        }
    }

    // seret: seluruh bar bisa digeser. Ketukan tetap sampai ke tombol; baru setelah jari bergeser melewati
    // batas "slop" sentuhan diambil alih. Yang digeser adalah posisi bar (barX/barY); panel mengikuti.
    private var dX = 0f; private var dY = 0f; private var dSx = 0; private var dSy = 0; private var dragging = false

    private fun dragEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { dX = e.rawX; dY = e.rawY; dSx = barX; dSy = barY; dragging = false }
            MotionEvent.ACTION_MOVE -> {
                val mx = e.rawX - dX; val my = e.rawY - dY
                val slop = ViewConfiguration.get(this).scaledTouchSlop
                if (!dragging && (abs(mx) > slop || abs(my) > slop)) dragging = true
                if (dragging) {
                    barX = (dSx + mx).toInt(); barY = (dSy + my).toInt()
                    if (attached) layoutHud()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val was = dragging
                if (was) RecPrefs.saveHudPos(this, barX, barY)
                dragging = false
                return was
            }
        }
        return dragging
    }

    /** Menyelaraskan tampilan dengan state (pengaturan, mic, menu terbuka/tutup). */
    private fun syncUi() {
        val rec = isRec()
        val draft = RecorderService.draft.value
        val review = draft != null
        if (rec) menuOpen = false
        recDot.background = rounded(0xFFFFFFFF.toInt(), if (rec) 3 else 6)   // bulat = rekam, kotak = stop
        // kartu waveform: tampil saat merekam dan saat menunggu keputusan simpan / buang
        waveCard.visibility = if (rec || review) View.VISIBLE else View.GONE
        val rv = if (review) View.VISIBLE else View.GONE
        icoPlay.visibility = rv; icoDiscard.visibility = rv; icoSave.visibility = rv
        waveView.review = review
        if (draft != null) { waveView.totalSec = draft.seconds; waveView.invalidate() }
        icoPlay.icon = if (player?.isPlaying == true) SolarIcons.PAUSE else SolarIcons.PLAY
        recBtn.alpha = if (review) 0.4f else 1f   // rekam baru baru bisa setelah rekaman ini diputuskan
        icoSpk.alpha = if (rec) 0.4f else 1f; icoMic.alpha = if (rec) 0.4f else 1f; icoMore.alpha = if (rec) 0.4f else 1f
        icoTools.alpha = if (rec) 0.4f else 1f
        if (attached && rec) { if (!waveRunning) { waveRunning = true; main.post(waveTick) } }
        icoSpk.icon = if (s.internal) SolarIcons.VOL else SolarIcons.VOL_X
        icoSpk.tint = if (s.internal) ACCENT else GRAY
        icoMic.icon = if (s.mic) SolarIcons.MIC_BOLD else SolarIcons.MIC
        icoMic.tint = if (s.mic) ACCENT else GRAY
        icoMic.slash = !s.mic
        icoMore.tint = if (menuOpen && panelMode == 0) ACCENT else TXT
        icoTools.tint = if (menuOpen && panelMode == 1) ACCENT else TXT

        modeChips.forEach { (v, t) -> styleSeg(t, (v == 1) == s.audioOnly) }
        resChips.forEach { (v, t) -> styleSeg(t, v == s.res) }
        orientChips.forEach { (v, t) -> styleSeg(t, v == s.orient) }
        fpsChips.forEach { (v, t) -> styleSeg(t, v == s.fps) }
        vidBlock.visibility = if (s.audioOnly) View.GONE else View.VISIBLE   // mode MP3: opsi video disembunyikan

        secMode.visibility = if (panelMode == 0) View.VISIBLE else View.GONE
        toolsWrap.visibility = if (panelMode == 1) View.VISIBLE else View.GONE
        if (menuOpen && panelMode == 0) { devs = inputDevices(); buildDevList() }   // daftar mic hanya perlu dibangun saat menu terbuka
        micWrap.visibility = if (s.mic && panelMode == 0) View.VISIBLE else View.GONE
        panelBox.visibility = if (menuOpen) View.VISIBLE else View.GONE

        // level mic hanya terlihat di panel, jadi pengukur hanya jalan saat menu terbuka
        if (attached && menuOpen && panelMode == 0 && s.mic) startMeter() else stopMeter()
        fitWindow()
    }

    private fun fitWindow() {
        val r = root ?: return
        if (!attached) return
        layoutHud()
        // ukur ulang sekali lagi setelah tata letak selesai (teks baru final di sini)
        r.post { if (attached) layoutHud() }
    }

    /**
     * Menghitung posisi bar + panel, lalu membuat satu jendela overlay seukuran gabungan keduanya.
     * - Bar tetap di barX/barY (tidak melompat saat menu dibuka/ditutup).
     * - Panel dipasang di bawah bar kalau muat, kalau tidak di atas, kalau tidak di sisi yang lebih lega.
     * - Panel ditengahkan terhadap bar lalu digeser agar tetap di dalam layar.
     * - Kalau tetap tidak muat, isi panel digulir; footer tetap terlihat.
     */
    private fun layoutHud() {
        val r = root ?: return
        if (!attached) return
        val dm = resources.displayMetrics
        val sw = dm.widthPixels; val sh = dm.heightPixels
        val m = dp(8); val g = dp(8)
        val unspec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)

        barCol.measure(unspec, unspec)
        val bw = barCol.measuredWidth; val bh = barCol.measuredHeight
        if (bw <= 0 || bh <= 0) return
        barX = barX.coerceIn(0, maxOf(0, sw - bw))
        barY = barY.coerceIn(0, maxOf(0, sh - bh))

        var winL = barX; var winT = barY; var winR = barX + bw; var winB = barY + bh
        var panelL = 0; var panelT = 0; var pw = 0; var ph = 0
        if (menuOpen) {
            pw = minOf(dp(260), sw - 2 * m)
            val innerW = View.MeasureSpec.makeMeasureSpec(pw - dp(2), View.MeasureSpec.EXACTLY)
            panelContent.measure(innerW, unspec)
            panelFooter.measure(innerW, unspec)
            val natural = panelContent.measuredHeight + panelFooter.measuredHeight + dp(2)
            val below = sh - (barY + bh) - g - m
            val above = barY - g - m
            val useBelow = when {
                natural <= below -> true
                natural <= above -> false
                else -> below >= above
            }
            ph = minOf(natural, maxOf(dp(96), if (useBelow) below else above))
            panelL = (barX + (bw - pw) / 2).coerceIn(m, maxOf(m, sw - m - pw))
            panelT = if (useBelow) barY + bh + g else barY - g - ph
            panelT = panelT.coerceIn(0, maxOf(0, sh - ph))
            winL = minOf(winL, panelL); winT = minOf(winT, panelT)
            winR = maxOf(winR, panelL + pw); winB = maxOf(winB, panelT + ph)
        }

        barCol.layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START)
            .apply { leftMargin = barX - winL; topMargin = barY - winT }
        if (menuOpen) {
            panelBox.layoutParams = FrameLayout.LayoutParams(pw, ph, Gravity.TOP or Gravity.START)
                .apply { leftMargin = panelL - winL; topMargin = panelT - winT }
        }
        lp.x = winL; lp.y = winT
        lp.width = winR - winL; lp.height = winB - winT
        try { wm.updateViewLayout(r, lp) } catch (_: Exception) { /* jendela sudah lepas */ }
    }

    private fun buildDevList() {
        val c: Context = this
        devList.removeAllViews()
        val rows = listOf(-1 to devLabel(-1)) + devs.map { it.id to devLabel(it.id) }
        rows.forEach { (id, label) ->
            val sel = id == s.micDev
            devList.addView(
                LinearLayout(c).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(34))
                    addView(radio(sel))
                    addView(
                        TextView(c).apply {
                            text = label; textSize = 13f; maxLines = 1; ellipsize = TextUtils.TruncateAt.END
                            setTextColor(if (sel) ACCENT else TXT); setPadding(dp(10), 0, 0, 0)
                        },
                        LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f),
                    )
                    tap {
                        s = s.copy(micDev = id); RecPrefs.save(c, s)
                        stopMeter(); syncUi()
                    }
                },
            )
        }
    }

    private fun inputDevices(): List<AudioDeviceInfo> =
        getSystemService(AudioManager::class.java).getDevices(AudioManager.GET_DEVICES_INPUTS).filter { it.type in MIC_TYPES }

    private fun devLabel(id: Int): String {
        val d = devs.firstOrNull { it.id == id }
        if (d == null) {
            val b = devs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_MIC }
            return if (b != null) "Default - ${b.productName}" else "Default"
        }
        val kind = when (d.type) {
            AudioDeviceInfo.TYPE_BUILTIN_MIC -> "Bawaan"
            AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Kabel"
            AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET -> "USB"
            else -> "Bluetooth"
        }
        return "${d.productName} ($kind)"
    }

    // ---------- level mic ----------

    private fun hasMicPerm() = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun setLevel(l: Double) {
        val lit = (l * dots.size + 0.5).toInt()
        dots.forEachIndexed { i, v -> (v.background as? GradientDrawable)?.setColor(if (i < lit) ACCENT else DOT_OFF) }
    }

    @SuppressLint("MissingPermission")
    private fun startMeter() {
        if (meterOn || !hasMicPerm()) return
        meterOn = true
        val my = ++gen
        val dev = devs.firstOrNull { it.id == s.micDev }
        thread(name = "hud-meter") {
            var ar: AudioRecord? = null
            try {
                val sr = 16000
                val buf = maxOf(AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT), 4096)
                ar = AudioRecord.Builder().setAudioSource(MediaRecorder.AudioSource.MIC)
                    .setAudioFormat(
                        AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build(),
                    )
                    .setBufferSizeInBytes(buf).build()
                if (ar.state != AudioRecord.STATE_INITIALIZED) return@thread
                if (dev != null) ar.setPreferredDevice(dev)
                ar.startRecording()
                val sh = ShortArray(1024)
                while (gen == my) {
                    val n = ar.read(sh, 0, sh.size)
                    if (n <= 0) break
                    var sum = 0.0
                    for (k in 0 until n) { val v = sh[k].toDouble(); sum += v * v }
                    val rms = sqrt(sum / n)
                    val db = if (rms < 1.0) -90.0 else 20 * log10(rms / 32768.0)
                    val lvl = ((db + 60) / 60).coerceIn(0.0, 1.0)
                    main.post { if (gen == my) setLevel(lvl) }
                }
            } catch (_: Exception) {
                // mic dipakai app lain / gagal dibuka: level diam saja
            } finally {
                try { ar?.stop() } catch (_: Exception) {}
                try { ar?.release() } catch (_: Exception) {}
                main.post { if (gen == my) meterOn = false }
            }
        }
    }

    private fun stopMeter() {
        gen++
        meterOn = false
        if (::dots.isInitialized) setLevel(0.0)
    }
}

// ---------- tampilan ikon Solar + bar yang bisa digeser ----------

private class SolarView(c: Context, icon: List<SolarPath>, private val iconDp: Float = 20f) : View(c) {
    var icon: List<SolarPath> = icon
        set(v) { field = v; invalidate() }
    var tint: Int = 0xFFE6E8EE.toInt()
        set(v) { field = v; invalidate() }
    var slash: Boolean = false
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(cv: Canvas) {
        val px = iconDp * resources.displayMetrics.density
        val sc = px / 24f
        cv.save()
        cv.translate((width - px) / 2f, (height - px) / 2f)
        cv.scale(sc, sc)
        p.color = tint
        p.strokeWidth = 1.5f; p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        for (sp in icon) {
            p.style = if (sp.fill) Paint.Style.FILL else Paint.Style.STROKE
            cv.drawPath(sp.path, p)
        }
        if (slash) {   // mic mati: coretan diagonal
            p.style = Paint.Style.STROKE
            cv.drawLine(4f, 4f, 20f, 20f, p)
        }
        cv.restore()
    }
}

/** Bar horizontal yang mengambil alih sentuhan begitu jari bergeser (untuk menggeser HUD). */
private class DragLinear(c: Context, private val ev: (MotionEvent) -> Boolean) : LinearLayout(c) {
    override fun onInterceptTouchEvent(e: MotionEvent): Boolean = ev(e)
    override fun onTouchEvent(e: MotionEvent): Boolean { ev(e); return true }
}

/**
 * Waveform rekaman audio, cara gambarnya sama dengan drawWave di playlist-canvas.ts (akuhanya):
 * envelope min/max per kolom, SATU KOLOM = SATU PIKSEL (bukan batang bersela), tanpa antialias, jadi gelombang tampil
 * sebagai siluet padat yang mengikuti bentuk sinyal. Garis dasar tipis (alpha 0.45).
 * Mode 'top' (default akuhanya): hanya sisi atas, puncak = |max| atau |min| terbesar per kolom, tumbuh ke atas dari
 * garis dasar di dekat dasar kartu. Ubah [WAVE_TOP] ke false untuk mode simetris atas + bawah dari tengah ('normal').
 *
 * Dua tampilan:
 * - live: jendela waktu terakhir, kolom paling kanan = suara paling baru, bergeser ke kiri seiring waktu.
 * - [review]: diam, SELURUH rekaman diperkecil ke lebar kartu (tiap kolom = min/max irisan di dalamnya); bagian yang
 *   sudah diputar terang, sisanya redup, dengan garis penanda posisi. Sentuh / geser = pilih posisi putar.
 *
 * Zoom (hanya render, hasil rekaman tidak diubah): skala linear akuhanya dikali gain otomatis mengikuti puncak yang terlihat, jadi suara mic yang kecil pun
 * memenuhi kartu. Di mode live gain naik pelan dan turun seketika kalau ada suara keras.
 */
private class WaveView(c: Context) : View(c) {
    var seconds: Int = 0          // live: lama rekaman
    var paused: Boolean = false
    var review: Boolean = false
        set(v) { if (field != v) { field = v; ovKey = -1; invalidate() } }
    var totalSec: Int = 0         // review: lama rekaman
    var posSec: Int = 0           // review: posisi putar
    var progress: Float = 0f      // review: 0..1, 0 = belum diputar
    var seeking: Boolean = false  // review: jari sedang menggeser playhead
    var onSeek: ((Float, Boolean) -> Unit)? = null   // (posisi 0..1, selesai?)
    private var gx0 = 0f; private var gw = 1f        // area gambar terakhir, untuk memetakan sentuhan ke posisi

    companion object {
        private const val INK = 0xFF4D7CFF.toInt()
        private const val WAVE_TOP = false     // false = simetris atas + bawah dari tengah (normal); true = hanya sisi atas
        private const val HEADROOM = 0.65f     // puncak terbesar diskalakan sampai 65% tinggi gelombang (sisanya lega, tidak mentok)
        private const val MIN_GAIN = 1.5f      // gain render minimal (hanya tampilan, audio tidak berubah)
        private const val MAX_GAIN = 12f       // batas atas supaya desis halus tidak tampak seperti suara
        private const val SILENCE = 0.012f     // di bawah ini dianggap sunyi (tidak di-zoom naik)
    }

    private val d = resources.displayMetrics.density
    private val col = Paint().apply { color = INK; isAntiAlias = false }          // 1 kolom = 1 piksel, tepi tajam
    private val baseLine = Paint().apply { color = INK; alpha = 115 }              // 0.45
    private val head = Paint().apply { color = 0xFFE6E8EE.toInt() }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF8A8F9C.toInt(); textSize = 11f * resources.displayMetrics.scaledDensity
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private var mn = FloatArray(LiveWave.CAP)
    private var mx = FloatArray(LiveWave.CAP)
    private var gain = MIN_GAIN
    private var ovKey = -1L          // cache gambaran rekaman utuh: (jumlah kolom, jumlah irisan)

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(resolveSize(0, w), (52 * d + 0.5f).toInt())
    }

    private fun fmt(s: Int) = "%02d:%02d".format(s / 60, s % 60)

    /** Review: sentuh = pilih posisi putar, geser = scrub. Sentuhan diambil dari bar induk supaya HUD tidak ikut bergeser. */
    @android.annotation.SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!review) return false
        val f = ((e.x - gx0) / gw).coerceIn(0f, 1f)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { parent?.requestDisallowInterceptTouchEvent(true); seeking = true; onSeek?.invoke(f, false) }
            MotionEvent.ACTION_MOVE -> onSeek?.invoke(f, false)
            MotionEvent.ACTION_UP -> { seeking = false; onSeek?.invoke(f, true) }
            MotionEvent.ACTION_CANCEL -> { seeking = false; onSeek?.invoke(f, true) }
        }
        return true
    }

    override fun onDraw(cv: Canvas) {
        val padX = (if (review) 4 else 10) * d
        val cols = (width - 2 * padX).toInt().coerceIn(1, LiveWave.CAP)           // 1 kolom = 1 piksel
        val x0 = Math.round(padX + ((width - 2 * padX) - cols) / 2f).toFloat()
        gx0 = x0; gw = cols.toFloat()

        // baris atas: waktu (live: titik status + waktu; review: posisi bila dipilih/diputar, selain itu total)
        val ty = 12 * d + txt.textSize * 0.35f
        if (review) {
            cv.drawText(fmt(if (progress > 0f) posSec else totalSec), padX + 2 * d, ty, txt)
        } else {
            dot.color = if (paused) 0xFF8A8F9C.toInt() else 0xFFE5484D.toInt()
            cv.drawCircle(padX + 3 * d, 12 * d, 3 * d, dot)
            cv.drawText(fmt(seconds), padX + 11 * d, ty, txt)
        }

        // area gelombang di bawah baris waktu
        val bodyY = 20 * d; val bodyH = height - bodyY - 3 * d
        val mid = bodyY + bodyH / 2f
        val base = if (WAVE_TOP) bodyY + bodyH * 0.94f else mid
        val amp = if (WAVE_TOP) bodyH * 0.92f else bodyH / 2f - 0.5f

        if (review) {
            val key = cols.toLong() * 1_000_000L + LiveWave.total()
            if (key != ovKey) { LiveWave.overview(cols, mn, mx); ovKey = key }
        } else {
            LiveWave.read(cols, mn, mx)
        }

        // zoom otomatis mengikuti puncak yang terlihat
        var peak = 0f
        for (i in 0 until cols) {
            if (mx[i] > peak) peak = mx[i]
            if (-mn[i] > peak) peak = -mn[i]
        }
        val target = if (peak < SILENCE) MIN_GAIN else (HEADROOM / peak).coerceIn(MIN_GAIN, MAX_GAIN)
        gain = when {
            review || target < gain -> target                  // review: pas; live: turun seketika
            else -> gain + (target - gain) * 0.08f             // live: naik pelan
        }

        val by = Math.round(base).toFloat()
        cv.drawRect(x0, by - 1f, x0 + cols, by, baseLine)                           // garis dasar 1 px
        val split = if (review && progress > 0f) (progress * cols).toInt() else cols
        for (i in 0 until cols) {
            val x = x0 + i
            col.alpha = if (i < split) 255 else 110                                 // belum diputar = redup
            if (WAVE_TOP) {
                val m = maxOf(mx[i], -mn[i]) * gain
                val h = m.coerceAtMost(1f) * amp
                if (h >= 0.5f) cv.drawRect(x, base - h, x + 1f, base, col)
            } else {
                val up = (mx[i] * gain).coerceAtMost(1f) * amp
                val dn = (-mn[i] * gain).coerceAtMost(1f) * amp
                if (up + dn >= 0.5f) cv.drawRect(x, base - up, x + 1f, base + dn, col)
            }
        }
        if (review && progress > 0f) {
            val px = x0 + progress * cols
            cv.drawRect(px - 0.75f * d, bodyY - 1 * d, px + 0.75f * d, height - 2 * d, head)
        }
    }
}
