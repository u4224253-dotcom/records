package com.laykit

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.launch
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.sqrt

/**
 * HUD melayang (bar gelap membulat) untuk mulai merekam dari app mana pun.
 * Tampil hanya saat rekaman IDLE. Begitu Record ditekan HUD dilepas total dari layar,
 * jadi tidak pernah ikut terekam; muncul lagi setelah rekaman selesai disimpan.
 */
class HudService : Service() {

    companion object {
        const val A_SHOW = "com.laykit.HUD_SHOW"
        const val A_CLOSE = "com.laykit.HUD_CLOSE"

        /** true dari Record ditekan sampai rekaman benar-benar jalan (atau dibatalkan): HUD disembunyikan. */
        val launching = MutableStateFlow(false)

        /** dinaikkan CaptureActivity setelah izin mic beres, supaya HUD membaca ulang pengaturan. */
        val refresh = MutableStateFlow(0)

        private const val CH = "hud"
        private const val NID = 2

        private const val BG = 0xFF181A20.toInt()
        private const val LINE = 0xFF2C303A.toInt()
        private const val TRACK = 0xFF101217.toInt()
        private const val PRESS = 0xFF262932.toInt()
        private const val TXT = 0xFFE6E8EE.toInt()
        private const val GRAY = 0xFF8A8F9C.toInt()
        private const val ACCENT = 0xFF4D7CFF.toInt()
        private const val DOT_OFF = 0xFF3A3D48.toInt()
        private const val RED = 0xFFE5484D.toInt()

        /** Dipanggil setelah rekaman diizinkan: kalau 8 dtk kemudian masih IDLE (gagal mulai), HUD dimunculkan lagi. */
        fun releaseLaunchLater() {
            Handler(Looper.getMainLooper()).postDelayed({
                if (RecorderService.ui.value.phase == Phase.IDLE) launching.value = false
            }, 8000)
        }

        // TYPE_BLE_HEADSET = 26 (API 31)
        private val MIC_TYPES = setOf(
            AudioDeviceInfo.TYPE_BUILTIN_MIC, AudioDeviceInfo.TYPE_WIRED_HEADSET,
            AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET,
            AudioDeviceInfo.TYPE_BLUETOOTH_SCO, 26,
        )
    }

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var root: FrameLayout? = null
    private var attached = false
    private var wanted = false
    private var menuOpen = false
    private var s = RecSettings()
    private var devs: List<AudioDeviceInfo> = emptyList()

    // posisi bar di layar (px). Jendela overlay dihitung dari bar + panel, jadi bar tidak melompat saat menu dibuka.
    private var barX = 0
    private var barY = 0
    private lateinit var bar: LinearLayout
    private lateinit var panelBox: LinearLayout
    private lateinit var panelContent: LinearLayout
    private lateinit var panelFooter: LinearLayout
    private lateinit var vidBlock: LinearLayout     // resolusi, orientasi, fps (disembunyikan di mode MP3)
    private lateinit var micWrap: LinearLayout      // bagian mikrofon di panel (muncul saat mic aktif)
    private lateinit var devList: LinearLayout
    private lateinit var dots: List<View>
    private lateinit var icoSpk: SolarView
    private lateinit var icoMic: SolarView
    private lateinit var icoMore: SolarView
    private var modeChips: List<Pair<Int, TextView>> = emptyList()
    private var resChips: List<Pair<Int, TextView>> = emptyList()
    private var orientChips: List<Pair<Int, TextView>> = emptyList()   // 0 auto, 1 potret, 2 lanskap
    private var fpsChips: List<Pair<Int, TextView>> = emptyList()

    // pengukur level mic
    @Volatile private var gen = 0
    private var meterOn = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WindowManager::class.java)
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CH, "HUD perekam", NotificationManager.IMPORTANCE_MIN))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == A_CLOSE) { shutdown(); return START_NOT_STICKY }
        startFg()
        if (!Settings.canDrawOverlays(this)) { shutdown(); return START_NOT_STICKY }
        if (!wanted) {
            wanted = true
            s = RecPrefs.load(this)
            buildUi()
            scope.launch {
                combine(RecorderService.ui, launching) { u, l -> u.phase == Phase.IDLE && !l }
                    .collect { if (it) showHud() else hideHud() }
            }
            scope.launch {
                RecorderService.ui.collect { if (it.phase != Phase.IDLE && launching.value) launching.value = false }
            }
            scope.launch {
                refresh.drop(1).collect { s = RecPrefs.load(this@HudService); syncUi() }
            }
        } else {
            showHud()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        wanted = false
        hideHud()
        scope.cancel()
        super.onDestroy()
    }

    private fun startFg() {
        val n = notif()
        if (Build.VERSION.SDK_INT >= 34) {
            ServiceCompat.startForeground(this, NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NID, n)
        }
    }

    private fun notif(): Notification {
        val close = PendingIntent.getService(
            this, 10, Intent(this, HudService::class.java).setAction(A_CLOSE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("HUD LayKit aktif")
            .setContentText("Ketuk Tutup untuk menyembunyikan HUD")
            .setOngoing(true).setPriority(NotificationCompat.PRIORITY_MIN)
            .addAction(0, "Tutup", close)
            .build()
    }

    private fun shutdown() {
        wanted = false
        hideHud()
        scope.cancel()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ---------- tampil / sembunyi ----------

    private fun showHud() {
        val r = root ?: return
        if (!wanted) return
        if (attached) { syncUi(); return }
        try { wm.addView(r, lp); attached = true } catch (e: Exception) { shutdown(); return }
        syncUi()
    }

    private fun hideHud() {
        menuOpen = false
        stopMeter()
        val r = root
        if (r != null && attached) { try { wm.removeView(r) } catch (_: Exception) { /* sudah lepas */ } }
        attached = false
    }

    // ---------- aksi ----------

    private fun onRecord() {
        stopMeter()
        menuOpen = false
        try {
            // HUD masih terpasang saat startActivity: izin overlay mengizinkan buka Activity dari latar belakang
            startActivity(Intent(this, CaptureActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            launching.value = true
            main.postDelayed({
                if (launching.value && !CaptureActivity.alive && RecorderService.ui.value.phase == Phase.IDLE) launching.value = false
            }, 4000)
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal membuka izin rekam", Toast.LENGTH_SHORT).show()
            syncUi()
        }
    }

    private fun onToggleMic() {
        if (!s.mic && !hasMicPerm()) {
            startActivity(
                Intent(this, CaptureActivity::class.java).putExtra(CaptureActivity.X_PERM_ONLY, true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
            return
        }
        s = s.copy(mic = !s.mic); RecPrefs.save(this, s)
        syncUi()
    }

    private fun onToggleInternal() {
        s = s.copy(internal = !s.internal); RecPrefs.save(this, s)
        syncUi()
    }

    private fun onToggleMore() {
        menuOpen = !menuOpen
        syncUi()
    }

    private fun onPickMode(audio: Boolean) {
        s = s.copy(audioOnly = audio); RecPrefs.save(this, s)
        syncUi()
    }

    private fun onPickRes(v: Int) {
        s = s.copy(res = v); RecPrefs.save(this, s)
        syncUi()
    }

    private fun onPickOrient(v: Int) {
        s = s.copy(orient = v); RecPrefs.save(this, s)
        syncUi()
    }

    private fun onPickFps(v: Int) {
        s = s.copy(fps = v); RecPrefs.save(this, s)
        syncUi()
    }

    private fun openApp(cmd: String) {
        startActivity(
            Intent(this, MainActivity::class.java).putExtra("cmd", cmd)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        )
    }

    // ---------- UI: bar ringkas (rekam, audio internal, mic, menu) + panel menu yang menempatkan diri ----------
    // Gaya datar: warna solid, garis tipis 1dp, tanpa bayangan/elevation.

    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun dpf(v: Float) = (v * resources.displayMetrics.density + 0.5f).toInt().coerceAtLeast(1)

    private fun rounded(fill: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(r).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun View.tap(f: () -> Unit) { setOnClickListener { f() } }

    /** Latar sentuh ikon: lingkaran abu gelap saat ditekan, selain itu transparan. */
    private fun pressOval() = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(PRESS) })
        addState(intArrayOf(), ColorDrawable(0))
    }

    /** Latar sentuh tombol footer panel: kotak abu gelap saat ditekan. */
    private fun pressRect() = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), ColorDrawable(PRESS))
        addState(intArrayOf(), ColorDrawable(0))
    }

    private fun ico(icon: List<SolarPath>, tint: Int = TXT): SolarView =
        SolarView(this, icon).apply {
            this.tint = tint
            background = pressOval()
            layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)).apply { setMargins(dp(1), 0, dp(1), 0) }
        }

    private fun hLine(): View = View(this).apply {
        setBackgroundColor(LINE)
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1))
    }

    /** Label kecil huruf kapital abu-abu (Mode, Resolusi, Mikrofon, ...). */
    private fun labelText(t: String) = TextView(this).apply {
        text = t; textSize = 11f; setTextColor(GRAY); maxLines = 1
        isAllCaps = true; letterSpacing = 0.05f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    private fun styleSeg(t: TextView, selected: Boolean) {
        t.background = if (selected) rounded(ACCENT, 8) else null
        t.setTextColor(if (selected) 0xFFFFFFFF.toInt() else GRAY)
        t.typeface = if (selected) Typeface.create("sans-serif-medium", Typeface.NORMAL) else Typeface.DEFAULT
    }

    /** Kontrol segmen datar: satu garis tipis, pilihan aktif berisi solid aksen. Mengembalikan wadah + daftar chip. */
    private fun seg(opts: List<Pair<String, Int>>, onPick: (Int) -> Unit): Pair<LinearLayout, List<Pair<Int, TextView>>> {
        val c: Context = this
        val chips = opts.map { (label, v) ->
            v to TextView(c).apply {
                text = label; textSize = 12f; maxLines = 1; gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(0, dp(24), 1f).apply { setMargins(dp(1), 0, dp(1), 0) }
                tap { onPick(v) }
            }
        }
        val box = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(TRACK, 10, LINE)
            setPadding(dp(2), dp(3), dp(2), dp(3))
        }
        chips.forEach { box.addView(it.second) }
        return box to chips
    }

    /** Satu baris panel: label di kiri (60dp) + kontrol segmen mengisi sisanya. */
    private fun segRow(title: String, box: View, topDp: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(topDp) }
        addView(labelText(title), LinearLayout.LayoutParams(dp(60), LinearLayout.LayoutParams.WRAP_CONTENT))
        addView(box, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
    }

    private fun radio(selected: Boolean): View {
        val c: Context = this
        return FrameLayout(c).apply {
            layoutParams = LinearLayout.LayoutParams(dp(12), dp(12))
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setColor(0)
                setStroke(dpf(1.5f), if (selected) ACCENT else GRAY)
            }
            if (selected) {
                addView(
                    View(c).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(ACCENT) } },
                    FrameLayout.LayoutParams(dp(6), dp(6), Gravity.CENTER),
                )
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildUi() {
        val c: Context = this
        val r = FrameLayout(c)

        // ---- bar: tombol rekam, audio internal, mic | menu ----
        val recBtn = FrameLayout(c).apply {
            background = rounded(RED, 18)
            layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)).apply { setMargins(0, 0, dp(4), 0) }
            addView(View(c).apply { background = rounded(0xFFFFFFFF.toInt(), 6) }, FrameLayout.LayoutParams(dp(12), dp(12), Gravity.CENTER))
            tap { onRecord() }
        }
        icoSpk = ico(SolarIcons.VOL).also { it.tap { onToggleInternal() } }
        icoMic = ico(SolarIcons.MIC).also { it.tap { onToggleMic() } }
        icoMore = ico(SolarIcons.MORE).also { it.tap { onToggleMore() } }
        val sep = View(c).apply {
            setBackgroundColor(LINE)
            layoutParams = LinearLayout.LayoutParams(dp(1), dp(20)).apply { setMargins(dp(4), 0, dp(4), 0) }
        }
        bar = DragLinear(c) { dragEvent(it) }.apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = rounded(BG, 23, LINE)
            setPadding(dp(5), dp(5), dp(5), dp(5))
            addView(recBtn); addView(icoSpk); addView(icoMic); addView(sep); addView(icoMore)
        }

        // ---- panel menu: mode, resolusi, orientasi, fps | mikrofon | layar utama, tutup ----
        val (modeBox, mChips) = seg(listOf("Video" to 0, "MP3" to 1)) { onPickMode(it == 1) }
        val (resBox, rChips) = seg(listOf("720p" to 720, "1080p" to 1080, "Asli" to 0)) { onPickRes(it) }
        val (oriBox, oChips) = seg(listOf("Auto" to 0, "Potret" to 1, "Lanskap" to 2)) { onPickOrient(it) }
        val (fpsBox, fChips) = seg(listOf("30" to 30, "60" to 60)) { onPickFps(it) }
        modeChips = mChips; resChips = rChips; orientChips = oChips; fpsChips = fChips

        vidBlock = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            addView(segRow("Resolusi", resBox, 8))
            addView(segRow("Orientasi", oriBox, 8))
            addView(segRow("FPS", fpsBox, 8))
        }
        val secMode = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            addView(segRow("Mode", modeBox, 0))
            addView(vidBlock)
        }

        dots = List(5) {
            View(c).apply {
                layoutParams = LinearLayout.LayoutParams(dp(12), dp(4)).apply { setMargins(dpf(1.5f), 0, dpf(1.5f), 0) }
                background = rounded(DOT_OFF, 2)
            }
        }
        val dotsRow = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            dots.forEach { addView(it) }
        }
        val micHead = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(labelText("Mikrofon"), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(dotsRow)
        }
        devList = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(4), 0, 0) }
        micWrap = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            addView(hLine())
            addView(LinearLayout(c).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(12), dp(12), dp(6))
                addView(micHead); addView(devList)
            })
        }
        panelContent = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            addView(secMode); addView(micWrap)
        }

        fun footBtn(label: String, icon: List<SolarPath>, f: () -> Unit) = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            background = pressRect()
            layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f)
            addView(SolarView(c, icon, 16f).apply { layoutParams = LinearLayout.LayoutParams(dp(16), dp(16)) })
            addView(TextView(c).apply { text = label; textSize = 12f; setTextColor(TXT); maxLines = 1; setPadding(dp(6), 0, 0, 0) })
            tap(f)
        }
        panelFooter = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            addView(hLine())
            addView(LinearLayout(c).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(footBtn("Layar utama", SolarIcons.HOME) { menuOpen = false; syncUi(); openApp("home") })
                addView(View(c).apply { setBackgroundColor(LINE) }, LinearLayout.LayoutParams(dp(1), LinearLayout.LayoutParams.MATCH_PARENT))
                addView(footBtn("Tutup HUD", SolarIcons.CLOSE) { shutdown() })
            })
        }

        // isi panel bisa digulir kalau layar tidak cukup tinggi; footer tetap menempel di dasar panel
        val scroll = ScrollView(c).apply {
            isVerticalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER
            addView(panelContent)
        }
        panelBox = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            background = rounded(BG, 16, LINE); clipToOutline = true
            setPadding(dp(1), dp(1), dp(1), dp(1))
            addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(panelFooter)
        }

        // ukuran dan posisi bar + panel diatur ulang tiap kali oleh layoutHud()
        r.addView(panelBox, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START))
        r.addView(bar, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START))
        // sentuhan di luar HUD menutup panel (FLAG_WATCH_OUTSIDE_TOUCH)
        r.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_OUTSIDE && menuOpen) { menuOpen = false; syncUi() }
            false
        }
        root = r

        val (px, py) = RecPrefs.hudPos(this)
        barX = if (px >= 0) px else dp(12)
        barY = if (py >= 0) py else resources.displayMetrics.heightPixels / 4
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = barX; y = barY
        }
    }

    // seret: seluruh bar bisa digeser. Ketukan tetap sampai ke tombol; baru setelah jari bergeser melewati
    // batas "slop" sentuhan diambil alih. Yang digeser adalah posisi bar (barX/barY); panel mengikuti.
    private var dX = 0f; private var dY = 0f; private var dSx = 0; private var dSy = 0; private var dragging = false

    private fun dragEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { dX = e.rawX; dY = e.rawY; dSx = barX; dSy = barY; dragging = false }
            MotionEvent.ACTION_MOVE -> {
                val mx = e.rawX - dX; val my = e.rawY - dY
                val slop = ViewConfiguration.get(this).scaledTouchSlop
                if (!dragging && (abs(mx) > slop || abs(my) > slop)) dragging = true
                if (dragging) {
                    barX = (dSx + mx).toInt(); barY = (dSy + my).toInt()
                    if (attached) layoutHud()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val was = dragging
                if (was) RecPrefs.saveHudPos(this, barX, barY)
                dragging = false
                return was
            }
        }
        return dragging
    }

    /** Menyelaraskan tampilan dengan state (pengaturan, mic, menu terbuka/tutup). */
    private fun syncUi() {
        icoSpk.icon = if (s.internal) SolarIcons.VOL else SolarIcons.VOL_X
        icoSpk.tint = if (s.internal) ACCENT else GRAY
        icoMic.icon = if (s.mic) SolarIcons.MIC_BOLD else SolarIcons.MIC
        icoMic.tint = if (s.mic) ACCENT else GRAY
        icoMic.slash = !s.mic
        icoMore.tint = if (menuOpen) ACCENT else TXT

        modeChips.forEach { (v, t) -> styleSeg(t, (v == 1) == s.audioOnly) }
        resChips.forEach { (v, t) -> styleSeg(t, v == s.res) }
        orientChips.forEach { (v, t) -> styleSeg(t, v == s.orient) }
        fpsChips.forEach { (v, t) -> styleSeg(t, v == s.fps) }
        vidBlock.visibility = if (s.audioOnly) View.GONE else View.VISIBLE   // mode MP3: opsi video disembunyikan

        devs = inputDevices()
        buildDevList()
        micWrap.visibility = if (s.mic) View.VISIBLE else View.GONE
        panelBox.visibility = if (menuOpen) View.VISIBLE else View.GONE

        // level mic hanya terlihat di panel, jadi pengukur hanya jalan saat menu terbuka
        if (attached && menuOpen && s.mic) startMeter() else stopMeter()
        fitWindow()
    }

    private fun fitWindow() {
        val r = root ?: return
        if (!attached) return
        layoutHud()
        // ukur ulang sekali lagi setelah tata letak selesai (teks baru final di sini)
        r.post { if (attached) layoutHud() }
    }

    /**
     * Menghitung posisi bar + panel, lalu membuat satu jendela overlay seukuran gabungan keduanya.
     * - Bar tetap di barX/barY (tidak melompat saat menu dibuka/ditutup).
     * - Panel dipasang di bawah bar kalau muat, kalau tidak di atas, kalau tidak di sisi yang lebih lega.
     * - Panel ditengahkan terhadap bar lalu digeser agar tetap di dalam layar.
     * - Kalau tetap tidak muat, isi panel digulir; footer tetap terlihat.
     */
    private fun layoutHud() {
        val r = root ?: return
        if (!attached) return
        val dm = resources.displayMetrics
        val sw = dm.widthPixels; val sh = dm.heightPixels
        val m = dp(8); val g = dp(8)
        val unspec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)

        bar.measure(unspec, unspec)
        val bw = bar.measuredWidth; val bh = bar.measuredHeight
        if (bw <= 0 || bh <= 0) return
        barX = barX.coerceIn(0, maxOf(0, sw - bw))
        barY = barY.coerceIn(0, maxOf(0, sh - bh))

        var winL = barX; var winT = barY; var winR = barX + bw; var winB = barY + bh
        var panelL = 0; var panelT = 0; var pw = 0; var ph = 0
        if (menuOpen) {
            pw = minOf(dp(260), sw - 2 * m)
            val innerW = View.MeasureSpec.makeMeasureSpec(pw - dp(2), View.MeasureSpec.EXACTLY)
            panelContent.measure(innerW, unspec)
            panelFooter.measure(innerW, unspec)
            val natural = panelContent.measuredHeight + panelFooter.measuredHeight + dp(2)
            val below = sh - (barY + bh) - g - m
            val above = barY - g - m
            val useBelow = when {
                natural <= below -> true
                natural <= above -> false
                else -> below >= above
            }
            ph = minOf(natural, maxOf(dp(96), if (useBelow) below else above))
            panelL = (barX + (bw - pw) / 2).coerceIn(m, maxOf(m, sw - m - pw))
            panelT = if (useBelow) barY + bh + g else barY - g - ph
            panelT = panelT.coerceIn(0, maxOf(0, sh - ph))
            winL = minOf(winL, panelL); winT = minOf(winT, panelT)
            winR = maxOf(winR, panelL + pw); winB = maxOf(winB, panelT + ph)
        }

        bar.layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START)
            .apply { leftMargin = barX - winL; topMargin = barY - winT }
        if (menuOpen) {
            panelBox.layoutParams = FrameLayout.LayoutParams(pw, ph, Gravity.TOP or Gravity.START)
                .apply { leftMargin = panelL - winL; topMargin = panelT - winT }
        }
        lp.x = winL; lp.y = winT
        lp.width = winR - winL; lp.height = winB - winT
        try { wm.updateViewLayout(r, lp) } catch (_: Exception) { /* jendela sudah lepas */ }
    }

    private fun buildDevList() {
        val c: Context = this
        devList.removeAllViews()
        val rows = listOf(-1 to devLabel(-1)) + devs.map { it.id to devLabel(it.id) }
        rows.forEach { (id, label) ->
            val sel = id == s.micDev
            devList.addView(
                LinearLayout(c).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(34))
                    addView(radio(sel))
                    addView(
                        TextView(c).apply {
                            text = label; textSize = 13f; maxLines = 1; ellipsize = TextUtils.TruncateAt.END
                            setTextColor(if (sel) ACCENT else TXT); setPadding(dp(10), 0, 0, 0)
                        },
                        LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f),
                    )
                    tap {
                        s = s.copy(micDev = id); RecPrefs.save(c, s)
                        stopMeter(); syncUi()
                    }
                },
            )
        }
    }

    private fun inputDevices(): List<AudioDeviceInfo> =
        getSystemService(AudioManager::class.java).getDevices(AudioManager.GET_DEVICES_INPUTS).filter { it.type in MIC_TYPES }

    private fun devLabel(id: Int): String {
        val d = devs.firstOrNull { it.id == id }
        if (d == null) {
            val b = devs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_MIC }
            return if (b != null) "Default - ${b.productName}" else "Default"
        }
        val kind = when (d.type) {
            AudioDeviceInfo.TYPE_BUILTIN_MIC -> "Bawaan"
            AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Kabel"
            AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET -> "USB"
            else -> "Bluetooth"
        }
        return "${d.productName} ($kind)"
    }

    // ---------- level mic ----------

    private fun hasMicPerm() = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun setLevel(l: Double) {
        val lit = (l * dots.size + 0.5).toInt()
        dots.forEachIndexed { i, v -> (v.background as? GradientDrawable)?.setColor(if (i < lit) ACCENT else DOT_OFF) }
    }

    @SuppressLint("MissingPermission")
    private fun startMeter() {
        if (meterOn || !hasMicPerm()) return
        meterOn = true
        val my = ++gen
        val dev = devs.firstOrNull { it.id == s.micDev }
        thread(name = "hud-meter") {
            var ar: AudioRecord? = null
            try {
                val sr = 16000
                val buf = maxOf(AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT), 4096)
                ar = AudioRecord.Builder().setAudioSource(MediaRecorder.AudioSource.MIC)
                    .setAudioFormat(
                        AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build(),
                    )
                    .setBufferSizeInBytes(buf).build()
                if (ar.state != AudioRecord.STATE_INITIALIZED) return@thread
                if (dev != null) ar.setPreferredDevice(dev)
                ar.startRecording()
                val sh = ShortArray(1024)
                while (gen == my) {
                    val n = ar.read(sh, 0, sh.size)
                    if (n <= 0) break
                    var sum = 0.0
                    for (k in 0 until n) { val v = sh[k].toDouble(); sum += v * v }
                    val rms = sqrt(sum / n)
                    val db = if (rms < 1.0) -90.0 else 20 * log10(rms / 32768.0)
                    val lvl = ((db + 60) / 60).coerceIn(0.0, 1.0)
                    main.post { if (gen == my) setLevel(lvl) }
                }
            } catch (_: Exception) {
                // mic dipakai app lain / gagal dibuka: level diam saja
            } finally {
                try { ar?.stop() } catch (_: Exception) {}
                try { ar?.release() } catch (_: Exception) {}
                main.post { if (gen == my) meterOn = false }
            }
        }
    }

    private fun stopMeter() {
        gen++
        meterOn = false
        if (::dots.isInitialized) setLevel(0.0)
    }
}

// ---------- tampilan ikon Solar + bar yang bisa digeser ----------

private class SolarView(c: Context, icon: List<SolarPath>, private val iconDp: Float = 20f) : View(c) {
    var icon: List<SolarPath> = icon
        set(v) { field = v; invalidate() }
    var tint: Int = 0xFFE6E8EE.toInt()
        set(v) { field = v; invalidate() }
    var slash: Boolean = false
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(cv: Canvas) {
        val px = iconDp * resources.displayMetrics.density
        val sc = px / 24f
        cv.save()
        cv.translate((width - px) / 2f, (height - px) / 2f)
        cv.scale(sc, sc)
        p.color = tint
        p.strokeWidth = 1.5f; p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        for (sp in icon) {
            p.style = if (sp.fill) Paint.Style.FILL else Paint.Style.STROKE
            cv.drawPath(sp.path, p)
        }
        if (slash) {   // mic mati: coretan diagonal
            p.style = Paint.Style.STROKE
            cv.drawLine(4f, 4f, 20f, 20f, p)
        }
        cv.restore()
    }
}

/** Bar horizontal yang mengambil alih sentuhan begitu jari bergeser (untuk menggeser HUD). */
private class DragLinear(c: Context, private val ev: (MotionEvent) -> Boolean) : LinearLayout(c) {
    override fun onInterceptTouchEvent(e: MotionEvent): Boolean = ev(e)
    override fun onTouchEvent(e: MotionEvent): Boolean { ev(e); return true }
}
