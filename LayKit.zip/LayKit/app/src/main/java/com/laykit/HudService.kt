package com.laykit

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.launch
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.sqrt

/**
 * HUD melayang (bar gelap membulat) untuk mulai merekam dari app mana pun.
 * Tampil hanya saat rekaman IDLE. Begitu Record ditekan HUD dilepas total dari layar,
 * jadi tidak pernah ikut terekam; muncul lagi setelah rekaman selesai disimpan.
 */
class HudService : Service() {

    companion object {
        const val A_SHOW = "com.laykit.HUD_SHOW"
        const val A_CLOSE = "com.laykit.HUD_CLOSE"

        /** true dari Record ditekan sampai rekaman benar-benar jalan (atau dibatalkan): HUD disembunyikan. */
        val launching = MutableStateFlow(false)

        /** dinaikkan CaptureActivity setelah izin mic beres, supaya HUD membaca ulang pengaturan. */
        val refresh = MutableStateFlow(0)

        private const val CH = "hud"
        private const val NID = 2

        private const val BG = 0xF2181A20.toInt()
        private const val STROKE = 0x33FFFFFF
        private const val TXT = 0xFFE6E8EE.toInt()
        private const val GRAY = 0xFF8A8F9C.toInt()
        private const val ACCENT = 0xFF4D7CFF.toInt()
        private const val DOT_OFF = 0xFF3A3D48.toInt()
        private const val RED = 0xFFE5484D.toInt()

        /** Dipanggil setelah rekaman diizinkan: kalau 8 dtk kemudian masih IDLE (gagal mulai), HUD dimunculkan lagi. */
        fun releaseLaunchLater() {
            Handler(Looper.getMainLooper()).postDelayed({
                if (RecorderService.ui.value.phase == Phase.IDLE) launching.value = false
            }, 8000)
        }

        // TYPE_BLE_HEADSET = 26 (API 31)
        private val MIC_TYPES = setOf(
            AudioDeviceInfo.TYPE_BUILTIN_MIC, AudioDeviceInfo.TYPE_WIRED_HEADSET,
            AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET,
            AudioDeviceInfo.TYPE_BLUETOOTH_SCO, 26,
        )
    }

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var root: FrameLayout? = null
    private var attached = false
    private var wanted = false
    private var micOpen = false
    private var s = RecSettings()
    private var devs: List<AudioDeviceInfo> = emptyList()

    private lateinit var micPanel: LinearLayout
    private lateinit var micLabel: TextView
    private lateinit var devList: LinearLayout
    private lateinit var dots: List<View>
    private lateinit var icoSpk: SolarView
    private lateinit var icoMic: SolarView
    private lateinit var chipRes: TextView

    // pengukur level mic
    @Volatile private var gen = 0
    private var meterOn = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WindowManager::class.java)
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CH, "HUD perekam", NotificationManager.IMPORTANCE_MIN))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == A_CLOSE) { shutdown(); return START_NOT_STICKY }
        startFg()
        if (!Settings.canDrawOverlays(this)) { shutdown(); return START_NOT_STICKY }
        if (!wanted) {
            wanted = true
            s = RecPrefs.load(this)
            buildUi()
            scope.launch {
                combine(RecorderService.ui, launching) { u, l -> u.phase == Phase.IDLE && !l }
                    .collect { if (it) showHud() else hideHud() }
            }
            scope.launch {
                RecorderService.ui.collect { if (it.phase != Phase.IDLE && launching.value) launching.value = false }
            }
            scope.launch {
                refresh.drop(1).collect { s = RecPrefs.load(this@HudService); syncUi() }
            }
        } else {
            showHud()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        wanted = false
        hideHud()
        scope.cancel()
        super.onDestroy()
    }

    private fun startFg() {
        val n = notif()
        if (Build.VERSION.SDK_INT >= 34) {
            ServiceCompat.startForeground(this, NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NID, n)
        }
    }

    private fun notif(): Notification {
        val close = PendingIntent.getService(
            this, 10, Intent(this, HudService::class.java).setAction(A_CLOSE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("HUD LayKit aktif")
            .setContentText("Ketuk Tutup untuk menyembunyikan HUD")
            .setOngoing(true).setPriority(NotificationCompat.PRIORITY_MIN)
            .addAction(0, "Tutup", close)
            .build()
    }

    private fun shutdown() {
        wanted = false
        hideHud()
        scope.cancel()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ---------- tampil / sembunyi ----------

    private fun showHud() {
        val r = root ?: return
        if (!wanted) return
        if (attached) { syncUi(); return }
        clampPos()
        try { wm.addView(r, lp); attached = true } catch (e: Exception) { shutdown(); return }
        syncUi()
    }

    private fun hideHud() {
        stopMeter()
        val r = root
        if (r != null && attached) { try { wm.removeView(r) } catch (_: Exception) { /* sudah lepas */ } }
        attached = false
    }

    private fun clampPos() {
        val dm = resources.displayMetrics
        lp.x = lp.x.coerceIn(0, maxOf(0, dm.widthPixels - dp(72)))
        lp.y = lp.y.coerceIn(0, maxOf(0, dm.heightPixels - dp(72)))
    }

    // ---------- aksi ----------

    private fun onRecord() {
        stopMeter()
        try {
            // HUD masih terpasang saat startActivity: izin overlay mengizinkan buka Activity dari latar belakang
            startActivity(Intent(this, CaptureActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            launching.value = true
            main.postDelayed({
                if (launching.value && !CaptureActivity.alive && RecorderService.ui.value.phase == Phase.IDLE) launching.value = false
            }, 4000)
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal membuka izin rekam", Toast.LENGTH_SHORT).show()
            syncUi()
        }
    }

    private fun onToggleMic() {
        if (!s.mic && !hasMicPerm()) {
            startActivity(
                Intent(this, CaptureActivity::class.java).putExtra(CaptureActivity.X_PERM_ONLY, true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
            return
        }
        s = s.copy(mic = !s.mic); RecPrefs.save(this, s)
        micOpen = false
        syncUi()
    }

    private fun onToggleInternal() {
        s = s.copy(internal = !s.internal); RecPrefs.save(this, s)
        syncUi()
    }

    private fun onCycleRes() {
        val order = listOf(720, 1080, 0)
        s = s.copy(res = order[(order.indexOf(s.res) + 1) % order.size]); RecPrefs.save(this, s)
        syncUi()
    }

    private fun openApp(cmd: String) {
        startActivity(
            Intent(this, MainActivity::class.java).putExtra("cmd", cmd)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        )
    }

    // ---------- UI (susunan meniru HUD Recordly: tombol rekam bulat merah, chip sumber, ikon Solar) ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun rounded(fill: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(r).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun View.tap(f: () -> Unit) { setOnClickListener { f() } }

    private fun ico(icon: List<SolarPath>, tint: Int = TXT): SolarView =
        SolarView(this, icon).apply {
            this.tint = tint
            layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)).apply { setMargins(dp(2), 0, dp(2), 0) }
        }

    private fun divider(): View {
        val c: Context = this
        return View(c).apply {
            setBackgroundColor(0x33FFFFFF)
            layoutParams = LinearLayout.LayoutParams(dp(1), dp(24)).apply { setMargins(dp(4), 0, dp(4), 0) }
        }
    }

    private fun buildUi() {
        val c: Context = this
        val r = FrameLayout(c)

        // tombol rekam: lingkaran merah 36dp dengan titik putih 14dp
        val recBtn = FrameLayout(c).apply {
            background = rounded(RED, 18)
            layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)).apply { setMargins(dp(2), 0, dp(6), 0) }
            addView(View(c).apply { background = rounded(0xFFFFFFFF.toInt(), 7) }, FrameLayout.LayoutParams(dp(14), dp(14), Gravity.CENTER))
            tap { onRecord() }
        }
        // chip "sumber": ikon monitor + resolusi (ketuk = ganti)
        chipRes = TextView(c).apply { setTextColor(TXT); textSize = 13f; maxLines = 1; setPadding(dp(6), 0, 0, 0) }
        val chip = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), 0, dp(10), 0)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(36))
            addView(SolarView(c, SolarIcons.MONITOR).apply { layoutParams = LinearLayout.LayoutParams(dp(20), dp(20)) })
            addView(chipRes)
            tap { onCycleRes() }
        }
        icoSpk = ico(SolarIcons.VOL).also { it.tap { onToggleInternal() } }
        icoMic = ico(SolarIcons.MIC).also { it.tap { onToggleMic() } }
        val icoHome = ico(SolarIcons.HOME).also { it.tap { openApp("home") } }
        val icoClose = ico(SolarIcons.CLOSE).also { it.tap { shutdown() } }
        val bar = DragLinear(c) { dragEvent(it) }.apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = rounded(BG, 20, STROKE); elevation = dp(6).toFloat()
            setPadding(dp(8), dp(6), dp(8), dp(6))
            addView(recBtn); addView(chip); addView(divider())
            addView(icoSpk); addView(icoMic); addView(divider())
            addView(icoHome); addView(icoClose)
        }

        // ---- panel mic (dropdown + level), muncul di atas bar saat mic aktif ----
        micLabel = TextView(c).apply {
            setTextColor(TXT); textSize = 13f; maxLines = 1; ellipsize = TextUtils.TruncateAt.END; maxWidth = dp(190)
        }
        val pill = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = rounded(0x22FFFFFF, 16, STROKE)
            setPadding(dp(12), dp(7), dp(8), dp(7))
            addView(micLabel)
            addView(SolarView(c, SolarIcons.CHEV).apply { layoutParams = LinearLayout.LayoutParams(dp(20), dp(20)) })
            tap { micOpen = !micOpen; syncUi() }
        }
        val dotsRow = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), 0, dp(6), 0) }
        dots = List(5) {
            View(c).apply {
                layoutParams = LinearLayout.LayoutParams(dp(14), dp(5)).apply { setMargins(dp(2), 0, dp(2), 0) }
                background = rounded(DOT_OFF, 3)
            }
        }
        dots.forEach { dotsRow.addView(it) }
        val top = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; addView(pill); addView(dotsRow) }
        devList = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        micPanel = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            background = rounded(BG, 20, STROKE); elevation = dp(6).toFloat()
            setPadding(dp(8), dp(8), dp(8), dp(8))
            addView(top); addView(devList)
        }

        val full = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            addView(micPanel, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) })
            addView(bar)
        }
        r.addView(full, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT))
        root = r

        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            val (px, py) = RecPrefs.hudPos(this@HudService)
            x = if (px >= 0) px else dp(12)
            y = if (py >= 0) py else resources.displayMetrics.heightPixels / 4
        }
    }

    // seret: seluruh bar bisa digeser (seperti HUD Recordly). Ketukan tetap sampai ke tombol; baru setelah
    // jari bergeser melewati batas "slop" sentuhan diambil alih untuk menggeser jendela.
    private var dX = 0f; private var dY = 0f; private var dSx = 0; private var dSy = 0; private var dragging = false

    private fun dragEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { dX = e.rawX; dY = e.rawY; dSx = lp.x; dSy = lp.y; dragging = false }
            MotionEvent.ACTION_MOVE -> {
                val mx = e.rawX - dX; val my = e.rawY - dY
                val slop = ViewConfiguration.get(this).scaledTouchSlop
                if (!dragging && (abs(mx) > slop || abs(my) > slop)) dragging = true
                if (dragging) {
                    lp.x = (dSx + mx).toInt(); lp.y = (dSy + my).toInt(); clampPos()
                    val r = root
                    if (attached && r != null) wm.updateViewLayout(r, lp)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val was = dragging
                if (was) RecPrefs.saveHudPos(this, lp.x, lp.y)
                dragging = false
                return was
            }
        }
        return dragging
    }

    /** Menyelaraskan tampilan dengan state (pengaturan, mic). */
    private fun syncUi() {
        icoSpk.icon = if (s.internal) SolarIcons.VOL else SolarIcons.VOL_X
        icoSpk.tint = if (s.internal) ACCENT else GRAY
        icoMic.icon = if (s.mic) SolarIcons.MIC_BOLD else SolarIcons.MIC
        icoMic.tint = if (s.mic) ACCENT else GRAY
        icoMic.slash = !s.mic
        chipRes.text = if (s.res <= 0) "Asli" else "${s.res}p"

        devs = inputDevices()
        micLabel.text = devLabel(s.micDev)
        buildDevList()
        micPanel.visibility = if (s.mic) View.VISIBLE else View.GONE
        devList.visibility = if (micOpen && s.mic) View.VISIBLE else View.GONE

        if (attached && s.mic) startMeter() else stopMeter()
    }

    private fun buildDevList() {
        val c: Context = this
        devList.removeAllViews()
        val rows = listOf(-1 to devLabel(-1)) + devs.map { it.id to devLabel(it.id) }
        rows.forEach { (id, label) ->
            devList.addView(TextView(c).apply {
                text = label; textSize = 13f; maxLines = 1; ellipsize = TextUtils.TruncateAt.END
                setTextColor(if (id == s.micDev) ACCENT else TXT)
                setPadding(dp(12), dp(9), dp(12), dp(9))
                tap {
                    s = s.copy(micDev = id); RecPrefs.save(c, s)
                    micOpen = false; stopMeter(); syncUi()
                }
            })
        }
    }

    private fun inputDevices(): List<AudioDeviceInfo> =
        getSystemService(AudioManager::class.java).getDevices(AudioManager.GET_DEVICES_INPUTS).filter { it.type in MIC_TYPES }

    private fun devLabel(id: Int): String {
        val d = devs.firstOrNull { it.id == id }
        if (d == null) {
            val b = devs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_MIC }
            return if (b != null) "Default - ${b.productName}" else "Default"
        }
        val kind = when (d.type) {
            AudioDeviceInfo.TYPE_BUILTIN_MIC -> "Bawaan"
            AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Kabel"
            AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET -> "USB"
            else -> "Bluetooth"
        }
        return "${d.productName} ($kind)"
    }

    // ---------- level mic ----------

    private fun hasMicPerm() = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun setLevel(l: Double) {
        val lit = (l * dots.size + 0.5).toInt()
        dots.forEachIndexed { i, v -> (v.background as? GradientDrawable)?.setColor(if (i < lit) ACCENT else DOT_OFF) }
    }

    @SuppressLint("MissingPermission")
    private fun startMeter() {
        if (meterOn || !hasMicPerm()) return
        meterOn = true
        val my = ++gen
        val dev = devs.firstOrNull { it.id == s.micDev }
        thread(name = "hud-meter") {
            var ar: AudioRecord? = null
            try {
                val sr = 16000
                val buf = maxOf(AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT), 4096)
                ar = AudioRecord.Builder().setAudioSource(MediaRecorder.AudioSource.MIC)
                    .setAudioFormat(
                        AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build(),
                    )
                    .setBufferSizeInBytes(buf).build()
                if (ar.state != AudioRecord.STATE_INITIALIZED) return@thread
                if (dev != null) ar.setPreferredDevice(dev)
                ar.startRecording()
                val sh = ShortArray(1024)
                while (gen == my) {
                    val n = ar.read(sh, 0, sh.size)
                    if (n <= 0) break
                    var sum = 0.0
                    for (k in 0 until n) { val v = sh[k].toDouble(); sum += v * v }
                    val rms = sqrt(sum / n)
                    val db = if (rms < 1.0) -90.0 else 20 * log10(rms / 32768.0)
                    val lvl = ((db + 60) / 60).coerceIn(0.0, 1.0)
                    main.post { if (gen == my) setLevel(lvl) }
                }
            } catch (_: Exception) {
                // mic dipakai app lain / gagal dibuka: level diam saja
            } finally {
                try { ar?.stop() } catch (_: Exception) {}
                try { ar?.release() } catch (_: Exception) {}
                main.post { if (gen == my) meterOn = false }
            }
        }
    }

    private fun stopMeter() {
        gen++
        meterOn = false
        if (::dots.isInitialized) setLevel(0.0)
    }
}

// ---------- tampilan ikon Solar + bar yang bisa digeser ----------

private class SolarView(c: Context, icon: List<SolarPath>) : View(c) {
    var icon: List<SolarPath> = icon
        set(v) { field = v; invalidate() }
    var tint: Int = 0xFFE6E8EE.toInt()
        set(v) { field = v; invalidate() }
    var slash: Boolean = false
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(cv: Canvas) {
        val px = 20f * resources.displayMetrics.density
        val sc = px / 24f
        cv.save()
        cv.translate((width - px) / 2f, (height - px) / 2f)
        cv.scale(sc, sc)
        p.color = tint
        p.strokeWidth = 1.5f; p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        for (sp in icon) {
            p.style = if (sp.fill) Paint.Style.FILL else Paint.Style.STROKE
            cv.drawPath(sp.path, p)
        }
        if (slash) {   // mic mati: coretan diagonal
            p.style = Paint.Style.STROKE
            cv.drawLine(4f, 4f, 20f, 20f, p)
        }
        cv.restore()
    }
}

/** Bar horizontal yang mengambil alih sentuhan begitu jari bergeser (untuk menggeser HUD). */
private class DragLinear(c: Context, private val ev: (MotionEvent) -> Boolean) : LinearLayout(c) {
    override fun onInterceptTouchEvent(e: MotionEvent): Boolean = ev(e)
    override fun onTouchEvent(e: MotionEvent): Boolean { ev(e); return true }
}
