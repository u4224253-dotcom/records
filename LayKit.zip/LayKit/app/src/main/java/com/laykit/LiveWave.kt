package com.laykit

/**
 * Peak waveform untuk rekaman audio yang sedang berjalan (real-time).
 *
 * Mengikuti ide waveform.ts: peak disimpan sebagai MIN dan MAX terpisah (int8, -127..127), keduanya mulai dari 0
 * sehingga envelope selalu mencakup garis nol (bagian sunyi menempel di tengah). Bedanya dengan versi file:
 * di sini tidak ada piramid / zoom, karena yang digambar hanya jendela waktu terakhir. Satu entri = satu irisan
 * waktu ([SLICE_MS] md) dan buffer berputar (ring) supaya memori tetap konstan berapa pun lama rekaman.
 *
 * Ditulis dari thread rekam ([push]), dibaca dari thread UI ([read]).
 */
object LiveWave {
    const val SLICE_MS = 20              // 1 entri = 20 md -> 50 kolom per detik
    const val CAP = 2048                 // entri yang disimpan (cukup untuk layar selebar apa pun)

    private val mn = ByteArray(CAP)
    private val mx = ByteArray(CAP)
    @Volatile private var head = 0L      // jumlah entri yang sudah ditulis sejak reset

    private fun q8(v: Int): Byte = (v * 127 / 32768).coerceIn(-127, 127).toByte()   // dipotong ke arah nol

    fun reset() {
        mn.fill(0); mx.fill(0)
        head = 0L
    }

    /** lo <= 0 <= hi, skala sampel 16-bit. */
    fun push(lo: Int, hi: Int) {
        val i = (head % CAP).toInt()
        mn[i] = q8(lo); mx[i] = q8(hi)
        head += 1                        // terbit terakhir supaya pembaca tidak melihat entri setengah jadi
    }

    /**
     * Mengisi [outMin]/[outMax] dengan [cols] kolom (nilai -1..1 / 0..1), kolom paling kanan = paling baru.
     * Kolom sebelum rekaman dimulai dibiarkan 0 dan dikembalikan sebagai [valid] = jumlah kolom berisi dari kanan.
     */
    fun read(cols: Int, outMin: FloatArray, outMax: FloatArray): Int {
        val n = cols.coerceIn(1, CAP)
        val h = head
        var valid = 0
        for (c in 0 until n) {
            val idx = h - n + c
            if (idx < 0) { outMin[c] = 0f; outMax[c] = 0f; continue }
            val k = (idx % CAP).toInt()
            outMin[c] = mn[k] / 127f; outMax[c] = mx[k] / 127f
            valid++
        }
        return valid
    }
}
