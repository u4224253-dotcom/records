package com.laykit

/**
 * Peak waveform untuk rekaman audio yang sedang berjalan (real-time).
 *
 * Mengikuti ide waveform.ts: peak disimpan sebagai MIN dan MAX terpisah (int8, -127..127), keduanya mulai dari 0
 * sehingga envelope selalu mencakup garis nol (bagian sunyi menempel di tengah). Bedanya dengan versi file:
 * di sini tidak ada piramid / zoom, karena yang digambar hanya jendela waktu terakhir. Satu entri = satu irisan
 * waktu ([SLICE_MS] md) dan buffer berputar (ring) supaya memori tetap konstan berapa pun lama rekaman.
 *
 * Ditulis dari thread rekam ([push]), dibaca dari thread UI ([read]).
 */
object LiveWave {
    const val SLICE_MS = 3               // 1 entri = 3 md -> ~333 kolom per detik: cukup rapat untuk 1 kolom = 1 piksel, bentuk gelombang terbaca
    const val CAP = 2048                 // entri yang disimpan (6 detik terakhir; cukup untuk layar selebar apa pun)

    private val mn = ByteArray(CAP)
    private val mx = ByteArray(CAP)
    @Volatile private var head = 0L      // jumlah entri yang sudah ditulis sejak reset

    // Rekaman utuh (tidak berputar): dipakai untuk menggambar gambaran seluruh rekaman saat pratinjau.
    // 1 entri = 2 byte per 3 md -> sekitar 2,4 MB per jam rekaman. Hanya dibaca setelah rekam berhenti.
    private var fMn = ByteArray(8192)
    private var fMx = ByteArray(8192)
    @Volatile private var fN = 0

    private fun q8(v: Int): Byte = (v * 127 / 32768).coerceIn(-127, 127).toByte()   // dipotong ke arah nol

    fun reset() {
        mn.fill(0); mx.fill(0)
        head = 0L
        fN = 0
    }

    /** lo <= 0 <= hi, skala sampel 16-bit. */
    fun push(lo: Int, hi: Int) {
        val i = (head % CAP).toInt()
        mn[i] = q8(lo); mx[i] = q8(hi)
        val n = fN
        if (n >= fMn.size) { fMn = fMn.copyOf(n * 2); fMx = fMx.copyOf(n * 2) }
        fMn[n] = mn[i]; fMx[n] = mx[i]
        fN = n + 1
        head += 1                        // terbit terakhir supaya pembaca tidak melihat entri setengah jadi
    }

    /** Jumlah entri rekaman utuh (berubah tiap ada irisan baru; dipakai sebagai kunci cache gambar). */
    fun total(): Int = fN

    /**
     * Gambaran SELURUH rekaman dalam [cols] kolom: tiap kolom = min/max dari irisan yang jatuh di dalamnya.
     * Dipanggil setelah rekam berhenti (data sudah tidak bertambah).
     */
    fun overview(cols: Int, outMin: FloatArray, outMax: FloatArray) {
        val n = fN
        val c = cols.coerceAtLeast(1)
        for (k in 0 until c) {
            if (n == 0) { outMin[k] = 0f; outMax[k] = 0f; continue }
            val a = (k.toLong() * n / c).toInt()
            val b = maxOf(a + 1, ((k + 1).toLong() * n / c).toInt()).coerceAtMost(n)
            var lo = 0; var hi = 0
            for (j in a until b) {
                if (fMn[j] < lo) lo = fMn[j].toInt()
                if (fMx[j] > hi) hi = fMx[j].toInt()
            }
            outMin[k] = lo / 127f; outMax[k] = hi / 127f
        }
    }

    /**
     * Mengisi [outMin]/[outMax] dengan [cols] kolom (nilai -1..1 / 0..1), kolom paling kanan = paling baru.
     * Kolom sebelum rekaman dimulai dibiarkan 0 dan dikembalikan sebagai [valid] = jumlah kolom berisi dari kanan.
     */
    fun read(cols: Int, outMin: FloatArray, outMax: FloatArray): Int {
        val n = cols.coerceIn(1, CAP)
        val h = head
        var valid = 0
        for (c in 0 until n) {
            val idx = h - n + c
            if (idx < 0) { outMin[c] = 0f; outMax[c] = 0f; continue }
            val k = (idx % CAP).toInt()
            outMin[c] = mn[k] / 127f; outMax[c] = mx[k] / 127f
            valid++
        }
        return valid
    }
}
