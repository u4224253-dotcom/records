# Mesin caption LayKit: whisper.cpp (MIT, lihat whisper.cpp/LICENSE) dibangun dari salinan di folder ini,
# ditambah jembatan JNI kecil (whisper_jni.cpp). Hanya backend CPU; tanpa OpenMP supaya tidak ada lib tambahan.
cmake_minimum_required(VERSION 3.18)
project(laykit_whisper C CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_POSITION_INDEPENDENT_CODE ON)

# Build "debug" Gradle akan memakai CMAKE_BUILD_TYPE=Debug (tanpa optimasi) yang membuat transkripsi jauh lebih lambat.
# Mesin ini selalu dioptimasi, apa pun varian app-nya.
set(CMAKE_C_FLAGS_DEBUG   "-O3 -DNDEBUG")
set(CMAKE_CXX_FLAGS_DEBUG "-O3 -DNDEBUG")

set(BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)
set(WHISPER_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(WHISPER_BUILD_TESTS OFF CACHE BOOL "" FORCE)
set(WHISPER_BUILD_SERVER OFF CACHE BOOL "" FORCE)
set(GGML_OPENMP OFF CACHE BOOL "" FORCE)
set(GGML_NATIVE OFF CACHE BOOL "" FORCE)
set(GGML_CCACHE OFF CACHE BOOL "" FORCE)
set(GGML_BACKEND_DL OFF CACHE BOOL "" FORCE)

add_subdirectory(whisper.cpp)

add_library(laykit_whisper SHARED whisper_jni.cpp)
target_link_libraries(laykit_whisper PRIVATE whisper)
if(ANDROID)
    find_library(LOG_LIB log)
    target_link_libraries(laykit_whisper PRIVATE ${LOG_LIB})
    # Halaman 16 KB (wajib untuk perangkat Android 15+ dengan halaman 16 KB)
    target_link_options(laykit_whisper PRIVATE -Wl,-z,max-page-size=16384)
endif()

# ---- Encoder MP3 (fitur "rekam audio saja"): LAME 3.100 (LGPL, lihat lame/COPYING) + jembatan JNI kecil ----
file(GLOB LAME_SRC ${CMAKE_CURRENT_SOURCE_DIR}/lame/libmp3lame/*.c)
add_library(laykit_lame SHARED lame_jni.cpp ${LAME_SRC})
target_include_directories(laykit_lame PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}/lame
    ${CMAKE_CURRENT_SOURCE_DIR}/lame/include
    ${CMAKE_CURRENT_SOURCE_DIR}/lame/libmp3lame)
target_compile_definitions(laykit_lame PRIVATE HAVE_CONFIG_H)
target_compile_options(laykit_lame PRIVATE -O3 -w)
if(ANDROID)
    target_link_options(laykit_lame PRIVATE -Wl,-z,max-page-size=16384)
endif()
