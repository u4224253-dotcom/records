// Jembatan JNI ke LAME (libmp3lame, LGPL) untuk fitur "rekam audio saja" -> .mp3
// Android tidak punya encoder MP3 bawaan, jadi LAME dibangun dari salinan di folder lame/.
#include <jni.h>
#include <cstdint>
#include "lame/include/lame.h"

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_laykit_Mp3Encoder_nInit(JNIEnv *, jobject, jint sampleRate, jint channels, jint kbps) {
    lame_t g = lame_init();
    if (!g) return 0;
    lame_set_in_samplerate(g, sampleRate);
    lame_set_out_samplerate(g, sampleRate);
    lame_set_num_channels(g, channels);
    lame_set_mode(g, channels == 1 ? MONO : JOINT_STEREO);
    lame_set_VBR(g, vbr_off);            // CBR: durasi akurat tanpa header Xing
    lame_set_brate(g, kbps);
    lame_set_quality(g, 2);              // 2 = kualitas tinggi, masih ringan untuk HP
    lame_set_bWriteVbrTag(g, 0);         // tidak menyisakan frame kosong di awal file
    if (lame_init_params(g) < 0) { lame_close(g); return 0; }
    return reinterpret_cast<jlong>(g);
}

/** pcm: sampel 16-bit interleaved; frames = jumlah frame (sampel per kanal). Mengembalikan jumlah byte MP3, <0 = galat. */
JNIEXPORT jint JNICALL
Java_com_laykit_Mp3Encoder_nEncode(JNIEnv *env, jobject, jlong h, jshortArray pcm, jint frames, jint channels, jbyteArray out) {
    lame_t g = reinterpret_cast<lame_t>(h);
    if (!g) return -1;
    jshort *in = env->GetShortArrayElements(pcm, nullptr);
    jbyte *o = env->GetByteArrayElements(out, nullptr);
    jsize cap = env->GetArrayLength(out);
    int n;
    if (channels == 1) n = lame_encode_buffer(g, in, nullptr, frames, reinterpret_cast<unsigned char *>(o), cap);
    else n = lame_encode_buffer_interleaved(g, in, frames, reinterpret_cast<unsigned char *>(o), cap);
    env->ReleaseShortArrayElements(pcm, in, JNI_ABORT);
    env->ReleaseByteArrayElements(out, o, 0);
    return n;
}

JNIEXPORT jint JNICALL
Java_com_laykit_Mp3Encoder_nFlush(JNIEnv *env, jobject, jlong h, jbyteArray out) {
    lame_t g = reinterpret_cast<lame_t>(h);
    if (!g) return -1;
    jbyte *o = env->GetByteArrayElements(out, nullptr);
    int n = lame_encode_flush(g, reinterpret_cast<unsigned char *>(o), env->GetArrayLength(out));
    env->ReleaseByteArrayElements(out, o, 0);
    return n;
}

JNIEXPORT void JNICALL
Java_com_laykit_Mp3Encoder_nClose(JNIEnv *, jobject, jlong h) {
    lame_t g = reinterpret_cast<lame_t>(h);
    if (g) lame_close(g);
}

}  // extern "C"
