// Jembatan JNI tipis untuk whisper.cpp. Kelasnya: com.laykit.WhisperNative (lihat WhisperEngine.kt).
// Semua fungsi dipanggil dari satu thread background; pembatalan lewat flag global.
#include <jni.h>

#include <atomic>
#include <cstring>
#include <string>

#include "whisper.h"

namespace {

std::atomic<bool> g_cancel{false};

struct ProgressCtx {
    JNIEnv* env;
    jobject cb;
    jmethodID mid;
    int last;
};

void on_progress(struct whisper_context*, struct whisper_state*, int progress, void* user) {
    auto* p = static_cast<ProgressCtx*>(user);
    if (p == nullptr || p->cb == nullptr || p->mid == nullptr) return;
    if (progress == p->last) return;
    p->last = progress;
    p->env->CallVoidMethod(p->cb, p->mid, static_cast<jint>(progress));
    if (p->env->ExceptionCheck()) p->env->ExceptionClear();
}

bool on_abort(void*) {
    return g_cancel.load();
}

}  // namespace

extern "C" {

JNIEXPORT jlong JNICALL Java_com_laykit_WhisperNative_nativeLoad(JNIEnv* env, jobject, jstring path) {
    const char* p = env->GetStringUTFChars(path, nullptr);
    if (p == nullptr) return 0;
    whisper_context_params cp = whisper_context_default_params();
    cp.use_gpu = false;
    whisper_context* ctx = whisper_init_from_file_with_params(p, cp);
    env->ReleaseStringUTFChars(path, p);
    return reinterpret_cast<jlong>(ctx);
}

JNIEXPORT void JNICALL Java_com_laykit_WhisperNative_nativeFree(JNIEnv*, jobject, jlong handle) {
    auto* ctx = reinterpret_cast<whisper_context*>(handle);
    if (ctx != nullptr) whisper_free(ctx);
}

JNIEXPORT void JNICALL Java_com_laykit_WhisperNative_nativeCancel(JNIEnv*, jobject, jboolean on) {
    g_cancel.store(on == JNI_TRUE);
}

/**
 * Transkripsi [samples] (PCM float mono 16 kHz). Hasil: jumlah segmen (>= 0), -1 kalau konteks kosong,
 * -2 kalau dibatalkan, -3 kalau whisper gagal. Segmen dibaca lewat nativeSeg*.
 * [lang]: kode bahasa ("id", "en", ...) atau "auto". [cb]: objek dengan onProgress(int) (boleh null).
 */
JNIEXPORT jint JNICALL Java_com_laykit_WhisperNative_nativeRun(
    JNIEnv* env, jobject, jlong handle, jfloatArray samples, jstring lang, jint threads, jobject cb) {
    auto* ctx = reinterpret_cast<whisper_context*>(handle);
    if (ctx == nullptr) return -1;

    const char* langC = env->GetStringUTFChars(lang, nullptr);
    std::string language = langC != nullptr ? langC : "auto";
    if (langC != nullptr) env->ReleaseStringUTFChars(lang, langC);

    jsize n = env->GetArrayLength(samples);
    jfloat* data = env->GetFloatArrayElements(samples, nullptr);
    if (data == nullptr) return -3;

    g_cancel.store(false);

    whisper_full_params wp = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    wp.n_threads = threads > 0 ? threads : 4;
    wp.language = language.c_str();
    wp.translate = false;
    wp.no_context = true;
    wp.print_progress = false;
    wp.print_realtime = false;
    wp.print_timestamps = false;
    wp.print_special = false;
    // baris pendek untuk subtitle: dipecah per kata, maksimal ~42 karakter per segmen
    wp.token_timestamps = true;
    wp.max_len = 42;
    wp.split_on_word = true;

    ProgressCtx pc{env, cb, nullptr, -1};
    if (cb != nullptr) {
        jclass cls = env->GetObjectClass(cb);
        pc.mid = env->GetMethodID(cls, "onProgress", "(I)V");
        if (env->ExceptionCheck()) env->ExceptionClear();
        wp.progress_callback = on_progress;
        wp.progress_callback_user_data = &pc;
    }
    wp.abort_callback = on_abort;
    wp.abort_callback_user_data = nullptr;

    int rc = whisper_full(ctx, wp, data, n);
    env->ReleaseFloatArrayElements(samples, data, JNI_ABORT);

    if (g_cancel.load()) return -2;
    if (rc != 0) return -3;
    return whisper_full_n_segments(ctx);
}

// Waktu segmen dalam 10 ms (centisecond), sesuai whisper.cpp.
JNIEXPORT jlong JNICALL Java_com_laykit_WhisperNative_nativeSegStart(JNIEnv*, jobject, jlong handle, jint i) {
    return whisper_full_get_segment_t0(reinterpret_cast<whisper_context*>(handle), i);
}

JNIEXPORT jlong JNICALL Java_com_laykit_WhisperNative_nativeSegEnd(JNIEnv*, jobject, jlong handle, jint i) {
    return whisper_full_get_segment_t1(reinterpret_cast<whisper_context*>(handle), i);
}

// Teks dikembalikan sebagai byte UTF-8 mentah (bukan jstring): pemotongan per token bisa memutus karakter
// multibyte, dan NewStringUTF dengan UTF-8 tidak valid membuat CheckJNI menghentikan app.
JNIEXPORT jbyteArray JNICALL Java_com_laykit_WhisperNative_nativeSegText(JNIEnv* env, jobject, jlong handle, jint i) {
    const char* t = whisper_full_get_segment_text(reinterpret_cast<whisper_context*>(handle), i);
    if (t == nullptr) t = "";
    jsize len = static_cast<jsize>(std::strlen(t));
    jbyteArray out = env->NewByteArray(len);
    if (out != nullptr && len > 0) env->SetByteArrayRegion(out, 0, len, reinterpret_cast<const jbyte*>(t));
    return out;
}

}  // extern "C"
