plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.laykit"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.laykit"
        minSdk = 29          // Android 10: wajib untuk audio internal (AudioPlaybackCapture)
        targetSdk = 34
        versionCode = 44
        versionName = "0.25.0"
        // Mesin caption (whisper.cpp) hanya dibangun untuk arm64: hampir semua HP Android 10+; emulator x86 tidak didukung
        ndk { abiFilters += listOf("arm64-v8a") }
        externalNativeBuild {
            cmake {
                // dioptimasi di semua varian: whisper.cpp tanpa optimasi puluhan kali lebih lambat
                arguments += listOf("-DCMAKE_BUILD_TYPE=Release", "-DANDROID_STL=c++_static")
            }
        }
    }
    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }
    // Keystore debug tetap (di-commit) supaya APK dari tiap build GitHub Actions bisa di-install menimpa versi lama.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    // net.lkm (9,2 MB) dan cnn.lkm (5,6 MB), float32 nyaris tidak bisa dikompres; simpan apa adanya supaya dibuka cepat
    androidResources { noCompress += "lkm" }
    buildFeatures { compose = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")
}
