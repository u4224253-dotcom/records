# LayKit (tahap 2)

Perekam layar Android native (Kotlin + Jetpack Compose). Minimal Android 10 (API 29).

## Build
1. Buka folder ini di **Android Studio** (Koala atau lebih baru), tunggu Gradle sync.
2. Sambungkan HP (USB debugging) lalu Run. Atau: Build > Build APK(s).

## Tampilan (v0.5)
- Layar utama dan editor dibuat ulang: datar tanpa card, muat satu layar (tanpa scroll halaman), potret dan lanskap
- Pengaturan (ikon gir di layar utama): tampilan Sistem / Terang / Gelap, plus pengaturan rekaman

## Fitur tahap 1
- Mulai / Jeda / Lanjut / Stop (Jeda dan Stop lewat notifikasi)
- Hitung mundur 3-2-1 (butuh izin overlay; tanpa izin langsung mulai)
- Audio internal (AudioPlaybackCapture) + mikrofon, dicampur
- Resolusi 720p / 1080p / asli, 30 / 60 fps
- Simpan otomatis ke galeri: Movies/LayKit/*.mp4

## Fitur tahap 2 (editor)
- Daftar rekaman di layar utama (Movies/LayKit), tombol Edit dan Bagikan
- Editor: pratinjau langsung, **potong (trim)**, **background** (gradient, warna solid, wallpaper mesh, gambar dari galeri, blur dari video), padding, sudut membulat, bayangan, rasio kanvas (Asli/16:9/9:16/1:1/4:5)
- Ekspor ke MP4 baru (video di-render ulang lewat OpenGL, audio disalin tanpa re-encode)

## HUD melayang (v0.6)
Bar kontrol gelap membulat yang tampil di atas app mana pun, untuk mulai merekam tanpa membuka LayKit.
- Buka lewat tombol **HUD** di layar utama (butuh izin overlay). Tutup lewat tombol X atau aksi "Tutup" di notifikasi.
- Tampilan dan susunan mengikuti HUD Recordly: tombol **Rekam** bulat merah, chip sumber (ikon monitor + resolusi; ketuk = ganti 720p / 1080p / Asli), toggle audio internal, toggle mikrofon, **Home** (buka daftar rekaman, rekaman terbaru di paling atas untuk di-edit), dan tutup. Seluruh bar bisa digeser.
- Saat mikrofon aktif muncul panel di atas bar: dropdown pilih perangkat mic + 5 titik level suara.
- **HUD hilang total begitu Rekam ditekan** (tidak pernah ikut terekam). Selama merekam, kontrol Jeda/Stop lewat notifikasi. Setelah rekaman tersimpan HUD muncul lagi di posisi yang sama.
- Pengaturan (resolusi, audio, mic, perangkat mic, posisi HUD) dibagi dengan layar utama lewat `RecPrefs`.
- Dialog izin rekam layar dibuka lewat `CaptureActivity` (transparan), karena hanya Activity yang bisa meminta izin itu.

## Zoom halus (v0.9)
Logika zoom disamakan dengan Openscreen (`zoomRegionUtils.ts`, `regions.rs`), supaya gerak kamera mulus (sebelumnya terasa bergejolak):
- **Blok = seluruh zoom, termasuk animasinya.** Animasi zoom-in mulai tepat di awal blok, lalu zoom penuh ditahan, dan animasi zoom-out selesai tepat di akhir blok. Blok yang lebih pendek dari dua kali transisi mempersingkat kedua animasinya sama rata.
- **Kurva = pegas teredam kritis** (kecepatan awal 0, tanpa overshoot, tiba tepat di 1), bukan smoothstep. Lama transisi bergantung skala: `600 + 550·ln(skala)` ms (~1 detik di 2x).
- **Skala diinterpolasi di ruang log**; titik fokus bergerak lurus ke posisi akhirnya. Posisi akhir dijepit sekali per blok (kartu menutupi kanvas), tidak ada jepit lagi selama transisi, jadi tidak ada patahan kecepatan.
- **Keyframe titik sorot.** Satu blok bisa punya beberapa keyframe (diamond di timeline). Tiap keyframe menyimpan skala dan titik fokus (area sorot); kamera bergerak mulus dari keyframe ke keyframe (skala di ruang log, fokus linear, easing `cubic-bezier(0.65, 0, 0.35, 1)`). Setelah keyframe terakhir keadaannya tetap. Pratinjau dan ekspor memakai rumus yang sama (`ZoomMath.stateAt`).
  - **Tombol keyframe (ikon belah ketupat)** ada di kartu player, di sebelah undo/redo. Ikon kosong dengan tanda + = tambah keyframe di posisi playhead (blok yang dipilih, atau yang berisi playhead); ikon terisi dengan tanda − = hapus keyframe yang aktif. Keyframe baru dimulai dari keadaan kamera saat itu (tidak melompat), lalu mode Pilih area terbuka untuk menggeser sorotnya.
  - Ketuk diamond untuk memilih (playhead lompat ke waktunya); geser untuk mengubah waktunya; slider Skala/X/Y atau Pilih area mengubah isinya.
  - Jarak minimum keyframe ke tepi blok dan ke keyframe lain 250 ms. Keyframe yang keluar dari blok saat blok dipendekkan tidak dihapus, hanya diabaikan sampai blok dipanjangkan lagi. Menggeser blok ikut menggeser keyframe-nya.
- **Panel Kurva** (tab "Kurva" di toolbar bawah): atur kurva animasi blok yang dipilih, dipakai untuk zoom masuk/keluar dan perpindahan antar keyframe. Preset: Pegas (bawaan), Halus, Sinematik, Linear, Masuk pelan, Keluar pelan. Kotak kurva punya dua titik kontrol cubic-bezier yang bisa digeser untuk kurva sendiri (nilai dijaga 0..1, tanpa overshoot). **Reset** kembali ke pegas bawaan, **Semua blok** menerapkan kurva ke seluruh blok. Pratinjau dan ekspor memakai kurva yang sama (`ZoomMath.ease`).
- **Blok berjarak <= 1,5 detik disambung** dengan pan 1 detik (easing `cubic-bezier(0.1, 0, 0.2, 1)`), tanpa zoom-out lalu masuk lagi. Transisi yang bertumpuk dicampur menurut kekuatannya, tanpa lompatan.
- **Pratinjau memakai jam per frame layar**: posisi pemutar diekstrapolasi tiap frame dan dikoreksi pelan-pelan oleh `currentPosition` (dulu dibaca tiap 40 ms langsung). Zoom dan kursor dibaca di fase gambar, jadi tidak membuat seluruh UI recompose tiap frame.

## Wallpaper foto (v0.9.2)
Tab Background > **Foto**: 18 wallpaper bawaan + tombol **Galeri** untuk gambar sendiri. File ada di `res/raw/wallpaper1..18.jpg` (diperkecil ke 1600 px, total ~1,4 MB), dipakai lewat Uri `android.resource://`, jadi pratinjau dan ekspor memakai jalur gambar yang sama. Sumber: `public/wallpapers` di [Openscreen](https://github.com/getopenscreen/openscreen) (lisensi kode MIT; asal tiap foto tidak didokumentasikan di repo itu).

## Pemutar pratinjau (v0.9.2)
Bug Play di editor: `MediaPlayer` dulu dibuat dan dibuang oleh callback `TextureView`, jadi setiap `TextureView` dilepas/dipasang ulang pemutar ikut dibuang dan Play tidak jalan. Sekarang `PlayerState.open` membuat pemutar sekali per video (`DisposableEffect(uri)`), dan `TextureView` hanya memasang/melepas surface (`attach`/`detach`). Play sebelum video siap diingat (`playWhenReady`), Play setelah video habis mulai lagi dari awal rentang potong, dan kegagalan pemutar tampil sebagai pesan di bar atas.

## Pilih area zoom manual (v0.9.1, diperluas di v0.9.2)
Untuk rekaman tanpa data ketukan (atau data yang kurang akurat), area zoom dipilih langsung di pratinjau:
1. Editor > Zoom > **+ Zoom** (atau pilih blok di timeline lalu **Pilih area**). Video dijeda di awal blok dan tampil tanpa zoom.
2. Persegi panjang putih = bagian **kanvas** yang akan memenuhi layar saat zoom penuh; di luarnya digelapkan. **Geser** untuk memindah, **cubit** untuk ubah skala, **ketuk** untuk menaruh pusat di titik itu.
3. **Selesai** (atau tekan Play) untuk melihat hasil zoom. Slider Skala/X/Y tetap ada untuk koreksi halus.

**v0.9.2: seleksi ke seluruh kanvas.** Pemilih area kini dipasang di atas seluruh kanvas (bukan di dalam kartu video), jadi jendela boleh keluar dari kartu ke area background. Ketentuan:
- Fokus (`fx`,`fy`) tetap dinormalisasi pada frame video, tetapi **boleh di luar 0..1** (di atas background). Jendela hanya dijepit supaya tidak keluar dari **kanvas** (`ZoomMath.focusFromCanvas`, `axisShift`).
- Jendela yang digambar = jendela yang dipakai kamera (`ZoomMath.window(region, geo)`), termasuk saat ada padding (sebelumnya jendela digambar terhadap kartu sehingga lebih kecil dari hasil zoom yang sebenarnya).
- Blok **otomatis** (dari ketukan) tetap memakai aturan lama: kartu menutupi kanvas, background tidak terlihat. Begitu blok diedit manual (`auto=false`), aturan kanvas yang berlaku.
- Slider X/Y diperlebar ke `-1..2`. Kamera 3D mode Orbit dan kursor sintetis menjepit fokus ke 0..1.
Komponen: `ZoomArea.kt` (overlay), `ZoomMath.window` / `ZoomMath.focusFromCanvas` (jendela yang digambar = jendela yang dipakai kamera).

## Fitur tahap 3 (zoom otomatis)
- **Timeline** di editor: ruler, baris video dengan handle potong, penanda sentuhan, dan baris blok zoom (geser badan = pindah, geser tepi = ubah panjang)
- **Auto-zoom dari ketukan**: ketukan yang berdekatan digabung jadi satu blok; zoom sudah penuh 0,5 detik sebelum ketukan pertama dan bertahan 1,5 detik setelah yang terakhir; fokus = tengah sebaran ketukan. Video dibuka dan ditutup dalam keadaan lebar
- Blok zoom bisa ditambah/dihapus manual, skala dan fokusnya diatur dengan slider
- Pratinjau dan ekspor memakai rumus yang sama (`ZoomMath.camera`), jadi hasil ekspor cocok dengan pratinjau
- **Zoom kartu** (v0.8.1): yang membesar adalah seluruh bingkai video (padding, sudut membulat, bayangan ikut), bukan hanya isinya di-crop di dalam bingkai yang diam, seperti di Openscreen. Saat zoom cukup besar kartu menutupi kanvas sehingga background tidak terlihat (`ZoomMath.cardZoom`)
- Data ketukan dicatat oleh layanan Aksesibilitas "LayKit (penanda sentuhan)" selama merekam dan disimpan di folder privat app (`touch/<nama-video>.csv`)

### Mengaktifkan pencatat sentuhan
1. Di layar utama tekan **Aktifkan pencatat sentuhan**, lalu nyalakan "LayKit" di Pengaturan > Aksesibilitas.
2. Jika tombolnya abu-abu (APK di-sideload, Android 13+): Info app > menu ⋮ > **Izinkan pengaturan terbatas**, lalu ulangi langkah 1.
3. Rekam seperti biasa. Di editor, tombol **Auto-zoom** aktif kalau rekaman punya data ketukan.

Layanan ini hanya membaca posisi (kotak) elemen yang diketuk, bukan isi teks layar, dan hanya mencatat saat rekaman berjalan.

## Kamera 3D dan kursor (v0.8)
- **Kamera 3D** per blok zoom (editor > Zoom > pilih blok): Mati / Kiri / Kanan / Orbit. Bingkai video dimiringkan dengan perspektif; Orbit memakai titik fokus zoom (X/Y). Pratinjau memakai `graphicsLayer`, ekspor memakai shader (`uTilt`). Efek ini terinspirasi fitur "3D camera" Openscreen (kodenya tidak disalin).
- **Kursor sintetis** (editor > Bingkai > Kursor). Saklar selalu bisa ditekan; kalau rekaman tidak punya data ketukan, kursor memakai titik fokus tiap blok zoom: panah + riak ketukan yang meluncur dari ketukan ke ketukan, dibuat dari data ketukan (`CursorMath` di `Cursor.kt`). Posisi = titik tengah elemen yang diketuk, jalur di antara ketukan adalah perkiraan, bukan gerakan jari asli. Ikut miring bersama bingkai di mode 3D.

## Editor baru, tahap 1 (v0.10.0)
Tampilan editor mengikuti referensi (gelap, datar, tanpa bayangan di UI):
- Editor selalu gelap (palet `EditorColors` di `Editor.kt`), terpisah dari pilihan tema aplikasi.
- Top bar: tombol kembali bulat, judul rekaman + rasio, tombol **Ekspor** oranye.
- Kartu player berbentuk pil di bawah pratinjau: waktu sekarang, tombol Play besar, durasi total.
- Toolbar ikon di paling bawah (Zoom, Background, Bingkai, Rasio); panel opsi tool ada tepat di atasnya.

## Editor baru, tahap 2 (v0.10.1)
Kartu player dilengkapi seperti referensi:
- Kiri: **layar penuh** (menyembunyikan timeline, panel, dan toolbar supaya pratinjau selebar mungkin; Back keluar dari mode ini) dan **mute**. Mute hanya memengaruhi pratinjau; hasil ekspor tetap membawa audio asli.
- Tengah: Play besar. Kanan: **undo** dan **redo**.
- Undo/redo mencatat semua perubahan editor (blok zoom, potongan, background, bingkai, rasio, kursor). Perubahan beruntun digabung per 350 ms (geser slider = satu langkah), maksimal 60 langkah.
- Notifikasi kecil di pojok kiri bawah pratinjau: Zoom ditambahkan / dihapus, Auto-zoom dibuat, Dibatalkan, Diulangi.
- Waktu "sekarang / total" dipindah ke atas timeline.

## Editor baru, tahap 3: timeline (v0.10.2)
`Timeline.kt` ditulis ulang mengikuti referensi:
- **Klip video berthumbnail** (16 potongan, diambil dengan `MediaMetadataRetriever`), sudut membulat. Bagian di luar potongan digelapkan; handle potong putih dengan garis grip di kedua ujung.
- **Playhead putih** dengan bulatan di atas, ruler tipis tanpa kotak latar.
- Baris Sentuh hanya muncul kalau rekaman punya data ketukan. Tanpa label kolom, jadi timeline lebih lebar. Tombol zoom timeline (− dan +) jadi bulat dan datar.

## Editor baru, tahap 4: panel tool (v0.10.3)
- Panel opsi tool kini **bottom sheet**: tertutup saat editor dibuka, sehingga pratinjau memakai hampir seluruh ruang tengah. Ketuk ikon di toolbar untuk membuka, ketuk lagi (atau tombol X, atau Back) untuk menutup. Tinggi mengikuti isi, tidak lagi dikunci 112 dp.
- Menambah blok zoom (tombol + di timeline atau "+ Zoom") otomatis membuka panel Zoom.
- Layar penuh (kartu player) menyembunyikan timeline, panel, dan toolbar.

## Editor: layout terkunci + panel overlay (v0.10.4)
- **Kanvas dan kartu player terkunci**: ukuran dan posisinya tidak lagi bergantung pada panel yang dibuka. Panel tool kini **overlay** yang melayang tepat di atas toolbar (tinggi maksimum = tinggi timeline, isi bisa digulir), jadi tidak ada yang terdorong atau mengecil.
- **Toolbar bawah ditipiskan** (~45 dp: ikon 20 dp + label 10 sp, sebelumnya ~70 dp).
- **Tombol + di kanan klip dihapus** dari timeline; menambah zoom lewat "+ Zoom" di panel Zoom.
- Pesan error pemutar/ekspor tampil sebagai chip melayang di atas pratinjau, bukan baris di top bar yang mendorong kanvas.

## Editor: layout mengikuti referensi (v0.14.0)
Tata letak editor dirapikan mengikuti editor referensi (datar, bersih, tanpa kartu):
- **Timeline gaya CapCut**: playhead putih **tetap di tengah**, isi timeline yang bergeser. Geser timeline = scrub (memutar jeda dulu); saat Play timeline berjalan sendiri. **Cubit dua jari** untuk memperbesar/memperkecil. Tombol **+ dan −** timeline **dihapus**.
- **Ruler tipis**: hanya label waktu kecil dan satu titik di tengah tiap selang, tanpa garis/kotak. **Waktu "sekarang / total" kecil** di pojok kiri atas timeline (yang sekarang terang, total redup).
- **Track rapi**: ruler, klip video (handle potong putih), blok zoom, lalu baris sentuhan tipis. Blok zoom punya label kecil ("2.0×", "Auto"); yang dipilih berbingkai putih dengan pegangan di kedua sisi.
- **Baris kontrol player datar** (tanpa kartu pil): layar penuh + mute | Play | keyframe, undo, redo.
- **Toolbar bawah tertutup total saat tool dibuka**: panel tool menggantikan toolbar (dan bagian bawah timeline). Ruler + baris video tetap terlihat (untuk Zoom: baris zoom juga), jadi playhead tetap bisa digeser. Tutup dengan centang di kanan atas panel (atau Back). Ukuran pratinjau tidak berubah.
- **Panel bertab** (kategori dipisah): Zoom = Blok / Atur / 3D / Kurva (tool Kurva digabung ke sini), Background = Gradient / Warna / Wallpaper / Foto / Blur, Bingkai = Bentuk / Bayangan / Kursor, Rasio.
- **Bentuk kontrol baru** (`PanelUi.kt`): slider tipis berbulatan putih (`FlatSlider`), slider berskala garis dengan label + angka (`TickSlider`), lingkaran pilihan parameter (`ParamCircle`), kartu aksi dan kartu rasio.
- Timeline tidak ikut berjalan ke playhead selama jari menyeret handle potong / blok zoom / keyframe, supaya handle tidak meluncur sendiri.

## Hapus rekaman + menu HUD (v0.16.0)
- **Tombol hapus** (ikon tempat sampah merah) di tiap baris daftar rekaman, di samping Edit dan Bagikan. Ada dialog konfirmasi; yang dihapus adalah file video di Movies/LayKit beserta data ketukannya (`touch/<nama-video>.csv`). Kalau file bukan milik app ini lagi (mis. setelah pasang ulang), Android menampilkan dialog izin hapus sendiri (`MediaStore.createDeleteRequest` di Android 11+, `RecoverableSecurityException` di Android 10). Kode: `Library.delete`, `TouchLog.delete`.
- **Menu titik tiga di HUD** (di antara mic dan Home): membuka panel di atas bar berisi pilihan **Orientasi** (Auto / Potret / Lanskap) dan **FPS** (30 / 60). Pilihan langsung disimpan lewat `RecPrefs`, jadi dipakai rekaman berikutnya dan ikut tampil di Pengaturan layar utama. Panel menutup sendiri saat Rekam ditekan.

## Glow / bloom (v0.17.0, cara blur dirombak di v0.17.2)
Efek baru di Editor > **Efek** > tab **Glow** (slider **Jumlah** dan **Ukuran**; Jumlah 0 = mati). Bagian video yang terang menyebarkan cahayanya lembut ke sekelilingnya, seperti bloom. Konsepnya (blur Gaussian lalu digabung mode Screen) dari efek Glow di jub0t/concat; kodenya tidak disalin, rumusnya ditulis sendiri.
- **Rumus** (`Looks`): `g = blur(clamp((rgb - T) / (1 - T)))` dengan ambang `T = 0.5`, lalu `rgb' = 1 - (1 - rgb) * (1 - jumlah * g)`. Urutan efek: filter warna -> glow -> vignette. Glow hanya di dalam bingkai video (tidak tumpah ke background) dan ikut zoom, kamera 3D, dan sudut membulat.
- **Ukuran**: sigma blur = `0.6%` sampai `4%` sisi terpendek kartu video (`Looks.glowSigmaFrac`).
- **Cara blur (v0.17.2)**: blur dikerjakan pada gambar **kecil** supaya mulus dan merata, bukan sampling jarang pada video penuh (itu yang bikin v0.17.0/0.17.1 kasar dan berbintik). Ide dasarnya sama dengan [video-ambient-glow](https://github.com/mike-at-redspace/video-ambient-glow): kecilkan frame dulu, blur di resolusi kecil, baru diperbesar. Ukuran tekstur dipilih supaya sigma blur ~3 piksel kecil (`Exporter.prepareGlow`).
- **Ekspor** (`Exporter.kt`): tiga langkah di GPU per frame, hanya saat Jumlah > 0. (1) video -> tekstur kecil dengan prefilter 6x6 tap per piksel (filter warna + ambang per tap), (2) blur Gaussian horizontal, (3) blur vertikal, keduanya di FBO kecil. Shader utama membaca hasilnya dengan interpolasi bilinear. Kalau FBO gagal dibuat, ekspor jalan tanpa glow (tidak gagal).
- **Pratinjau** (`Editor.kt`, `GlowOverlay`): langkah yang sama di CPU (`Looks.glowPreview`) di `Dispatchers.Default`: gambar 3x lebih besar dari tekstur glow diambil dari `TextureView`, dirata-ratakan, diberi ambang, diblur Gaussian, diperbesar bilinear, dan digambar dengan `BlendMode.Screen` pada alpha = Jumlah. Jalan di semua versi Android.
- Jumlah dan Ukuran ikut undo/redo. Bagian `FrameStyle`: `glow`, `glowSize`.

## Panel editor desain baru (v0.18.0)
Panel tool dan nav bawah disamakan dengan desain `LayKit_PanelEditor.html` (hanya tata letak dan tampilan; isi dan logika tiap tab tidak berubah):
- **Nav bawah 72 dp** (`ToolNav`, `PanelUi.kt`): 5 tombol, ikon dalam pil 52x30 dengan indikator aksen yang tumbuh saat aktif, garis tipis bergradasi di atasnya. Area bawah jadi 224 + 72 + 1 = 297 dp; tinggi panel = 297 - 74 = 223 dp (Zoom: 297 - 114 = 183 dp), rumusnya tetap (`TL_ROWS_TOP` / `TL_ROWS_ZOOM`).
- **Panel naik dari bawah** (0,3 dtk) dan tingginya beranimasi saat pindah tool (0,25 dtk).
- **Header 46 dp**: tab 14 sp dengan garis bawah selebar teks, ikon **Reset** di header (menggantikan baris "Reset": tab 3D Customize, Kurva, Bentuk, Vignette, Glow), centang berwarna aksen.
- **Zoom**: Blok = 4 kartu sama lebar (tinggi 64); Atur dan 3D Customize = baris pilihan "nama + nilai" dengan SATU slider tipis (menggantikan lingkaran dan 4 slider berskala); 3D = segmen; Kurva = chip preset + kotak kurva 76 dp (kurva bawaan bertitik), pilihan channel di sebelah kotak.
- **Background**: Gradient dan Warna = bulatan 6 kolom; Wallpaper = 3 kolom (gradien radial seperti desain); Foto = 2 baris yang bisa digeser dengan tombol Galeri setinggi dua baris; Blur = label dengan nilai tebal + slider tipis.
- **Bingkai**: kelompok berlatar kartu dengan slider berskala 20 garis; saklar 48x28 buatan sendiri (hijau teal saat hidup).
- **Rasio**: 5 kartu persegi sama lebar. **Efek**: tile pratinjau warna untuk Filter (intensitas 60%), Vignette dan Glow di dalam kelompok kartu.
- Komponen baru di `PanelUi.kt`: `PanelTabs`, `ParamRow`, `PanelSeg`, `PanelPill`, `PanelGroup`, `GridRows`, `ToolNav`; `CurvePanel.kt` ditulis ulang; `ParamCircle` dan `ResetLink` dihapus. `Seg` dan `Pill` di `Ui.kt` tetap dipakai layar utama.

## Caption otomatis (v0.19.0)
Editor > **Caption** (tool paling kanan). Suara video dikenali di HP dengan [whisper.cpp](https://github.com/ggml-org/whisper.cpp) (MIT, dipasang sebagai salinan di `app/src/main/cpp/whisper.cpp`, tag v1.9.5, hanya CPU), lalu hasilnya jadi baris caption yang bisa diubah dan dibakar ke video saat ekspor.
- **Tab Buat**: pilih model (**Tiny** 75 MB, **Base** 142 MB, **Small** 466 MB; multibahasa) dan bahasa (Otomatis / Indonesia / English), lalu **Buat caption**. Model diunduh sekali dari Hugging Face ke folder privat app (`filesDir/whisper`, butuh internet, izin INTERNET); setelah itu semuanya jalan offline. Ada tombol Batal; keluar dari editor juga menghentikan prosesnya.
- **Tab Teks**: daftar baris caption. Ketuk baris = lompat ke waktunya + ubah teks / hapus. **Simpan SRT** menulis `Download/LayKit/<nama>.srt` untuk rentang potong yang sedang dipakai (waktu digeser mulai dari 0, sama dengan video hasil ekspor).
- **Tab Gaya**: Tampil / Sembunyi dan ukuran huruf. Gaya tetap datar: kotak hitam solid agak transparan + teks putih tebal, di dasar kanvas, tanpa bayangan.
- **Pratinjau dan ekspor memakai bitmap yang sama** (`Captions.renderBand`): pratinjau menggambarnya di atas kanvas, ekspor mengunggahnya sebagai tekstur GL dan menimpanya setelah semua efek (`Gl.drawCaption`). Caption tidak ikut zoom / kamera 3D.
- Caption disimpan di project (`captions`, `capOn`, `capSize` di JSON) dan ikut undo/redo. Waktu caption = waktu video sumber, seperti blok zoom, jadi mengubah potongan tidak menggeser caption.
- Alur kode: `WhisperEngine.kt` (unduh model, decode suara `MediaCodec` -> PCM mono 16 kHz, `CaptionEngine.generate`), `app/src/main/cpp/whisper_jni.cpp` (jembatan JNI), `Captions.kt` (data, render bitmap, SRT), panel di `Editor.kt`.
- Whisper memotong segmen sekitar 42 karakter per baris (per kata), dengan penanda waktu per token.

Catatan build: lib native hanya untuk **arm64-v8a** (APK tidak bisa dipasang di HP 32-bit / emulator x86). Build pertama mengunduh NDK + CMake 3.22.1 lewat Gradle dan mengompilasi whisper.cpp (beberapa menit). CMake memaksa `-O3` di semua varian karena whisper tanpa optimasi sangat lambat. Tanpa OpenMP; jumlah thread 2 sampai 4.

## Struktur
- `Cursor.kt`          kursor sintetis dari ketukan: `CursorMath` + gambar panah/riak untuk pratinjau
- `ZoomModel.kt`       blok zoom, kamera zoom (`ZoomMath.camera`: pegas, log-scale, pan antar blok), operasi edit (`ZoomOps`), pembuat zoom otomatis (`AutoZoom`)
- `ZoomArea.kt`        pemilih area zoom di atas seluruh kanvas pratinjau (geser/cubit/ketuk)
- `Timeline.kt`        timeline editor (Compose): playhead tengah, cubit zoom, track
- `PanelUi.kt`         komponen panel editor: tab, slider, kartu aksi/rasio
- `TouchLog.kt`        pencatat ketukan + penyimpanan sidecar
- `TouchService.kt`    layanan Aksesibilitas yang mengirim posisi ketukan ke `TouchLog`
- `Look.kt`            filter warna, vignette, dan rumus glow (`Looks`)
- `Exporter.kt`        trim + frame/background: MediaCodec decode -> shader GLES -> encode H.264 -> MediaMuxer
- `Editor.kt`          layar editor (Compose) + pratinjau MediaPlayer/TextureView
- `Captions.kt`        caption: model data, render bitmap, SRT, cache pratinjau
- `WhisperEngine.kt`   caption: unduh model, decode suara, panggil whisper (JNI `WhisperNative`)
- `Library.kt`         daftar rekaman dari MediaStore
- `Recorder.kt`        pipeline: VirtualDisplay -> H.264, audio -> AAC, MediaMuxer -> MediaStore
- `HudService.kt`      HUD melayang (overlay View biasa)
- `SolarIcons.kt`      data path ikon Solar (CC BY 4.0, lihat kredit)
- `CaptureActivity.kt` Activity transparan: izin rekam layar / mikrofon untuk HUD
- `RecPrefs.kt`        pengaturan rekaman + posisi HUD (SharedPreferences)
- `RecorderService.kt` foreground service, state, notifikasi, hitung mundur
- `MainActivity.kt`    UI Compose + alur izin

## Batasan yang diketahui
- Ukuran video terkunci saat mulai (rotasi saat merekam tidak mengubah ukuran). Untuk app/game landscape pilih Orientasi video = Landscape.
- App yang memblokir capture audio (mis. beberapa app streaming/DRM) tidak akan terekam suaranya.
- Posisi ketukan = titik tengah elemen yang diketuk (Android tidak memberi koordinat sentuhan mentah ke app biasa). Elemen yang tidak dikenali aksesibilitas (sebagian game / kanvas custom) tidak tercatat.
- Koordinat ketukan dinormalisasi terhadap layar saat itu; jika Orientasi video dipaksa berbeda dari orientasi layar, fokus auto-zoom bisa meleset.
- Rekaman lama (sebelum tahap 3) dan hasil ekspor tidak punya data ketukan; zoom manual tetap bisa dipakai.
- Level mic di HUD bisa datar saat app lain di depan, tergantung aturan mikrofon Android; rekaman tidak terpengaruh.
- Caption: Whisper bisa salah dengar (nama, istilah, musik latar); koreksi lewat tab Teks. Model Small butuh RAM besar dan lambat di HP lama. Caption dibuat dari seluruh suara video, bukan hanya rentang potong. Belum ada baris caption di timeline.
- Belum ada: webcam. Kursor di hasil video adalah kursor sintetis, bukan jari asli.

## Kredit
Wallpaper foto: dari Openscreen (MIT), lihat bagian Wallpaper foto.
Caption: [whisper.cpp](https://github.com/ggml-org/whisper.cpp) / ggml oleh Georgi Gerganov dan kontributor (MIT, salinan lisensi di `app/src/main/cpp/whisper.cpp/LICENSE`); model Whisper oleh OpenAI (MIT), dalam format ggml dari `ggerganov/whisper.cpp` di Hugging Face.
Ikon HUD: [Solar Icon Set](https://github.com/480-Design/Solar-Icon-Set) oleh 480 Design, lisensi [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). Path SVG dikonversi ke Android Path; ikon mikrofon mati ditambah coretan diagonal. Susunan HUD terinspirasi Recordly (kode Recordly tidak disalin).
